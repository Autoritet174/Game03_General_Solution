--
-- PostgreSQL database dump
--

\restrict 0dg9VkNayYH2Ky00GMzhU4oGd7OAeU4ueVPSt3PuccD4vmewAdmZJRfSlaQMzSn

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2026-01-02 21:48:44

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_ban_reason_id__user_ban_reasons__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_tokens DROP CONSTRAINT IF EXISTS identity_user_tokens__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__role_id__identity_roles__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_logins DROP CONSTRAINT IF EXISTS identity_user_logins__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_claims DROP CONSTRAINT IF EXISTS identity_user_claims__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_role_claims DROP CONSTRAINT IF EXISTS identity_role_claims__role_id__identity_roles__fkey;
ALTER TABLE IF EXISTS ONLY logs.auth_reg_logs DROP CONSTRAINT IF EXISTS auth_reg_logs__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY logs.auth_reg_logs DROP CONSTRAINT IF EXISTS auth_reg_logs__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__creature_type_id__creature_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__equipment_type_id__equipment_type;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__damage_type_id__damage_types__fke;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__smithing_materials_id__smithing_mater;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__damage_type_id__damage_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__smithing_material_id__smithing_materials__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__equipment_type_id__equipment_types__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment9id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment8id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment7id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment6id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment5id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment4id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment3id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment2id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment1id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment12id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment11id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment10id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__base_equipment_id__base_equipments__fkey;
DROP INDEX IF EXISTS users.user_bans__user_id__idx;
DROP INDEX IF EXISTS users.user_bans__user_ban_reason_id__idx;
DROP INDEX IF EXISTS users.identity_users__normalized_user_name__idx;
DROP INDEX IF EXISTS users.identity_users__normalized_email__idx;
DROP INDEX IF EXISTS users.identity_user_roles__role_id__idx;
DROP INDEX IF EXISTS users.identity_user_logins__user_id__idx;
DROP INDEX IF EXISTS users.identity_user_claims__user_id__idx;
DROP INDEX IF EXISTS users.identity_roles__normalized_name__idx;
DROP INDEX IF EXISTS users.identity_role_claims__role_id__idx;
DROP INDEX IF EXISTS server.user_ban_reasons__name__idx;
DROP INDEX IF EXISTS logs.auth_reg_logs__user_id__idx;
DROP INDEX IF EXISTS logs.auth_reg_logs__user_device_id__idx;
DROP INDEX IF EXISTS game_data.x_hero_creature_type__creature_type_id__idx;
DROP INDEX IF EXISTS game_data.x_equipment_type_damage_type__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.smithing_materials__name__idx;
DROP INDEX IF EXISTS game_data.slot_types__name__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__smithing_materials_id__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__name__idx;
DROP INDEX IF EXISTS game_data.damage_types__name__idx;
DROP INDEX IF EXISTS game_data.creature_types__name__idx;
DROP INDEX IF EXISTS game_data.base_heroes__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__smithing_material_id__idx;
DROP INDEX IF EXISTS game_data.base_equipments__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__equipment_type_id__idx;
DROP INDEX IF EXISTS collection.heroes__user_id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment9id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment8id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment7id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment6id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment5id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment4id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment3id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment2id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment1id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment12id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment11id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment10id__idx;
DROP INDEX IF EXISTS collection.heroes__base_hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__user_id__idx;
DROP INDEX IF EXISTS collection.equipments__base_equipment_id__idx;
ALTER TABLE IF EXISTS ONLY users.user_devices DROP CONSTRAINT IF EXISTS user_devices__pkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_users DROP CONSTRAINT IF EXISTS identity_users__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_tokens DROP CONSTRAINT IF EXISTS identity_user_tokens__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_logins DROP CONSTRAINT IF EXISTS identity_user_logins__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_claims DROP CONSTRAINT IF EXISTS identity_user_claims__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_roles DROP CONSTRAINT IF EXISTS identity_roles__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_role_claims DROP CONSTRAINT IF EXISTS identity_role_claims__pkey;
ALTER TABLE IF EXISTS ONLY server.user_ban_reasons DROP CONSTRAINT IF EXISTS user_ban_reasons__pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY logs.auth_reg_logs DROP CONSTRAINT IF EXISTS auth_reg_logs__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.smithing_materials DROP CONSTRAINT IF EXISTS smithing_materials__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slot_types DROP CONSTRAINT IF EXISTS slot_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__pkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.damage_types DROP CONSTRAINT IF EXISTS damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.creature_types DROP CONSTRAINT IF EXISTS creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_heroes DROP CONSTRAINT IF EXISTS base_heroes__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__pkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__pkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__pkey;
DROP TABLE IF EXISTS users.user_devices;
DROP TABLE IF EXISTS users.user_bans;
DROP TABLE IF EXISTS users.identity_users;
DROP TABLE IF EXISTS users.identity_user_tokens;
DROP TABLE IF EXISTS users.identity_user_roles;
DROP TABLE IF EXISTS users.identity_user_logins;
DROP TABLE IF EXISTS users.identity_roles;
DROP TABLE IF EXISTS users.identity_user_claims;
DROP TABLE IF EXISTS users.identity_role_claims;
DROP TABLE IF EXISTS server.user_ban_reasons;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS logs.auth_reg_logs;
DROP TABLE IF EXISTS game_data.x_hero_creature_type;
DROP TABLE IF EXISTS game_data.x_equipment_type_damage_type;
DROP TABLE IF EXISTS game_data.smithing_materials;
DROP TABLE IF EXISTS game_data.slot_types;
DROP TABLE IF EXISTS game_data.material_damage_percents;
DROP TABLE IF EXISTS game_data.equipment_types;
DROP TABLE IF EXISTS game_data.damage_types;
DROP TABLE IF EXISTS game_data.creature_types;
DROP TABLE IF EXISTS game_data.base_heroes;
DROP TABLE IF EXISTS game_data.base_equipments;
DROP TABLE IF EXISTS collection.heroes;
DROP TABLE IF EXISTS collection.equipments;
DROP SCHEMA IF EXISTS users;
DROP SCHEMA IF EXISTS server;
DROP SCHEMA IF EXISTS logs;
DROP SCHEMA IF EXISTS game_data;
DROP SCHEMA IF EXISTS collection;
--
-- TOC entry 6 (class 2615 OID 26435)
-- Name: collection; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA collection;


--
-- TOC entry 7 (class 2615 OID 26436)
-- Name: game_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA game_data;


--
-- TOC entry 8 (class 2615 OID 26437)
-- Name: logs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA logs;


--
-- TOC entry 9 (class 2615 OID 26438)
-- Name: server; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA server;


--
-- TOC entry 10 (class 2615 OID 26439)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 26440)
-- Name: equipments; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.equipments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    base_equipment_id integer NOT NULL,
    group_name character varying(256)
);


--
-- TOC entry 225 (class 1259 OID 26453)
-- Name: heroes; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.heroes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_hero_id integer NOT NULL,
    health1000 bigint CONSTRAINT heroes_health_not_null NOT NULL,
    strength integer NOT NULL,
    agility integer NOT NULL,
    intelligence integer NOT NULL,
    crit_chance integer NOT NULL,
    crit_power integer NOT NULL,
    haste integer NOT NULL,
    versality integer NOT NULL,
    endurance_physical integer NOT NULL,
    endurance_magical integer NOT NULL,
    resist_damage_physical integer NOT NULL,
    resist_damage_magical integer NOT NULL,
    equipment1id uuid,
    equipment2id uuid,
    equipment3id uuid,
    equipment4id uuid,
    equipment5id uuid,
    equipment6id uuid,
    equipment7id uuid,
    equipment8id uuid,
    equipment9id uuid,
    equipment10id uuid,
    equipment11id uuid,
    equipment12id uuid,
    experience_now bigint DEFAULT 0 NOT NULL,
    group_name character varying(256),
    level integer DEFAULT 1 NOT NULL,
    rarity integer DEFAULT 1 NOT NULL,
    damage jsonb
);


--
-- TOC entry 226 (class 1259 OID 26483)
-- Name: base_equipments; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_equipments (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    equipment_type_id integer NOT NULL,
    health jsonb,
    damage jsonb,
    smithing_material_id integer
);


--
-- TOC entry 227 (class 1259 OID 26494)
-- Name: base_equipments_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_equipments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_equipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 26495)
-- Name: base_heroes; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_heroes (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL,
    health jsonb,
    damage jsonb
);


--
-- TOC entry 229 (class 1259 OID 26507)
-- Name: base_heroes_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_heroes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_heroes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 26508)
-- Name: creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.creature_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 26513)
-- Name: creature_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.creature_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.creature_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 26514)
-- Name: damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.damage_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256),
    dev_hint_ru text,
    category integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 26523)
-- Name: damage_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.damage_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.damage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 26524)
-- Name: equipment_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.equipment_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256) NOT NULL,
    mass_physical integer DEFAULT 0 NOT NULL,
    mass_magical integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    spend_action_points integer DEFAULT 0 NOT NULL,
    block_other_hand boolean,
    damage jsonb
);


--
-- TOC entry 235 (class 1259 OID 26543)
-- Name: equipment_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.equipment_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.equipment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 26544)
-- Name: material_damage_percents; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.material_damage_percents (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 26551)
-- Name: material_damage_percents_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.material_damage_percents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.material_damage_percents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 26552)
-- Name: slot_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slot_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256)
);


--
-- TOC entry 239 (class 1259 OID 26559)
-- Name: slot_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slot_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slot_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 26560)
-- Name: smithing_materials; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.smithing_materials (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256)
);


--
-- TOC entry 241 (class 1259 OID 26567)
-- Name: smithing_materials_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.smithing_materials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.smithing_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 26568)
-- Name: x_equipment_type_damage_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_equipment_type_damage_type (
    equipment_type_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    damage_coef integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 26575)
-- Name: x_hero_creature_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_hero_creature_type (
    base_hero_id integer CONSTRAINT x_hero_creature_type_hero_id_not_null NOT NULL,
    creature_type_id integer NOT NULL
);


--
-- TOC entry 258 (class 1259 OID 27014)
-- Name: auth_reg_logs; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.auth_reg_logs (
    id uuid NOT NULL,
    email character varying(256),
    user_id uuid,
    success boolean NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_device_id uuid,
    ip inet,
    action_is_authentication boolean DEFAULT true NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 26591)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 26596)
-- Name: user_ban_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_ban_reasons (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 26603)
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_ban_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_ban_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 252 (class 1259 OID 26875)
-- Name: identity_role_claims; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_role_claims (
    id integer CONSTRAINT asp_net_role_claims_id_not_null NOT NULL,
    role_id uuid CONSTRAINT asp_net_role_claims_role_id_not_null NOT NULL,
    claim_type text,
    claim_value text
);


--
-- TOC entry 251 (class 1259 OID 26874)
-- Name: asp_net_role_claims_id_seq; Type: SEQUENCE; Schema: users; Owner: -
--

ALTER TABLE users.identity_role_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME users.asp_net_role_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 254 (class 1259 OID 26890)
-- Name: identity_user_claims; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_claims (
    id integer CONSTRAINT asp_net_user_claims_id_not_null NOT NULL,
    user_id uuid CONSTRAINT asp_net_user_claims_user_id_not_null NOT NULL,
    claim_type text,
    claim_value text
);


--
-- TOC entry 253 (class 1259 OID 26889)
-- Name: asp_net_user_claims_id_seq; Type: SEQUENCE; Schema: users; Owner: -
--

ALTER TABLE users.identity_user_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME users.asp_net_user_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 249 (class 1259 OID 26852)
-- Name: identity_roles; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_roles (
    id uuid CONSTRAINT asp_net_roles_id_not_null NOT NULL,
    name character varying(256),
    normalized_name character varying(256),
    concurrency_stamp text
);


--
-- TOC entry 255 (class 1259 OID 26904)
-- Name: identity_user_logins; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_logins (
    login_provider text CONSTRAINT asp_net_user_logins_login_provider_not_null NOT NULL,
    provider_key text CONSTRAINT asp_net_user_logins_provider_key_not_null NOT NULL,
    provider_display_name text,
    user_id uuid CONSTRAINT asp_net_user_logins_user_id_not_null NOT NULL
);


--
-- TOC entry 256 (class 1259 OID 26919)
-- Name: identity_user_roles; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_roles (
    user_id uuid CONSTRAINT asp_net_user_roles_user_id_not_null NOT NULL,
    role_id uuid CONSTRAINT asp_net_user_roles_role_id_not_null NOT NULL
);


--
-- TOC entry 257 (class 1259 OID 26936)
-- Name: identity_user_tokens; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_tokens (
    user_id uuid CONSTRAINT asp_net_user_tokens_user_id_not_null NOT NULL,
    login_provider text CONSTRAINT asp_net_user_tokens_login_provider_not_null NOT NULL,
    name text CONSTRAINT asp_net_user_tokens_name_not_null NOT NULL,
    value text
);


--
-- TOC entry 250 (class 1259 OID 26860)
-- Name: identity_users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_users (
    id uuid CONSTRAINT asp_net_users_id_not_null NOT NULL,
    user_name character varying(256),
    normalized_user_name character varying(256),
    email character varying(256),
    normalized_email character varying(256),
    email_confirmed boolean CONSTRAINT asp_net_users_email_confirmed_not_null NOT NULL,
    password_hash text,
    security_stamp text,
    concurrency_stamp text,
    phone_number text,
    phone_number_confirmed boolean CONSTRAINT asp_net_users_phone_number_confirmed_not_null NOT NULL,
    two_factor_enabled boolean CONSTRAINT asp_net_users_two_factor_enabled_not_null NOT NULL,
    lockout_end timestamp with time zone,
    lockout_enabled boolean CONSTRAINT asp_net_users_lockout_enabled_not_null NOT NULL,
    access_failed_count integer CONSTRAINT asp_net_users_access_failed_count_not_null NOT NULL,
    created_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone CONSTRAINT asp_net_users_created_at_not_null NOT NULL,
    time_zone character varying(256),
    updated_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone CONSTRAINT asp_net_users_updated_at_not_null NOT NULL,
    version bigint DEFAULT 1 CONSTRAINT asp_net_users_version_not_null NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 26604)
-- Name: user_bans; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_bans (
    id uuid NOT NULL,
    user_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    user_ban_reason_id integer NOT NULL
);


--
-- TOC entry 248 (class 1259 OID 26614)
-- Name: user_devices; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_devices (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    system_environment_user_name character varying(256),
    time_zone_minutes integer,
    device_unique_identifier character varying(256),
    device_model character varying(256),
    device_type character varying(256),
    operating_system character varying(256),
    processor_type character varying(256),
    processor_count integer,
    system_memory_size integer,
    graphics_device_name character varying(256),
    graphics_memory_size integer,
    system_info_supports_instancing boolean,
    system_info_npot_support character varying(256)
);


--
-- TOC entry 5214 (class 0 OID 26440)
-- Dependencies: 224
-- Data for Name: equipments; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.equipments (id, user_id, version, created_at, updated_at, base_equipment_id, group_name) FROM stdin;
bc658f5b-271e-413d-8772-01e5b007fe3d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 15:52:42.946044+08	2026-01-02 15:52:42.946044+08	1	\N
d93c1740-5cbb-4999-9111-d6d3e911438f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 16:31:49.146447+08	2026-01-02 16:31:49.146447+08	1	\N
004eac23-45a7-4c23-bc9a-f5cface0724e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
03c21165-35ea-40eb-93d4-c8e0a21f12c2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
0728f0a9-4467-4b19-8327-ad7a38b999d6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
0818ce4d-a550-4af1-9720-47e6e34d93f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
0941dcf5-f725-43ee-93c5-99025a0749f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
09d32c97-4701-4285-aed0-5bc2e8900dd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
0b8705ad-b51f-4150-b348-61fe3d5022e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
0baea179-2ced-4c5f-98bf-db2e215756fa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
0d60e004-045f-4814-9815-d865dcc4d78c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
0d68e344-00f9-49a9-a58f-4bd6f4c709cf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
0fc1b8ea-793b-4e45-a9a7-11f96111ad33	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
14e5a55d-bbb1-4725-9e64-f6534c6a243f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
15532ac5-f5a5-4859-bd84-3386a4423c60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
16228250-1463-4aa3-be37-8d392c72c9c2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
1772726b-5e3b-44bb-8bd4-e38bb4d6911d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
177aff17-7de1-4e0c-a925-6cfda50b6d2f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
1911011e-f51a-4740-9825-dd30b75b9f60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
1beb3870-caa1-4ca5-8ced-d3087f00cf06	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
1c292258-50ca-495d-ade8-96f2c806ea4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
1e56081d-2f18-4021-b38e-56c04e5125a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
21206d91-cccf-498c-b98d-a2164f3316fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
24250502-0844-49bb-917d-d60a7de3b879	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
281160a4-1d0a-49a4-9da8-b453658ba7c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
2a6666b9-c75f-4dff-a49f-f67390cc7929	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
2b4980ab-cbea-4819-ab36-6882f53269a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
2e297eb9-73b5-4f3c-9165-bd031d2b1164	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
2ee52ff8-2437-4b40-8a93-45bd812c2510	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
2f0d86f4-1d9f-4afb-a5cd-9a86c8c7443d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
3172af51-2883-4939-bb6e-7728690886e2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
404201c5-0458-4bc4-aca1-5f4b4de403c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
4374af37-05eb-4649-864c-7db43de733f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
44905d22-b651-4015-a946-77d1fb3da0a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
4858af6f-c03d-4b5d-8e51-a118ada986fe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
486b8fb7-86f9-4355-8c1e-7402453b8233	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
4abadd00-2a20-4865-80a9-466dd1593f9e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
4ad6fea0-cd58-4596-8f0a-57ade89f6a4d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
4cd987bf-ff00-477a-94b6-ce5ff050e320	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
4cfd6971-54bb-4214-81b7-238ba51c6b03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
54551190-5dc3-4992-b3f3-4b52a9c5af0d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
5e572c90-cd06-4716-b948-e46743a7f084	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
62c00c46-355c-4c81-bf5d-78c30f63e317	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
662b725f-5d76-461a-b43f-fe245e0e6938	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
6bdda9c4-819a-4eff-a08e-43d70272a0fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
6f2b1238-3a32-4ac4-8160-d7fabdc8e055	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
70242065-3ee0-4068-b703-4675e62cfd8c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
7582f03b-0c80-4d43-80c4-6252293d14e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
76092f4e-9590-4449-a084-4d089e6c2537	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
7b3a1271-d793-49f1-a25e-632e0904ecbc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
80c1d388-8e54-44a0-9689-15a4ea28d124	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
80e2b06e-361c-4981-8b54-3d252a3909c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
88fe39a3-1753-48db-8648-062434eb4943	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
89a62f9c-02e3-43c3-b43c-e85ed404f905	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
8becde0f-700c-4085-be4c-62b0d597c0e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
90d42bde-ee4e-4f2d-8e12-f2c111f15b26	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
921258a5-6bd4-482b-aed7-ad1d5423f108	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
9335f1fa-78b9-4271-a26b-71bfa80e569a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
93470745-5108-441f-b23e-5601e2007e3a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
98b0da3a-2bcc-4329-a36a-26cb6bc13633	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
990971b2-89ed-4b92-a751-810da143ad5a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
9f72c879-f5eb-4636-b78a-98682b0a071e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
a0fd5a82-5969-4f3d-83ca-7678b13c74ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
a2a63ce0-bcba-4570-989d-a81ff4f56531	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
a2bb8afa-4b0b-488f-9e62-a20c634b729d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
a834c17f-3188-48b4-8025-86e3cc0bdf0a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
a8cb9a26-6249-439e-aed7-f55e0e90399f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
a91ee17e-74d2-498b-a6c3-326a3ff43a10	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
ab351ca9-1f4c-4f49-80ff-d33a3b6860d2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
abf7d895-5486-4398-97fc-447e5c1d5c94	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
b0b60e7d-99de-4d36-9f75-34011a398acf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
b3109a89-a033-4aa7-9e3f-3c6ec8fa509e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
b44b6bc8-ff3f-462a-919c-d47719dd8962	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
b4a46daa-eb71-4e9f-9547-e3c2cb405ddb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
b8e8291e-bd33-45d0-94f4-0ca449b2a8a9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
b938d21a-8951-46ea-9bf9-dafceb3ccf47	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
be6022b8-d505-4986-8900-a0bad47cbc25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
bfdbe6aa-1915-4ecf-860a-6c6c2c939334	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
c1970acb-ae5e-4e04-8b79-a89f5af3478a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
c1fc4653-b96a-4100-a0cd-2d0d42eace5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
c2e4c3ad-659b-4ce0-8fbd-002ded27d18e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
c79c3d53-06e3-4135-9592-f255c3979322	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
c811abc5-dcac-426d-8774-0eff73e52af6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
c811f6b7-04b3-427d-b594-1d2cf2bc9d79	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
c852cf2c-79bd-4549-a7de-dc5b47790aea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
c8e8b107-dbbd-41a2-923e-04c5b83e737a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
cdacef26-5c67-49c0-99e3-8969deeb1012	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
d0e066e0-cacb-4927-a207-975e23e6be98	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
d4df6bae-9bfa-4f0d-aa4a-e17aa3748f9b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
d4fb341b-d7de-44f7-9e1a-e50d39816ef1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
d5d3cafc-eb45-43cf-8757-5eb4dcdaa86c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
d903e974-c37e-417d-9e68-36a7fbb10279	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
da5a7832-bd3f-463e-87e2-4b766b7fe11f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
dffa4c5c-fd2a-4bb9-a27c-45f7fa553852	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
e2eabb23-3dcf-4b57-89d4-f0ce03337c22	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
e5d8cc10-0f19-4677-9768-7c0b8fa6c815	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
e60484c7-e027-4f17-becb-3482576fc50c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
eb3fb02e-4351-47e4-bc2e-57c252962833	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
ef649618-6fc3-4b29-94c8-1f2ccd11c5d8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
f848e76d-0abd-486a-b098-43ae740ef2c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
f8f02643-b4c6-4fc1-81a4-da2ec5c3b6cb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
f9074397-5296-4dc7-a21a-9170c04a76de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
007fb8ff-635b-44fd-91c7-5f90d9929fbd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
06215d30-a645-434c-b01a-d79e9119b26a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
06f621e6-5898-4c10-a8ef-ee81be6938e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
083f7830-321a-435f-8b63-b821a789049a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
0a94e05f-8b3e-4997-b3a1-edf586a71c8e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
0ea2b2b1-cff4-466a-add8-b3327463cde6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
117f3921-7c47-40b0-8f0e-c9eb7d857082	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
11f98e9d-2abd-4c50-b29e-a5e1798dd14f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
16a0117c-f84c-4154-abea-889dba76dee6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
1a43fcf1-b6f7-4fd2-a0ad-8ace9631c62f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
1c8e67b9-20b8-4bbc-8a48-5b764cc90527	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
290e124f-0b1d-4675-8710-6cc68c61897d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
2a5d7295-91b3-4eb3-a7e1-76dafea76a76	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
2f3f4082-cd7a-4453-9eca-291012762956	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
31ce9a1a-200c-4112-b138-d378f8f3af91	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
3305df7d-a699-4d6a-beb3-b14a4aa3deac	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
3a44dda9-77ba-4491-91a1-cc9dcd1429bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
3cc5ee0b-958e-436c-8ed6-8f678c22d401	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
3fc37e1b-9b3d-4ff1-b225-974a0174aeb2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
3fd3050b-5124-43fc-b3a1-21d7a2cef715	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
40723513-6b5d-4cb8-9309-3145630b690c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
43980a85-0963-40c0-99fb-76ea962556ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
49533fe0-41ec-4068-a55d-9cd7c58591b5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
4c722bc1-482e-4251-a99d-efe04ddfb59f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
4d05a739-acd1-411e-b209-155907bb31a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
4d976284-a6dc-48cd-83e4-d7f2f894344e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
4e7f7b5a-f072-4296-920a-7611ba5f8b49	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
4f8c1255-be27-4d37-b63d-0b44cdd035ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
51eaae7d-216a-4cd1-ae5c-2032338608ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
5382ca7f-7558-441d-9d8d-e80f7a21d501	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
5419e4ed-45d9-4c11-aed7-11e56d31f7e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
5523751a-5dda-4e28-9cad-762f598a1cb7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
55773bc3-50ff-4269-a8ad-7a55f8b1ae5b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
56c2c02b-a474-4d61-97d4-0269d6469fe0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
59150023-2912-4d0b-8a52-789c55d88f25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
59f16175-b77a-47b8-86b0-da960c018e5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
5b067d42-bd9b-4354-94b3-7197ab48c35e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
5b563efe-67f1-4d1f-8af1-1f6b88fa714a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
5d8b8fcf-b60b-4597-ae3a-c1452a4c07e8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
5e076804-ba23-4a08-80be-dd5cf23d5e45	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
5e63a3ef-0a0d-4f73-b0cd-9549c630fd36	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
602ae1f0-ef45-4f51-b2d1-3c8ef93f6638	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
6aa8dd70-f3d0-410f-ad64-ab7a62907c32	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
71ccc8eb-05b6-4709-a740-3b615194c9c8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
76e72ba0-b270-4d23-9704-f319c101a1fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
774d5117-2628-4e8c-90c6-0ddaf398b1c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
777a0401-45b0-418a-80bc-3425e95db6b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
78830dd5-3adc-4278-83ed-e55fe0f452c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
7e1e1850-f912-499b-993e-74d764089129	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
7ecf1025-781e-4629-9595-defb4ab1b6bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
82714929-210d-458c-9d89-1b8aaa9577aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
82e015ff-8374-4440-a7bd-b101203d00b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
834b96da-8144-4336-a3d3-f192471b4214	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
89f608fa-db98-454c-9fcc-85fbb8f42d21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
8fc09204-0f4f-4118-8ec9-dd8c85de2d9f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
93dffad3-c0a4-484b-a56e-b7477db9a9b3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
97131b87-bce4-4c52-aafc-ef8378f78ea7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
995572df-5ba3-4377-b694-d6e9fe017bc9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
99e584cb-5ec5-4de1-9d0d-91b8759e8b18	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
9e765e4c-7048-4484-9e41-968019c87f39	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
9edde83b-bf78-4bf9-b1e2-c893c1a20d3b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
a0060589-5283-4f2e-adda-64cb31ca61b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
a1858b11-e636-4f3f-8f19-3829c69f1da0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
a262216e-373b-4231-988b-8966717879db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
a3952170-bbc6-44df-908b-2ddd4aec18c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
a51eb0c0-b5b5-4578-946d-e5b90f3b1cf5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
a60152ac-7ffa-4307-835a-8f5d3e74045d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
a7e22674-3d61-475d-9e84-acfa44994e24	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
a85a52b9-c269-4efc-aac5-6c6d47f93654	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
a9c2a338-7c08-4255-94fb-0bd7c45c283a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
ab56d6ec-fdf1-4d64-9293-db7f571be8c7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
ac2783e6-48ab-45ad-abf9-e0fd3e73c337	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
ac3723f8-9be6-4893-9083-e15f61bd4df9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
b1372774-7834-428f-adbd-a65416fb0667	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
b22b1c17-d3dc-4691-b735-867cfc07169b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
b5cdedca-ae41-4208-8bac-dcb50c82e085	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
b6297efb-c9b6-4aa4-95d9-d868fca7eb9d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
b700eb7d-c2d4-445f-b66f-1949f20d45cc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
ba0e4120-ce83-4b6b-a773-a7608c9ab6fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
ba9f89c5-bca8-4060-9c25-2b24b188c45a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
c581f993-c590-40c2-8ba4-60577d3776b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
c6afcce0-cc91-49c6-a5ce-e31715423c08	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
ce711283-f774-469d-a311-9046810c12b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
d52c707e-f2ac-4694-8aea-11170130b2ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
d6b4bc72-8e32-4ee8-86bc-2fadfebe918b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
d89f0aa3-d3cc-436e-b609-4aa5d7cea7b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
da03d703-2058-4553-bb88-99cf9edfeacd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
dba4c117-51d3-4aac-a1a9-8e32506f3e11	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
dc370da0-6cfe-4fa4-be72-fa06f177bdca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
dcf95c24-5efe-4917-a254-a976fa0782b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
de47d95b-6ff3-4f77-a4e0-6baefc36d21d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
de9b6a2e-d425-426d-bf8a-6bfc8818d66d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
e331c1a9-498a-4657-b488-ea3f8292ac3f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
e621af9b-7976-4c6c-8bd9-e45ac4fc96e6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
e68754c3-407c-4c8d-9c76-440cd5c85284	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
e7004cad-dfbf-4baf-ad59-8f87c3a727aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
eae8115b-4db6-48dd-8182-019f4dc44b2c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
f04a2861-811b-4bdf-9cda-f2028e45eff6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
f97ceaaa-0679-4f84-9c68-8f93257735a0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
fa4965b4-4fea-4895-a862-5ced93c5d226	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
\.


--
-- TOC entry 5215 (class 0 OID 26453)
-- Dependencies: 225
-- Data for Name: heroes; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.heroes (id, user_id, version, created_at, updated_at, base_hero_id, health1000, strength, agility, intelligence, crit_chance, crit_power, haste, versality, endurance_physical, endurance_magical, resist_damage_physical, resist_damage_magical, equipment1id, equipment2id, equipment3id, equipment4id, equipment5id, equipment6id, equipment7id, equipment8id, equipment9id, equipment10id, equipment11id, equipment12id, experience_now, group_name, level, rarity, damage) FROM stdin;
000d8f96-d7d1-49cb-a257-bcbeece4fc21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
007db588-959a-4e33-ba2c-45fcad85e537	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
00e4594b-3a58-4e16-980d-a71a38162957	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
012e12b1-5d42-4688-91da-be9eab34e1a3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
01530400-219b-407f-9f67-73b9e1bff972	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
020894e6-91ee-41a8-b7c3-ddee5ff169fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
023e6201-8ff3-4092-aa19-dd86df5ee638	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
023ff2f3-92bc-42fa-8d59-641babbaabba	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
02530f31-b833-4d11-a356-3f32ab817f64	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
03928911-c648-4bb4-a945-810d4a29f8c4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
03ad1f2d-7b10-4c43-b494-8a547ebeb30d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
03c5d4d5-fc2d-410c-929b-b4458682092a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
03d692fe-e17c-4a83-90f8-5d3ba4ebfa51	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
03da9c9c-aafe-494a-b290-02ffa9d85534	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
03f58049-7412-40f4-8d96-febac1d4ae7a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0400a823-0ea8-4cec-902d-436f696ff68c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
04219cff-f791-41ee-9a0e-fea681741710	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0423f279-dab5-4744-b45b-b2d86bff0629	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0454f46e-ba2e-4724-8043-4d61adfad8ca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0482e246-2b09-45c0-a493-055379c451e0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
0572eb8e-385e-450d-adae-d7dc4faae7c4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
05a7d60d-f29d-4e5a-b81f-1c8662e71831	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
05c447de-b02b-4f60-ae7e-e087acc2c461	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
06069f0e-937c-4e9f-9963-0a05e2e47909	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
0608ddae-c582-4929-976b-bf2db032bb08	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
060aab78-72b9-443b-9db8-5ec808c035f4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0679d1f6-9cda-4c92-92d5-003f6d33b351	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
06e77716-dba6-48be-b715-77b2b0e9c752	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
0710eef1-ea23-454e-a5d7-0197e0e65a36	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0729dbaf-4611-4e2c-bce0-1e121e5f5d25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
073f9d73-c06d-4c78-b58f-1d9adf134912	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
07cbc391-1275-437d-a5a1-73cec849ae12	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
07cd7fc4-145f-4fad-8c68-3f3ba8c07e4b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
07d3119a-4c45-4550-9a3e-01e047b6c99a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
07f7ebb0-36b3-4465-91f0-6c6871c01469	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
07fe844b-268c-4b57-a5ad-4cf7279d4dc9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
081127f4-c60b-4aed-ba45-4532164cf883	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0827d213-7c51-4a75-b0d6-c7fa07647071	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
084bf657-c856-4653-84d5-c3bc2f3fd342	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0863b25f-3471-474e-a94a-6cf58967c1de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
08bd3059-9f90-4476-9738-93420118c34e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
08dbdbcd-9b18-4694-926a-63ba74f05508	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
0935ad4b-8e25-4699-b655-b8d8ce7008cc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
09422150-c4c4-4de1-8ccf-046f51a6f14b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
094dba9b-f11a-4091-b3d1-50d28f1a7d93	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
0960908a-7bad-4a8f-8564-5b4662106543	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
096d2747-0355-49f2-8f65-c605865f9aee	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0a0b6518-da8e-45bc-9c2f-bf578e8b945e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0a2a7076-ee60-47db-b4bf-948c51ee4e6b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0a3af91a-f75d-4656-8d2a-bfb0529bd69a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0ad389a2-1e0e-4860-94f0-765ff5c23231	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0af5456b-9f3b-42cb-8d22-5a8245220741	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0b3324c9-3a2e-488c-92e6-b0896e385884	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0bc76530-c042-4cb7-9be7-d4696109f5b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0c10684a-99f8-47be-9847-c76f6f0dfc0a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0c820d45-2ff7-476a-b70e-b69ce62625e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
0cef9dc2-8739-4962-9b9e-7a03006ee03a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
0d1cfbaa-071c-4492-8393-424a1c49077d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0d3e4499-1d40-4829-af84-0b76a7667cd6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0d4f60cd-d231-48fa-9264-70d452d108b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0d693cc1-e27f-4062-9f60-2a68dcba0dcd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
0d950921-115b-4b46-822f-f862dbdd78ca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
0dc3fe6a-0f84-4487-883d-108e1f134ef7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0dd4f6d5-7b0b-4339-91c5-5027ba8267e6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0de06739-8bfc-4fb1-99c5-1d8f8c6fe39b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
0dfd4679-ce4a-4ffd-aa93-44f98e080b9e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0e0de07b-fb33-43e7-aa78-b65f6f7f811b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0e2c0be5-d99e-4704-b0ab-812d86a0851a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0ea714ad-a72f-4978-b2d0-e4a190068dd3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0ee2e2fa-09f8-4a9f-bdfb-3961557ad357	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
0ef7c652-a28a-4e41-9a1f-d74575a56596	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
0f034259-28dd-493a-9b42-963bcd511df3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0f14e58a-3309-4897-9f7f-c4c19439ebda	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0f23dd1e-5bf8-4e04-8982-9dd816ff1dab	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
0f45b298-cd5b-499e-85a3-657397968a9c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
0fc837ca-0e03-4b9d-805c-045e25d37640	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
108f5de8-b1e7-493d-8b33-3aa54d19c6b1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
10e9970a-3143-48c8-a480-d46d9eda03e7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1103dbe3-526c-4cbe-9bc5-03fde068a4d0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
114efe12-0e85-473e-8e45-6f410d0025b6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
11ac9f09-faaa-47c3-99ef-b9f20412cc52	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
11d63b22-343d-42c9-9ff6-a2ecef042fef	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
122676d1-acdc-4f3c-9980-861bd3df980b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
122eecf9-e42d-4cc9-967e-2c6dbf817891	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
1271e143-c647-4883-b3f1-f8a22a432298	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
12734964-4a97-472e-b20a-b80390b5e090	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
127b9575-75b5-41b9-85c4-4e309d541d14	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
129f8f92-284a-40c8-94db-5f9cf6583203	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
12e9e671-bf39-4749-a67e-b8566b134584	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
12f7591b-8d3a-4194-999e-0b3f18a6e6bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
13265d66-fe0b-4e15-be2e-a614f6588663	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
1374908b-f05a-4b38-9b03-35afb869b47e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
13acb2d0-2440-4d7a-b05c-ac9a105ab23c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
13bee8f6-e793-4110-8b97-6a20c0ae4a91	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
13cac238-f5bd-4a07-80db-92e76b3e6594	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
13ed6f37-6515-4bad-8bf8-bdc5078650e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
14211872-443b-44e7-a82f-d2605c89bfac	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
147bb8e2-a0ed-4572-8445-b9f01c083359	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1501728d-c6ff-4544-8ef8-78b3d8570aab	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
15093257-5cc3-4570-81ed-53bc1197239b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
1540ad1a-1630-44fe-8b8b-244d613ed484	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
155b072a-9c39-4d86-bae4-2c470c7a2562	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
15b0d30d-ee1c-473b-8cab-5a04f3908df6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
15da91b0-fc85-495a-95df-7e3d9c52a3fc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
16614906-f49b-49b1-9c43-1d4a8d82dfc8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
167eea11-4237-4ea3-8db0-24a87cbad857	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
16ba9b85-5ec4-4b94-b037-9fa27ef0d205	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
170663d4-5a18-429a-b320-1acb108c1c17	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
170ea0fb-db2a-4f9f-a28d-865327bc44be	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
173aa1da-5f94-45ed-aad8-a28ca340832d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
17a14681-4e0b-4419-adba-afa7cbba2202	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
17dc071f-93ac-49c3-bea1-588367c5c955	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1843bcd0-79b1-4970-8643-159ec305e2eb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
1868de60-48be-480a-bc99-9d3251230f13	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
186aa020-7e46-455c-80dd-a8007c98eb95	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
18ac903b-b98e-4b5b-af52-41d74eaa626f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
194bfb65-c6bd-47a0-ae42-686c8cd97e2a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
19865eae-b2be-4c3c-87fd-054db72a8f04	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
198d3517-2042-4ec3-9a71-0b721f5f3ca7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
198d81a3-5b90-4403-8a67-7c6a8201f281	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1a09e43b-ee36-4a39-9e73-849ed858a578	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
1a668978-07d7-40fa-960c-91e36ea674b2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1aaaa280-71b9-404e-81c6-9dec8ec80396	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
1b0e3308-aa47-42d0-af5c-dd6d45bb18f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1b98593c-bbce-4a35-88cc-6c4dd6d7877f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
1bc91e93-2765-4bb3-8f16-e88207482d5a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
1c22cb8a-4859-4fe8-8d55-5fcca619372f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1c28d8a3-cd7b-4f36-afcd-79642ac9c176	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1cdc0ab1-90ef-4b37-80b6-7a15b61a6661	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
1d0cc98c-1e96-4791-bc9d-1fad9a09ac1a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
1d9fc437-d6d8-41b6-8281-caeb7b2a56d3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
1dc9fa0c-47a0-49ba-a261-7e971f3acd72	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1dd68377-0b4b-468e-800b-075b80b73ef4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1dec41ed-bfd1-4dbb-9800-2cdd52c04030	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1e10969b-7b15-467a-9a6b-73d26843cc00	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1e2a15bb-fa44-4fff-8b52-73a5118dfd7a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1eb996e7-e875-411c-9a2a-634d1bf45097	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
1ec73067-e887-4e18-a362-7c85a3badedc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1f07712e-1614-439f-aac3-6a8f3d6c3f4c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
1f5f6adb-cdd9-43cf-be7b-6e6ef74fb8b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
1f64a31e-2f0b-4f4c-94a3-f8ab51fd0282	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
1f92c584-4308-4767-a056-1f6ade25d5ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1fa3fae1-1b85-4cb0-825e-718c2995371e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1fac2edb-c96e-4d89-b464-0e560c2dc4da	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
20551a08-8889-4ce5-a189-96358cd89e33	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
2098efdf-424c-4899-8a98-3457d8d055f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
20eb60e5-ad78-4842-8665-7db5debba68c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
20f5b65d-d556-4dbd-8951-3559dfc56d54	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
2107660f-1b1d-4f18-93db-c6fbf8ab6d90	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
213c1092-0878-436a-a769-6de9847c3776	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
2140d05b-c8c6-4558-9454-185bfa3655ef	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
214f0386-1da6-4533-9c45-bdb3fd8b4e38	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
21d9beef-9a69-41ab-b11b-466b2a280710	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
21f2f1d2-1214-4cfd-870e-e7e54f003946	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
233bf89f-ffd0-4255-b10e-156687489ca4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
235cfaf0-5e85-4f51-8e8c-8305f259bc4d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
235fd631-0509-4386-9c8f-a8b625183576	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
23909737-50c1-471a-9894-63d9ad801015	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
2450175a-cdf2-4fbc-af86-bab4d760a1e7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
24a8cd46-b315-4c79-a27d-c67180e4fb59	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
2570559b-bef8-4d05-b95d-a1860f3d64b3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
258eebbf-373d-4dfd-bcfc-1ab564754466	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
2594d937-2bdc-455e-95a4-b3b159b14ffb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
25b99c56-903a-47c2-a016-632821e094d7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
25bfd106-8025-4930-9860-8febd8354cf6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
25ce4ef8-5c6a-4ef8-b5bd-0df5f46b37a1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
2600b8d0-9497-4e25-aaad-c106b5986ace	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
26694492-8b5e-4f00-a6f9-77f270f8ff56	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
26ca9ec5-edb0-465c-a623-5fa369b5f7b5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
2728506e-4434-4333-9618-9a8a2761e2eb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
275f17c5-c182-4ea1-8f0a-c0d8fa6b6298	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
277abc92-882e-4e9c-aac5-7e4751cc8aa2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
287eb9e1-985f-48d0-99f3-5134b32b7254	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
28830980-799f-4a6d-9b77-ee8e2ffdbf47	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
28aa5945-8035-4e4d-a6cf-bfd129a27fbb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
28bf09e8-4b4f-425e-b63f-413fa910faa9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
28cd3a36-3d2f-4098-b087-07538e2fd7af	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
28d44237-9011-435b-a4c7-fe6e8d233736	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
290465ae-0b15-46bc-96f3-33d1c51058df	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
2912df12-bfc6-44ad-93f8-9ba266e4eec9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
291b5f71-c9b3-42e5-8e56-d61f29688823	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
29564c72-e0f0-46b2-9b31-57b9ee508930	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
2968f86f-1e14-4347-87af-8c59e923240a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
29a41c12-2fb0-4212-9457-656463192ae5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
29f2950d-0ea0-483c-a8fa-eba03859352f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
2a3a7458-e80d-43f2-8e6e-24b9b0405c01	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
2aa904aa-dcba-4013-b520-dd503b2c71c2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
2adebcd5-9238-46cb-bc4b-60c40a1027d0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
2afd2a33-981a-4b34-b944-3941868de7fc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
2b2b15fa-8304-46b2-b16f-a7ece8ab222f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
2b703223-29fc-4070-b78d-c0fb64e430af	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
2b832290-b7e7-498c-9d92-a3bb808ffb87	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
2bdb8151-49a1-49f5-8237-8637e7ef84ca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
2c0fa5bf-3d26-4095-bea4-72e82fc1649a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
2c253c95-a49e-4dd1-b2fe-b45ff5f30cc6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
2c281e98-30e5-420b-9bda-30caea3ae484	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
2c332e5f-798d-455e-b63a-d61aa4f5ef09	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
2ccbe8e8-3abb-4dda-8f7b-e8cf8e3a98ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
2d165411-cc22-4c92-aae8-0fa181d44b22	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
2d4dc563-5662-4dc4-b012-4a134c8b89f4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
2d7c6311-63ca-4fe6-a62f-4ae55f07b84a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
2d8687c1-6a08-41fc-9a45-74aeeef8fb48	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
2e4b03b5-740f-4a18-b46a-ec94b591f6f8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
2eb47905-f4b1-4041-af0d-5586fd6f9263	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
2ec58c4f-377b-418d-8c28-f311ae9597b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
2f0c1748-a4f9-44e2-b7ce-b7f542fdc059	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
2fa8c20c-6001-47a1-83ef-824d912f111e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
2fe9f070-2f5d-4636-a609-e6dd9b0c7ecb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
30279513-cac6-451e-b82f-0e174ed99f4e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
3030a9f5-264d-41af-be14-fa0de17b6ef8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
304432cd-9a5d-465f-9a1b-c945f780463d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
304cdc52-3246-4b93-8ffd-b05a03e3a113	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
306820f8-4ce3-41f9-92d1-0ab4a99e3544	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
30776a8d-13a0-4af9-b393-55c98a1c715a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
308f66f2-8ef0-41da-a40a-6b189ef49562	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
311aa071-f5f3-4fef-8cfa-a670eec7f2de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
3132f611-1bd4-44bc-8ed1-eda7ad8d1145	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
313e8528-f69e-4511-96d8-3a968ef11320	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3244d272-5d9d-429e-9804-b00501ade564	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
32b647d8-9006-4cc4-82aa-1da76b030b79	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
339db4e6-e6a1-4144-a7c6-2fd285c68d43	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
33a90cdf-7c99-4d34-bd2a-62ec22a77150	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
33c654a7-19fa-4da3-8072-db7da07f77d6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
340f9d95-8818-4336-89dd-597a1d98dfae	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
342cd04a-c336-43c9-aef4-27594a612f50	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
343bb885-464e-4663-8813-1cc064d2f113	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
344445e0-7180-45e5-9687-8447eeca9088	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
36ac4996-d112-4a0d-8328-0043ad8087d9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3740cd65-05de-4019-ad52-a8975e355ad7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
374bd7e4-12d1-4b3f-838b-7d85c94a407c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
37a64f28-0519-4ea0-afe1-beed248e7743	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
380237f2-3ecd-46c1-872a-de7aced94960	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
3885419b-115f-4ddd-8ebf-b141b91f90a1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
388b9e5e-a6c0-41e3-8efb-290b106bf9d4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
38a8840b-6f9f-422e-85b4-ed29528f0607	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
38ba0a3c-941f-4429-b49d-835679120f50	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
39086c42-0ff2-45f1-8d59-2cb6941799f0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
394217a9-29fc-4f20-81ea-9218994cde65	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
39b4a895-1921-45ed-bf5e-cbb12dce3817	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
39c9d86e-6c65-45bf-965e-7aca01d8a5cd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3a2686a5-cafc-4697-8993-1d114a721d7b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3a36e25e-a958-481e-8c20-c238ec742f66	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
3a3ab115-5189-4738-be20-b24955b71365	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
3a722684-7cee-4127-9823-aa6abff788ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
3acfcf7c-66b0-4aa6-bf9e-6f1002356b30	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
3b1880b8-093f-4df0-a1ce-a2cc84f69e22	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
3b26feee-dfa4-4447-9198-d8614eadc048	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3b9f42c9-0baa-47b0-8884-497ac5c5e180	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3bb36278-e503-46ef-afe8-19181349d509	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3bdd5033-537a-41d1-853b-91bbb96e7297	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3c15d0b3-2182-4654-8f13-2abf2f1fb68a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
3c36e3a7-fe51-42ee-a036-5c58fcb7b2e2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
3c5eeaf8-155c-49be-a509-10addeadab9a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
3c8e2c6e-75db-4eca-839b-503bca5c0864	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
3ca8d1a0-dac6-4d22-8166-d1c872076fbe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3ce4ec34-71ce-47fe-8764-f9afb5f188f9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3d2bd865-3c4b-4de5-a2dd-2fb67efda795	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
3d353fd9-fa9c-47e7-9e6f-86913a9d0ad7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3d36e2d2-1eed-46ba-adc3-2c4ce7b4805f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
3d4d7fdf-1175-4d12-b210-bcfc7769d9bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
3dafdec8-1b55-4ac2-88a6-efe33c603b40	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
3e488c83-4db3-42d7-9f5d-2060e7215681	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3e97d7ea-9031-45c9-8e9a-b31eb430f59b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
3eafa746-d3d2-407a-95d1-4a0f66ae61d9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
3ec8a27d-2db1-44ce-9e1e-aec71fe282cc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
3ee8f1a8-19be-4654-92f4-fd7510959b2d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3f1f3211-8b7f-4b99-b750-77fbaba61f57	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
3f3586b1-f107-4a2f-bef4-1049a63bf4db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3f3cb13e-ebe9-4a8a-aaf1-413945daa627	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
3f81fe2c-6a51-420a-a037-9a27feb8d6a8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4015d104-7bf7-48f5-8df8-c0e6c2229dd8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
404559bc-decd-4ad6-97b2-9856d0285652	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
4073d0cd-5304-44ee-b10f-e045bbd90f9f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
40fac477-b273-45ce-8fc9-3ac95d11b8a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
4261ad0f-7c53-499d-93d3-a741218c6b4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4294719d-62d3-4ef6-be69-93436da1e26f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
42a7406b-973d-4ace-92c0-cfce5305f37a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
42e1bc37-f0d2-4a42-be54-ed3ac61a4b66	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
43037edb-524b-4e64-8b48-2171c16ef6aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
431f68f4-6590-4718-9ad2-3f39cee250e5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4367d1f7-43fd-4f94-8b44-11d9e29dbbe0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
43a8b125-2e12-433a-9a42-b3bbcfb0f3b5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
4420e723-35e8-4b69-bc93-4fb86ef9caeb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
4423c670-e188-4845-a8a3-17b3159c1be8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
45516016-7b75-46ec-a852-654b657dc870	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
45a80065-7bb7-42fb-b23b-9ac14f6a656a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
461002b4-269f-453e-8d44-a7eff1107811	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
46643f81-b049-4702-8590-4588c9cc60c4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
46862009-2016-492a-b309-4acc47e0e281	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
468f510c-e12b-43e9-802a-82139b35d0f9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
4694f6fb-4eef-4007-9889-bb7a7fdf404b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
46a0c1d2-782a-4a86-b0f4-89880a42ea9c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
46ccfdcf-7529-417e-862a-04fc31e2a6de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
46e3e19a-aba3-4cd4-8622-a4f1fafb69d0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
46ed967c-b318-4c7e-8255-85d1dc056cd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
472ae662-5677-4998-9816-651d93221cda	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
4764b134-b938-439e-bc2e-8f77518f8988	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
4771fab7-71dd-4a12-9418-b1c1e2cb4d8e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
47bcf6ba-e634-469f-9219-6093d9d50f27	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
47f020c6-ec60-48f9-bd56-35d28466c6c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
487d9126-a736-4edb-91bf-5766f43029cc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
48c21026-eb23-4193-becf-dbae40df8954	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
48d4b286-b2fb-4314-b4eb-a0736770ebf0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
48f7428a-5031-498e-89c7-5c24454fdb7e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
493cd51e-08e9-4289-adaa-a4fa16ca2921	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
495ed262-d080-48a2-b1cd-c8455711a8a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
496983d4-17ab-4f1f-b7d1-1ec701169368	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
49791e59-dfae-451e-a46f-d598df582463	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
49d79f9f-a5ac-4a18-bed6-eb77ae039666	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
49e68edb-ab2c-404f-987c-8417a59e5aa9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
4a698792-8197-45c5-bae6-0b77da48b972	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
4aa0e34d-360b-47a9-89cd-96eeaab70333	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
4accda29-6a54-450f-b894-84e0ef9dc01b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4ae87f52-4496-49d9-98ed-9707e501290c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4b704142-fb6d-452d-ba90-f040cef302dd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
4bc76800-1bf5-4f3c-914d-a51625326013	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4bd337db-eef6-483f-9b8b-315f61a0e6a1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4c0cb884-e06a-4613-98d0-df621582de07	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
4d772ad1-eff7-4e54-bc66-24d9a82d2fb5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
4de8e342-e88c-476b-ba85-2106b27633bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
4e107a74-a67e-42a3-a302-a8b09fbbd211	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
4e1e02e8-b597-4f44-84de-04736b1d3e5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
4e1e9d81-4b00-4b39-88aa-58be6e05d13d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
4e9e8465-a0aa-4219-a671-04f3386d207f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
4ee641a7-c2e9-4d55-9728-506a8e109fbe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4ff60492-88ba-4dad-8e3d-6c1996cef8aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
501a2e2f-7e2a-4a1d-8797-b87e5444a4de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
50967e06-d18e-4d7c-bb8f-0de00b052b8a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
51021f5e-f217-4397-8391-7d54e15bfce1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5129f528-8f1c-4bd7-a931-16dd33142fc1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
529b9e10-f082-481b-b879-d7ab2cbd3070	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
52a3ef7d-4ca8-4a8e-91d1-7a4796c19ea9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
537055cc-69a9-4c7e-8b2c-f3fd5b394916	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5377a422-3fae-467b-8b27-4a113300eb88	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
5392be61-0a08-4e34-bce9-3514b6379938	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
53f41968-823c-4143-a1a2-7cb83dd3fda7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
54a270d1-1ad7-4e16-9c98-6b28d4ab03e0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
556e8ae3-2f43-4b9c-9615-cfeb72658676	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5577f98d-0a3c-43bd-8ac2-2bc540fc6522	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
55dc1def-30eb-4c86-9d5b-2668300681c7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
5610e389-5195-46bc-820e-e3ecd7d15b57	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
56bc150f-3de3-4a5e-bdf6-ad354e72b134	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
570adbb4-b235-40e5-8ccc-0a37a87163e8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
57bb36f0-99f4-417f-9769-348689ae3156	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
57ced434-01e3-4c17-86cd-e35f7469f6fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
58209419-ea9e-4df5-8ae7-8c301d2eda7b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
58c967a8-ce71-49e1-a718-1e7236b592b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
590dd399-146d-47c0-9a15-3a2317ade33a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
59398704-de31-41d1-b52f-4fcf48205915	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
598cda4e-869f-48cf-91a8-2091a29f562b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
59c9fa12-d902-49d8-9c89-f0f01fa911ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
59d91be6-afb5-46f4-a047-dbaed94a1861	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
59ed168f-092a-41b2-b33f-ade0d2383ce0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5a04d665-9cf2-4d71-b81c-f8f9721206ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
5a3c5729-081c-4c3a-940d-6c2404cc12c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5a46129f-8850-41e1-b4c4-11ff37e9e339	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5a4de632-a2ce-4b62-9893-5e7b684dd88f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
5a8eedd5-4502-4dfe-92e1-628a1d9a17ab	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5ae97c67-248c-441f-8d24-152581a90bd7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5aed2960-f185-489f-b052-ba27135a06b2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5af073fb-2b70-4488-9dfe-806107920c22	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
5b16caf0-5ffe-415b-bf43-10af0b187824	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5b757775-f7a8-4fd0-9d26-ee3426c0d548	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5b7f6970-9073-408f-8fc2-f6ca8b6de5ba	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
5b996e78-f25f-4321-966f-63abbf06d19e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
5bbd4dbd-4c23-4e48-9623-7659e0a87701	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5c0e51ad-3d8f-4f97-946f-8f15fd0a0f09	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5c1bfdcd-a363-4afe-a1fb-9f8f34d3f254	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
5c2dd7e7-03be-47dd-b24b-d9d448899372	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
5c507c3f-42fa-492c-ac8f-d5c205e50960	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
5d4fdb65-9e01-4445-b279-92b8c5fb1d7a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5d55b960-c8c2-42be-98c4-6fdc22e88413	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5d7132a7-9e5a-455b-8f1c-8d93122cdd4c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5dd1413c-a76b-4175-b364-49019ff771ac	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5dd1b83d-4d7d-464f-91f5-5fea0b245350	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
5de1844f-b9b6-42e1-876c-fbe775f27331	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5de3a21e-266d-422c-9bad-1d2178aa9472	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
5e2d8b14-70d6-40b5-a11e-f4d9317b03ad	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5e3d06f0-70b8-4a38-b4e3-3eae72cbe2ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
5e45ee16-1867-4522-8d11-8de996d285da	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5e82f4e2-8453-4414-b8a2-0435a153cc7c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5fbe7c5b-e12e-4a0c-88e3-ec9f67a6b3d2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
603125cb-d1d1-440e-a7ec-5ebddb4ddea3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
6032cb86-d3a9-44cd-8091-9d1b322a060c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
60a93321-8ae6-43bd-a31a-333749eefd01	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
60adfccf-7344-4f5c-83bf-d6ce5c65e541	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
60bee697-05d6-421b-a255-a9683912265c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
60c26178-9ac7-4039-a07f-c769fc5039da	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
61a56938-648f-413a-bf6b-79c232b27adf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
61bcd1ce-4a07-4b4c-a015-bba86638bb02	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
61d03164-d0f7-4e9e-a462-26484848b881	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
61e1a7f0-8d7f-495e-8d75-ac08aabf4745	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
628b7af9-a98b-4acb-8f5b-c77495198f7f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
62b0cb15-bb57-4fd9-a43a-d5b0bdf6beda	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
62fa1dcc-f1ba-493f-9e04-e069336ffd11	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
63000c05-2749-4ff2-a58d-00f15b20be57	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
6328db4f-9eb3-47f0-89ab-95f757681de7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
63829e3b-4ff5-411e-ab3b-516465a3b964	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
63f189f6-d06a-46d2-9a46-1bf4ba0dabb1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
63feabba-d6db-4000-a70e-e253ed9db5e9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
655b37b0-2a78-42e2-9aff-351093f96d97	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
656a884b-da7b-478d-a092-fbc644b63a32	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
656b3140-1d79-4c0a-beef-e71c45fe0dab	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
6573be9b-a08b-4dc3-9337-7961fcf1af58	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
65c4a2cb-1932-4af1-9169-22b779c23f7f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
66550bc6-371a-4c5c-ab55-80017a587b41	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
670cecec-ce8b-422f-a5bb-8d1153250b86	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
6743bcbd-b392-4ffc-bc95-7bc4d3ea560f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
685c3bdd-ddf6-4b91-af99-6ebd0d9987e7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
686508c9-af09-47e3-9cbd-631f51496812	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
69088adf-d2c5-4d2b-a5d3-262b7b2834cd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
69608d1d-ec84-4855-9d8f-55f8ff544bab	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
69620cac-6062-4002-b6e5-304a05370840	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
69c19f22-2a78-4743-8210-ad905ae21ab6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
69c24c8e-d766-4434-ab4d-c9b1e7cd40ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6a7185e0-2504-4861-96ae-75fe72307ef7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
6a91ca7d-04ce-40a5-92e5-9edd447fa5b5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
6ae36068-e115-4e0e-bc47-dc0bb87b7b7f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
6afba75d-0aa5-42ef-bed3-cea4a53d8052	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
6bb9cb5e-39d9-4ece-9223-75b0d7c9f411	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
6befb6ca-9b26-4826-b1ab-27d41710464d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6c13dced-ed5f-4d17-9e31-94750503c877	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
6c86c3ae-357a-4582-9293-fc7b670be1db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
6cec15e7-dc5a-47e9-ac9b-928714164bdf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
6d2205fa-2013-4bae-b0e9-c5f2bd04dbd6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
6dade211-9e05-4aee-a16d-7fd5c01cb23c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
6dd53790-8eff-47a6-b26e-18147b882178	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
6dd6bedf-c15d-415c-ba32-e521f2db9d00	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
6df183d2-d85e-4c94-91e5-c7a7cd51a394	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6e5a7354-04b6-44f1-8a8a-d326128d5776	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
6eefb4e1-e8d5-4165-8756-506c17e45de2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
6fb2d8c8-48fc-4518-a543-154b53818a9a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
6fb6f21d-3cbf-4010-9b39-43346e5797cd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
6fed057b-d498-4572-a42d-e379176dc38c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
7005fd74-32bd-4f82-acf7-6c9cde3f0d21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
7011f9b6-764b-465f-bb0c-2fbd60e3493c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
70160fd6-7a4b-465a-9bda-4f4fc95a759c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
70d1d8fc-0a67-4423-846f-426749c57043	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
71f64106-7b23-4ce5-86ea-27155402e635	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
7212e497-2cab-4578-9940-0f3d0057cd5d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
72a5d80c-51cc-412c-acc8-833100dccf85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
7326da3a-f168-45f4-8089-dadef12a4033	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
7348cd3a-f9af-4e03-987e-2debd4bf01db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
7362de89-d7f8-4917-a3ec-0489122e27ad	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
7395ddb3-9a72-48a5-bd21-c05d84febdff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
74356d7e-71a2-4307-8f38-5f2c0f10d431	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
745c80ac-81d1-4a9b-926a-00736116efc1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
746c67b3-1268-4eea-b241-5dd5a0f8a0ac	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
755a56a1-27fb-4558-bd4e-08d4b5da220f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
75790461-1c9e-42ad-a0ef-860e1b853a7e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
757eb5ba-2751-4ebf-832d-8c1735ea6029	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
7585dccf-dd02-4451-9476-d4770685f266	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
7635ef36-07d6-4347-9d50-b29d8b752c9e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
765ebc56-8740-407c-bab9-85b7d8178280	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
76b1b9ce-b1ae-4792-9d2e-682b7f9e5626	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
76cfdd41-d3d3-40c2-9a23-6d6910750b85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
773fba59-4928-4e7b-84d8-0810adc9ce33	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
77441ea1-3911-4ca4-8780-412292e36ccc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
7785e557-ed7f-43f3-8743-85dec688999c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
77fe40e2-df83-4314-8279-02007667b1cb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
78102854-35cc-4c01-9ec6-e1d102a44bd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
7872aa3c-fee5-4ca4-a240-820812d60b22	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
78caf16a-5453-4006-89ef-92d1c0d14f4e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
790f5b9d-e2b6-417f-b0aa-c862f687db00	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
793547a9-63eb-413d-9de9-d99e117283f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
794cbf7a-fcdd-4e21-8c38-ac5767446a56	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
798dbbe4-c32d-46d7-a052-7fc1e21c7cfd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
7a4b3ce8-bf44-4fe8-a3a3-b6ce02a9531a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
7a830909-953e-4469-a662-b26609af3791	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
7b3a3431-efbd-47ed-8274-81530ee98317	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
7b6b3463-1453-476d-ab88-86ca0e99a519	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
7b6f427b-9ea3-4c2f-a778-350732404e90	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
7bd554f6-d6d2-4963-86cf-4967418af027	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
7bef4e1e-d828-4182-ac63-8d7b04ef3bfb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
7c795c4b-1e51-445b-aa79-81d4270f79cd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
7c83f8e1-128d-481e-90cd-17ce61c3a436	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
7d76cc51-0335-4ad1-8170-7afa647bffa3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
7d7fe376-f436-48f9-8835-b3a8fa0b3b7b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
7db8092e-bb0a-4f90-93c3-696739a2bf63	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
7dbdbc97-8ee7-4fa6-a477-065fff45b63c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
7df3b241-ff42-42df-b7c6-8f24c11bc461	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
7e0b292a-221d-4ab2-8959-d28ec4c990ae	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
7e93a1e4-5f90-4595-9baf-05c258b90b68	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
7ecb7d78-27cc-4954-a50a-cb79500f146a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
7f104868-2a35-4ceb-affc-a5adfd40c58f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
7fb0e6fc-8784-435b-ad29-c2731fa88834	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
7fb9707a-542b-4909-b449-79da124cc696	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
7fbb9558-342b-49c9-a36d-d240beb98f81	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
8089fbc3-08e7-4679-8283-98465f776536	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
80dffffa-a2cd-424a-84e6-164038db2521	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
813ce255-5d6b-49c1-a4e3-2b33a0c30f48	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
816c5e5e-94fa-4da5-b42c-b79a1e8ed600	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
816fbb86-7317-47e9-90a3-f499020cb7af	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
81a432ec-e903-41a4-afd9-3d12ea137be9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
82308289-0111-4497-bf3c-a50ee7324d94	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
823f2841-4402-4488-a0bf-823163aa8039	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
8246726f-5bcd-44ed-94db-43f0edf4ab77	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
824cad12-000f-45a9-bec3-c061186ea340	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
825945f1-5183-47e3-af74-20db50581598	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
82dd63d9-1299-4d9c-bf51-32b34309409b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
8393f9f1-a5d2-4032-b644-87dd3c893af3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
83ca72f8-7b69-4232-887e-3fbba8c2f7fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
848d832f-f2da-413a-ac4e-13b8b27f2016	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
84923edc-ea09-4eaf-a0b9-899dbd8be2c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
84a1af7b-0948-4b07-9fd5-047506db6fc0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
84ac7779-1edf-4094-9a70-b1b4073d24e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
84ea7e2c-e54f-4d64-a191-6edcac8f891a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
85026004-2bf8-4bdb-a1e3-98d8638e9323	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
85047352-cc56-474c-8229-aaa43ad0804e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
85186886-2c13-4ce7-906a-b09079630989	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
85411987-17b4-4e5d-ab38-f2ef50c1b24a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
85484d2c-3ea2-44c5-90d3-bacb4775104d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
855e55a7-e5e1-4a80-9bbc-461c76db6728	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
85d584bb-fd9c-4b56-9549-9354327c077f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
85e73693-12ac-45fc-8b44-a416ac67d28f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
862f9d62-f45c-4610-b724-9695b5acab79	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
864b0f01-2166-482c-b996-e97d0e035284	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
865bd04c-5f7b-4897-a998-1cfb05e16123	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
8669d62c-d14e-4d63-ba51-9c91e6de8efd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
86899930-1950-4021-85b8-30b3d8082d52	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
869b8025-c3a3-4550-8127-fe3a888e971e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
86e62188-f280-4b84-9706-8aa54fbabdfc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
87b15400-d499-4008-9cfb-d31e72e3db65	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
87be82d4-9da6-432e-b899-3cea437452d6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
87f4815c-adad-448e-87a6-2604e8c38501	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
88256809-87d9-4dcd-89d2-9b4febf143be	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
884a06aa-07cd-42fa-bb26-ce0ea63a0499	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
88ccd54e-ee64-4ac6-8ceb-1293675945b0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
891c5189-66c7-4eeb-aa4b-d4c1fc885e0c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
896197b9-76e5-4c24-a6e9-e66d2f25cc76	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
896e9ed9-af86-4274-b3b8-63984da8584f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
8972a456-614f-4ed6-a805-098464a4dd52	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8991f74d-53f9-4420-98f5-31854f0c22a8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
89f29829-09eb-4fa9-9f64-d2008659d468	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
8a07a130-f5a8-43c9-98ad-d4457bf89352	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
8a1f34df-f0e9-4640-9a18-51e4c9565115	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
8b2f2d1f-e269-4232-8ae0-c978145ec285	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8b7ca653-61b0-490b-a979-0c3900f192f9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8bab7934-810f-4b88-b9fb-be7c149b8a55	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
8bb1f853-fecc-46af-83c6-d5e653d8acd4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8bbfbe08-245b-4a51-8e8a-5ccfa9b7ca26	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8bc70fa8-a155-4030-ba2f-6b8fda95c003	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8bf089a4-afe6-40c1-9b85-0a9aa90a9c58	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
8c1105bd-38e4-43a3-ac1e-9154c8cdd5e1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
8cb246a8-b6ef-4890-a7db-a9d7119a2d6b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8cc4b2cf-2533-4a7b-ada5-fd5d691e5362	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
8ce138ea-0837-4c0b-a353-6392dc4d53d0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
8d25a3b6-33e0-4362-9a6d-39f007ef5de3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
8d5f86f9-403b-4507-91bb-1d0584506585	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
8e413ea7-ec79-42f1-9d90-fc961d194a91	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
8e469185-7390-4f36-8c79-54ffede67696	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
8e849c83-0e38-49fa-aa13-118ef1b19c2b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
8f373a79-c232-421e-bbab-e52698965543	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
8fba6100-571d-40a0-b47d-576dbbd53ce2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
8fd62faa-c111-4e64-ae92-92de7ce54b09	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
8fe73615-94fb-4dd1-9995-58729449294e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
8ff708ba-383a-461b-8bbf-34bc9c4dc7a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
90299656-d506-4f3e-80db-ee49d46bba92	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
90362170-2895-48ab-81cc-319051a436aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
90daeda0-53cb-46eb-a725-c1f1ff3d31c8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
90f92fea-d978-40fa-8805-190abd8d85eb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
919f60f6-96ec-41e0-8659-b796e4fa50e9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
91e82319-c658-411b-919a-74b2bc19dcd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
921aa5f0-d7a2-4339-a995-2159fec8bcf8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
9240ccfb-189a-4e64-9daa-07b61789d93f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
936e3697-f3bc-4099-88ad-7618cdc35d36	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
93944f04-45df-4b25-ae13-0df5caf8e198	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
93b8f477-981a-4d09-b4e3-0279ef5eab72	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
942aa599-01c4-4023-b1c9-9cc8b74c7a62	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
943dd0d1-a7c4-482e-97c2-7619ed7ff194	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
944f6573-47ba-430a-a244-01b37d750808	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
94608c68-333b-467e-9073-97735685ab85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
94b2dcb9-4c17-4c65-b7b4-ac5598a03472	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
94dda9c9-5b90-4704-9960-0cec23e5e584	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
9536227e-fba9-4ce5-83c5-1abb45bddc20	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
9554b187-676e-4a0c-8156-9047fd827746	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
957c147b-e39c-4d28-97e5-711ef527b65e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
9596ee35-70b0-4fcd-87f0-7d0a880f06c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
96955177-b9f7-4001-ba3d-60d545aea121	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
96bc5df8-6474-49ce-8b68-8bde27a13898	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
96e5840e-70ea-41a7-b55f-2d3f3a1e6e68	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
975822f9-630f-4f0a-b359-dc81465cd6d7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
9766d8c6-8ff8-4614-8de6-40ea4120c60c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
976806bb-0b6c-4cff-8c2c-6a33ef50f03d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
977914d1-dff6-4beb-829c-ab676fea7fe9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
978dff54-ba40-4a82-8f14-9658575fa0f0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9796f3c6-2442-4a7c-9931-97e567b1efe5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
97a67f6f-a025-4877-b190-563efced2fd3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
97c50562-a109-40c6-9ccf-bba9563bf692	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
97eef75d-f78b-4924-a6c7-231aab736e7e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
985635fc-5f87-4174-8be3-92f493993a36	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
9895d9b1-a340-411f-9ba6-6a87f52118ee	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
98e24066-aa9d-4f58-ba4c-fa3068e03cbf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
99366fc0-eb2d-43ef-807d-c2d653a3c104	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
993d023d-6b88-4f98-9117-179408ef14be	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
99ac2991-5037-4d7c-84c5-a6423095b979	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
99e970d9-bc5e-47a8-91f6-2a3c28cba3cc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9a16cb5d-6038-4ae3-a244-2a63b49a2f08	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9a22108b-1220-4a00-97c2-871440ce3410	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
9a25c792-1234-4ef5-a2a3-535fbdb38036	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9a46190e-6a6e-4f4b-b43b-fcb021ebd75a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
9a814cf4-8c26-44c1-ad21-9e7abc05ccf6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9a863db4-2a1f-4d5e-a2f6-6edea17b5d22	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9aa29203-e3f6-498d-a700-44b510e81171	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9ad88f37-dc73-42a6-8a8b-d24c69e7e325	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9af363f2-6703-40fb-9348-db5a71604d48	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
9b1579fb-da9b-46d0-b0c3-f0d9717cd86b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9bb8a14a-f38f-4048-b91f-d5175de9d3b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
9c0862c8-ed93-44c3-bd8c-342890112ede	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
9c208fca-c15e-47ce-8883-36a251122813	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
9ce09645-e229-4025-b965-79653bd8beae	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9cf18289-5557-4ff5-8695-551a722fe70a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9d02119f-b6e2-4dd8-a74d-72a36a1cb586	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
9d16794c-7733-4c0f-b9d2-1a54ecad3b04	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
9d27781b-857a-40a2-ac35-fa9e2b7649a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9d2e046e-72b1-4d46-9785-452f3fb21dc6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9d3189f7-f1f6-4142-b4b2-d6506e4f7fbc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9d5cdbf9-d20d-437f-8b94-d3eddff04782	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9e3e2b52-bdef-401a-9188-5302d91c4429	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
9e46e3f8-b7eb-4820-8dc9-fecc3eafb59d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
a0311219-ce14-43b9-8a02-d399a1d6d07e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a046d370-98b2-49f3-acc8-c761677551c8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a0693ce1-b6b5-4a9e-9a51-66f4c189307d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a0793ddc-5e44-4334-af11-e7c24552816b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a08b5f24-0c82-4cde-9a8d-847fd5fe0011	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
a0b97921-0a93-4824-a1bc-55d541875c06	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a10a933a-de38-4edb-94b5-ab9c0b380c0c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a150c636-b0c0-48ad-a9af-555a4d9ff154	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
a181e111-656b-4f72-b610-c3c1ca5e36ca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a1baa4c4-a9a4-4a33-a231-2767b333a036	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a1d726c2-4595-4af4-9551-9e71680324e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a2145f8f-f5d9-4ba1-9527-521eb8295c8f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a2c2d9ef-bb9b-4b69-89cc-d2bff512ac3c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
a33d1d36-87d8-496f-ab20-1dc3e7e366ef	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
a3bf8565-af27-4e29-aa32-61b05c326168	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a3c3d61e-d843-4697-b44e-09080870636d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a3cc9079-cd89-4904-8dbc-92f8f67322e0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
a3e5200f-c0ce-48ef-b49d-5fc145ef045b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a428fd03-b1a2-4186-8481-3d8b083a5712	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a44613b6-f13e-4047-8b28-368226a7da61	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a47a29bc-2c7a-42dd-946c-2d4a198cd16f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a489159e-6941-40ee-a7f3-df2b13764e66	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a4b74aca-8dc9-4c50-ad41-8fad694db332	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a59118ba-7278-40cb-ac5d-127f82a4c0ed	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a616e2b9-eee6-4745-9f6b-05f646209545	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a638defb-5998-46fd-a25f-c491b8fcbf3d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a73bcddb-0d0e-4840-8b3b-364547ae75cb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a7569084-5f1b-43c7-bdc6-08cef2ab6bcc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a7a52a29-78d4-43ce-a211-fda8a401e866	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a8463e8c-9280-4eea-88a7-1017f508a721	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
a8855af9-9992-44cb-bed1-ab6a76ce647f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a8c5363a-e897-4f2e-999b-f68813ca9832	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a8cbfb8c-2c6f-444e-859b-0be6c61a346f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
a9348ac2-7da7-4506-9f4f-9d9911c612db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
a97cc796-7965-4f33-9546-c4057e875d9b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a99f9528-0868-47b0-922f-bb5238c677a9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
a9a9f355-5424-431d-ba48-a7ecab303f05	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
aac6a30e-dacb-4d37-aa70-014bdf58f9f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ab268f14-980e-4b75-a813-9e203cda5667	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ab2e9732-e2eb-4c13-8ff0-93e3cd8b24e7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ab3057a4-f42b-4172-b65e-2b5a2481de5d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
ab77cf1c-a0e2-4927-bf82-e2861755714c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ab8774d8-aadc-434c-ad15-68b36a9c3f42	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
abb426b7-e92d-445b-9df1-1b081dcbbfe7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
abe38f5e-0b9c-4986-bf9a-59401920b1ef	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
ac3e3d5a-5de7-49c2-9d88-321816c60c8a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
ac9f020a-0aa2-4cd0-8d64-48ba8de8ad11	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ad7f6842-104d-444c-b665-fce953797639	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
ad81c775-667e-4693-a2d6-f77e7da4bb77	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
ada5dd59-8561-4ac5-992c-e61e5cd29728	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
af3366a4-72d5-4489-bc7a-3d2b760c259c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
afa773a5-7264-4638-be1a-e1d680f4884f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
afa9e923-1778-4939-ba35-0cc58a4893ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
afaa7987-3cab-4d06-9d8a-4f582298f46c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b0e3412d-e25e-4d22-896e-11ec1e98c1f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b228c88e-5e1d-421b-8997-fb31c5f974c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
b22b876d-e3cf-4024-9c59-6c3aa609d923	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
b23bf02f-615a-45f2-a115-0875d78ca97d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
b23db1bb-86dd-46bf-a2c8-006fdf671373	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b2c327af-b9c8-4877-b3a7-9d38b424b068	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
b2e247a2-4988-40be-8787-6c6d1acb4e63	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
b3a522aa-5b29-4316-a957-c16d11daa974	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b400fd78-694d-4bc0-94e3-aef93429f860	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
b402e80f-c2a7-4905-b0bb-35d4f41a5160	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b5365910-6370-4c50-bc7d-5ba42861e7d5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
b54111e8-816a-40ef-87af-77076dc3c702	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
b548ea77-a42a-4c40-a8d2-715df01e1e36	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b6a3903f-0876-4408-9786-7a31bafc90ab	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
b6f9bb87-f650-4056-a145-a3583273df35	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
b7232cd1-fab1-45ed-aba3-5eec324af431	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
b7a76eae-7ff6-45e8-935a-b60a9a293d82	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b7a7c897-e45b-4abb-ac86-853aca3c18f2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b7d8dc57-9799-4c11-b70a-7624bbb9a533	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
b886fd95-b49e-4caa-bfa0-4726419f98ee	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
b8880208-c229-45af-b81a-2e609cb2ff1b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
b8dc1728-0b7c-497b-be9a-e9ebde9099ad	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
b913e1b2-5568-4f4f-a1ce-68addc98a50a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
b92e605a-19ed-42ce-9fa4-4a86cd853a29	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
b945fda2-ff88-4de9-aa26-bd01df027192	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b99b2656-ecb2-4ecd-b1e7-6ccd240bdc07	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
b99bed84-8e7a-4d13-ae6b-e5b67a6bbadc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
ba4f3cac-6faf-46e4-b0fc-eaecf388d0a1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
ba525038-6de4-4674-9903-693ef26de0a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
ba5c7f56-113e-4578-bf11-937c718ddbe0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
bab1d615-341d-45dc-aa89-561cf4a11dad	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
bae055fe-3046-47f6-86c2-b6ccffef875b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
bb5fab58-0e22-4ae0-80d7-ccfdf00dc3ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
bb66f1b5-b5c6-41d6-8f77-47387bc2e5cc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
bb928c0e-41be-4320-938c-9bf6a100e400	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
bba86c04-54c3-49a7-9a42-359f680c063b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
bcc05030-1339-48c2-8096-ed60bf850edd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
bda7f2c0-1ad3-4236-a5a9-7fda4aa2dd5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
be031422-cbbc-4574-bb8e-962564513a06	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
be333605-d65d-4cad-951a-5de4a354c780	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
be4a505d-a920-4d1e-9469-0467a10d7d3c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
be51d33f-55c9-4168-b99e-21e070a1f091	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
be818a15-b813-4cb0-b840-8371db0a6ee5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bf1b8b06-ed70-4b64-a6b6-709cc4cf14c8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bf3e9dcb-dd97-4519-9c2c-a2fc9c03b5c0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
bf920372-ed38-4544-98da-3e66d47b63bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
bfb7feb9-6dbd-4e7d-9944-f48142e64166	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
bfb88c3c-4032-49e4-b1b1-a450bfec620d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bfcafaa8-b249-4c5f-bdfe-7425ab29dcc8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c0635ce3-9111-4210-bcb8-c4740bd015d5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
c0718507-6fbd-4c87-9471-bfee7d00fb82	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c0a82371-0ac2-4e7e-8628-7c1283c0c16a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c1137606-55f0-44f6-9442-0beacea2e1a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
c16c2273-4f8a-4e95-9f0b-2a0666b9afec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
c17b7df5-5946-43c1-af65-3c1455cddd71	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c19687a0-77e6-4510-99c2-bda2d8266739	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
c19d618c-c924-4fde-a27a-9f9320881edc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c1ce5146-7040-44ad-90b0-eeca8d41d351	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
c1d3172c-5073-467f-a798-303520495fc9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
c1eafbda-29df-4fea-9a57-6cdb3350b010	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c22abd0d-df29-4596-8ff2-3f19a25307b2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c2631256-d0d8-4143-a275-37bf0f98fba4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
c2a14920-6806-4a74-95dc-7d8ef802ef59	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
c2dbb792-e766-4369-b16e-a98ed9bb3749	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c49f225d-f53d-4bd6-b774-d9cfabc5a609	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c53a92ac-3085-45f5-8e1c-20e2780362e5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
c588b148-8a5b-4e55-9b33-4d079b677a51	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c60c9844-5ad3-47d4-9916-2d90857a8e2f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c6439ff7-b258-4e27-ac99-e2708292b1a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c66ce7b9-981f-4377-b6d4-d934e170be1c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
c6d5526f-b967-493a-9359-0db63e1a5dbb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
c6eab2af-fe45-43f7-bbe5-265f0e57e365	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
c6edcff5-056d-42ac-a533-5c0b97d35c93	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
c73f703f-1eb3-4c01-b89b-28616219f679	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c76c3777-b071-4f66-9ed9-f706dc08a986	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c7743a45-4744-4fee-abd6-749e4cb6dec7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
c7749d41-69ea-477c-8db9-9c2b76532b6d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c7d0c153-90e5-4ccf-a985-b91aa7e2d3f4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c813042c-4d5d-4e26-b118-e0129ee516ad	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c81834ad-9dca-41eb-a7f6-826936c048ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c8321521-c9d1-431f-a7a4-2099689ca397	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c84aba4b-6edb-4765-bdda-ddc0bd9d1607	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c91cb4a4-8d87-4325-bb97-f260ef21fe37	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c952efa0-f20b-46b0-a7a9-79d869a3c2f4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c969cd7f-adeb-4949-ae60-307da5a78e17	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
c9a3334e-dba5-4d96-9f01-2a8a6de39126	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
c9d126a6-5fdf-4fb4-9e96-ef542cdcbc00	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
c9f89b9f-11b0-4f77-8cbe-3c73ac8e15f5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ca0d5177-387b-4b31-988e-309efa017baa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
ca4b5ec7-23df-406f-a11e-563e880478f5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ca9c56ca-a8d5-4014-89de-951d84a63782	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
cac423a7-2014-406a-94a2-27df47d1c111	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
cb0f1102-1262-49e9-9a2f-99d4cfb0f9f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
cb2aff3f-3b5c-483e-97db-ef2a59910b41	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
cb3e0fbb-9981-4d13-b39d-2e6b73031d60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
cb41d02f-8769-424f-ae2e-ed628942fe64	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
cb7181db-e026-4509-81c1-55c8703daaaf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
cbb8dd93-2d98-4537-a2b1-e83fc523ed61	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
cbcae438-b3a0-450c-b26f-f8c73a17b827	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
cbcf17e1-46c9-4630-95aa-9524de84bec0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
cbe56a81-b84e-4ecd-a92d-0bb6db33ed5a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
cc02ff07-adf9-4fbf-81a8-942d60e0a272	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
cc5ea304-56c4-4885-82d3-54026cd6b8df	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
cd98d5a3-5a85-4f50-96ff-f6b68a234a86	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
ce51f207-5b2f-45f6-a5ee-5dc22a435308	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
cea95697-a469-437e-a6e9-b757380a9540	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
cf2aba3c-89a8-4939-bfdb-56ef9e6dedb2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
cf57d1cf-3f74-49eb-93b5-e35839af61d2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
cf68ae21-1736-4ac6-87e5-4a9100a2de99	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
cf7fe65f-e998-4b03-aef6-17e73de58822	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
cfa0deb3-2816-462d-b623-53b917b007fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
cfc150d2-091a-4476-a577-b5d710ee4457	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
cfd05b45-3af0-4591-a940-eea89dd12904	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d00047ee-1d04-4835-923a-4c014b6534bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d014056c-4543-477e-a158-550ff3fce85e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d0d2cd14-5ad6-4dcf-a23e-787a836402a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d117f4dd-5f3f-46ba-81e6-6662afeab8db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d1b0f7e1-2d27-4d16-b5d1-fb5775536618	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d1bf373b-efae-4684-80aa-1ca75e8727c4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d1dc249f-d6f5-477e-bc02-a84ac046d638	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
d2344e8f-4bec-4dc8-b3f2-6fc10ceed1bb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d27e3b52-4ae4-4279-ab19-560706df3935	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d2b8731e-10dc-47c1-8640-26933cc49002	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d2b971db-d426-48e2-9623-abde2d851805	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
d2c56c8f-1d77-4546-a20e-541f8d003af3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d33675e7-ac5d-4147-adc5-a234a3f0f8be	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
d352d020-316e-4c3b-bd7e-bbc5d71c8aa4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d3caa5e0-e761-4c49-9a20-7df643f0e7d0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d3dce79a-360b-4479-bdde-ff3f9442084a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d4983da5-4fbc-493a-9ede-9791cddc4cbe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
d498ef59-b490-483f-8a0b-c03b7a07ddf7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d4b46ea7-d927-4538-b127-3dc6ab182d29	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d537d21b-c573-4f53-a364-2bd4015dd909	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d55da344-75d4-4a0e-ab3b-5cabb9cfb8c4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d5678be2-d1fa-4b39-8dfa-6118df7d66d6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
d5b13b87-0074-42cd-9f81-0d751443a2b2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d5bdb749-1b0c-4976-8672-f81387d746a0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
d60d7fb6-4890-42c6-8293-54aa6054cd60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
d634399c-638d-42ff-beb4-9698d82e1efe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d6a7cae0-e86c-4f3f-a4f2-f4249e75a646	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d6af748d-9d07-4dbc-abbe-fcf8e98c2f4b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
d6c13537-3d08-4775-b7a1-f59837aa2b0f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d6d63c3e-881d-4d90-ba97-9295b699656f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d7010a6e-8f02-4877-a9ce-e1a63fff3800	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d75277f5-8178-495a-8d4d-6a7ea1165d21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d7554821-2564-4743-84c5-d821defe5421	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d75b048c-873d-4775-b92b-44ea3b3c6fc7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d76bbb52-12f7-4a8b-920f-c1ded3d61ffb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d79ddbbe-abf7-4f1b-aed2-569a35e170ba	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d809619f-194f-4ddc-a99f-b26195fc87e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
d853c8ab-1105-451a-a265-50dc45042680	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d86294fd-6726-436e-beb8-c4471d42eb9c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d88bd0ec-10b1-429c-99a1-a10a20372c4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d8cf8a1d-5068-4f61-8fc4-b42095ed7133	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d9511978-8813-463d-9b56-6aca62ac0be9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
d956971e-78ca-4366-af58-449df2a598de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d9831ade-5df3-4b71-b9eb-2af94f755a66	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d986f141-138b-4cf5-ac02-e941f670a312	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
d9aee84e-be88-43c5-8854-5e9811273f5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d9ea656e-bcaa-413c-862e-2814e75d6e94	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
da002224-3b3c-4b8d-a2bb-d11d13dc5039	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
da07f63d-e317-4df2-a74c-f4acb42d271d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
da47edad-e4f2-4e15-bdf3-877a7ab554e8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
da667927-9db7-4abc-ad71-c1e60476ae21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
da70497d-e5fd-4576-9a0f-61ddd80a257e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
db00a3cb-2c94-4456-811f-57cf9f8ae192	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
db325028-0078-48c9-a4ff-db6cf1e11ecd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
db551f42-226b-420f-86d5-54bb085df3d1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
dc043430-214d-4fa7-962f-73fc3e889254	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
dc06803c-2b44-41f4-81e5-5edda797a5ba	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
dc09d0ac-fc88-4b03-a976-dfe9ed52a042	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
dc4244e4-aa9c-404d-993f-c83a9fc9c03f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
dd00b16a-79d0-4ff6-b676-c359d5726731	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
dd825961-ded6-4197-bf1f-4d01f58d4cc3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
dd84e84e-cc59-4f66-bcbb-237b5903c24a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
dd8cf9f6-8483-42e8-a372-b0900b045bc7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
de0f8585-e0b9-4603-8c0f-8fd7d3cc3c25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
de45dd78-3b49-410c-8935-57c87f195d3b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
def55476-d692-4d63-80b8-3fb818f3905c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
df443b8f-8f40-45ac-866d-a5bbbcd15708	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
df7a8ffe-68f6-4d93-9fbc-fb43ece55f49	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
df92fb66-ebd4-43b9-b235-e526affdfa8e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
df930e2c-2b8f-40d6-9ddb-792416f0eee3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
dfae20b0-12c9-44d8-bbbb-e2265417f915	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
dfb084c5-dadc-4df5-a9f5-eb08ee0fb0e5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
dfd41cc8-c482-4281-baaa-99631dc70e39	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
dfda6bd0-dcc9-4790-bc96-c1c1db60ee01	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e046e8ca-8e36-41b2-b8c0-61c5e5c4353e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
e09fd8b2-fbaf-4689-90a7-68c058e0e815	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e0da04ad-f74e-43a9-b1bc-97d3cd8d93f8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e0ea9720-0bfa-4146-bdf2-906324052e0f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
e0ecf6ef-a545-4a69-811e-57c8101981ca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e16a3a83-3090-471b-9020-472b3f72f881	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
e16e255d-1318-4d5d-9717-cbb4ef42beb7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
e183d0f3-f079-4fbc-aad5-61e199414fc9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
e183fa5c-22a6-43ec-843c-770d8f178228	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e1d6f575-7727-441f-b011-6888aa678987	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
e1d81203-a9ae-4824-a1ec-8f5ec68283e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e21a2563-cf67-4b86-a483-c4941c56262c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e23f72e1-adf2-4e30-b84b-322bbb15c8bc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e2d6a611-440f-41a9-9af9-dc69c4d4f6f9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
e33cd072-0094-4642-9f1a-d0218b76ce3c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e34b9f0a-df69-4ced-9494-9d0e487febd6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
e395952d-5087-4a8b-92fc-d646e4180f96	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
e3b54620-06b9-4405-8108-e3b16f6af470	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
e422d675-a8be-4711-ba8f-444da8a384f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e45231c9-fb69-403f-9c9f-9d050218c094	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e495f018-f7b7-4e5b-9b00-f352bbd3e6c0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
e4acb0e4-65ea-40a2-a698-931a34f69e91	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e502c7b4-4efc-4455-9381-4e0f9b680c55	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e53347d3-af60-43a9-9653-03474f6a1794	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e54bbaf6-42d5-4c87-9b2e-8add5f588885	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
e6265ce5-2965-45f5-9f2f-7a01df6cd938	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
e67d5cb8-193f-4155-9dcd-daa28027ca60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e6a26d9e-1b8e-4369-a04f-e6e85fc99802	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e750f004-a00e-497c-b73b-19dda8b74dc5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
e7721129-0f1b-472a-a3b2-a42f0e406b45	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e779c15e-d14b-416c-a953-af412dbaef5a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
e781ecc7-541d-4fe5-81f9-5f9c4694442d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e7b73b0a-2253-4bda-bab3-29350f7bd2c0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
e7b78a54-ca5b-462d-b837-9b22dd19ddc7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e7d62afb-1251-4d32-9b13-2cb9ba4379d4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
e7db4945-65b0-4c33-a78f-c0d301cc2a6f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e7e2728a-5738-445e-aae7-ee411234b01c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
e8d88117-3ed9-4c2e-8678-3ec723d6de8c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
e91bb6a9-8b46-4c26-94c4-852eb7523a5a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
e9b532be-6481-4f19-8d7c-ecc97dbd38d9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
ea036427-319f-4ead-878a-cf3b3a7cd436	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ea1d8e85-0aef-4c4e-8612-d1b5a44cc0ae	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
ea4212a6-8f6e-4600-af3a-f2ea5d7d08f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
ea962e23-1622-4c53-93ab-f08561f61b75	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
eb1481ab-965e-4948-8ae7-5b7bc265eae8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
eb220dba-caf7-4c71-87e8-6720587a735b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
eb96c713-9026-437a-a44f-df9a4800fd1e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
ec699cfa-5076-4ffb-97c8-88d2e450eb07	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ec857114-6a75-4139-813f-c1a45f2cec97	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ec8c636e-ff94-4ec6-a5b5-1515cc9a4a86	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
ecb95c83-1215-40de-911c-e7150f7ce4d4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
ecda8644-5a58-4346-b721-5f073d8ae1ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ed0cd897-01e0-42e5-94f7-cca9ff7150bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ed52d2c9-ab44-428f-8b86-77c46be270d9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ee034783-e989-406c-9da6-671f5c1a4391	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ee38d0c1-7507-4cb4-9b4f-52c0284f1ea8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
ee3a7f2e-13f3-4bae-ab4d-2e1da72140bb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ee8869a0-1fa5-48e4-b713-105ce907931b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
eecc0b07-f604-4a25-8175-ab08f814fb88	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ef51c907-fb88-45fe-b011-19b203da8555	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f007a247-3b8f-400e-8d4a-3df742cfef63	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f0354d7b-f7cd-4a86-8d8e-be6e026932c7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f04cb846-5ec0-42a9-ab9d-854c0bf40027	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f1c95c8c-a03c-4200-b866-a2bf818e8eb1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f1dcdcf1-8b56-4700-9123-02f8f26304c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f220f9f9-2fa4-4a22-9ead-6fc6bbdaa7ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f24d772c-1256-4a73-89ac-d4df4b77e979	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
f282f010-3a6a-4a8c-81ab-28740b683c3e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f2aef371-6ce1-45ef-9d15-675b17c08b63	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f2cbd2fe-84c7-4c5d-bc27-41a2106feb3f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f2dc1155-dab6-46d8-b6c6-026cb343a953	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f2ede9d7-1476-4f9a-b7d6-f5622f26910c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
f2f5a0b3-d0ce-4c6b-99fe-013876234c13	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
f3497f14-67f6-4922-99a0-00d69a4aa7fa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f3536394-04a5-4c72-b5ef-04980bc5f39e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
f35ac4bf-83ac-4e71-aa2c-690a8dec4c68	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
f364a8f9-bb51-4ee2-a849-3926bc26755e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
f3aeead7-f98d-4da8-93f5-2c8aa4d14332	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f3b04499-b8fd-48c0-b95f-d203fb6f46fa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f3df0d2d-3e95-4937-a68b-6823940b71c9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
f4ef5c85-4dd3-443c-b751-d7ff2a561446	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f50a72fd-55c3-4171-9c0f-4008cffebdcc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
f54b8633-c224-4644-b4c2-70c0c24e6115	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
f57af26f-33c4-43b9-b56f-58849ed2ee36	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
f58e3914-b02f-45a4-a2fd-aca826b79faf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f5917874-1d3c-46d1-870e-4bdcf5654667	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
f59a8008-1168-4409-94a9-1a3922ed119c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
f5d63f39-df24-45ed-b27e-de88aaa63f3e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
f5fa15fb-0749-42ec-8d7e-618024dd63d9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f69d1747-bc6c-485d-a617-773c532379cd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
f6c91cc8-611a-40c6-9bcd-a631f2f77bb8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f6f57dff-5ab7-4628-b8c1-205b9d98c578	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f7029b0b-bf0e-4206-b5c3-1d9dc617dde7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f725bf21-1a69-4f09-a4a4-6c7248c5b40e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
f7517c14-80df-4fb8-9d00-3d333f77aefc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f7b14fed-0042-43c7-84d6-b54352899f0c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
f7d981a2-e080-436e-a3f7-a247623c70dc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f8415ea1-4545-4c46-b023-ebc4d60248e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f854ce34-a838-4af2-a4ba-9c7ef1b7a74c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f8f8814a-8eb2-45bd-9fde-1a900e04c341	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f9004ba2-385d-49ce-9c43-508b5f8d1897	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f90206e8-259e-4a20-b9b4-7c03163980f1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f939017a-fa2a-4f43-85af-c1960526f02d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f9609dd2-f7b3-47c0-9e02-f4b3c0128587	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f9825e3e-4043-4a11-aa53-173dd3a8055a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f9941089-ab89-4005-bfe5-82d347dcce99	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f9cb7dd5-9402-4084-abaa-1c0378eeb14c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
f9fdd998-8730-44ca-a55c-e58d77113a29	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fa406063-2384-4ffc-97d8-bd6bd0ad335c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fa78481f-710c-4769-9874-5fa6b34054b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
faa53e21-4069-477d-a738-686f349f0101	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
faef6405-b9bc-43f8-aaf1-ccbc6f553d7d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fb0213ad-2c93-40c1-a7a5-5a5d986f3b70	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
fb1bac98-76f7-4600-a677-66e3082dc8ab	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fb54472a-9c43-41b9-a243-3cc3c87ab988	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
fbb7426c-d4df-4b09-abc9-ab0d2d34fd80	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
fbd48145-d627-4ce2-87b3-ac70386599d3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
fc1292d2-ed66-4775-b542-9d3db0ed0613	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fcb899fd-b1fb-416b-9ef9-126f25829256	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
fccc9593-ebe3-4cd7-a813-c64efea13ebf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fd219e40-45cd-4a20-9cc6-4696ec3c24e1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
fd86077f-d3a3-4230-a03f-544d75a8ddee	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
fd9280e9-a14b-47a2-9b80-43442a350126	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fdabb5b0-621a-4f58-b1cc-617e2d7eb8a7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
fdc21d01-1ae9-47ee-bcfe-3b7f49a15535	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
fde08642-1f37-48ef-b70e-2f8d28dbd5b1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
fde8246e-9863-49b4-b281-6ee99a74712d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
fdfbd328-9706-417a-b9fc-12543bcc1b9f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fe1a4764-c269-4170-8f92-970b5627bbe7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
fe5537ca-4122-4990-999f-819e62d109d3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fe66b2e2-afb7-4d19-b373-52d57b7c625a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
fe7ccd09-d818-4c9f-91d8-25b1ca2ca8a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
fed30a4b-ba47-4920-8b49-9035a9846d25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
ff1cd298-8567-4814-b674-13c15d1fe072	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ff3954ef-937b-4317-a827-d1b62d37fa16	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ff46fee6-6661-4175-ad7a-74819d26dbd3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
ff6be757-2f23-4714-a1d9-66738682c37d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
ff7520e8-a14d-4832-abba-7d12b0da24de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
ff78320c-377f-4969-8d3d-15c4251e49a1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 21:46:22.74246+08	2026-01-02 21:46:22.74246+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
\.


--
-- TOC entry 5216 (class 0 OID 26483)
-- Dependencies: 226
-- Data for Name: base_equipments; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_equipments (id, name, rarity, is_unique, equipment_type_id, health, damage, smithing_material_id) FROM stdin;
1	Iron sword	1	f	1	\N	\N	1
2	Iron axe	1	f	2	\N	\N	1
3	Thunderfury	4	t	15	\N	\N	11
4	Iron armor	1	f	28	\N	\N	1
5	Iron gloves	1	f	26	\N	\N	1
6	Iron helmet	1	f	27	\N	\N	1
8	Iron boots	1	f	29	\N	\N	1
\.


--
-- TOC entry 5218 (class 0 OID 26495)
-- Dependencies: 228
-- Data for Name: base_heroes; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_heroes (id, name, rarity, is_unique, main_stat, health, damage) FROM stdin;
1	Warrior	1	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 24}}	\N
2	Huntress	1	f	2	{"damage": {"c": 5, "s": 21}, "health": {"c": 10, "s": 28}}	\N
3	Hammerman	1	f	1	{"damage": {"c": 3, "s": 25}, "health": {"c": 11, "s": 39}}	\N
4	Rogue	1	f	2	{"damage": {"c": 4, "s": 23}, "health": {"c": 15, "s": 21}}	\N
5	Battle orc	2	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 58}}	\N
\.


--
-- TOC entry 5220 (class 0 OID 26508)
-- Dependencies: 230
-- Data for Name: creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.creature_types (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5222 (class 0 OID 26514)
-- Dependencies: 232
-- Data for Name: damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.damage_types (id, name, name_ru, dev_hint_ru, category) FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)	1
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 	1
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)	1
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда	1
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"	0
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."	0
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."	1
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."	2
11	Radiant	Лучистый	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."	2
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."	2
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."	2
17	Dark magic	Тёмная магия	Критерий\tНекротический урон\tТёмная магия (Shadow/Dark)\nСуть\tРазложение, смерть, конец.\tСтрах, боль, подавление, коррупция.\nИсточник\tСмерть, небытие, пустота, анти-жизнь.\tОтрицательные эмоции, тени, извращённая магия, пакты с тёмными сущностями.\nКак выглядит/ощущается\tХолод, влажность, запах тления, серо-зелёные тона, иссушение, гниение.\tХолод или ледяное жжение, ощущение ужаса, давление на разум, чёрные/фиолетовые тона, искажение света.\nЭффект на живую цель\tВысасывает жизненную силу, вызывает быстрое старение, некроз тканей, разложение.\tДробит волю, наводит ужас, вызывает боль, ввергает в отчаяние, может подчинять разум.\nЭффект на нежить\tЧасто исцеляет или усиливает (это её родная стихия).\tМожет наносить урон (как любая агрессивная магия), а может усиливать, делая более агрессивной.\nЭффект на демонов/исчадий\tОбычно эффективен (смерть для всех).\tЧасто неэффективен или даже подпитывает их (они сами из этой энергии).\nТипичные заклинания\t«Палящий взгляд», «Круг смерти», «Вытягивание жизни», «Увядание».\t«Стрела Тьмы», «Объятья страха», «Проклятие боли», «Порча разума».\nАналогия\tРадиация или смертельная болезнь. Убивает всё живое, разлагает материю.\tПыточный инструмент или психологическая пытка. Ломает дух, чтобы сломить тело.\nЦель атаки\tТело и душа (физическое уничтожение).\tПсихика и дух (ментальное подчинение → физический урон).\nАрхетип мага\tНекромант. Холодный учёный смерти.\tЧернокнижник, Тёмный колдун. Эмоциональный манипулятор, заключивший сделку с силами тьмы.\n	2
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."	0
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."	0
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."	0
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."	0
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."	0
\.


--
-- TOC entry 5224 (class 0 OID 26524)
-- Dependencies: 234
-- Data for Name: equipment_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.equipment_types (id, name, name_ru, mass_physical, mass_magical, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, spend_action_points, block_other_hand, damage) FROM stdin;
1	Sword	Меч	1600	0	1	t	f	0	\N	{"c": 8, "s": 4}
2	Axe	Топор	2800	0	1	t	f	0	\N	{"c": 4, "s": 17}
3	Halberd	Алебарда	4400	0	1	t	f	0	\N	{"c": 4, "s": 27}
4	Berdysh	Бердыш	3800	0	1	t	f	0	\N	{"c": 4, "s": 23}
5	Poleaxe	Секира	4000	0	1	t	f	0	\N	{"c": 4, "s": 24}
6	Chakram	Чакрам	350	0	1	t	f	0	\N	{"c": 5, "s": 3}
7	Shuriken	Сюрикен	180	0	1	t	f	0	\N	{"c": 6, "s": 2}
8	Scythe	Коса	3200	0	1	t	f	0	\N	{"c": 5, "s": 3}
9	War fan	Боевой веер	800	0	1	t	f	0	\N	{"c": 5, "s": 3}
10	Scimitar	Скимитар	1200	0	1	t	f	0	\N	{"c": 6, "s": 4}
11	Katana	Катана	1100	0	1	t	f	0	\N	{"c": 7, "s": 3}
12	Yataghan	Ятаган	1000	0	1	t	f	0	\N	{"c": 6, "s": 3}
13	Sabre	Сабля	1100	0	1	t	f	0	\N	{"c": 7, "s": 3}
14	Morning star	Моргенштерн	5000	0	1	t	f	0	\N	{"c": 1, "s": 123}
15	Warhammer	Боевой молот	6200	0	1	t	f	0	\N	{"c": 1, "s": 153}
16	Mace	Булава	3000	0	1	t	f	0	\N	{"c": 1, "s": 73}
17	Crossbow	Арбалет	3200	0	1	t	f	0	\N	{"c": 14, "s": 2}
19	Trident	Трезубец	3400	0	1	t	f	0	\N	{"c": 28, "s": 2}
20	Rapier	Рапира	850	0	1	t	f	0	\N	{"c": 8, "s": 2}
21	Pike	Пика	2800	0	1	t	f	0	\N	{"c": 24, "s": 2}
22	Spear	Копьё	2200	0	1	t	f	0	\N	{"c": 20, "s": 2}
23	Broadaxe	Широкий топор	5200	0	1	t	f	0	\N	{"c": 4, "s": 32}
24	Dagger	Кинжал	400	0	1	t	f	0	\N	{"c": 4, "s": 2}
18	Bow	Лук	960	0	1	t	f	0	t	{"c": 4, "s": 2}
26	Hands	Руки	1240	0	7	t	f	0	\N	\N
27	Helmet	Шлем	1240	0	4	t	f	0	\N	\N
29	Boots	Сапоги	1860	0	9	t	f	0	\N	\N
25	Waist	Пояс	2170	0	10	t	f	0	\N	\N
28	Armor	Доспех	2480	0	6	t	f	0	\N	\N
\.


--
-- TOC entry 5226 (class 0 OID 26544)
-- Dependencies: 236
-- Data for Name: material_damage_percents; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.material_damage_percents (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5228 (class 0 OID 26552)
-- Dependencies: 238
-- Data for Name: slot_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slot_types (id, name, name_ru) FROM stdin;
14	Ring	Кольцо
16	Trinket	Аксессуар
1	Weapon	Оружие
2	Shield	Щит
4	Head	Голова
6	Armor	Доспех
7	Hands	Руки
9	Feet	Ступни
10	Waist	Пояс
17	Neck	Шея
\.


--
-- TOC entry 5230 (class 0 OID 26560)
-- Dependencies: 240
-- Data for Name: smithing_materials; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.smithing_materials (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5232 (class 0 OID 26568)
-- Dependencies: 242
-- Data for Name: x_equipment_type_damage_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_equipment_type_damage_type (equipment_type_id, damage_type_id, damage_coef) FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5233 (class 0 OID 26575)
-- Dependencies: 243
-- Data for Name: x_hero_creature_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_hero_creature_type (base_hero_id, creature_type_id) FROM stdin;
\.


--
-- TOC entry 5248 (class 0 OID 27014)
-- Dependencies: 258
-- Data for Name: auth_reg_logs; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.auth_reg_logs (id, email, user_id, success, version, created_at, user_device_id, ip, action_is_authentication) FROM stdin;
71a71144-316b-4530-8fcb-ab9307943346	SUPERadmin@mail.RU	\N	t	1	2026-01-02 00:11:42.371645+08	\N	::1	f
09813629-2b45-4230-b8ab-4dc92468578b	SUPERadmin@mail.RU	\N	t	1	2026-01-02 00:12:35.714515+08	\N	::1	f
3d9bd4f3-612e-46d1-8b28-84b484c8a6f5	SUPERadmin@mail.RU	\N	t	1	2026-01-02 10:52:16.837456+08	\N	::1	f
8fc23f7f-6904-49a0-bc30-fc3156f7656c	SUPERadmin@mail.RU	\N	t	1	2026-01-02 10:57:55.461398+08	\N	::1	f
ea4e7f09-fe44-44f1-b2ae-9807b0809cb1	SUPERadmin@mail.RU	\N	t	1	2026-01-02 10:59:42.158534+08	\N	::1	f
92fbd663-1ae8-41ba-a0fe-fab900402652	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:32:43.559755+08	\N	::1	f
23176af5-6d33-4cd2-974a-146fdfd3752a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:32:53.585177+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6ca8bd58-abe7-461d-9aa5-9362d7d0b972	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:36:08.552296+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2bb2682c-112b-40d4-a3c4-4ae68af98748	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:37:03.563437+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cbcb5337-be48-411c-a96c-58a48f700294	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:37:53.549686+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
57aab23b-8eab-413d-b5aa-7c4dd27e7b36	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:39:08.563693+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
492c2e49-c016-4aa2-9e03-081de2bede86	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:40:03.553397+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e8d451ef-b8df-4181-ab81-030cb03dd262	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:41:39.44512+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0188d17d-bc85-4074-9e21-364fa12166ac	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:45:04.339918+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2de1ef76-1d59-4952-9ce5-0f27f4383ce6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:45:22.17775+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cbb3d23c-a7ad-4c97-94b2-5f88675d5cdb	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:45:57.121681+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
560c5a21-3626-46b8-b47d-babb6b868119	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:46:12.080752+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
39167e3a-120b-4ab2-8c11-fd476b200508	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:47:25.893726+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
363c7ea1-6a15-45ba-a8cb-86589869f1cc	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:48:00.807997+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b6a74205-b6e2-445c-b2f8-c79db7185e8a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:48:35.770324+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9ce3acfb-690c-420b-bab1-e9ffead31b28	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:50:05.776837+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
40eaac14-3e5c-40cd-aae1-c82ca3e7e6eb	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:50:20.770259+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e2b67c45-5784-4f1e-a197-212206e87f76	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:52:00.774426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1bc76057-a9dd-4d6e-8445-b94edc948c9a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:54:41.936821+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
df87a4a4-485a-421f-bc3b-895bf32adf4e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:55:11.853077+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
72c54948-2d12-4404-8b77-64624f76868e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:56:21.835368+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2eb2fd7c-c4ae-4d36-b5cd-51490c70d89c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:57:58.693925+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ab2c2c03-de76-4239-b1e9-392e4ccc7eb3	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:59:13.582034+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
93e785ab-4bbf-47b3-a757-f7e0d5a9d636	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:02:01.383439+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
25478e51-c95d-452f-8739-70c92b81f0d5	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:02:41.154421+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3226b745-f503-4d6f-952e-0c0170f30644	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:37:18.452495+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
af23cd4c-746e-49c5-b790-6f6613abe9da	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:44:07.479777+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
dc709891-0755-417b-9c42-31c614a9fcfd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:45:50.837765+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9e055232-2f19-4001-ba5b-49b0d9140850	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:47:56.707208+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0a7e545f-9235-4dd1-91d0-7380e3e52bd4	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:50:42.312118+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6f29a4cf-e079-476e-b646-3d13d9bfa846	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:50:52.225168+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0ed64679-9004-4224-a672-0dd67bb9981c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:52:51.644232+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7695a98f-3441-434d-94cf-24a5465ceace	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:54:11.576177+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6328ccac-08de-48ab-9c14-7d96b93c5727	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:55:37.370762+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d3b3c019-86b0-4482-9046-a35b3a72a07a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:56:02.296767+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
22515d44-c94c-40ad-a9a6-1dc5f3bea743	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:59:51.790728+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
815c581b-372f-4d1b-ab9f-9ea3459d5b14	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:02:07.220659+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
544fdae5-e6b1-4305-a2a0-309e9bb3dd03	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:03:21.837268+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4fa4d608-b6d6-4f73-bc1a-2060463afa29	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:04:16.875283+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8806f029-e83a-4939-a6e4-616fac452b11	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:16:05.441375+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3ba3f347-a050-4714-bb83-1b77009be694	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:23:00.648812+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5ac1e580-bba1-4aec-b537-c7671ae48714	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:23:20.479146+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
dfa47a1e-12ec-4b37-abb7-41bb15db066c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:24:05.457418+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1487db39-4650-47e5-affa-da4ac8c8c845	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:24:25.448785+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3fd37551-2384-46f4-bfdd-bc7f5993a9af	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:25:25.462777+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
52a57ac6-f0d5-4fcf-93c1-7b9825d7b5db	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:26:00.455459+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
69353c7a-ad32-4922-a39e-c0a99902dc7e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:28:33.285147+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1da1fab6-c3fe-43ac-b49a-fe80683dc4fd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:28:48.19455+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
144b6c9e-4288-4962-8c74-12d1d03557fb	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:30:51.830137+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b86b59d7-26c1-48b6-a516-d76e79adb503	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 16:32:59.299886+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
bf7b00b3-4e8d-4798-bf4f-386d4581a931	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:55:08.509977+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ee46000a-323d-4d2c-9f93-8ad5c6f2a408	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:55:38.457619+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d846d533-47e0-4065-9bb2-e98271996256	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:55:58.433802+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e98529e9-56e1-414a-ae1e-8caa7603b482	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:57:33.42592+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6b4138f8-4c51-4473-8d97-102d4ef996dc	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:58:53.429441+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
34eb07cb-c183-408e-bec7-fcc17654dcb1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:59:13.423363+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0f751873-6309-4be2-8b8d-fb40f715164c	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:00:58.42813+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ae101342-f230-4e50-84e7-468f679d5f99	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:06:13.914208+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0509d1ee-fd4f-40ef-a3b0-42caa442ae32	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:08:20.594881+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3ffb6602-bcf6-4dd6-b5a5-e7e8f31b5924	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:17:15.522619+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
91a3e543-12a5-4a7f-8eaa-79d5293e14f5	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:22:25.485956+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3d55943c-f4b4-4386-ae9f-a17686094a50	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:24:05.49302+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c64d4b8d-76d3-440f-8f00-fb878cddbabc	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:29:00.49528+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
684a4515-ecdd-4dc5-ab10-981034b09132	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:31:20.49667+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ac4c50b8-2d05-49d2-9569-65b8e651bfa7	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:32:00.486618+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
239f2563-a2a3-4538-b42d-662e8f1f8d7e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:33:25.485896+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d5faab10-4135-4f7a-8f3c-4f19f5ee1b66	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:46:30.485642+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c370e45f-d8cf-40a7-8f39-ba827542a98c	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:49:00.484928+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cbb087f8-17c8-4ed6-99f2-6a755594f5af	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:49:35.492159+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a7510f49-fbe1-4f64-8cd3-9554daaf1e2f	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:01:05.52426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
16a3e5e5-c221-4ec1-ba92-e8ec557b77e6	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:10:30.488393+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6d45ac55-380c-4a05-b42e-8e727a92ed8e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:11:20.488928+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
157228a0-096e-4019-8572-3031399c8001	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:12:20.48864+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f54e8842-677a-48cc-bb76-c96b9f3095d5	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:12:50.489775+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
404faa84-c533-455b-8554-b752b19ff06e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:13:35.493181+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4b2dd22e-2a65-4e53-a70c-c920510a0301	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:14:10.492961+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c55adc8b-073a-4fc9-8309-b214bfbc3334	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:16:00.482302+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
04ef5169-0b9f-43b6-af85-d1cfb9bbaa47	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:16:50.496701+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9a14c9d7-d9b3-4a32-a9ff-37bca6220dde	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:23:40.495151+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
17061018-3419-415e-9e59-95eb220f0a72	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:26:35.492572+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4202f9c3-d49e-43e4-9659-b8b181a5e850	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:42:40.487852+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2033f071-a874-4016-a70d-5df5ececf81b	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:45:19.77623+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
39c04f76-f8cf-446b-a83a-98497e8071e8	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:55:37.545692+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
bc6623cb-528d-4612-b158-c030ae5cf836	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:56:42.44766+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
fb168619-5be3-41aa-a98d-d1446e773f0a	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:59:22.995494+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
87bad630-cfd0-4bec-beff-51cd39a04aa6	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:00:22.919556+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8c546c3e-0eec-4f8e-9a7b-8105b8064a9d	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:02:42.881803+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d1d75a6b-2eb9-4749-a534-08f88819a0b0	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:05:12.891581+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d85f3965-b4a6-446f-a1fc-dc432f23ad28	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:07:22.896553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
60f1f354-ed8d-4f75-acc1-17f4fb2ced75	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:15:42.892882+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
de822b78-b7bf-4fbb-a67e-f2f7a3070065	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:18:57.88284+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
293e3304-0f21-42bf-bbba-4bf1ddc108ec	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:20:42.88661+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f86daf09-d574-4cb4-a815-9d548c6b7575	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:26:32.890176+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
31ea6688-6d99-453b-b86f-1a80f4361e84	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:47:23.409136+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
\.


--
-- TOC entry 5234 (class 0 OID 26591)
-- Dependencies: 244
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251218141532_Init	10.0.1
20251219010850_Fix1	10.0.1
20251219104853_Fix2	10.0.1
20251219125100_Fix3	10.0.1
20251219144649_Fix4	10.0.1
20251219145307_Fix5	10.0.1
20251220111640_Fix6	10.0.1
20251220140152_Fix7	10.0.1
20251221062947_Fix8	10.0.1
20251221115503_Fix9	10.0.1
20251221115727_Fix10	10.0.1
20251222005509_Fix11	10.0.1
20251222005528_Fix12	10.0.1
20251222012124_Fix13	10.0.1
20251222014603_Fix14	10.0.1
20251222032345_Fix15	10.0.1
20251222082512_Fix16	10.0.1
20251222142042_Fix17	10.0.1
20251224050619_Fix18	10.0.1
20251224060154_Fix19	10.0.1
20251224071911_Fix20	10.0.1
20251224075948_Fix21	10.0.1
20251224084507_Fix22	10.0.1
20251224125003_Fix23	10.0.1
20251229100603_Fix24	10.0.1
20251230112703_InitIdentity	10.0.1
20251231063604_IdentityFix1	10.0.1
20260101132651_IdentityFix2	10.0.1
20260101140259_IdentityFix3	10.0.1
20260101154436_IdentityFix4	10.0.1
20260102073949_IdentityFix5	10.0.1
20260102074626_IdentityFix6	10.0.1
\.


--
-- TOC entry 5235 (class 0 OID 26596)
-- Dependencies: 245
-- Data for Name: user_ban_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_ban_reasons (id, name) FROM stdin;
\.


--
-- TOC entry 5242 (class 0 OID 26875)
-- Dependencies: 252
-- Data for Name: identity_role_claims; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_role_claims (id, role_id, claim_type, claim_value) FROM stdin;
\.


--
-- TOC entry 5239 (class 0 OID 26852)
-- Dependencies: 249
-- Data for Name: identity_roles; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_roles (id, name, normalized_name, concurrency_stamp) FROM stdin;
\.


--
-- TOC entry 5244 (class 0 OID 26890)
-- Dependencies: 254
-- Data for Name: identity_user_claims; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_claims (id, user_id, claim_type, claim_value) FROM stdin;
\.


--
-- TOC entry 5245 (class 0 OID 26904)
-- Dependencies: 255
-- Data for Name: identity_user_logins; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_logins (login_provider, provider_key, provider_display_name, user_id) FROM stdin;
\.


--
-- TOC entry 5246 (class 0 OID 26919)
-- Dependencies: 256
-- Data for Name: identity_user_roles; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_roles (user_id, role_id) FROM stdin;
\.


--
-- TOC entry 5247 (class 0 OID 26936)
-- Dependencies: 257
-- Data for Name: identity_user_tokens; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_tokens (user_id, login_provider, name, value) FROM stdin;
\.


--
-- TOC entry 5240 (class 0 OID 26860)
-- Dependencies: 250
-- Data for Name: identity_users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_users (id, user_name, normalized_user_name, email, normalized_email, email_confirmed, password_hash, security_stamp, concurrency_stamp, phone_number, phone_number_confirmed, two_factor_enabled, lockout_end, lockout_enabled, access_failed_count, created_at, time_zone, updated_at, version) FROM stdin;
019b7d31-93fd-703f-a582-c82e6bd40036	SUPERadmin@mail.RU	SUPERADMIN@MAIL.RU	SUPERadmin@mail.RU	SUPERADMIN@MAIL.RU	f	AQAAAAIAAYagAAAAEBag9pn4pztxrJtK71md3akGQ04Q/cWVqpDT8he8Ispn7t+HNGhKzrdXtWkKnE16vA==	JHMUKRZCKGMKN5TPX7UY47QU3OYRA44C	78551647-ef36-40b6-872c-bd8bbd3aa67e	\N	f	f	\N	t	0	2026-01-02 13:32:39.809088+08	\N	2026-01-02 13:32:39.809088+08	1
\.


--
-- TOC entry 5237 (class 0 OID 26604)
-- Dependencies: 247
-- Data for Name: user_bans; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_bans (id, user_id, version, created_at, updated_at, expires_at, user_ban_reason_id) FROM stdin;
\.


--
-- TOC entry 5238 (class 0 OID 26614)
-- Dependencies: 248
-- Data for Name: user_devices; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_devices (id, created_at, system_environment_user_name, time_zone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
47ee0275-bae7-c959-af87-f8b416a6cfd0	2025-12-19 22:55:44.844376+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
2f3585e2-e396-345a-b6d2-8d7079e5cdfc	2025-12-22 14:23:32.052081+08	adm-shumkov	480	30af10590f9f87bea6b087c950be35295e8eee95	B760 DS3H (Gigabyte Technology Co., Ltd.)	Desktop	Windows 10  (10.0.19045) 64bit	Intel(R) Core(TM) i9-14900K	32	65296	Intel(R) UHD Graphics 770	32648	t	Full
94a4eb4e-400c-2a56-ac6c-10dfb9250180	2026-01-02 13:31:08.667201+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
\.


--
-- TOC entry 5254 (class 0 OID 0)
-- Dependencies: 227
-- Name: base_equipments_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_equipments_id_seq', 9, true);


--
-- TOC entry 5255 (class 0 OID 0)
-- Dependencies: 229
-- Name: base_heroes_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_heroes_id_seq', 6, false);


--
-- TOC entry 5256 (class 0 OID 0)
-- Dependencies: 231
-- Name: creature_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.creature_types_id_seq', 9, false);


--
-- TOC entry 5257 (class 0 OID 0)
-- Dependencies: 233
-- Name: damage_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.damage_types_id_seq', 17, true);


--
-- TOC entry 5258 (class 0 OID 0)
-- Dependencies: 235
-- Name: equipment_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.equipment_types_id_seq', 32, true);


--
-- TOC entry 5259 (class 0 OID 0)
-- Dependencies: 237
-- Name: material_damage_percents_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.material_damage_percents_id_seq', 25, false);


--
-- TOC entry 5260 (class 0 OID 0)
-- Dependencies: 239
-- Name: slot_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slot_types_id_seq', 17, true);


--
-- TOC entry 5261 (class 0 OID 0)
-- Dependencies: 241
-- Name: smithing_materials_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.smithing_materials_id_seq', 19, true);


--
-- TOC entry 5262 (class 0 OID 0)
-- Dependencies: 246
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_ban_reasons_id_seq', 1, false);


--
-- TOC entry 5263 (class 0 OID 0)
-- Dependencies: 251
-- Name: asp_net_role_claims_id_seq; Type: SEQUENCE SET; Schema: users; Owner: -
--

SELECT pg_catalog.setval('users.asp_net_role_claims_id_seq', 1, false);


--
-- TOC entry 5264 (class 0 OID 0)
-- Dependencies: 253
-- Name: asp_net_user_claims_id_seq; Type: SEQUENCE SET; Schema: users; Owner: -
--

SELECT pg_catalog.setval('users.asp_net_user_claims_id_seq', 1, false);


--
-- TOC entry 4944 (class 2606 OID 26634)
-- Name: equipments equipments__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4960 (class 2606 OID 26636)
-- Name: heroes heroes__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4965 (class 2606 OID 26638)
-- Name: base_equipments base_equipments__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4969 (class 2606 OID 26640)
-- Name: base_heroes base_heroes__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_heroes
    ADD CONSTRAINT base_heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4972 (class 2606 OID 26642)
-- Name: creature_types creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.creature_types
    ADD CONSTRAINT creature_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4975 (class 2606 OID 26644)
-- Name: damage_types damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.damage_types
    ADD CONSTRAINT damage_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4978 (class 2606 OID 26646)
-- Name: equipment_types equipment_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4982 (class 2606 OID 26648)
-- Name: material_damage_percents material_damage_percents__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__pkey PRIMARY KEY (id);


--
-- TOC entry 4986 (class 2606 OID 26650)
-- Name: slot_types slot_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slot_types
    ADD CONSTRAINT slot_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4989 (class 2606 OID 26652)
-- Name: smithing_materials smithing_materials__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.smithing_materials
    ADD CONSTRAINT smithing_materials__pkey PRIMARY KEY (id);


--
-- TOC entry 4992 (class 2606 OID 26654)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__pkey PRIMARY KEY (equipment_type_id, damage_type_id);


--
-- TOC entry 4995 (class 2606 OID 26656)
-- Name: x_hero_creature_type x_hero_creature_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__pkey PRIMARY KEY (base_hero_id, creature_type_id);


--
-- TOC entry 5029 (class 2606 OID 27027)
-- Name: auth_reg_logs auth_reg_logs__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.auth_reg_logs
    ADD CONSTRAINT auth_reg_logs__pkey PRIMARY KEY (id);


--
-- TOC entry 4997 (class 2606 OID 26660)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 5000 (class 2606 OID 26662)
-- Name: user_ban_reasons user_ban_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_ban_reasons
    ADD CONSTRAINT user_ban_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 5015 (class 2606 OID 27117)
-- Name: identity_role_claims identity_role_claims__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_role_claims
    ADD CONSTRAINT identity_role_claims__pkey PRIMARY KEY (id);


--
-- TOC entry 5009 (class 2606 OID 27115)
-- Name: identity_roles identity_roles__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_roles
    ADD CONSTRAINT identity_roles__pkey PRIMARY KEY (id);


--
-- TOC entry 5018 (class 2606 OID 27113)
-- Name: identity_user_claims identity_user_claims__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_claims
    ADD CONSTRAINT identity_user_claims__pkey PRIMARY KEY (id);


--
-- TOC entry 5021 (class 2606 OID 27111)
-- Name: identity_user_logins identity_user_logins__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_logins
    ADD CONSTRAINT identity_user_logins__pkey PRIMARY KEY (login_provider, provider_key);


--
-- TOC entry 5024 (class 2606 OID 27109)
-- Name: identity_user_roles identity_user_roles__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__pkey PRIMARY KEY (user_id, role_id);


--
-- TOC entry 5027 (class 2606 OID 27107)
-- Name: identity_user_tokens identity_user_tokens__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_tokens
    ADD CONSTRAINT identity_user_tokens__pkey PRIMARY KEY (user_id, login_provider, name);


--
-- TOC entry 5013 (class 2606 OID 27105)
-- Name: identity_users identity_users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_users
    ADD CONSTRAINT identity_users__pkey PRIMARY KEY (id);


--
-- TOC entry 5002 (class 2606 OID 26664)
-- Name: user_bans user_bans__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__pkey PRIMARY KEY (id);


--
-- TOC entry 5006 (class 2606 OID 26666)
-- Name: user_devices user_devices__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_devices
    ADD CONSTRAINT user_devices__pkey PRIMARY KEY (id);


--
-- TOC entry 4942 (class 1259 OID 26669)
-- Name: equipments__base_equipment_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__base_equipment_id__idx ON collection.equipments USING btree (base_equipment_id);


--
-- TOC entry 4945 (class 1259 OID 26670)
-- Name: equipments__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__user_id__idx ON collection.equipments USING btree (user_id);


--
-- TOC entry 4946 (class 1259 OID 26671)
-- Name: heroes__base_hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__base_hero_id__idx ON collection.heroes USING btree (base_hero_id);


--
-- TOC entry 4947 (class 1259 OID 26672)
-- Name: heroes__equipment10id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment10id__idx ON collection.heroes USING btree (equipment10id);


--
-- TOC entry 4948 (class 1259 OID 26673)
-- Name: heroes__equipment11id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment11id__idx ON collection.heroes USING btree (equipment11id);


--
-- TOC entry 4949 (class 1259 OID 26674)
-- Name: heroes__equipment12id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment12id__idx ON collection.heroes USING btree (equipment12id);


--
-- TOC entry 4950 (class 1259 OID 26675)
-- Name: heroes__equipment1id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment1id__idx ON collection.heroes USING btree (equipment1id);


--
-- TOC entry 4951 (class 1259 OID 26676)
-- Name: heroes__equipment2id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment2id__idx ON collection.heroes USING btree (equipment2id);


--
-- TOC entry 4952 (class 1259 OID 26677)
-- Name: heroes__equipment3id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment3id__idx ON collection.heroes USING btree (equipment3id);


--
-- TOC entry 4953 (class 1259 OID 26678)
-- Name: heroes__equipment4id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment4id__idx ON collection.heroes USING btree (equipment4id);


--
-- TOC entry 4954 (class 1259 OID 26679)
-- Name: heroes__equipment5id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment5id__idx ON collection.heroes USING btree (equipment5id);


--
-- TOC entry 4955 (class 1259 OID 26680)
-- Name: heroes__equipment6id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment6id__idx ON collection.heroes USING btree (equipment6id);


--
-- TOC entry 4956 (class 1259 OID 26681)
-- Name: heroes__equipment7id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment7id__idx ON collection.heroes USING btree (equipment7id);


--
-- TOC entry 4957 (class 1259 OID 26682)
-- Name: heroes__equipment8id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment8id__idx ON collection.heroes USING btree (equipment8id);


--
-- TOC entry 4958 (class 1259 OID 26683)
-- Name: heroes__equipment9id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment9id__idx ON collection.heroes USING btree (equipment9id);


--
-- TOC entry 4961 (class 1259 OID 26684)
-- Name: heroes__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__user_id__idx ON collection.heroes USING btree (user_id);


--
-- TOC entry 4962 (class 1259 OID 26685)
-- Name: base_equipments__equipment_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__equipment_type_id__idx ON game_data.base_equipments USING btree (equipment_type_id);


--
-- TOC entry 4963 (class 1259 OID 26974)
-- Name: base_equipments__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_equipments__name__idx ON game_data.base_equipments USING btree (name);


--
-- TOC entry 4966 (class 1259 OID 26687)
-- Name: base_equipments__smithing_material_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__smithing_material_id__idx ON game_data.base_equipments USING btree (smithing_material_id);


--
-- TOC entry 4967 (class 1259 OID 26972)
-- Name: base_heroes__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_heroes__name__idx ON game_data.base_heroes USING btree (name);


--
-- TOC entry 4970 (class 1259 OID 26970)
-- Name: creature_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX creature_types__name__idx ON game_data.creature_types USING btree (name);


--
-- TOC entry 4973 (class 1259 OID 26968)
-- Name: damage_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX damage_types__name__idx ON game_data.damage_types USING btree (name);


--
-- TOC entry 4976 (class 1259 OID 26966)
-- Name: equipment_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX equipment_types__name__idx ON game_data.equipment_types USING btree (name);


--
-- TOC entry 4979 (class 1259 OID 26692)
-- Name: equipment_types__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX equipment_types__slot_type_id__idx ON game_data.equipment_types USING btree (slot_type_id);


--
-- TOC entry 4980 (class 1259 OID 26693)
-- Name: material_damage_percents__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__damage_type_id__idx ON game_data.material_damage_percents USING btree (damage_type_id);


--
-- TOC entry 4983 (class 1259 OID 26694)
-- Name: material_damage_percents__smithing_materials_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__smithing_materials_id__idx ON game_data.material_damage_percents USING btree (smithing_materials_id);


--
-- TOC entry 4984 (class 1259 OID 26963)
-- Name: slot_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slot_types__name__idx ON game_data.slot_types USING btree (name);


--
-- TOC entry 4987 (class 1259 OID 26961)
-- Name: smithing_materials__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX smithing_materials__name__idx ON game_data.smithing_materials USING btree (name);


--
-- TOC entry 4990 (class 1259 OID 26697)
-- Name: x_equipment_type_damage_type__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_equipment_type_damage_type__damage_type_id__idx ON game_data.x_equipment_type_damage_type USING btree (damage_type_id);


--
-- TOC entry 4993 (class 1259 OID 26698)
-- Name: x_hero_creature_type__creature_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_hero_creature_type__creature_type_id__idx ON game_data.x_hero_creature_type USING btree (creature_type_id);


--
-- TOC entry 5030 (class 1259 OID 27039)
-- Name: auth_reg_logs__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX auth_reg_logs__user_device_id__idx ON logs.auth_reg_logs USING btree (user_device_id);


--
-- TOC entry 5031 (class 1259 OID 27038)
-- Name: auth_reg_logs__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX auth_reg_logs__user_id__idx ON logs.auth_reg_logs USING btree (user_id);


--
-- TOC entry 4998 (class 1259 OID 26701)
-- Name: user_ban_reasons__name__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_ban_reasons__name__idx ON server.user_ban_reasons USING btree (name);


--
-- TOC entry 5016 (class 1259 OID 26951)
-- Name: identity_role_claims__role_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_role_claims__role_id__idx ON users.identity_role_claims USING btree (role_id);


--
-- TOC entry 5007 (class 1259 OID 26952)
-- Name: identity_roles__normalized_name__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX identity_roles__normalized_name__idx ON users.identity_roles USING btree (normalized_name);


--
-- TOC entry 5019 (class 1259 OID 26953)
-- Name: identity_user_claims__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_claims__user_id__idx ON users.identity_user_claims USING btree (user_id);


--
-- TOC entry 5022 (class 1259 OID 26954)
-- Name: identity_user_logins__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_logins__user_id__idx ON users.identity_user_logins USING btree (user_id);


--
-- TOC entry 5025 (class 1259 OID 26955)
-- Name: identity_user_roles__role_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_roles__role_id__idx ON users.identity_user_roles USING btree (role_id);


--
-- TOC entry 5010 (class 1259 OID 26956)
-- Name: identity_users__normalized_email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_users__normalized_email__idx ON users.identity_users USING btree (normalized_email);


--
-- TOC entry 5011 (class 1259 OID 26957)
-- Name: identity_users__normalized_user_name__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX identity_users__normalized_user_name__idx ON users.identity_users USING btree (normalized_user_name);


--
-- TOC entry 5003 (class 1259 OID 26702)
-- Name: user_bans__user_ban_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_ban_reason_id__idx ON users.user_bans USING btree (user_ban_reason_id);


--
-- TOC entry 5004 (class 1259 OID 26703)
-- Name: user_bans__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_id__idx ON users.user_bans USING btree (user_id);


--
-- TOC entry 5032 (class 2606 OID 26705)
-- Name: equipments equipments__base_equipment_id__base_equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__base_equipment_id__base_equipments__fkey FOREIGN KEY (base_equipment_id) REFERENCES game_data.base_equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5033 (class 2606 OID 27123)
-- Name: equipments equipments__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5034 (class 2606 OID 26715)
-- Name: heroes heroes__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5035 (class 2606 OID 26720)
-- Name: heroes heroes__equipment10id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment10id__equipments__fkey FOREIGN KEY (equipment10id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5036 (class 2606 OID 26725)
-- Name: heroes heroes__equipment11id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment11id__equipments__fkey FOREIGN KEY (equipment11id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5037 (class 2606 OID 26730)
-- Name: heroes heroes__equipment12id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment12id__equipments__fkey FOREIGN KEY (equipment12id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5038 (class 2606 OID 26735)
-- Name: heroes heroes__equipment1id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment1id__equipments__fkey FOREIGN KEY (equipment1id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5039 (class 2606 OID 26740)
-- Name: heroes heroes__equipment2id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment2id__equipments__fkey FOREIGN KEY (equipment2id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5040 (class 2606 OID 26745)
-- Name: heroes heroes__equipment3id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment3id__equipments__fkey FOREIGN KEY (equipment3id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5041 (class 2606 OID 26750)
-- Name: heroes heroes__equipment4id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment4id__equipments__fkey FOREIGN KEY (equipment4id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5042 (class 2606 OID 26755)
-- Name: heroes heroes__equipment5id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment5id__equipments__fkey FOREIGN KEY (equipment5id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5043 (class 2606 OID 26760)
-- Name: heroes heroes__equipment6id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment6id__equipments__fkey FOREIGN KEY (equipment6id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5044 (class 2606 OID 26765)
-- Name: heroes heroes__equipment7id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment7id__equipments__fkey FOREIGN KEY (equipment7id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5045 (class 2606 OID 26770)
-- Name: heroes heroes__equipment8id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment8id__equipments__fkey FOREIGN KEY (equipment8id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5046 (class 2606 OID 26775)
-- Name: heroes heroes__equipment9id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment9id__equipments__fkey FOREIGN KEY (equipment9id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5047 (class 2606 OID 27128)
-- Name: heroes heroes__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5048 (class 2606 OID 26785)
-- Name: base_equipments base_equipments__equipment_type_id__equipment_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__equipment_type_id__equipment_types__fkey FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5049 (class 2606 OID 26790)
-- Name: base_equipments base_equipments__smithing_material_id__smithing_materials__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__smithing_material_id__smithing_materials__fkey FOREIGN KEY (smithing_material_id) REFERENCES game_data.smithing_materials(id) ON DELETE RESTRICT;


--
-- TOC entry 5050 (class 2606 OID 26795)
-- Name: equipment_types equipment_types__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5051 (class 2606 OID 26800)
-- Name: material_damage_percents material_damage_percents__damage_type_id__damage_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__damage_type_id__damage_types__fkey FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5052 (class 2606 OID 26805)
-- Name: material_damage_percents material_damage_percents__smithing_materials_id__smithing_mater; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__smithing_materials_id__smithing_mater FOREIGN KEY (smithing_materials_id) REFERENCES game_data.smithing_materials(id) ON DELETE RESTRICT;


--
-- TOC entry 5053 (class 2606 OID 26810)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__damage_type_id__damage_types__fke; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__damage_type_id__damage_types__fke FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5054 (class 2606 OID 26815)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__equipment_type_id__equipment_type; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__equipment_type_id__equipment_type FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5055 (class 2606 OID 26820)
-- Name: x_hero_creature_type x_hero_creature_type__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5056 (class 2606 OID 26825)
-- Name: x_hero_creature_type x_hero_creature_type__creature_type_id__creature_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__creature_type_id__creature_types__fkey FOREIGN KEY (creature_type_id) REFERENCES game_data.creature_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5065 (class 2606 OID 27033)
-- Name: auth_reg_logs auth_reg_logs__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.auth_reg_logs
    ADD CONSTRAINT auth_reg_logs__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE RESTRICT;


--
-- TOC entry 5066 (class 2606 OID 27118)
-- Name: auth_reg_logs auth_reg_logs__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.auth_reg_logs
    ADD CONSTRAINT auth_reg_logs__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE CASCADE;


--
-- TOC entry 5059 (class 2606 OID 27133)
-- Name: identity_role_claims identity_role_claims__role_id__identity_roles__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_role_claims
    ADD CONSTRAINT identity_role_claims__role_id__identity_roles__fkey FOREIGN KEY (role_id) REFERENCES users.identity_roles(id) ON DELETE RESTRICT;


--
-- TOC entry 5060 (class 2606 OID 27138)
-- Name: identity_user_claims identity_user_claims__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_claims
    ADD CONSTRAINT identity_user_claims__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5061 (class 2606 OID 27143)
-- Name: identity_user_logins identity_user_logins__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_logins
    ADD CONSTRAINT identity_user_logins__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5062 (class 2606 OID 27148)
-- Name: identity_user_roles identity_user_roles__role_id__identity_roles__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__role_id__identity_roles__fkey FOREIGN KEY (role_id) REFERENCES users.identity_roles(id) ON DELETE RESTRICT;


--
-- TOC entry 5063 (class 2606 OID 27153)
-- Name: identity_user_roles identity_user_roles__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5064 (class 2606 OID 27158)
-- Name: identity_user_tokens identity_user_tokens__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_tokens
    ADD CONSTRAINT identity_user_tokens__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5057 (class 2606 OID 26840)
-- Name: user_bans user_bans__user_ban_reason_id__user_ban_reasons__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_ban_reason_id__user_ban_reasons__fkey FOREIGN KEY (user_ban_reason_id) REFERENCES server.user_ban_reasons(id) ON DELETE RESTRICT;


--
-- TOC entry 5058 (class 2606 OID 27163)
-- Name: user_bans user_bans__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE CASCADE;


-- Completed on 2026-01-02 21:48:45

--
-- PostgreSQL database dump complete
--

\unrestrict 0dg9VkNayYH2Ky00GMzhU4oGd7OAeU4ueVPSt3PuccD4vmewAdmZJRfSlaQMzSn

