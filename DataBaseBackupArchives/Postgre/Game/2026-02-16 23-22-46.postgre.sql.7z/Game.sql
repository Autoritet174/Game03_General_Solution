--
-- PostgreSQL database dump
--

\restrict pSqshW8X6zrqUr0b6JpQ4BRHiaFJbNoloMEOMdg4qGuZ7WR0eGvHtL8j5nb5J2z

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2026-02-16 23:22:45

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS on_ddl_create_table__prevent_id_update;
ALTER TABLE IF EXISTS ONLY users.user_sessions DROP CONSTRAINT IF EXISTS user_sessions__user_session_inactivation_reason_id__user_sessio;
ALTER TABLE IF EXISTS ONLY users.user_sessions DROP CONSTRAINT IF EXISTS user_sessions__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_ban_reason_id__user_ban_reasons__fkey;
ALTER TABLE IF EXISTS ONLY users.user_accesskeys DROP CONSTRAINT IF EXISTS user_accesskeys__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_tokens DROP CONSTRAINT IF EXISTS identity_user_tokens__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__role_id__identity_roles__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_logins DROP CONSTRAINT IF EXISTS identity_user_logins__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_claims DROP CONSTRAINT IF EXISTS identity_user_claims__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_role_claims DROP CONSTRAINT IF EXISTS identity_role_claims__role_id__identity_roles__fkey;
ALTER TABLE IF EXISTS ONLY logs.registration_logs DROP CONSTRAINT IF EXISTS registration_logs__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY logs.registration_logs DROP CONSTRAINT IF EXISTS registration_logs__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY logs.authentication_logs DROP CONSTRAINT IF EXISTS authentication_logs__user_session_id__user_sessions__fkey;
ALTER TABLE IF EXISTS ONLY logs.authentication_logs DROP CONSTRAINT IF EXISTS authentication_logs__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY logs.authentication_logs DROP CONSTRAINT IF EXISTS authentication_logs__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_heroes_creature_types DROP CONSTRAINT IF EXISTS x_heroes_creature_types__creature_type_id__creature_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_heroes_creature_types DROP CONSTRAINT IF EXISTS x_heroes_creature_types__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_types_damage_types DROP CONSTRAINT IF EXISTS x_equipment_types_damage_types__equipment_type_id__equipment_ty;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_types_damage_types DROP CONSTRAINT IF EXISTS x_equipment_types_damage_types__damage_type_id__damage_types__f;
ALTER TABLE IF EXISTS ONLY game_data.slots DROP CONSTRAINT IF EXISTS slots__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__smithing_materials_id__smithing_mater;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__damage_type_id__damage_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__smithing_material_id__smithing_materials__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__equipment_type_id__equipment_types__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__slot_id__slots__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__hero_id__heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__base_equipment_id__base_equipments__fkey;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.users;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.user_sessions;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.user_devices;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.user_bans;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.user_accesskeys;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.refresh_tokens;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.identity_users;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.identity_user_claims;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.identity_roles;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.identity_role_claims;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON server.user_session_inactivation_reasons;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON server.user_ban_reasons;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON logs.registration_logs;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON logs.authentication_logs;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.smithing_materials;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.slots;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.slot_types;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.material_damage_percents;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.equipment_types;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.damage_types;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.creature_types;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.base_heroes;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.base_equipments;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON collection.heroes;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON collection.equipments;
DROP INDEX IF EXISTS users.users__email__idx;
DROP INDEX IF EXISTS users.user_sessions__user_session_inactivation_reason_id__idx;
DROP INDEX IF EXISTS users.user_sessions__user_device_id__idx;
DROP INDEX IF EXISTS users.user_sessions__refresh_token_hash__idx;
DROP INDEX IF EXISTS users.user_bans__user_id__idx;
DROP INDEX IF EXISTS users.user_bans__user_ban_reason_id__idx;
DROP INDEX IF EXISTS users.user_accesskeys__user_id__idx;
DROP INDEX IF EXISTS users.refresh_tokens__user_id__idx;
DROP INDEX IF EXISTS users.identity_users__normalized_user_name__idx;
DROP INDEX IF EXISTS users.identity_users__normalized_email__idx;
DROP INDEX IF EXISTS users.identity_user_roles__role_id__idx;
DROP INDEX IF EXISTS users.identity_user_logins__user_id__idx;
DROP INDEX IF EXISTS users.identity_user_claims__user_id__idx;
DROP INDEX IF EXISTS users.identity_roles__normalized_name__idx;
DROP INDEX IF EXISTS users.identity_role_claims__role_id__idx;
DROP INDEX IF EXISTS server.user_session_inactivation_reasons__code__idx;
DROP INDEX IF EXISTS server.user_ban_reasons__name__idx;
DROP INDEX IF EXISTS logs.registration_logs__user_id__idx;
DROP INDEX IF EXISTS logs.registration_logs__user_device_id__idx;
DROP INDEX IF EXISTS logs.authentication_logs__user_session_id__idx;
DROP INDEX IF EXISTS logs.authentication_logs__user_id__idx;
DROP INDEX IF EXISTS logs.authentication_logs__user_device_id__idx;
DROP INDEX IF EXISTS game_data.x_heroes_creature_types__creature_type_id__idx;
DROP INDEX IF EXISTS game_data.x_equipment_types_damage_types__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.smithing_materials__name__idx;
DROP INDEX IF EXISTS game_data.slots__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.slots__name__idx;
DROP INDEX IF EXISTS game_data.slot_types__name__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__smithing_materials_id__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__name__idx;
DROP INDEX IF EXISTS game_data.damage_types__name__idx;
DROP INDEX IF EXISTS game_data.creature_types__name__idx;
DROP INDEX IF EXISTS game_data.base_heroes__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__smithing_material_id__idx;
DROP INDEX IF EXISTS game_data.base_equipments__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__equipment_type_id__idx;
DROP INDEX IF EXISTS collection.heroes__user_id__idx;
DROP INDEX IF EXISTS collection.heroes__base_hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__user_id__idx;
DROP INDEX IF EXISTS collection.equipments__slot_id__idx;
DROP INDEX IF EXISTS collection.equipments__hero_id__slot_id__idx;
DROP INDEX IF EXISTS collection.equipments__base_equipment_id__idx;
ALTER TABLE IF EXISTS ONLY users.users DROP CONSTRAINT IF EXISTS users__pkey;
ALTER TABLE IF EXISTS ONLY users.user_sessions DROP CONSTRAINT IF EXISTS user_sessions__pkey;
ALTER TABLE IF EXISTS ONLY users.user_devices DROP CONSTRAINT IF EXISTS user_devices__pkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__pkey;
ALTER TABLE IF EXISTS ONLY users.user_accesskeys DROP CONSTRAINT IF EXISTS user_accesskeys__pkey;
ALTER TABLE IF EXISTS ONLY users.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_users DROP CONSTRAINT IF EXISTS identity_users__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_tokens DROP CONSTRAINT IF EXISTS identity_user_tokens__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_logins DROP CONSTRAINT IF EXISTS identity_user_logins__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_claims DROP CONSTRAINT IF EXISTS identity_user_claims__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_roles DROP CONSTRAINT IF EXISTS identity_roles__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_role_claims DROP CONSTRAINT IF EXISTS identity_role_claims__pkey;
ALTER TABLE IF EXISTS ONLY server.user_session_inactivation_reasons DROP CONSTRAINT IF EXISTS user_session_inactivation_reasons__pkey;
ALTER TABLE IF EXISTS ONLY server.user_ban_reasons DROP CONSTRAINT IF EXISTS user_ban_reasons__pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY logs.registration_logs DROP CONSTRAINT IF EXISTS registration_logs__pkey;
ALTER TABLE IF EXISTS ONLY logs.authentication_logs DROP CONSTRAINT IF EXISTS authentication_logs__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_heroes_creature_types DROP CONSTRAINT IF EXISTS x_heroes_creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_types_damage_types DROP CONSTRAINT IF EXISTS x_equipment_types_damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.smithing_materials DROP CONSTRAINT IF EXISTS smithing_materials__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slots DROP CONSTRAINT IF EXISTS slots__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slot_types DROP CONSTRAINT IF EXISTS slot_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__pkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.damage_types DROP CONSTRAINT IF EXISTS damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.creature_types DROP CONSTRAINT IF EXISTS creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_heroes DROP CONSTRAINT IF EXISTS base_heroes__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__pkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__pkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__pkey;
DROP TABLE IF EXISTS users.users;
DROP TABLE IF EXISTS users.user_sessions;
DROP TABLE IF EXISTS users.user_devices;
DROP TABLE IF EXISTS users.user_bans;
DROP TABLE IF EXISTS users.user_accesskeys;
DROP TABLE IF EXISTS users.refresh_tokens;
DROP TABLE IF EXISTS users.identity_users;
DROP TABLE IF EXISTS users.identity_user_tokens;
DROP TABLE IF EXISTS users.identity_user_roles;
DROP TABLE IF EXISTS users.identity_user_logins;
DROP TABLE IF EXISTS users.identity_roles;
DROP TABLE IF EXISTS users.identity_user_claims;
DROP TABLE IF EXISTS users.identity_role_claims;
DROP TABLE IF EXISTS server.user_session_inactivation_reasons;
DROP TABLE IF EXISTS server.user_ban_reasons;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS logs.registration_logs;
DROP TABLE IF EXISTS logs.authentication_logs;
DROP TABLE IF EXISTS game_data.x_heroes_creature_types;
DROP TABLE IF EXISTS game_data.x_equipment_types_damage_types;
DROP VIEW IF EXISTS game_data.v_base_heroes;
DROP TABLE IF EXISTS game_data.smithing_materials;
DROP TABLE IF EXISTS game_data.slots;
DROP TABLE IF EXISTS game_data.slot_types;
DROP TABLE IF EXISTS game_data.material_damage_percents;
DROP TABLE IF EXISTS game_data.equipment_types;
DROP TABLE IF EXISTS game_data.damage_types;
DROP TABLE IF EXISTS game_data.creature_types;
DROP TABLE IF EXISTS game_data.base_heroes;
DROP TABLE IF EXISTS game_data.base_equipments;
DROP TABLE IF EXISTS collection.heroes;
DROP TABLE IF EXISTS collection.equipments;
DROP FUNCTION IF EXISTS public.prevent_id_update();
DROP FUNCTION IF EXISTS public.format_dice_only_expected(dice_jsonb jsonb);
DROP FUNCTION IF EXISTS public.format_dice(dice_jsonb jsonb);
DROP FUNCTION IF EXISTS public.fn_on_ddl_prevent_id_update();
DROP FUNCTION IF EXISTS public.create_triggers__prevent_id_update();
DROP FUNCTION IF EXISTS public.bytea_to_decimal_string(data bytea);
DROP SCHEMA IF EXISTS users;
DROP SCHEMA IF EXISTS server;
DROP SCHEMA IF EXISTS logs;
DROP SCHEMA IF EXISTS game_data;
DROP SCHEMA IF EXISTS collection;
--
-- TOC entry 6 (class 2615 OID 37171)
-- Name: collection; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA collection;


--
-- TOC entry 7 (class 2615 OID 37172)
-- Name: game_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA game_data;


--
-- TOC entry 8 (class 2615 OID 37173)
-- Name: logs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA logs;


--
-- TOC entry 9 (class 2615 OID 37174)
-- Name: server; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA server;


--
-- TOC entry 10 (class 2615 OID 37175)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


--
-- TOC entry 269 (class 1255 OID 37176)
-- Name: bytea_to_decimal_string(bytea); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.bytea_to_decimal_string(data bytea) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    result text := '';
    i integer;
BEGIN
    FOR i IN 1..length(data) LOOP
        IF result <> '' THEN
            result := result || ' ';
        END IF;
        result := result || get_byte(data, i-1)::text;
    END LOOP;
    RETURN result;
END;
$$;


--
-- TOC entry 281 (class 1255 OID 37177)
-- Name: create_triggers__prevent_id_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_triggers__prevent_id_update() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    tbl_record RECORD;
BEGIN
    -- Перебор всех таблиц, кроме схемы public, у которых есть колонка 'id'
    FOR tbl_record IN
        SELECT n.nspname AS schema_name, c.relname AS table_name
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname != 'public'
          AND c.relkind = 'r' -- только обычные таблицы
          AND EXISTS (
              SELECT 1 
              FROM pg_attribute a 
              WHERE a.attrelid = c.oid 
                AND a.attname = 'id' 
                AND a.attnum > 0 
                AND NOT a.attisdropped
          )
    LOOP
        -- Динамическое создание триггера
        EXECUTE format('
            DROP TRIGGER IF EXISTS trg_prevent_id_change ON %I.%I;
            CREATE TRIGGER trg_prevent_id_change
            BEFORE UPDATE ON %I.%I
            FOR EACH ROW
            EXECUTE FUNCTION public.prevent_id_update();',
            tbl_record.schema_name, tbl_record.table_name,
            tbl_record.schema_name, tbl_record.table_name
        );
    END LOOP;
END;
$$;


--
-- TOC entry 282 (class 1255 OID 37178)
-- Name: fn_on_ddl_prevent_id_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_on_ddl_prevent_id_update() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    obj RECORD;
    schema_name TEXT;
    table_name TEXT;
    has_id BOOLEAN;
    trigger_exists BOOLEAN;
BEGIN
    -- Перебор объектов, затронутых командой DDL
    FOR obj IN SELECT * FROM pg_event_trigger_ddl_commands() LOOP
        
        -- Работаем только с таблицами
        IF obj.object_type = 'table' THEN
            
            -- Получение имени схемы и таблицы через OID объекта
            SELECT n.nspname, c.relname
            INTO schema_name, table_name
            FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE c.oid = obj.objid;

            -- Проверка условий: схема не public
            IF schema_name IS DISTINCT FROM 'public' THEN
                
                -- Проверка наличия колонки id
                SELECT EXISTS (
                    SELECT 1 
                    FROM pg_attribute 
                    WHERE attrelid = obj.objid 
                      AND attname = 'id' 
                      AND attnum > 0 
                      AND NOT attisdropped
                ) INTO has_id;

                -- Если колонка id есть
                IF has_id THEN
                    -- ВАЖНО: Проверяем, существует ли уже такой триггер для этой таблицы
                    SELECT EXISTS (
                        SELECT 1 
                        FROM pg_trigger 
                        WHERE tgrelid = obj.objid 
                          AND tgname = 'trg_prevent_id_change'
                    ) INTO trigger_exists;

                    -- Создаем триггер только если его нет
                    IF NOT trigger_exists THEN
                        EXECUTE format('
                            CREATE TRIGGER trg_prevent_id_change
                            BEFORE UPDATE ON %I.%I
                            FOR EACH ROW
                            EXECUTE FUNCTION public.prevent_id_update();',
                            schema_name, table_name
                        );
                    END IF;
                END IF;
            END IF;
        END IF;
    END LOOP;
END;
$$;


--
-- TOC entry 283 (class 1255 OID 37179)
-- Name: format_dice(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.format_dice(dice_jsonb jsonb) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_count INTEGER;
    v_sides INTEGER;
    v_mod BIGINT;
    v_expected NUMERIC;
    v_formatted TEXT;
    v_mod_formatted TEXT;
    v_expected_formatted TEXT;
BEGIN
    -- Извлекаем значения из JSON
    v_count := COALESCE((dice_jsonb->>'c')::INTEGER, 0);
    v_sides := COALESCE((dice_jsonb->>'s')::INTEGER, 0);
    v_mod := (dice_jsonb->>'m')::BIGINT;
    
    -- Вычисляем ожидаемое значение по формуле
    -- (500L * (Count * (Sides + 1))) + (Modificator1000 ?? 0L)
    v_expected := (500.0 * (v_count * (v_sides + 1))) + COALESCE(v_mod, 0);
    v_expected := v_expected / 1000.0; -- Делим на 1000 для получения float значения
    
    -- Форматируем основную часть
    IF v_mod IS NOT NULL AND v_mod != 0 THEN
        -- Форматируем модификатор
        v_mod_formatted := REPLACE(
            ROUND(v_mod / 1000.0, 3)::TEXT,
            '.',
            ','
        );
        
        -- Убираем лишние нули после запятой
        v_mod_formatted := TRIM(TRAILING '0' FROM v_mod_formatted);
        v_mod_formatted := TRIM(TRAILING ',' FROM v_mod_formatted);
        
        -- Определяем знак модификатора
        IF v_mod > 0 THEN
            v_formatted := FORMAT('%sd%s+%s', v_count, v_sides, v_mod_formatted);
        ELSE
            v_formatted := FORMAT('%sd%s%s', v_count, v_sides, v_mod_formatted);
        END IF;
    ELSE
        v_formatted := FORMAT('%sd%s', v_count, v_sides);
    END IF;
    
    -- Форматируем ожидаемое значение
    v_expected_formatted := REPLACE(
        ROUND(v_expected, 3)::TEXT,
        '.',
        ','
    );
    
    -- Убираем лишние нули после запятой
    v_expected_formatted := TRIM(TRAILING '0' FROM v_expected_formatted);
    v_expected_formatted := TRIM(TRAILING ',' FROM v_expected_formatted);
    
    -- Формируем финальную строку
    RETURN FORMAT('%s (%s)', v_formatted, v_expected_formatted);
EXCEPTION
    WHEN OTHERS THEN
        RETURN 'Invalid damage format';
END;
$$;


--
-- TOC entry 284 (class 1255 OID 37180)
-- Name: format_dice_only_expected(jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.format_dice_only_expected(dice_jsonb jsonb) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    v_count INTEGER;
    v_sides INTEGER;
    v_mod BIGINT;
BEGIN
    -- Извлекаем значения из JSON
    v_count := COALESCE((dice_jsonb->>'c')::INTEGER, 0);
    v_sides := COALESCE((dice_jsonb->>'s')::INTEGER, 0);
    v_mod := COALESCE((dice_jsonb->>'m')::BIGINT, 0);
    
    -- Формула: (500L * (Count * (Sides + 1))) + (Modificator1000 ?? 0L)
    -- Возвращаем как NUMERIC с делением на 1000
    RETURN ((500.0 * (v_count * (v_sides + 1))) + v_mod) / 1000.0;
END;
$$;


--
-- TOC entry 285 (class 1255 OID 37181)
-- Name: prevent_id_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_id_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Проверка на изменение значения id
    IF NEW.id IS DISTINCT FROM OLD.id THEN
        RAISE EXCEPTION 'Изменение поля "id" запрещено. (Table: %.%)', TG_TABLE_SCHEMA, TG_TABLE_NAME;
    END IF;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 37182)
-- Name: equipments; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.equipments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    base_equipment_id integer NOT NULL,
    group_name character varying(256),
    hero_id uuid,
    slot_id integer
);


--
-- TOC entry 225 (class 1259 OID 37195)
-- Name: heroes; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.heroes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_hero_id integer NOT NULL,
    health1000 bigint CONSTRAINT heroes_health_not_null NOT NULL,
    strength integer NOT NULL,
    agility integer NOT NULL,
    intelligence integer NOT NULL,
    crit_chance integer NOT NULL,
    crit_power integer NOT NULL,
    haste integer NOT NULL,
    versality integer NOT NULL,
    endurance_physical integer NOT NULL,
    endurance_magical integer NOT NULL,
    resist_damage_physical integer NOT NULL,
    resist_damage_magical integer NOT NULL,
    experience_now bigint DEFAULT 0 NOT NULL,
    group_name character varying(256),
    level integer DEFAULT 1 NOT NULL,
    rarity integer DEFAULT 1 NOT NULL,
    damage jsonb
);


--
-- TOC entry 226 (class 1259 OID 37225)
-- Name: base_equipments; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_equipments (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    equipment_type_id integer NOT NULL,
    health jsonb,
    damage jsonb,
    smithing_material_id integer
);


--
-- TOC entry 227 (class 1259 OID 37236)
-- Name: base_equipments_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_equipments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_equipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 37237)
-- Name: base_heroes; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_heroes (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL,
    health jsonb,
    damage jsonb
);


--
-- TOC entry 229 (class 1259 OID 37249)
-- Name: base_heroes_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_heroes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_heroes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 37250)
-- Name: creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.creature_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 37255)
-- Name: creature_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.creature_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.creature_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 37256)
-- Name: damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.damage_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256),
    dev_hint_ru text,
    category integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 37265)
-- Name: damage_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.damage_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.damage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 37266)
-- Name: equipment_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.equipment_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256) NOT NULL,
    mass_physical integer DEFAULT 0 NOT NULL,
    mass_magical integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    spend_action_points integer DEFAULT 0 NOT NULL,
    block_other_hand boolean,
    damage jsonb
);


--
-- TOC entry 235 (class 1259 OID 37285)
-- Name: equipment_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.equipment_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.equipment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 37286)
-- Name: material_damage_percents; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.material_damage_percents (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 37293)
-- Name: material_damage_percents_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.material_damage_percents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.material_damage_percents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 37294)
-- Name: slot_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slot_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256),
    have_alt_slot boolean DEFAULT false NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 37301)
-- Name: slot_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slot_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slot_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 37302)
-- Name: slots; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slots (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    slot_type_id integer NOT NULL,
    main_slot boolean DEFAULT true NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 37308)
-- Name: slots_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slots ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 37309)
-- Name: smithing_materials; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.smithing_materials (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256)
);


--
-- TOC entry 243 (class 1259 OID 37316)
-- Name: smithing_materials_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.smithing_materials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.smithing_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 244 (class 1259 OID 37317)
-- Name: v_base_heroes; Type: VIEW; Schema: game_data; Owner: -
--

CREATE VIEW game_data.v_base_heroes AS
 SELECT id,
    name,
    rarity,
    is_unique,
    main_stat,
    health,
    damage,
    public.format_dice(health) AS dice_health,
    public.format_dice(damage) AS dice_damage
   FROM game_data.base_heroes
  ORDER BY id;


--
-- TOC entry 245 (class 1259 OID 37321)
-- Name: x_equipment_types_damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_equipment_types_damage_types (
    equipment_type_id integer CONSTRAINT x_equipment_type_damage_type_equipment_type_id_not_null NOT NULL,
    damage_type_id integer CONSTRAINT x_equipment_type_damage_type_damage_type_id_not_null NOT NULL,
    damage_coef integer DEFAULT 0 CONSTRAINT x_equipment_type_damage_type_damage_coef_not_null NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 37328)
-- Name: x_heroes_creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_heroes_creature_types (
    base_hero_id integer CONSTRAINT x_hero_creature_type_hero_id_not_null NOT NULL,
    creature_type_id integer CONSTRAINT x_hero_creature_type_creature_type_id_not_null NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 37333)
-- Name: authentication_logs; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.authentication_logs (
    id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    email character varying(256),
    user_id uuid,
    success boolean NOT NULL,
    user_device_id uuid,
    ip inet,
    user_session_id uuid
);


--
-- TOC entry 248 (class 1259 OID 37343)
-- Name: registration_logs; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.registration_logs (
    id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    email character varying(256),
    user_id uuid,
    success boolean NOT NULL,
    user_device_id uuid,
    ip inet
);


--
-- TOC entry 249 (class 1259 OID 37353)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 37358)
-- Name: user_ban_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_ban_reasons (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- TOC entry 251 (class 1259 OID 37365)
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_ban_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_ban_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 252 (class 1259 OID 37366)
-- Name: user_session_inactivation_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_session_inactivation_reasons (
    id integer NOT NULL,
    name text NOT NULL,
    code integer NOT NULL
);


--
-- TOC entry 253 (class 1259 OID 37374)
-- Name: user_session_inactivation_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_session_inactivation_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_session_inactivation_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 254 (class 1259 OID 37375)
-- Name: identity_role_claims; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_role_claims (
    id integer CONSTRAINT asp_net_role_claims_id_not_null NOT NULL,
    role_id uuid CONSTRAINT asp_net_role_claims_role_id_not_null NOT NULL,
    claim_type text,
    claim_value text
);


--
-- TOC entry 255 (class 1259 OID 37382)
-- Name: asp_net_role_claims_id_seq; Type: SEQUENCE; Schema: users; Owner: -
--

ALTER TABLE users.identity_role_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME users.asp_net_role_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 256 (class 1259 OID 37383)
-- Name: identity_user_claims; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_claims (
    id integer CONSTRAINT asp_net_user_claims_id_not_null NOT NULL,
    user_id uuid CONSTRAINT asp_net_user_claims_user_id_not_null NOT NULL,
    claim_type text,
    claim_value text
);


--
-- TOC entry 257 (class 1259 OID 37390)
-- Name: asp_net_user_claims_id_seq; Type: SEQUENCE; Schema: users; Owner: -
--

ALTER TABLE users.identity_user_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME users.asp_net_user_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 258 (class 1259 OID 37391)
-- Name: identity_roles; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_roles (
    id uuid CONSTRAINT asp_net_roles_id_not_null NOT NULL,
    name character varying(256),
    normalized_name character varying(256),
    concurrency_stamp text
);


--
-- TOC entry 259 (class 1259 OID 37397)
-- Name: identity_user_logins; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_logins (
    login_provider text CONSTRAINT asp_net_user_logins_login_provider_not_null NOT NULL,
    provider_key text CONSTRAINT asp_net_user_logins_provider_key_not_null NOT NULL,
    provider_display_name text,
    user_id uuid CONSTRAINT asp_net_user_logins_user_id_not_null NOT NULL
);


--
-- TOC entry 260 (class 1259 OID 37405)
-- Name: identity_user_roles; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_roles (
    user_id uuid CONSTRAINT asp_net_user_roles_user_id_not_null NOT NULL,
    role_id uuid CONSTRAINT asp_net_user_roles_role_id_not_null NOT NULL
);


--
-- TOC entry 261 (class 1259 OID 37410)
-- Name: identity_user_tokens; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_tokens (
    user_id uuid CONSTRAINT asp_net_user_tokens_user_id_not_null NOT NULL,
    login_provider text CONSTRAINT asp_net_user_tokens_login_provider_not_null NOT NULL,
    name text CONSTRAINT asp_net_user_tokens_name_not_null NOT NULL,
    value text
);


--
-- TOC entry 262 (class 1259 OID 37418)
-- Name: identity_users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_users (
    id uuid CONSTRAINT asp_net_users_id_not_null NOT NULL,
    user_name character varying(256),
    normalized_user_name character varying(256),
    email character varying(256),
    normalized_email character varying(256),
    email_confirmed boolean CONSTRAINT asp_net_users_email_confirmed_not_null NOT NULL,
    password_hash text,
    security_stamp text,
    concurrency_stamp text,
    phone_number text,
    phone_number_confirmed boolean CONSTRAINT asp_net_users_phone_number_confirmed_not_null NOT NULL,
    two_factor_enabled boolean CONSTRAINT asp_net_users_two_factor_enabled_not_null NOT NULL,
    lockout_end timestamp with time zone,
    lockout_enabled boolean CONSTRAINT asp_net_users_lockout_enabled_not_null NOT NULL,
    access_failed_count integer CONSTRAINT asp_net_users_access_failed_count_not_null NOT NULL,
    created_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone CONSTRAINT asp_net_users_created_at_not_null NOT NULL,
    time_zone character varying(256),
    updated_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone CONSTRAINT asp_net_users_updated_at_not_null NOT NULL,
    version bigint DEFAULT 1 CONSTRAINT asp_net_users_version_not_null NOT NULL
);


--
-- TOC entry 263 (class 1259 OID 37435)
-- Name: refresh_tokens; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.refresh_tokens (
    id uuid NOT NULL,
    token text,
    expired_date timestamp with time zone NOT NULL,
    user_id uuid NOT NULL
);


--
-- TOC entry 264 (class 1259 OID 37443)
-- Name: user_accesskeys; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_accesskeys (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    descriptor_id bytea NOT NULL,
    public_key bytea NOT NULL,
    signature_counter bigint NOT NULL,
    device_name character varying(256),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    version bigint DEFAULT 1 NOT NULL
);


--
-- TOC entry 265 (class 1259 OID 37457)
-- Name: user_bans; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_bans (
    id uuid NOT NULL,
    user_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    user_ban_reason_id integer NOT NULL
);


--
-- TOC entry 266 (class 1259 OID 37468)
-- Name: user_devices; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_devices (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    system_environment_user_name character varying(255),
    time_zone_minutes integer,
    device_unique_identifier character varying(255),
    device_model character varying(255),
    device_type character varying(255),
    operating_system character varying(255),
    processor_type character varying(255),
    processor_count integer,
    system_memory_size integer,
    graphics_device_name character varying(255),
    graphics_memory_size integer,
    system_info_supports_instancing boolean,
    system_info_npot_support character varying(255)
);


--
-- TOC entry 267 (class 1259 OID 37475)
-- Name: user_sessions; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    refresh_token_hash bytea CONSTRAINT user_sessions_token_hash_not_null NOT NULL,
    is_used boolean NOT NULL,
    is_revoked boolean NOT NULL,
    inactivated_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    user_device_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    user_session_inactivation_reason_id integer DEFAULT 0
);


--
-- TOC entry 268 (class 1259 OID 37493)
-- Name: users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.users (
    id uuid NOT NULL,
    email character varying(255),
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    time_zone character varying(255),
    is_admin boolean DEFAULT false NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 5303 (class 0 OID 37182)
-- Dependencies: 224
-- Data for Name: equipments; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.equipments (id, user_id, version, created_at, updated_at, base_equipment_id, group_name, hero_id, slot_id) FROM stdin;
03c21165-35ea-40eb-93d4-c8e0a21f12c2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
0728f0a9-4467-4b19-8327-ad7a38b999d6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
0818ce4d-a550-4af1-9720-47e6e34d93f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
0941dcf5-f725-43ee-93c5-99025a0749f3	019b7d31-93fd-703f-a582-c82e6bd40036	2	2026-01-02 17:53:16.146893+08	2026-02-15 11:08:54.840533+08	4	\N	21b8d7da-a0d5-464b-a845-4afb764f9314	4
ba0e4120-ce83-4b6b-a773-a7608c9ab6fb	019b7d31-93fd-703f-a582-c82e6bd40036	2	2026-01-02 17:55:03.324747+08	2026-02-14 23:39:55.187786+08	3	\N	df3d5869-fd33-436b-a34e-ae200a67fbc3	1
0baea179-2ced-4c5f-98bf-db2e215756fa	019b7d31-93fd-703f-a582-c82e6bd40036	2	2026-01-02 17:53:16.146893+08	2026-02-14 23:42:22.81086+08	3	\N	0dfbeb24-96fc-486e-8a45-8e07a6c40aa0	1
\.


--
-- TOC entry 5304 (class 0 OID 37195)
-- Dependencies: 225
-- Data for Name: heroes; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.heroes (id, user_id, version, created_at, updated_at, base_hero_id, health1000, strength, agility, intelligence, crit_chance, crit_power, haste, versality, endurance_physical, endurance_magical, resist_damage_physical, resist_damage_magical, experience_now, group_name, level, rarity, damage) FROM stdin;
00d15172-a3af-4d5b-b74a-afff5e4f40ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
0266366e-b12a-469c-803f-b7ee15b27873	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
04656b9b-054e-46e5-a1e9-37a89f7a567c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
05dffd34-79a7-4ff1-acf2-21fd50813567	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
0754256d-73cf-491b-9db5-6d602d5f6d85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
07a88b06-e936-47ad-a6b6-3a7bcbc9b2ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
08408de3-dae4-4f8c-9d2e-0a51f2a7f2c7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
08e3971a-f82b-495d-99d8-500b901ef8a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
0aeef53d-4cd4-418b-afbb-f5410a3f3928	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
0b643d98-6e79-435f-933d-e5509760dd1a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
0cf13183-5006-4ec3-be7d-b5c6baf97f32	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
0dfbeb24-96fc-486e-8a45-8e07a6c40aa0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
0ed634b5-ecc9-43cb-835d-4be0cfe2d7fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
143d2a3b-b95e-4d37-8c43-469d7adb0bd4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
14b74ba6-ac36-4175-a598-a1635ac7d990	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
15997452-6402-4b73-9e45-317bf4175749	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
15a600d4-bd74-46b8-b517-7aef13bf8409	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
164918fa-e22a-4967-98b5-133fcf95a176	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
17e05720-b2b4-42c4-86fc-e07b7a110099	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
18cbf529-1ff3-4207-9471-7fc56481c5b0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
1bf8858e-4976-4c1e-a1ca-4536fedcd9f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
1c126ec2-7da6-4336-99e2-193f91ee4ef3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
1c668c54-9a1a-42dc-8cde-0726b2e3c3e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
1eca8648-1ee4-4a2f-85f9-bfddb1d553c4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
21b8d7da-a0d5-464b-a845-4afb764f9314	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
2338b545-48d8-41f0-bb27-1706937571c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
235a0901-ad04-48ed-96a2-1cfa40889ba3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
24217f56-f036-4aa6-9903-28891644aefc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
260dc441-c013-4e75-8e4a-8d131d2f37e2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
26953a41-ac9b-4a74-851b-483d85cfdada	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
27ab0120-3d47-484f-ad6a-3417ce5562cf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
28b197a1-4e7e-4dd4-9b80-1634ae196c03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
28b6618a-e460-4a11-a1db-0006e70a8a03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
29149a2a-f227-4e48-b3d8-45784b5f5fe5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
2994039f-7818-4bc3-8496-40b1908b048e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
299b966a-b4d9-41fc-a78c-5dcf9d55e176	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
2a2dc63e-0ad8-48fe-9544-bcab07ae160a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
2ab86ee2-ae56-4008-9b1a-d034c1790977	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
2d8330a3-ee74-401a-82a9-b738dd4a13a2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
2daf9231-5dd6-4957-b81b-734092b3e3d2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
2e0d1dd3-3445-462a-82b9-291d67f5dba0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
2eb96905-9161-4046-b21c-ea225a83c57e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
2ef1f600-ff3a-4fee-a4cc-3c156cc8879c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
33136c07-231f-4e3a-9d28-754750e34c82	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
347c32b1-be4c-424c-b9f2-26f0b6e7b8f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
352f4318-ab60-4d8f-8733-b4a06b837a28	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
3554516d-5d1d-40dd-bc0a-382f3cdd6175	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
35ce8e97-293c-4498-8080-6f7707a951ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
36621c98-6130-4705-bc35-e4ee62bf9834	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
37321558-1511-44ea-9dcc-f3abacc0b722	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
39533131-8e76-494e-b892-72e0bdaca095	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
3a004616-16ec-4fc0-84f3-979ca75f5458	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
3a4f3e78-8e09-499a-b51f-0ab76a642cf1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
3c8f700c-7c97-4b9c-beec-bce8386fab21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
3dcf3d9b-18cd-43f5-9ac4-7f2a6e9cbc4b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
3e08f530-b3e5-4c2b-83a3-6a30c1d70895	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
3e3bb90b-9765-46ad-91d0-0af6e027fa60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
3feae5f6-4173-43c9-8674-9472be58d11d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
417d044d-f573-4ff9-9494-0f5e7e2bb983	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
43de1edd-e6c0-436e-a72c-ddb657a37c67	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
444c5f8d-541c-4448-b2d6-f08e81e84a02	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
44c7f1b3-7a29-4af2-a641-1aedee48ad49	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
45c4bf90-5f56-433d-aa18-2c53a79c55a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
47384d33-dfb2-4e33-8953-f1f237e4dfe1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
47941a9f-9397-4d41-b8c6-7ccdb4038c03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
47ad56fd-e6e7-4b14-adb2-14c90cc01041	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
498ee4a9-4814-496b-a57b-2186a17501ca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
49b9cbda-2d0b-43f3-a3c7-b902216a458d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
4b216c1a-dcd8-4bb6-8dd4-b65323e7659a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
4badfaf1-690c-4eec-bc94-88cf458bdb2f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
4de978cd-1498-4ea9-8b3d-5f7a9f49dead	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
4e2bd5bd-e070-4833-a399-c36169364991	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
4ed77d72-b373-43d0-a740-71c5986d6b8a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
50140a70-35e3-48fe-87ec-78d750e87829	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
51f0791d-c533-4e99-bfc5-45487eb0b798	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
5378244b-33d9-40cd-b979-f6caf9e20624	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
53aaa744-d42f-4ba8-a9d1-f780be297b2e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
5483ba12-b589-42f2-840d-e95ccc5353bc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
549109c6-87f6-4e13-8208-7e8de50e07e7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
566dd384-a6ee-43cd-88be-7ed3c9870edb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
567aec0c-fc1d-4f68-9208-3d1ec66d8bc5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
57a8f725-f89f-4536-a1a9-baa402c2eaa2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
587a8df8-3c79-4f58-872c-e4942752f0a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
5a6e0f92-82b5-4a21-a0e4-121bc823e0c6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
5ca8da99-0bb2-416f-81ce-c687393c6eb6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
5ca99e73-3fc5-45b3-9da9-7f90aaf8a727	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
5d263dfd-f053-4b02-8bd6-6ba87393d3c0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
602632ba-91bc-4d93-ae4c-456df49617d1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
61bb7d59-a254-40d8-bdfa-7cdbebd7de8b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
65e4d6ae-c24f-4b06-adc8-a88b3da71afa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
67aee31b-94ef-4e2a-9fa0-f2440106123d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
67b0ded4-13d6-4ff7-a84d-813cdaae250d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
686f057b-c241-4482-9cd7-05a9877564b2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
69079a58-6f66-4573-891d-aa2148178761	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
6a7b5600-f310-4b58-8c06-42f2227ae46d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
6cf5f15e-d67b-4c4f-aa46-4e4073b1fed4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
6d65f37f-e3c4-4698-955a-40726263b0ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
6d9e52cc-2644-47df-a0c8-86671aaedce5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
6db66014-a2ad-475b-9a2d-e0a2b1432eec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
702d89ff-47ad-4a87-838a-2862346fea1d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
70ec6702-e712-4f01-9ae1-c9917103faed	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
72dfce7a-6b85-4b56-ac05-efd8abe1fdb8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
72fd8f83-0e33-4355-9743-829c68f17501	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
7309230e-9f0e-4e56-985c-c79a1320ea97	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
73162e8a-595f-4001-8757-fe1ad4aa6c33	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
7573ced8-e346-4d0d-a836-8bbb4e2bdf28	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
77da8bc1-f6d3-4aa4-86e2-0dfdc647cc4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
77fb8139-31ec-4fdb-9626-8cd844159158	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
79a7bf50-bfa8-4d9d-a940-669caa4877e8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
7a2041d7-3afb-4301-aaf2-0c589ba59b43	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
7ab5047f-d279-4ae6-bac7-a5d06e480986	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
7b30180a-c80e-4d8f-b471-24a7a979e61b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
7c83549e-9983-45b8-b5a1-6d6de58d7c79	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
7d0f369f-2d57-4d41-97d5-ac3c53703898	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
7f09f517-1cfc-4dc6-b01d-bfc75bb06a26	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
817541c5-5ae1-453c-bfc1-f77ca632f52b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
84932dae-6f57-43e8-81c9-7f00d00383d7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
84b0d445-4047-4d32-84cb-34244a67d72d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
85241ad0-9eca-4ca4-a615-69cd595423b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
85f46ec5-d1d6-4771-a3d9-20dcae0dca4b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
887a9f50-0b29-4162-bd96-31be110f0e41	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
88c4caad-6959-47a9-a66c-668111d847f8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
89e6ad14-944f-49c8-ba88-84d26dbd714d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
8ebb103b-a606-404e-89dc-aeb034769481	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
8f353329-0d5c-45e6-b845-f0cce6b63002	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
8f3a7207-72c7-45bf-9e90-f54d99845a59	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
90414897-1a40-4503-8b40-7ec27abe4996	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
91030051-7ab7-4c87-bd45-5995f27f21a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
912c2462-9baf-469b-b864-df1981b81198	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
91ba5479-f3ba-48d1-9610-616f4ea1ad13	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
924f92f3-1031-4251-88c7-79d58b1bb6f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
92ce93cb-9ab5-47e3-8eb7-bcd596e379b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
932acfe8-1010-4f6e-88ef-dc51a3515442	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
93913d4f-eb01-4f5d-8706-d086436bd816	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
9404d5b8-aebf-49d6-94eb-583a43c37ea7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
94f6739e-b3a2-4463-bbba-d07f067c754c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
96c51438-3f00-4037-b046-f84abd0c9c5e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
976ad311-bcc9-4529-9c4f-2248e4a6439c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
9879c96e-c051-420e-beac-04d7177203ad	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
9972340a-728e-4772-8ac7-7e01752ad3ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
99b7f946-a50a-44c4-8a45-e07e703fe563	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
9ab7e8b5-87ba-41b6-9372-bdb2c353b9a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9b280c5f-fbaf-4676-8c97-0db424ee52b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9bf7a6bc-db0d-4cb1-898b-33c972ca0977	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9c366980-6b1c-499c-9839-9c8467da26c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
9ca6453f-e5d8-4cde-9629-038316cbc150	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
9cdcf225-7d3a-4abf-ad76-34a2a6a88f54	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9dec1ea9-34e4-48b6-9e56-390e7064e518	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9e39cbe2-b61e-4ad2-ac1b-e25d6835ff90	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
a06c3454-2df7-4f50-8c6e-e1b712329a12	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a2a422ff-d378-4d31-b983-8338200adb85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a556f541-3a99-43fb-b7b7-c540f3c1137f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a73a02e7-200d-40ef-91d2-d0e3f9a12d3e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a7586e78-024a-432a-8a10-ecc2dfc44a16	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a810022f-b398-4cdb-b121-5da91566af50	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
a928352e-38b5-491f-987b-4616c1c557db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
ab19f278-6e8b-42f4-b4f8-b757e84524ed	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
ab96228d-cfee-460d-a42b-4c8472f13fd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
ac2c2a75-11f0-48eb-8265-60c582270c43	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
ac77287e-2332-4bab-93ef-c92485d3d887	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
ae954a8c-e01b-4848-a0ac-3b62fdb22ece	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
affbc6fd-eb14-436a-8072-e998d5f6df4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
b168f7f2-a4f2-4a7d-8fe8-d2a3f8751931	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
b2057ed6-7d8f-460d-8092-ea8fc8aa0843	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
b3157acb-c35e-4ebd-896d-c558762f42e1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
b3232122-d4e7-449a-aa9a-1ea3c000415f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
b52ddded-2886-4028-a8c5-312a9f7d4b67	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
b635e153-c218-492e-b961-af2c5deb985f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
b7fc51e6-bb13-487a-9ce9-f7a11461d255	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
b95e820e-eeff-42ad-a2d3-e9eb7fb2864b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
b9bafd58-7007-472f-8b49-6d21de3b7ce5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
bbd74e3d-60e1-486d-a528-2dcb93c5f09d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
bd019229-908d-4a6b-89ea-ded814b6343c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
c184f138-d63e-4a9d-82ad-5dc2f675f73d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
c28d7f23-b962-4b6a-8273-cafc97bc1984	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
c2c1f159-c5d5-45ec-8ad3-7bb85c7ad697	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
c355be9f-5f2d-4a0d-a29e-614cbe507803	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
c5995d09-8512-49a1-bcb2-c45c409876e6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
c59bcd6f-fbed-43fb-a0de-80f6bbc72de1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
c7205015-f658-4978-a048-cfdf148bbe68	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
cad48311-9743-4f9b-baf4-d59c410afbb0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
cb3112b1-6623-4243-bd3c-9db977223401	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
cdca3c82-9a42-4739-93b5-6e815921883d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
ce9c45fa-65a9-45ed-b8b1-99ff12349fd4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
cf7ccdfe-58aa-4457-85dc-6020ab16a872	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
cfbae36f-dde6-4fc9-9984-96332b4df1a0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
d05000de-d4b1-4968-9cb6-1e2a9a71651a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
d476bf17-3e8a-4ed4-9185-bf53826f3c7e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
d5e5039c-64c4-4640-a884-7ff67ce83917	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
d63fae21-d77f-4267-b614-f3fec4a5013f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
d65c68f7-8f0b-40bc-9406-e21ab3995426	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
d7012e7f-7d97-4860-b490-2ffed166b752	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
d9addd2a-4362-4893-af6a-3939578711c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
da070b1b-2c6d-4c82-a5dc-8d00e70163ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
db45a856-033e-47b9-9aeb-5b95a4f4fc62	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
de36369c-53ef-4eab-901e-d4a494bbfe6b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
df3d5869-fd33-436b-a34e-ae200a67fbc3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
df6a9350-2d5c-4626-934b-2d87f272c209	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
e0273cb3-0aac-47a9-b1c1-80f2fef6964d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
e1a90213-17a4-4a31-be8f-6b90c9977891	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
e47c25a7-53e8-49a3-bbe2-08ff8d39c299	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
e5b44b3f-8179-4e43-b1cc-e7a0176fbbb1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
e91cc994-36ea-4186-ad1f-7c1b100e3639	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
e99a18e3-b1bb-429f-99b4-f7c0bcf9198b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
eb1f65e7-0c6b-400f-ab99-f573986a5e2e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
ed418019-be95-4ce1-b66d-b6d77bb819bc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
ee9aabcf-d974-46fb-954d-63a6b95f181b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
ef074ea3-d9df-4dbc-b770-b12c6103017f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
f1340e8e-e78e-453f-a504-ea78bcfa95a3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
f175eeaa-a3a8-4e90-97aa-100261d4fe52	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
f3aa4050-9419-4d39-96e4-e679f3d12531	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
f41e2f91-2f66-4c3d-bf89-042319dbf9d0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
f43c1ce5-23d6-416c-b15c-1f48d4094408	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
f45ae12f-83ed-43b3-90cd-b45d7dc8f5f0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
f520e26b-8245-4a73-81e2-df07196c7835	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
f6c8110a-2387-4948-bc41-0e476dc2dbf9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
fa372fc6-1741-4b3e-99ab-6e02755b622c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
fa3b5524-a911-4f8a-a7d9-f1aecb2426fe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
fb283b84-6e4d-466c-998c-a4b0b1099330	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
fbb50ac2-4700-4f88-908f-d6ca43309560	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
fbed6823-1e5e-4687-8d70-8eb1bf80d40e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
fce0c821-3b32-45b9-8099-d9fd1b1627f8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
\.


--
-- TOC entry 5305 (class 0 OID 37225)
-- Dependencies: 226
-- Data for Name: base_equipments; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_equipments (id, name, rarity, is_unique, equipment_type_id, health, damage, smithing_material_id) FROM stdin;
2	Iron axe	1	f	2	\N	\N	1
3	Thunderfury	4	t	15	\N	\N	11
4	Iron armor	1	f	28	\N	\N	1
5	Iron gloves	1	f	26	\N	\N	1
6	Iron helmet	1	f	27	\N	\N	1
8	Iron boots	1	f	29	\N	\N	1
1	Iron sword	1	f	1	\N	\N	1
\.


--
-- TOC entry 5307 (class 0 OID 37237)
-- Dependencies: 228
-- Data for Name: base_heroes; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_heroes (id, name, rarity, is_unique, main_stat, health, damage) FROM stdin;
2	Huntress	1	f	2	{"c": 10, "s": 28}	{"c": 5, "s": 21}
3	Hammerman	1	f	1	{"c": 11, "s": 39}	{"c": 3, "s": 25}
4	Rogue	1	f	2	{"c": 15, "s": 21}	{"c": 4, "s": 23}
5	Battle orc	2	f	1	{"c": 16, "s": 58}	{"c": 4, "s": 21}
1	Warrior	1	f	1	{"c": 16, "s": 24}	{"c": 4, "s": 21}
\.


--
-- TOC entry 5309 (class 0 OID 37250)
-- Dependencies: 230
-- Data for Name: creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.creature_types (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5311 (class 0 OID 37256)
-- Dependencies: 232
-- Data for Name: damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.damage_types (id, name, name_ru, dev_hint_ru, category) FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)	1
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 	1
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)	1
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда	1
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"	0
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."	0
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."	1
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."	2
11	Radiant	Лучистый	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."	2
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."	2
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."	2
17	Dark magic	Тёмная магия	Критерий\tНекротический урон\tТёмная магия (Shadow/Dark)\nСуть\tРазложение, смерть, конец.\tСтрах, боль, подавление, коррупция.\nИсточник\tСмерть, небытие, пустота, анти-жизнь.\tОтрицательные эмоции, тени, извращённая магия, пакты с тёмными сущностями.\nКак выглядит/ощущается\tХолод, влажность, запах тления, серо-зелёные тона, иссушение, гниение.\tХолод или ледяное жжение, ощущение ужаса, давление на разум, чёрные/фиолетовые тона, искажение света.\nЭффект на живую цель\tВысасывает жизненную силу, вызывает быстрое старение, некроз тканей, разложение.\tДробит волю, наводит ужас, вызывает боль, ввергает в отчаяние, может подчинять разум.\nЭффект на нежить\tЧасто исцеляет или усиливает (это её родная стихия).\tМожет наносить урон (как любая агрессивная магия), а может усиливать, делая более агрессивной.\nЭффект на демонов/исчадий\tОбычно эффективен (смерть для всех).\tЧасто неэффективен или даже подпитывает их (они сами из этой энергии).\nТипичные заклинания\t«Палящий взгляд», «Круг смерти», «Вытягивание жизни», «Увядание».\t«Стрела Тьмы», «Объятья страха», «Проклятие боли», «Порча разума».\nАналогия\tРадиация или смертельная болезнь. Убивает всё живое, разлагает материю.\tПыточный инструмент или психологическая пытка. Ломает дух, чтобы сломить тело.\nЦель атаки\tТело и душа (физическое уничтожение).\tПсихика и дух (ментальное подчинение → физический урон).\nАрхетип мага\tНекромант. Холодный учёный смерти.\tЧернокнижник, Тёмный колдун. Эмоциональный манипулятор, заключивший сделку с силами тьмы.\n	2
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."	0
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."	0
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."	0
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."	0
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."	0
\.


--
-- TOC entry 5313 (class 0 OID 37266)
-- Dependencies: 234
-- Data for Name: equipment_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.equipment_types (id, name, name_ru, mass_physical, mass_magical, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, spend_action_points, block_other_hand, damage) FROM stdin;
1	Sword	Меч	1600	0	1	t	f	0	\N	{"c": 8, "s": 4}
2	Axe	Топор	2800	0	1	t	f	0	\N	{"c": 4, "s": 17}
3	Halberd	Алебарда	4400	0	1	t	f	0	\N	{"c": 4, "s": 27}
4	Berdysh	Бердыш	3800	0	1	t	f	0	\N	{"c": 4, "s": 23}
5	Poleaxe	Секира	4000	0	1	t	f	0	\N	{"c": 4, "s": 24}
6	Chakram	Чакрам	350	0	1	t	f	0	\N	{"c": 5, "s": 3}
7	Shuriken	Сюрикен	180	0	1	t	f	0	\N	{"c": 6, "s": 2}
8	Scythe	Коса	3200	0	1	t	f	0	\N	{"c": 5, "s": 3}
9	War fan	Боевой веер	800	0	1	t	f	0	\N	{"c": 5, "s": 3}
10	Scimitar	Скимитар	1200	0	1	t	f	0	\N	{"c": 6, "s": 4}
11	Katana	Катана	1100	0	1	t	f	0	\N	{"c": 7, "s": 3}
12	Yataghan	Ятаган	1000	0	1	t	f	0	\N	{"c": 6, "s": 3}
13	Sabre	Сабля	1100	0	1	t	f	0	\N	{"c": 7, "s": 3}
14	Morning star	Моргенштерн	5000	0	1	t	f	0	\N	{"c": 1, "s": 123}
15	Warhammer	Боевой молот	6200	0	1	t	f	0	\N	{"c": 1, "s": 153}
16	Mace	Булава	3000	0	1	t	f	0	\N	{"c": 1, "s": 73}
17	Crossbow	Арбалет	3200	0	1	t	f	0	\N	{"c": 14, "s": 2}
19	Trident	Трезубец	3400	0	1	t	f	0	\N	{"c": 28, "s": 2}
20	Rapier	Рапира	850	0	1	t	f	0	\N	{"c": 8, "s": 2}
21	Pike	Пика	2800	0	1	t	f	0	\N	{"c": 24, "s": 2}
22	Spear	Копьё	2200	0	1	t	f	0	\N	{"c": 20, "s": 2}
23	Broadaxe	Широкий топор	5200	0	1	t	f	0	\N	{"c": 4, "s": 32}
24	Dagger	Кинжал	400	0	1	t	f	0	\N	{"c": 4, "s": 2}
18	Bow	Лук	960	0	1	t	f	0	t	{"c": 4, "s": 2}
26	Hands	Руки	1240	0	7	t	f	0	\N	\N
27	Helmet	Шлем	1240	0	4	t	f	0	\N	\N
29	Boots	Сапоги	1860	0	9	t	f	0	\N	\N
25	Waist	Пояс	2170	0	10	t	f	0	\N	\N
28	Armor	Доспех	2480	0	6	t	f	0	\N	\N
\.


--
-- TOC entry 5315 (class 0 OID 37286)
-- Dependencies: 236
-- Data for Name: material_damage_percents; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.material_damage_percents (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5317 (class 0 OID 37294)
-- Dependencies: 238
-- Data for Name: slot_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slot_types (id, name, name_ru, have_alt_slot) FROM stdin;
4	Head	Голова	f
6	Armor	Доспех	f
7	Hands	Руки	f
9	Feet	Ступни	f
10	Waist	Пояс	f
17	Neck	Шея	f
2	Shield	Щит	f
1	Weapon	Оружие	t
14	Ring	Кольцо	t
16	Trinket	Аксессуар	t
\.


--
-- TOC entry 5319 (class 0 OID 37302)
-- Dependencies: 240
-- Data for Name: slots; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slots (id, name, slot_type_id, main_slot) FROM stdin;
1	RightHand	1	t
3	Head	4	t
4	Armor	6	t
5	Hands	7	t
6	Feet	9	t
7	Waist	10	t
8	Ring1	14	t
10	Trinket1	16	t
12	Neck	17	t
9	Ring2	14	f
11	Trinket2	16	f
2	LeftHand	2	t
\.


--
-- TOC entry 5321 (class 0 OID 37309)
-- Dependencies: 242
-- Data for Name: smithing_materials; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.smithing_materials (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5323 (class 0 OID 37321)
-- Dependencies: 245
-- Data for Name: x_equipment_types_damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_equipment_types_damage_types (equipment_type_id, damage_type_id, damage_coef) FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5324 (class 0 OID 37328)
-- Dependencies: 246
-- Data for Name: x_heroes_creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_heroes_creature_types (base_hero_id, creature_type_id) FROM stdin;
\.


--
-- TOC entry 5325 (class 0 OID 37333)
-- Dependencies: 247
-- Data for Name: authentication_logs; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.authentication_logs (id, version, created_at, email, user_id, success, user_device_id, ip, user_session_id) FROM stdin;
019c1957-09c6-7316-8f3f-b207798bd800	1	2026-02-01 21:14:20.504008+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c1967-4f67-7318-ac76-57c0a5bfa3d3	1	2026-02-01 21:32:06.91431+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c1967-b0ee-75cb-aef8-30d75dc93952	1	2026-02-01 21:32:31.854783+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c1968-12a4-77f3-8a87-c331828e6289	1	2026-02-01 21:32:56.868583+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c1969-4b22-77c1-ba36-771c55aaad8f	1	2026-02-01 21:34:16.866484+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c20fa-2834-70f3-a6a0-df86b7164725	1	2026-02-03 08:49:51.178507+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c20fa-b0cb-73dc-bd15-b62c0e1ea2f5	1	2026-02-03 08:50:26.124203+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c20fe-8162-71eb-aace-b425dfe7b671	1	2026-02-03 08:54:36.130796+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2100-2b9a-735b-8e12-e79407563bfd	1	2026-02-03 08:56:25.254795+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2102-4e7c-728f-b0e3-82d2d599b92f	1	2026-02-03 08:58:45.244383+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2105-34ac-75e1-a047-db2f8b439d86	1	2026-02-03 09:01:55.245632+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2134-07f0-7007-88ab-2dcc8dfb130e	1	2026-02-03 09:53:03.996666+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2141-759f-717d-a3a3-46aac31fd6a8	1	2026-02-03 10:07:44.032175+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2144-34d9-7210-9647-60873cd9305b	1	2026-02-03 10:10:44.057774+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2153-2287-75c3-bb81-31cdc4ec2aa5	1	2026-02-03 10:27:02.418455+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2154-4776-7445-bb28-3a923d8e07fc	1	2026-02-03 10:28:17.398672+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2155-ba97-7087-87f6-de11fe20db84	1	2026-02-03 10:29:52.407967+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2156-6a5e-72ad-8c1f-093103b79e69	1	2026-02-03 10:30:37.406786+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2157-b66d-7451-8395-0aa855517ce5	1	2026-02-03 10:32:02.414072+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c215f-098e-718d-96b1-44ead5e9bd5e	1	2026-02-03 10:40:02.446806+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2161-18ed-7581-a33f-b5b402876dc9	1	2026-02-03 10:42:17.45419+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c216b-65d1-765f-b031-fa43c668d1cc	1	2026-02-03 10:53:32.497969+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c216c-291f-7263-a6a9-b0eef4da6f86	1	2026-02-03 10:54:22.495808+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c216c-d8ef-7402-b1d5-1ba04f3067c7	1	2026-02-03 10:55:07.503532+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c216e-d4c3-7543-b4e5-82d2cdb68a93	1	2026-02-03 10:57:17.507369+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2171-8072-770f-ac39-f67e927c9e02	1	2026-02-03 11:00:12.530562+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2173-41ad-70c4-987a-47ca259a050b	1	2026-02-03 11:02:07.533962+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2174-8db4-7520-bd9d-45a61033599c	1	2026-02-03 11:03:32.532607+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c217a-813e-76c6-abdd-2b239a05bd85	1	2026-02-03 11:10:02.559056+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c217b-310e-7220-a47c-b381fdfb28c0	1	2026-02-03 11:10:47.566941+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c217b-a63c-7111-a8b2-f73c38b02802	1	2026-02-03 11:11:17.56467+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c217d-2ce1-76c1-bd86-df68394bccec	1	2026-02-03 11:12:57.569153+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c218e-6b2a-76e7-bf4b-0d6729c8e09c	1	2026-02-03 11:31:47.627119+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2191-0343-751e-a3b3-209794abc644	1	2026-02-03 11:34:37.635767+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2192-eb9b-7460-b43b-5d0d9991f5b1	1	2026-02-03 11:36:42.651938+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2194-fafb-7368-8226-711bca87bf65	1	2026-02-03 11:38:57.659469+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2195-9734-73b4-ac0f-3766e087b748	1	2026-02-03 11:39:37.652146+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2196-d62e-7104-ad83-e3b8fe0785b9	1	2026-02-03 11:40:59.320286+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c2198-222c-7033-9e2f-c3fc72a0a179	1	2026-02-03 11:42:24.301122+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c21bb-3ca1-70ab-bf91-93a24f4b2089	1	2026-02-03 12:20:44.833364+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	6f21aa64-9da0-8689-a7e3-1275e9272c53	127.0.0.1	\N
019c3349-578a-75f4-831a-ec373ddb21f4	1	2026-02-06 22:09:30.526862+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c334d-a21e-774f-84b2-e7185cb00657	1	2026-02-06 22:14:11.764159+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c5a93-32ab-749c-8ee9-ac5951dada0f	1	2026-02-14 13:15:22.173494+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c5b40-7bda-70e4-a1dc-0773db44d9cb	1	2026-02-14 16:24:38.636189+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c5b42-e1d5-7667-a36a-e713f786a8e7	1	2026-02-14 16:27:15.823642+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c5c12-4dad-7025-8767-5340a1a6fa57	1	2026-02-14 20:13:49.374507+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c5c37-c047-714d-9ac4-9e8779bc454f	1	2026-02-14 20:54:43.544955+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
019c5cd1-2f1a-72fd-bf08-b2380302785a	1	2026-02-14 23:42:18.924073+08	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1e5022ef-a866-824a-9e8a-cfbab69f91f7	127.0.0.1	\N
\.


--
-- TOC entry 5326 (class 0 OID 37343)
-- Dependencies: 248
-- Data for Name: registration_logs; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.registration_logs (id, version, created_at, email, user_id, success, user_device_id, ip) FROM stdin;
\.


--
-- TOC entry 5327 (class 0 OID 37353)
-- Dependencies: 249
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251218141532_Init	10.0.1
20251219010850_Fix1	10.0.1
20251219104853_Fix2	10.0.1
20251219125100_Fix3	10.0.1
20251219144649_Fix4	10.0.1
20251219145307_Fix5	10.0.1
20251220111640_Fix6	10.0.1
20251220140152_Fix7	10.0.1
20251221062947_Fix8	10.0.1
20251221115503_Fix9	10.0.1
20251221115727_Fix10	10.0.1
20251222005509_Fix11	10.0.1
20251222005528_Fix12	10.0.1
20251222012124_Fix13	10.0.1
20251222014603_Fix14	10.0.1
20251222032345_Fix15	10.0.1
20251222082512_Fix16	10.0.1
20251222142042_Fix17	10.0.1
20251224050619_Fix18	10.0.1
20251224060154_Fix19	10.0.1
20251224071911_Fix20	10.0.1
20251224075948_Fix21	10.0.1
20251224084507_Fix22	10.0.1
20251224125003_Fix23	10.0.1
20251229100603_Fix24	10.0.1
20251230112703_InitIdentity	10.0.1
20251231063604_IdentityFix1	10.0.1
20260101132651_IdentityFix2	10.0.1
20260101140259_IdentityFix3	10.0.1
20260101154436_IdentityFix4	10.0.1
20260102073949_IdentityFix5	10.0.1
20260102074626_IdentityFix6	10.0.1
20260106100111_EquipmentFix1	10.0.1
20260106110903_EquipmentFix2	10.0.1
20260107064521_RefreshTokenInit	10.0.1
20260112031013_EasyRefreshTokenRemove	10.0.1
20260112061648_UserSessionInit	10.0.1
20260113004051_UserSessionFix1	10.0.1
20260123052621_UserSessionFix2	10.0.2
20260126004106_UserSessionFix3	10.0.2
20260126014922_Fix25	10.0.2
20260126030039_UserSessionFix4	10.0.2
20260127150706_Fix26	10.0.2
20260128080318_LogFix1	10.0.2
20260128151422_UserSessionFix5	10.0.2
20260214110326_EquipmentFix3	10.0.2
20260214110727_EquipmentFix4	10.0.2
20260214144229_EquipmentFix6	10.0.2
\.


--
-- TOC entry 5328 (class 0 OID 37358)
-- Dependencies: 250
-- Data for Name: user_ban_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_ban_reasons (id, name) FROM stdin;
\.


--
-- TOC entry 5330 (class 0 OID 37366)
-- Dependencies: 252
-- Data for Name: user_session_inactivation_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_session_inactivation_reasons (id, name, code) FROM stdin;
1	EXPIRED	1
2	ROTATION	2
3	USER_LOGOUT	3
5	MANUAL_REVOCATION	4
7	OTHER_DEVICE	5
\.


--
-- TOC entry 5332 (class 0 OID 37375)
-- Dependencies: 254
-- Data for Name: identity_role_claims; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_role_claims (id, role_id, claim_type, claim_value) FROM stdin;
\.


--
-- TOC entry 5336 (class 0 OID 37391)
-- Dependencies: 258
-- Data for Name: identity_roles; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_roles (id, name, normalized_name, concurrency_stamp) FROM stdin;
\.


--
-- TOC entry 5334 (class 0 OID 37383)
-- Dependencies: 256
-- Data for Name: identity_user_claims; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_claims (id, user_id, claim_type, claim_value) FROM stdin;
\.


--
-- TOC entry 5337 (class 0 OID 37397)
-- Dependencies: 259
-- Data for Name: identity_user_logins; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_logins (login_provider, provider_key, provider_display_name, user_id) FROM stdin;
\.


--
-- TOC entry 5338 (class 0 OID 37405)
-- Dependencies: 260
-- Data for Name: identity_user_roles; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_roles (user_id, role_id) FROM stdin;
\.


--
-- TOC entry 5339 (class 0 OID 37410)
-- Dependencies: 261
-- Data for Name: identity_user_tokens; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_tokens (user_id, login_provider, name, value) FROM stdin;
\.


--
-- TOC entry 5340 (class 0 OID 37418)
-- Dependencies: 262
-- Data for Name: identity_users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_users (id, user_name, normalized_user_name, email, normalized_email, email_confirmed, password_hash, security_stamp, concurrency_stamp, phone_number, phone_number_confirmed, two_factor_enabled, lockout_end, lockout_enabled, access_failed_count, created_at, time_zone, updated_at, version) FROM stdin;
019b7d31-93fd-703f-a582-c82e6bd40036	SUPERadmin@mail.RU	SUPERADMIN@MAIL.RU	SUPERadmin@mail.RU	SUPERADMIN@MAIL.RU	f	AQAAAAIAAYagAAAAEBag9pn4pztxrJtK71md3akGQ04Q/cWVqpDT8he8Ispn7t+HNGhKzrdXtWkKnE16vA==	JHMUKRZCKGMKN5TPX7UY47QU3OYRA44C	78551647-ef36-40b6-872c-bd8bbd3aa67e	\N	f	f	\N	t	0	2026-01-02 13:32:39.809088+08	\N	2026-01-02 13:32:39.809088+08	1
\.


--
-- TOC entry 5341 (class 0 OID 37435)
-- Dependencies: 263
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.refresh_tokens (id, token, expired_date, user_id) FROM stdin;
019b97b5-19de-7cb6-a733-9c1735bd282e	+gw9KupdUq+e1nwl8Urk0YYURi5SI63N0AA9h8oL06g=	2026-02-06 17:06:26.897926+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9cb1-838d-7606-9d32-a753d5c29f0a	zbv337X4UPQj1YMDjpGB13v58qF4gJTt+vCwocyHOBU=	2026-02-07 16:20:37.892781+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9cb1-ac6b-76e6-bad5-77534f4d9492	zTxcdbt3Hx5U6Hkv91NJi3pSHIYCP5zv0LAwRd8iSKw=	2026-02-07 16:20:48.363212+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9cc2-c976-7161-9cda-0264905335c8	tMctB+bwD1jxYyN+Sdbh1lgpOlQDnJW3mEqdxA+Y5fo=	2026-02-07 16:39:29.900663+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9cd6-9ed2-757b-b0b6-640b5894787b	Juy6D1OVoDsqbwfzfbO17GVBfwoGOBhCGt42S4gU+VY=	2026-02-07 17:01:09.713893+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9d0c-d09c-7692-80a3-705078979d3c	l0dR/jskyvfPOm4qggdl5IfwZ7+EXsr+5QLtfxdvL3s=	2026-02-07 18:00:21.404268+08	019b7d31-93fd-703f-a582-c82e6bd40036
\.


--
-- TOC entry 5342 (class 0 OID 37443)
-- Dependencies: 264
-- Data for Name: user_accesskeys; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_accesskeys (id, user_id, descriptor_id, public_key, signature_counter, device_name, created_at, updated_at, version) FROM stdin;
\.


--
-- TOC entry 5343 (class 0 OID 37457)
-- Dependencies: 265
-- Data for Name: user_bans; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_bans (id, user_id, version, created_at, updated_at, expires_at, user_ban_reason_id) FROM stdin;
\.


--
-- TOC entry 5344 (class 0 OID 37468)
-- Dependencies: 266
-- Data for Name: user_devices; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_devices (id, created_at, system_environment_user_name, time_zone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
1e5022ef-a866-824a-9e8a-cfbab69f91f7	2026-02-01 21:14:16.189161+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
6f21aa64-9da0-8689-a7e3-1275e9272c53	2026-02-03 08:49:50.428878+08	adm-shumkov	480	30af10590f9f87bea6b087c950be35295e8eee95	B760 DS3H (Gigabyte Technology Co., Ltd.)	Desktop	Windows 10  (10.0.19045) 64bit	Intel(R) Core(TM) i9-14900K	32	65296	Intel(R) UHD Graphics 770	32648	t	Full
\.


--
-- TOC entry 5345 (class 0 OID 37475)
-- Dependencies: 267
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_sessions (id, user_id, refresh_token_hash, is_used, is_revoked, inactivated_at, expires_at, created_at, updated_at, user_device_id, version, user_session_inactivation_reason_id) FROM stdin;
019c21ce-0e55-752f-a56e-73bbf0a64295	019b7d31-93fd-703f-a582-c82e6bd40036	\\x3f2f9bab0d6ef0c6107eb7d0fb874cbc298406c7dbda54f9565ecbbee91e5676	t	f	2026-02-03 12:43:12.533522+08	2026-02-17 12:41:18.165653+08	2026-02-03 12:41:18.165839+08	2026-02-03 12:43:12.533652+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21cf-cd15-77e4-ae1a-65a4cc091ae6	019b7d31-93fd-703f-a582-c82e6bd40036	\\x807b9f5d768f807ffa4f0930ba461fe66c3f6c7b91de00e0b1f15a503f0ed897	t	f	2026-02-03 12:50:04.785804+08	2026-02-17 12:43:12.533523+08	2026-02-03 12:43:12.533652+08	2026-02-03 12:50:04.785987+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21d6-1771-71c8-bf84-c782a035f6d5	019b7d31-93fd-703f-a582-c82e6bd40036	\\x7e9cbbd35d8bf0279a44f2570787a3bb67d5c6bcd6500197cbead041ceb07f75	t	f	2026-02-03 12:51:05.041274+08	2026-02-17 12:50:04.785805+08	2026-02-03 12:50:04.785987+08	2026-02-03 12:51:05.04145+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21bb-3650-717a-9b83-0562149ae1cc	019b7d31-93fd-703f-a582-c82e6bd40036	\\xf58c3e10546a90cf8fcf696a91fd9a8991480ecd281f321e0b3d2beea4a39800	t	f	2026-02-03 12:20:55.4667+08	2026-02-17 12:20:43.216025+08	2026-02-03 12:20:43.216296+08	2026-02-03 12:20:55.466867+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21bb-662a-76e0-94df-ade6650e40c3	019b7d31-93fd-703f-a582-c82e6bd40036	\\x51adeb91022ca17827ddf7342b24cd03246f5957f27ecf876a9a33f1256f0bc8	t	f	2026-02-03 12:30:07.892433+08	2026-02-17 12:20:55.466701+08	2026-02-03 12:20:55.466867+08	2026-02-03 12:30:07.892628+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21c3-d414-71b8-ac20-893a493792b3	019b7d31-93fd-703f-a582-c82e6bd40036	\\xbfb072dab1cadfb4904b705cd99a3e9488b7a67183cfbcd1b8f058232dde247e	t	f	2026-02-03 12:30:20.755472+08	2026-02-17 12:30:07.892433+08	2026-02-03 12:30:07.892628+08	2026-02-03 12:30:20.755649+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21c4-0653-7583-9e19-172470fd6f30	019b7d31-93fd-703f-a582-c82e6bd40036	\\xdfd9db6c21f0167e3adab42822fabeff8a61520bc32057b317fdbf259912989a	t	f	2026-02-03 12:41:18.165652+08	2026-02-17 12:30:20.755473+08	2026-02-03 12:30:20.755649+08	2026-02-03 12:41:18.165839+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21d7-02d1-77c2-90f8-946205674903	019b7d31-93fd-703f-a582-c82e6bd40036	\\xf4c37d0c2027869994d8960aff0a83f447977ce11b302ffaf0b46e39683d7e15	t	f	2026-02-03 12:52:54.255187+08	2026-02-17 12:51:05.041274+08	2026-02-03 12:51:05.04145+08	2026-02-03 12:52:54.255365+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21d8-ad6f-7141-814f-c958374acbf2	019b7d31-93fd-703f-a582-c82e6bd40036	\\x4ddd6a6358d1e454dca5f560b3a5bb6cd39f752d6faedbea81305a9237f4ba9a	t	f	2026-02-03 12:53:50.275776+08	2026-02-17 12:52:54.255188+08	2026-02-03 12:52:54.255365+08	2026-02-03 12:53:50.27592+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21d9-8843-7309-becc-c8e951f03314	019b7d31-93fd-703f-a582-c82e6bd40036	\\x417558b47435035089f608e1473ba5c16087a7d8f49387c55da7962841f32f35	t	f	2026-02-03 12:55:08.368916+08	2026-02-17 12:53:50.275776+08	2026-02-03 12:53:50.27592+08	2026-02-03 12:55:08.369056+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21da-b950-73fe-bfdf-6f1474e2e490	019b7d31-93fd-703f-a582-c82e6bd40036	\\x1359ddccf049dfb833501df7e4381155a2dace5c6a9c3ab71b8b9564149a6a07	t	f	2026-02-03 12:58:06.718929+08	2026-02-17 12:55:08.368916+08	2026-02-03 12:55:08.369056+08	2026-02-03 12:58:06.719072+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21dd-71fe-771e-a50b-18e80b144ec8	019b7d31-93fd-703f-a582-c82e6bd40036	\\x91d06532467687dc9072ee9650f4a7a5a840bf0b4611d78f0f73dc05576935bd	t	f	2026-02-03 13:04:49.627096+08	2026-02-17 12:58:06.718929+08	2026-02-03 12:58:06.719072+08	2026-02-03 13:04:49.62724+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21e3-97db-72e1-baac-5d7fc1d78024	019b7d31-93fd-703f-a582-c82e6bd40036	\\x3b0878cd20a38f1e32583051c19f07b2c6a12949822aabb2b759de0221e5eda4	t	f	2026-02-03 13:07:48.69339+08	2026-02-17 13:04:49.627096+08	2026-02-03 13:04:49.62724+08	2026-02-03 13:07:48.693525+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21e6-5355-7238-85d3-2bd26c5bda42	019b7d31-93fd-703f-a582-c82e6bd40036	\\xb94804614074b371ffb006f89baa6b83faf2cbf5c7c4815c81cd71aa8fe21bac	t	f	2026-02-03 13:10:01.34302+08	2026-02-17 13:07:48.69339+08	2026-02-03 13:07:48.693525+08	2026-02-03 13:10:01.343164+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21e8-597f-7505-a132-cd88c359cb84	019b7d31-93fd-703f-a582-c82e6bd40036	\\x694dd6937352a86aa2060a317b2da0e73a2415eea9ffb49e3717b5abeb4f1007	t	f	2026-02-03 13:14:32.773868+08	2026-02-17 13:10:01.34302+08	2026-02-03 13:10:01.343164+08	2026-02-03 13:14:32.773993+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21ec-7dc5-7234-922a-4f0a217ade91	019b7d31-93fd-703f-a582-c82e6bd40036	\\x0a559a59f74106cf5a6abec88c0d423d697c757c661458241f66537acdde257a	t	f	2026-02-03 13:15:08.726391+08	2026-02-17 13:14:32.773868+08	2026-02-03 13:14:32.773993+08	2026-02-03 13:15:08.726532+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21ed-0a36-75c1-8a46-9e822434de2b	019b7d31-93fd-703f-a582-c82e6bd40036	\\xc375528912452f355c67b08927af045f19e96989e401d003163ef996399f5c1d	t	f	2026-02-03 13:16:18.781373+08	2026-02-17 13:15:08.726392+08	2026-02-03 13:15:08.726532+08	2026-02-03 13:16:18.781497+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c21ee-1bdd-74b7-a490-b918ca44caaa	019b7d31-93fd-703f-a582-c82e6bd40036	\\xde2c6e82e320586c224ee084e92fead26ecd68ca3596795daa882357be7fd5bf	t	f	2026-02-03 13:19:06.558109+08	2026-02-17 13:16:18.781374+08	2026-02-03 13:16:18.781497+08	2026-02-03 13:19:06.558232+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c3349-559b-7041-adcb-8cee30cbc1c7	019b7d31-93fd-703f-a582-c82e6bd40036	\\x8fa366f6d17127666536559062ea14e5a3c5f68bf945ad60594a3f93b6e179b3	t	f	2026-02-06 22:12:44.569179+08	2026-02-20 22:09:30.010253+08	2026-02-06 22:09:30.075788+08	2026-02-06 22:12:44.572713+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c334c-4d99-750e-9d4c-21ee73407474	019b7d31-93fd-703f-a582-c82e6bd40036	\\x0c8ce62bea1ff4d3f5cc3cf49fc2692281ef1d5dd3360ab65aaf3156a36ec8cd	t	f	2026-02-06 22:13:20.357596+08	2026-02-20 22:12:44.56922+08	2026-02-06 22:12:44.572713+08	2026-02-06 22:13:20.357881+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c334c-d965-7428-9b1d-51c57e9d0025	019b7d31-93fd-703f-a582-c82e6bd40036	\\x959d77b6bc653cefcee313338644485edcf45c9f32288f583fc1e4a3386e7bc7	f	f	\N	2026-02-20 22:13:20.357597+08	2026-02-06 22:13:20.357881+08	2026-02-06 22:13:20.357881+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	1	\N
019c334d-988b-7775-b2ca-a05549cd31d4	019b7d31-93fd-703f-a582-c82e6bd40036	\\x519ab4437158fd6c06c7dd8c3b3f5515eab3cca3ed87794e1334bffdc852e246	t	f	2026-02-06 22:19:36.778152+08	2026-02-20 22:14:09.287728+08	2026-02-06 22:14:09.358087+08	2026-02-06 22:19:36.783107+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3352-97ca-72f6-8428-c0f1ea8f0e92	019b7d31-93fd-703f-a582-c82e6bd40036	\\x2272fb302039d6d7d53814ec28133aa3b3f31ceb37cdbf451c9746c0a1ab1410	t	f	2026-02-06 22:21:20.545917+08	2026-02-20 22:19:36.778232+08	2026-02-06 22:19:36.783107+08	2026-02-06 22:21:20.546221+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3354-2d21-73a9-a669-b1d601eeb4f7	019b7d31-93fd-703f-a582-c82e6bd40036	\\x55f41a160c9d957d8fbf2c4de1ebf4df23e2bfca947045d47122b72f1e4b5561	t	f	2026-02-06 22:22:00.645754+08	2026-02-20 22:21:20.545918+08	2026-02-06 22:21:20.546221+08	2026-02-06 22:22:00.645928+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3354-c9c5-70eb-8e69-cb3a1fbd68b7	019b7d31-93fd-703f-a582-c82e6bd40036	\\x6605d46ac3d9a6a5b67428115686e9c385266adefc20a4b93a169ee7fee05fb7	t	f	2026-02-06 22:22:57.786311+08	2026-02-20 22:22:00.645755+08	2026-02-06 22:22:00.645928+08	2026-02-06 22:22:57.786499+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3355-a8fa-751d-9330-16f7a2e5a1d6	019b7d31-93fd-703f-a582-c82e6bd40036	\\x2613a09d38b1dfaf0479949318a13349ae46cfb22accf13bc25e75a52da1d40a	t	f	2026-02-06 22:24:25.356317+08	2026-02-20 22:22:57.786312+08	2026-02-06 22:22:57.786499+08	2026-02-06 22:24:25.356578+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3356-ff0c-7706-be4d-b2f994f8c4e5	019b7d31-93fd-703f-a582-c82e6bd40036	\\x64706270919fd5d35b93ee2519fef1386d0933701d451d57b54039c1685e9669	t	f	2026-02-06 22:25:27.847017+08	2026-02-20 22:24:25.356318+08	2026-02-06 22:24:25.356578+08	2026-02-06 22:25:27.847251+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3357-f327-76f6-af6a-4da44a4b0664	019b7d31-93fd-703f-a582-c82e6bd40036	\\xae8a171def28ad2a14cb21ab69f9db63f9345e7eaba2f9b38b5f51aaa9a9b729	t	f	2026-02-06 22:30:06.578272+08	2026-02-20 22:25:27.847018+08	2026-02-06 22:25:27.847251+08	2026-02-06 22:30:06.578518+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c335c-33f2-74b4-ac69-bc9ff1d91c41	019b7d31-93fd-703f-a582-c82e6bd40036	\\x5cad92449273024be525aca0550159e3be7f0401a6e9bf4c4307573d00ab9a98	t	f	2026-02-06 22:31:13.208943+08	2026-02-20 22:30:06.578272+08	2026-02-06 22:30:06.578518+08	2026-02-06 22:31:13.209092+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c335d-3838-77af-84c3-1e5572f51001	019b7d31-93fd-703f-a582-c82e6bd40036	\\xdab6b6c052f9b9eede7e19ec378ea511f6ea2c7c81f32f473300cd2a7b940a86	t	f	2026-02-06 22:31:48.356542+08	2026-02-20 22:31:13.208943+08	2026-02-06 22:31:13.209092+08	2026-02-06 22:31:48.356747+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c335d-c184-707a-9f92-09efcc8f8c06	019b7d31-93fd-703f-a582-c82e6bd40036	\\x9207802e9436e2d2f25d7870dd40865c1ed6f0199b6b022bb1dc8d49879c52c7	t	f	2026-02-06 22:32:26.427705+08	2026-02-20 22:31:48.356542+08	2026-02-06 22:31:48.356747+08	2026-02-06 22:32:26.427938+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c335e-563b-771e-9d17-5cb4ace7c597	019b7d31-93fd-703f-a582-c82e6bd40036	\\xd9f49fd2252fee86044ffbdd83d3d70074374fcf01c785d30e8642a8857b4d79	t	f	2026-02-06 22:33:34.111845+08	2026-02-20 22:32:26.427705+08	2026-02-06 22:32:26.427938+08	2026-02-06 22:33:34.112041+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c335f-5e9f-7535-9812-af288ad5ff3d	019b7d31-93fd-703f-a582-c82e6bd40036	\\xbb6957a649ff8e05b4c0a5f701243230bddc6bf102fc35b4ec93f870516cd340	t	f	2026-02-06 22:34:08.488494+08	2026-02-20 22:33:34.111846+08	2026-02-06 22:33:34.112041+08	2026-02-06 22:34:08.488658+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c335f-e4e8-719a-b85f-2486256d5680	019b7d31-93fd-703f-a582-c82e6bd40036	\\x8d975294521b239cccaa8afa9bd50fb359cd8fbae407374a91f864e6ae027f04	t	f	2026-02-06 22:36:16.011263+08	2026-02-20 22:34:08.488494+08	2026-02-06 22:34:08.488658+08	2026-02-06 22:36:16.011442+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3361-d70b-73b7-8b64-ffd9e0166f1b	019b7d31-93fd-703f-a582-c82e6bd40036	\\x3290f9230d99ca181b3a7cb52b1cc43fb17db1529c1860e47eb88c93424c45cd	t	f	2026-02-06 22:39:39.403707+08	2026-02-20 22:36:16.011264+08	2026-02-06 22:36:16.011442+08	2026-02-06 22:39:39.403913+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3364-f18b-73bf-80fc-ac462e942a85	019b7d31-93fd-703f-a582-c82e6bd40036	\\xbbc7346a291977b6bb6753d211acf54b3bd0d5c05790cfd7d506fd05d64af654	t	f	2026-02-06 22:41:43.176287+08	2026-02-20 22:39:39.403708+08	2026-02-06 22:39:39.403913+08	2026-02-06 22:41:43.17642+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3366-d508-726c-9f5f-16ef2d1a4bd6	019b7d31-93fd-703f-a582-c82e6bd40036	\\x6ee221a61554a4f110c61b5b949446564fc58f406c1d4d76f11d65e0e57d50e5	t	f	2026-02-06 22:43:09.112741+08	2026-02-20 22:41:43.176288+08	2026-02-06 22:41:43.17642+08	2026-02-06 22:43:09.11287+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3368-24b8-7135-87ea-92a23b1613da	019b7d31-93fd-703f-a582-c82e6bd40036	\\x1d4f87bd6b368e993c9487f2573d3da1e05386ffa89fc5ec968b4cb6cffdba87	t	f	2026-02-06 22:45:52.58924+08	2026-02-20 22:43:09.112741+08	2026-02-06 22:43:09.11287+08	2026-02-06 22:45:52.589389+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c336a-a34d-7218-9c7d-bce18beb37b3	019b7d31-93fd-703f-a582-c82e6bd40036	\\xf469c0d2cbbb964b4f35181e5dfbef7cfc789c81f67b971d7ccb0c690907f096	t	f	2026-02-06 22:48:40.821067+08	2026-02-20 22:45:52.58924+08	2026-02-06 22:45:52.589389+08	2026-02-06 22:48:40.821257+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c336d-3475-727e-8aa8-9e043470e1d8	019b7d31-93fd-703f-a582-c82e6bd40036	\\x58252a869847458aed905f36233b6ef34c9fbc18a13c937592f2677e635791be	t	f	2026-02-06 22:50:48.651383+08	2026-02-20 22:48:40.821067+08	2026-02-06 22:48:40.821257+08	2026-02-06 22:50:48.65152+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c336f-27cb-7290-9301-e4f90c6fa622	019b7d31-93fd-703f-a582-c82e6bd40036	\\x6cbe55e52ca6ebd60552ee744e0e9cbbba4abfbae9b92ce6019998da3eface2f	t	f	2026-02-06 22:52:35.014894+08	2026-02-20 22:50:48.651384+08	2026-02-06 22:50:48.65152+08	2026-02-06 22:52:35.015072+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3370-c746-7348-ac72-ac2cb7220ac9	019b7d31-93fd-703f-a582-c82e6bd40036	\\xde90d926079d7250f96a9d1ea4200437b041910026841a41d84b603a994a08ad	t	f	2026-02-06 22:56:07.155635+08	2026-02-20 22:52:35.014894+08	2026-02-06 22:52:35.015072+08	2026-02-06 22:56:07.15593+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3374-03f3-72b1-908d-9c1643819691	019b7d31-93fd-703f-a582-c82e6bd40036	\\xfb8f90e2c20598ede293c157fabd713c247f549bf3db058053a4266d92e03870	t	f	2026-02-06 23:05:20.949611+08	2026-02-20 22:56:07.155636+08	2026-02-06 22:56:07.15593+08	2026-02-06 23:05:20.949773+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c337c-7735-77ab-ae8f-468b5d526238	019b7d31-93fd-703f-a582-c82e6bd40036	\\xcd788727c8b4d43cff33c6cefa8d9b90355c04f55fa4f3cf55a129afb441985b	t	f	2026-02-06 23:07:10.55589+08	2026-02-20 23:05:20.949611+08	2026-02-06 23:05:20.949773+08	2026-02-06 23:07:10.556026+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c337e-235b-71d5-b40a-f1dcda4e1282	019b7d31-93fd-703f-a582-c82e6bd40036	\\xf4ecf838cd6a7db0cab37694e56515a773757e74611f7a9517698e2589f98b97	t	f	2026-02-06 23:07:30.468503+08	2026-02-20 23:07:10.55589+08	2026-02-06 23:07:10.556026+08	2026-02-06 23:07:30.468657+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c337e-7124-7189-8865-b84d614fced0	019b7d31-93fd-703f-a582-c82e6bd40036	\\x58f3ae1ea7f4a6ce190a0f80a374e91c6c19aa27b6ca6655968cc6daaa8c51d7	t	f	2026-02-06 23:08:18.223777+08	2026-02-20 23:07:30.468504+08	2026-02-06 23:07:30.468657+08	2026-02-06 23:08:18.223878+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c337f-2baf-7718-a334-6f393dd29367	019b7d31-93fd-703f-a582-c82e6bd40036	\\xb92bfad09f2b2482a390e1d021a5a6b0a553223a7f3901485148013d8f2c1e91	t	f	2026-02-06 23:09:02.835902+08	2026-02-20 23:08:18.223777+08	2026-02-06 23:08:18.223878+08	2026-02-06 23:09:02.836023+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c337f-d9f3-70e4-9e09-e5a7c1b177c5	019b7d31-93fd-703f-a582-c82e6bd40036	\\xe9a16c0089fcc0861a03d7beb28a3fab9338389aface188f733b8d7a116beeed	t	f	2026-02-06 23:13:41.061333+08	2026-02-20 23:09:02.835902+08	2026-02-06 23:09:02.836023+08	2026-02-06 23:13:41.061443+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3384-18c5-75a8-8732-349bb18840b7	019b7d31-93fd-703f-a582-c82e6bd40036	\\x9ff307a542d7566ad4c3611b40ac9d4f6fe812820105ea4fa72e5fbac04d3251	t	f	2026-02-06 23:15:22.805759+08	2026-02-20 23:13:41.061333+08	2026-02-06 23:13:41.061443+08	2026-02-06 23:15:22.805898+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3385-a635-76b3-93e7-30b7df34c411	019b7d31-93fd-703f-a582-c82e6bd40036	\\xc27f73409259f3d4cc9622a71f0b633889e6280fc36aea5b54df029051405aa8	t	f	2026-02-06 23:18:31.226601+08	2026-02-20 23:15:22.80576+08	2026-02-06 23:15:22.805898+08	2026-02-06 23:18:31.226835+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3388-863a-76fd-81a7-5a3581f12927	019b7d31-93fd-703f-a582-c82e6bd40036	\\xe78f97540bae83fe85ea8835342da4157bcb77ee4b207dd6eb91fa134896078a	t	f	2026-02-06 23:20:29.223889+08	2026-02-20 23:18:31.226602+08	2026-02-06 23:18:31.226835+08	2026-02-06 23:20:29.22405+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c338a-5327-76fe-a320-6fa1d4ec9e9a	019b7d31-93fd-703f-a582-c82e6bd40036	\\x023bf0242badb6e144153fe4a275af5b9ace877d65846a3f286d53c1e85b1b41	t	f	2026-02-06 23:24:19.023581+08	2026-02-20 23:20:29.22389+08	2026-02-06 23:20:29.22405+08	2026-02-06 23:24:19.023699+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c338d-d4cf-75a1-a480-587618acf2eb	019b7d31-93fd-703f-a582-c82e6bd40036	\\xe954a788c191149b5220bd6925e1895f1ac5a98b6531ce1db2b06de64b387ff1	t	f	2026-02-06 23:27:12.644113+08	2026-02-20 23:24:19.023581+08	2026-02-06 23:24:19.023699+08	2026-02-06 23:27:12.644298+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3390-7b04-7340-b463-d9cb1d18f4f7	019b7d31-93fd-703f-a582-c82e6bd40036	\\x8a8d157ab8fe5344dc3f50064822d185db5cde1ebb5eb7a6d0aa4575d14a7e9c	t	f	2026-02-06 23:29:46.500852+08	2026-02-20 23:27:12.644114+08	2026-02-06 23:27:12.644298+08	2026-02-06 23:29:46.500966+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3392-d404-715f-9ed1-748bdb001e9c	019b7d31-93fd-703f-a582-c82e6bd40036	\\x8638c455af83c4f3c5ec420c1259fe0f1f422251a12272f15a586aa95d8f7609	t	f	2026-02-06 23:30:03.570946+08	2026-02-20 23:29:46.500853+08	2026-02-06 23:29:46.500966+08	2026-02-06 23:30:03.571062+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3393-16b2-7373-80a5-470fb0bd0326	019b7d31-93fd-703f-a582-c82e6bd40036	\\x72219e1ed9aa76e3ca9c4bb64f28b5b0d123b56586a4ad5a4b22678d855cb946	t	f	2026-02-06 23:34:13.529707+08	2026-02-20 23:30:03.570947+08	2026-02-06 23:30:03.571062+08	2026-02-06 23:34:13.529845+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3396-e719-71f4-ad6a-52d22a379a65	019b7d31-93fd-703f-a582-c82e6bd40036	\\xf6b83fb16515de5473f1ec01d220132d170b0df6e0197681575820190a8167b3	t	f	2026-02-06 23:36:54.650362+08	2026-02-20 23:34:13.529708+08	2026-02-06 23:34:13.529845+08	2026-02-06 23:36:54.650486+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3399-5c7a-75cb-a600-93217d097773	019b7d31-93fd-703f-a582-c82e6bd40036	\\x7ee7b3283811ad85a2ab24550dc6bc6339bba3625a7cd71548ab41b968f83d9d	t	f	2026-02-07 13:24:28.018312+08	2026-02-20 23:36:54.650363+08	2026-02-06 23:36:54.650486+08	2026-02-07 13:24:28.063855+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c368f-02f3-7599-8b5b-da0adc2fb61c	019b7d31-93fd-703f-a582-c82e6bd40036	\\x394babdae05f8c63e9b30e825a156c7c00efe130cfcf292f4c205b2c90fac18f	t	f	2026-02-07 13:36:03.427794+08	2026-02-21 13:24:28.018372+08	2026-02-07 13:24:28.063855+08	2026-02-07 13:36:03.428601+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c3699-9f63-72bd-a087-4c20d27c1ab6	019b7d31-93fd-703f-a582-c82e6bd40036	\\xb5050fa1b9dbe4a37b5614a25f151f48f125f51fb6b0bc37b005a0243e3c23ab	t	f	2026-02-07 13:40:25.3941+08	2026-02-21 13:36:03.427794+08	2026-02-07 13:36:03.428601+08	2026-02-07 13:40:25.394335+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c369d-9eb2-73e6-91b1-07a1ed320c56	019b7d31-93fd-703f-a582-c82e6bd40036	\\x1450561989f6f128340f378226b78c8fa26501cd48b87cd158d6fdb1fda86f3a	t	f	2026-02-07 13:42:44.665967+08	2026-02-21 13:40:25.3941+08	2026-02-07 13:40:25.394335+08	2026-02-07 13:42:44.666145+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c369f-beb9-779d-a887-6331a7f437b3	019b7d31-93fd-703f-a582-c82e6bd40036	\\x94d4f1f0ebb341c368947afb4964e8af58ec56834b5e7333f1263d72dcb0ff92	t	f	2026-02-07 13:45:02.606418+08	2026-02-21 13:42:44.665967+08	2026-02-07 13:42:44.666145+08	2026-02-07 13:45:02.606611+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36a1-d98e-7768-a5e8-8703a1bab6f3	019b7d31-93fd-703f-a582-c82e6bd40036	\\x50ab615cf01dd7d3bc9f52d56a8e764b30a8ecf5970ffe10e275a4ddb4d83942	t	f	2026-02-07 13:45:19.758391+08	2026-02-21 13:45:02.606418+08	2026-02-07 13:45:02.606611+08	2026-02-07 13:45:19.758601+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36a2-1c8e-74d9-9fff-52f23179af65	019b7d31-93fd-703f-a582-c82e6bd40036	\\x9b1ee3f807d2aa637ab5c2123c211335ed13ba46dd7d62ac937333b1d16f17ca	t	f	2026-02-07 13:45:59.873156+08	2026-02-21 13:45:19.758391+08	2026-02-07 13:45:19.758601+08	2026-02-07 13:45:59.873307+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36a2-b941-77a8-a974-98fa746209df	019b7d31-93fd-703f-a582-c82e6bd40036	\\x88632083245289636ef4f669cbf682b48d3c13d54f0c43ccf2f4097f22ae31e5	t	f	2026-02-07 13:47:09.420618+08	2026-02-21 13:45:59.873156+08	2026-02-07 13:45:59.873307+08	2026-02-07 13:47:09.420797+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36a3-c8ec-712c-b64f-afd49a948508	019b7d31-93fd-703f-a582-c82e6bd40036	\\x7045a37717386f0e699fdb7c4ef49ea0090de1c88ca3dee006ed4fbf5cb12719	t	f	2026-02-07 14:02:00.967777+08	2026-02-21 13:47:09.420619+08	2026-02-07 13:47:09.420797+08	2026-02-07 14:02:00.967929+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36b1-6387-778f-a4fa-8fd4b8e6f5a1	019b7d31-93fd-703f-a582-c82e6bd40036	\\x49d68fbba84c0af9e2ad11c21c5fad371ef9c3af262b4a958329a136f28562d7	t	f	2026-02-07 14:02:58.703863+08	2026-02-21 14:02:00.967777+08	2026-02-07 14:02:00.967929+08	2026-02-07 14:02:58.704026+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36b2-450f-73da-9a17-eea4005af0ce	019b7d31-93fd-703f-a582-c82e6bd40036	\\x8c38a2a478c6e85a02057f2898a487c7ef7c11bcf141e4f4d9f1d510c2b89496	t	f	2026-02-07 14:07:57.076771+08	2026-02-21 14:02:58.703863+08	2026-02-07 14:02:58.704026+08	2026-02-07 14:07:57.076956+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36b6-d294-7671-b767-7cb5193d9cea	019b7d31-93fd-703f-a582-c82e6bd40036	\\x65ebd517ff637628748c5091144aecc651e34d07dc6d42cc51ae5eb9e1ef7a93	t	f	2026-02-07 14:09:46.493028+08	2026-02-21 14:07:57.076772+08	2026-02-07 14:07:57.076956+08	2026-02-07 14:09:46.493284+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36b8-7dfd-71c6-bd2d-ed3b040b19b7	019b7d31-93fd-703f-a582-c82e6bd40036	\\x1b87ab14c03a7b72766adbdc2734d501985eee927fb7f01a7ae2b3039a0131b0	t	f	2026-02-07 14:17:11.965906+08	2026-02-21 14:09:46.493028+08	2026-02-07 14:09:46.493284+08	2026-02-07 14:17:11.966092+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c36bf-4a1d-7054-8b7d-fbfc61e7651a	019b7d31-93fd-703f-a582-c82e6bd40036	\\x02e154375100f8e49b4b21fd9aa6f7895bbca4498b105078e05741afe3323f1a	t	f	2026-02-07 19:12:12.232855+08	2026-02-21 14:17:11.965907+08	2026-02-07 14:17:11.966092+08	2026-02-07 19:12:12.23309+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c21f0-ab3e-72f9-a37b-5e3246b95c7b	019b7d31-93fd-703f-a582-c82e6bd40036	\\xcd3df0c8f43a170ca49df1a136e34879bc20e39b5d2e74f79e4c9c399b4fd7bd	t	f	2026-02-10 11:06:14.313871+08	2026-02-17 13:19:06.558109+08	2026-02-03 13:19:06.558232+08	2026-02-10 11:06:14.353559+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c4583-89ad-76c0-b11d-534845be429f	019b7d31-93fd-703f-a582-c82e6bd40036	\\x08c1737f1bc94879e422147f485615f5c21bfeee2ac404d27fbb80b4c1432811	t	f	2026-02-10 11:25:13.218453+08	2026-02-24 11:06:14.313956+08	2026-02-10 11:06:14.353559+08	2026-02-10 11:25:13.219408+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c4594-ea82-7627-bff6-b2b649ff139e	019b7d31-93fd-703f-a582-c82e6bd40036	\\xb8e38af4aef44124d518eb4858b7878c9fb54410169cd8bf5cb2d67a9a28135c	t	f	2026-02-10 11:27:14.322505+08	2026-02-24 11:25:13.218453+08	2026-02-10 11:25:13.219408+08	2026-02-10 11:27:14.322715+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c4596-c392-72c8-bf08-2cce0085eee0	019b7d31-93fd-703f-a582-c82e6bd40036	\\x3baf3604a07dc64167cde0e6970a251e304e277de3efc4dcc106460e42d73ddc	t	f	2026-02-10 11:41:38.358611+08	2026-02-24 11:27:14.322505+08	2026-02-10 11:27:14.322715+08	2026-02-10 11:41:38.387045+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c45a3-f2b7-777b-b388-14b91ec9529d	019b7d31-93fd-703f-a582-c82e6bd40036	\\xd72f255aece2ec9ea720c5a1aabc5221a11560213b8625f0b810b889cae63e41	t	f	2026-02-10 11:42:19.802313+08	2026-02-24 11:41:38.358661+08	2026-02-10 11:41:38.387045+08	2026-02-10 11:42:19.803024+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c45a4-949a-7039-b12f-c6c0e809bb34	019b7d31-93fd-703f-a582-c82e6bd40036	\\x0c503d62e6ca4609dc1da572de1bd1a3b00f60d5dda3358cd5cb1a4d385c9481	t	f	2026-02-10 11:43:50.394088+08	2026-02-24 11:42:19.802313+08	2026-02-10 11:42:19.803024+08	2026-02-10 11:43:50.39431+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c45a5-f67a-715b-9ab6-f105d4346120	019b7d31-93fd-703f-a582-c82e6bd40036	\\xde939f125b317a8385f8402cdb9b0cc13bf71814a358589dcb611014e5477bbd	t	f	2026-02-10 11:49:22.548697+08	2026-02-24 11:43:50.394089+08	2026-02-10 11:43:50.39431+08	2026-02-10 11:49:22.548893+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c45ab-07f4-72e8-a30e-57afa9a61fe0	019b7d31-93fd-703f-a582-c82e6bd40036	\\x400b8eb031fbb50a30d117fb6ca435e0f2d22a9fdfb6082634eb981bbc4bbe1c	t	f	2026-02-10 11:50:32.108143+08	2026-02-24 11:49:22.548697+08	2026-02-10 11:49:22.548893+08	2026-02-10 11:50:32.108267+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c45ac-17ac-70a5-ab51-b552798fd164	019b7d31-93fd-703f-a582-c82e6bd40036	\\x7d62aa3c504fad6f601d68fa6d8cc98a82e293c780ce38bee1b5330629516b87	t	f	2026-02-10 11:51:18.308639+08	2026-02-24 11:50:32.108143+08	2026-02-10 11:50:32.108267+08	2026-02-10 11:51:18.308826+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c45ac-cc24-7757-bf82-05f8fcab0390	019b7d31-93fd-703f-a582-c82e6bd40036	\\x4e8540a299ab4d2b9804e794a7f5bcf201cc9f560076e89ccf6b427ea9412ca1	t	f	2026-02-10 11:52:39.995026+08	2026-02-24 11:51:18.308639+08	2026-02-10 11:51:18.308826+08	2026-02-10 11:52:39.995175+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c45ae-0b3b-72cd-a2bc-e7d5e2d63048	019b7d31-93fd-703f-a582-c82e6bd40036	\\xd21e9ffc6e3284ed0d6e7a9f0a1c4fa81b4d3b6917f54bfdec4961df8b13c9b4	t	f	2026-02-10 12:50:01.642122+08	2026-02-24 11:52:39.995027+08	2026-02-10 11:52:39.995175+08	2026-02-10 12:50:01.642294+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c45e2-8f2a-7307-b721-4dbaaf079c55	019b7d31-93fd-703f-a582-c82e6bd40036	\\xc247e6c520547a99479991bc24d2708ac359d849c7c7dfa8351fbdfa279012ae	t	f	2026-02-10 13:41:39.217052+08	2026-02-24 12:50:01.642123+08	2026-02-10 12:50:01.642294+08	2026-02-10 13:41:39.217226+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c4611-d311-736f-bc4d-c8262d914975	019b7d31-93fd-703f-a582-c82e6bd40036	\\xb1dfdb05068cc38f44a62d3a072d822a3e91fd3b76589906eb683933db633a12	t	f	2026-02-10 13:42:42.259072+08	2026-02-24 13:41:39.217052+08	2026-02-10 13:41:39.217226+08	2026-02-10 13:42:42.259249+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c4612-c953-72cd-b257-0f3c1f33f7e9	019b7d31-93fd-703f-a582-c82e6bd40036	\\x4ad5d461ad98adb5e87e73df7b63d508031c39d69ce10e87fa2d7e06260f1555	t	f	2026-02-10 13:46:30.4922+08	2026-02-24 13:42:42.259073+08	2026-02-10 13:42:42.259249+08	2026-02-10 13:46:30.492347+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c4616-44dc-7741-a557-923dc1e98a2e	019b7d31-93fd-703f-a582-c82e6bd40036	\\x7553af6c02c9bfa4f95c249c3aa9214c2a365b33c6aa68097a1c13be326307e5	t	f	2026-02-10 14:00:56.327553+08	2026-02-24 13:46:30.4922+08	2026-02-10 13:46:30.492347+08	2026-02-10 14:00:56.327795+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c4623-7b07-71aa-b330-da60c42f3d6c	019b7d31-93fd-703f-a582-c82e6bd40036	\\xa21d8017a3a7ae05f2cb4523c820d857f29182ebc71ec85567c9561c312f20ac	t	f	2026-02-10 14:01:53.731372+08	2026-02-24 14:00:56.327553+08	2026-02-10 14:00:56.327795+08	2026-02-10 14:01:53.731491+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c4624-5b43-7689-a1f9-2f0a24af1679	019b7d31-93fd-703f-a582-c82e6bd40036	\\x4eb07bb6e11912ef0f4c9788845d6d4788f3f808072c558243af7ae329621e43	t	f	2026-02-10 14:26:11.751932+08	2026-02-24 14:01:53.731373+08	2026-02-10 14:01:53.731491+08	2026-02-10 14:26:11.752083+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c463a-9aa7-7590-b878-444766394065	019b7d31-93fd-703f-a582-c82e6bd40036	\\x85f33b70da6bf7e705844ebb2a37ba2d1ae8cb67c050c70b39feb799ab53f119	t	f	2026-02-10 16:27:58.321857+08	2026-02-24 14:26:11.751933+08	2026-02-10 14:26:11.752083+08	2026-02-10 16:27:58.322118+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	2	1
019c46aa-17f1-779c-be4a-10cb02b061a8	019b7d31-93fd-703f-a582-c82e6bd40036	\\xd5dd66231462063ae67fb30a6b393ab0dcfafae77e17e0c41403fab40cfd7d20	f	f	\N	2026-02-24 16:27:58.321857+08	2026-02-10 16:27:58.322118+08	2026-02-10 16:27:58.322118+08	6f21aa64-9da0-8689-a7e3-1275e9272c53	1	\N
019c37cd-5fc8-7142-bce4-765d9b13f78d	019b7d31-93fd-703f-a582-c82e6bd40036	\\x74d3433c5debc23ff7bab2b1d297cc0d76d8a01fba540de02e6a4532a0953c3d	t	f	2026-02-12 21:27:06.350834+08	2026-02-21 19:12:12.232855+08	2026-02-07 19:12:12.23309+08	2026-02-12 21:27:06.395078+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5208-ad70-7107-92a4-47ebf4a95d0f	019b7d31-93fd-703f-a582-c82e6bd40036	\\xb8aa7155bb9a2a80246e3c18d523292cfccf6ec13e2bee3c4967b2c55af00ccc	f	f	\N	2026-02-26 21:27:06.350908+08	2026-02-12 21:27:06.395078+08	2026-02-12 21:27:06.395078+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	1	\N
019c5a93-2a59-7728-bd62-f35c38885140	019b7d31-93fd-703f-a582-c82e6bd40036	\\x4aef220d3bf2dfbf578a9ad771e31f73c44904e86ae939a661143f2c9032babe	t	f	2026-02-14 13:16:47.799608+08	2026-02-28 13:15:20.024105+08	2026-02-14 13:15:20.081857+08	2026-02-14 13:16:47.80321+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5a94-8137-7199-9813-6fb0f38afde2	019b7d31-93fd-703f-a582-c82e6bd40036	\\xccb2dcb6eb50533414d30c333ffd9cb53f5455922ba3dddf2e6363b6216800e6	t	f	2026-02-14 13:22:40.687594+08	2026-02-28 13:16:47.799647+08	2026-02-14 13:16:47.80321+08	2026-02-14 13:22:40.687883+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5a99-e3af-7534-8758-69bbbf18298f	019b7d31-93fd-703f-a582-c82e6bd40036	\\xa6b7ee82c817045d2889f2aeaaf5da124a66521b1a1f631dfc6d1f0b9a2c4f8d	t	f	2026-02-14 13:24:12.972382+08	2026-02-28 13:22:40.687595+08	2026-02-14 13:22:40.687883+08	2026-02-14 13:24:12.972632+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5a9b-4c2c-77ee-a1b5-6f40d1e73d6d	019b7d31-93fd-703f-a582-c82e6bd40036	\\xfcd4d89a9b8c526aec61b44a3e7dce3ba7a86e02ece4bf50cf332f4b79827140	t	f	2026-02-14 13:34:53.787757+08	2026-02-28 13:24:12.972382+08	2026-02-14 13:24:12.972632+08	2026-02-14 13:34:53.8267+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5aa5-135c-74e4-9d3c-e428e4d1fc69	019b7d31-93fd-703f-a582-c82e6bd40036	\\x5f42b52d0776eac0a2fb5cef3f66125a5960a743820c12b61282b1f21f3bb7c0	t	f	2026-02-14 14:34:27.208696+08	2026-02-28 13:34:53.787828+08	2026-02-14 13:34:53.8267+08	2026-02-14 14:34:27.253134+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5adb-9a09-77a8-80bd-1a410ce4b253	019b7d31-93fd-703f-a582-c82e6bd40036	\\x98047927f74864611944438da640dc1292b569edc758c36941e5e1bbe976ba9e	t	f	2026-02-14 14:38:29.599912+08	2026-02-28 14:34:27.208755+08	2026-02-14 14:34:27.253134+08	2026-02-14 14:38:29.6434+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5adf-4ce1-7045-a504-e25fdfdd5a46	019b7d31-93fd-703f-a582-c82e6bd40036	\\x41032f441aa448ab5dd4b2873842cecab5cfdf447f9c73f371fdab78b4a9d180	t	f	2026-02-14 16:23:58.279794+08	2026-02-28 14:38:29.599984+08	2026-02-14 14:38:29.6434+08	2026-02-14 16:23:58.281205+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5b3f-de47-73ee-ab7c-917fdb7c3925	019b7d31-93fd-703f-a582-c82e6bd40036	\\xf856f5ec1615ca28543024dfb4c7c5685e7107f0db3697d5b16dd95cbbf0a530	f	f	\N	2026-02-28 16:23:58.279794+08	2026-02-14 16:23:58.281205+08	2026-02-14 16:23:58.281205+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	1	\N
019c5b40-6e0e-7793-8e96-660ac55c4bc5	019b7d31-93fd-703f-a582-c82e6bd40036	\\x10dc9aefc9e10adfcc39ee430d044b5d0f1a176539b909040a4cbd04884888f2	f	f	\N	2026-02-28 16:24:35.086569+08	2026-02-14 16:24:35.096001+08	2026-02-14 16:24:35.096001+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	1	\N
019c5b42-d536-7345-ad66-f6ef7e4ed2bf	019b7d31-93fd-703f-a582-c82e6bd40036	\\x371ceef6834eb4e90c69179a3d16fd83db24ddc4547054723d2876ca41da6f54	f	f	\N	2026-02-28 16:27:12.565604+08	2026-02-14 16:27:12.641736+08	2026-02-14 16:27:12.641736+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	1	\N
019c5c12-41aa-730e-92a3-ecbfbdc944ca	019b7d31-93fd-703f-a582-c82e6bd40036	\\xd8b6664c9a30750d4709e8f74f295ffa784f1a80e84e3c90796caccfd90f6bb0	t	f	2026-02-14 20:15:07.374842+08	2026-02-28 20:13:46.281163+08	2026-02-14 20:13:46.351827+08	2026-02-14 20:15:07.378975+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c13-7e6e-77d3-8155-acf71919674d	019b7d31-93fd-703f-a582-c82e6bd40036	\\x05b34f195f8ec4c9ae00c6b56291ae35ce9703739971eb1488c4a0ad9022cc26	t	f	2026-02-14 20:17:59.283362+08	2026-02-28 20:15:07.374898+08	2026-02-14 20:15:07.378975+08	2026-02-14 20:17:59.327593+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c16-1df4-758a-b5ee-d136aa195ae5	019b7d31-93fd-703f-a582-c82e6bd40036	\\x79ca26e16dcca86066cabab7aa6fd6bbcf3266d95ab70ba50412bacb55d6e4ec	t	f	2026-02-14 20:23:07.256521+08	2026-02-28 20:17:59.283423+08	2026-02-14 20:17:59.327593+08	2026-02-14 20:23:07.29651+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c1a-d0f9-7578-b795-af1b76c4d335	019b7d31-93fd-703f-a582-c82e6bd40036	\\x857f3a7c3854189f93c3acfd9714ba1ced1e82835fcdbcbfcedb5061621604c9	t	f	2026-02-14 20:27:44.281119+08	2026-02-28 20:23:07.256583+08	2026-02-14 20:23:07.29651+08	2026-02-14 20:27:44.326731+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c1f-0b19-77c3-9ed5-9cc603750790	019b7d31-93fd-703f-a582-c82e6bd40036	\\xfa38768564fd99c8c0129722755223e49b647952e3f4b261cc4c007ec2469eae	t	f	2026-02-14 20:28:25.593277+08	2026-02-28 20:27:44.281181+08	2026-02-14 20:27:44.326731+08	2026-02-14 20:28:25.635331+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c1f-ac7a-74b8-9118-a7de4bd2544f	019b7d31-93fd-703f-a582-c82e6bd40036	\\xd6c124da6cc88263c9c61351329a9a00642b3f6d13197516f75d862509861c45	t	f	2026-02-14 20:29:11.850771+08	2026-02-28 20:28:25.593341+08	2026-02-14 20:28:25.635331+08	2026-02-14 20:29:11.908091+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c20-612f-760c-9404-3cec96a61d97	019b7d31-93fd-703f-a582-c82e6bd40036	\\xdaaccc44960b55eee48a0ffed74eede921f81a62a7ef8a08dbaae1e9d07dac04	t	f	2026-02-14 20:32:49.386377+08	2026-02-28 20:29:11.850876+08	2026-02-14 20:29:11.908091+08	2026-02-14 20:32:49.444967+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c23-b2eb-7571-bf40-43d611d965fe	019b7d31-93fd-703f-a582-c82e6bd40036	\\xc4d6d7aef99fe870dc675f6237f74ffb6b19278aebac337775a99426f830334a	t	f	2026-02-14 20:34:19.581922+08	2026-02-28 20:32:49.386442+08	2026-02-14 20:32:49.444967+08	2026-02-14 20:34:19.626906+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c25-133f-7786-aa58-55a7a710896c	019b7d31-93fd-703f-a582-c82e6bd40036	\\x7991299d44d401636975240a2f7e5554e056e2f45ac42f3fcdb5903ca6c81081	t	f	2026-02-14 20:37:42.699535+08	2026-02-28 20:34:19.582029+08	2026-02-14 20:34:19.626906+08	2026-02-14 20:37:42.744315+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c28-2cac-72e4-8dc2-ffa331bba31e	019b7d31-93fd-703f-a582-c82e6bd40036	\\x4dbf8b4a17f9681ac51886a2b821a060d8151734007e2f9aba83af388e34c3df	t	f	2026-02-14 20:40:44.167316+08	2026-02-28 20:37:42.699649+08	2026-02-14 20:37:42.744315+08	2026-02-14 20:40:44.212873+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c2a-f188-771c-8687-0ff7b1a1444f	019b7d31-93fd-703f-a582-c82e6bd40036	\\x977a5ba447e0c969955f563ecd0d97357f9788f40bf2aa3de1f33de9170b60cd	t	f	2026-02-14 20:44:21.058286+08	2026-02-28 20:40:44.167378+08	2026-02-14 20:40:44.212873+08	2026-02-14 20:44:21.106978+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c2e-40c3-756d-a7e3-27e7436afd08	019b7d31-93fd-703f-a582-c82e6bd40036	\\x1053fbefdf9b1f8df87ca38d62a93920063c0ed304842ae130bc1ff8e8526c6a	t	f	2026-02-14 20:49:21.201743+08	2026-02-28 20:44:21.05835+08	2026-02-14 20:44:21.106978+08	2026-02-14 20:49:21.250605+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5c32-d532-755b-b466-89d31a81034e	019b7d31-93fd-703f-a582-c82e6bd40036	\\x24de57a1d60ff84acfe9f961d3aa47585b035a071fdcbf1e704f4e20d30214a8	f	f	\N	2026-02-28 20:49:21.201807+08	2026-02-14 20:49:21.250605+08	2026-02-14 20:49:21.250605+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	1	\N
019c5c37-b367-74f6-a826-1bc877cda201	019b7d31-93fd-703f-a582-c82e6bd40036	\\xd477406f0c3e29ec298661501f7d454a4b203802b938b0192f4406cac05b1e73	t	f	2026-02-14 23:36:54.182942+08	2026-02-28 20:54:40.230434+08	2026-02-14 20:54:40.286703+08	2026-02-14 23:36:54.242402+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5ccc-3aa8-7453-9a6b-ef9f57f4260f	019b7d31-93fd-703f-a582-c82e6bd40036	\\x8fd0982b0d35f51663c4589661f81a7ed2912bd90946d4fc6feef165970fd882	t	f	2026-02-14 23:38:11.959154+08	2026-02-28 23:36:54.183063+08	2026-02-14 23:36:54.242402+08	2026-02-14 23:38:12.021905+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5ccd-6a7b-70fe-9e90-8ceb776e080b	019b7d31-93fd-703f-a582-c82e6bd40036	\\x6e491b4b85af017e572374d5ab2bd90c001ccf69c4569b36a98dc8a9d2e44333	t	f	2026-02-14 23:39:34.599574+08	2026-02-28 23:38:11.959282+08	2026-02-14 23:38:12.021905+08	2026-02-14 23:39:34.654894+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5cce-ad4b-7563-b852-f73d175885f3	019b7d31-93fd-703f-a582-c82e6bd40036	\\xd839c4306b94043984e3c329a5beebd9e68ece05f8d8a095d383be638aa2f3da	f	f	\N	2026-02-28 23:39:34.599676+08	2026-02-14 23:39:34.654894+08	2026-02-14 23:39:34.654894+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	1	\N
019c5cd1-2519-768a-b644-42a69c382002	019b7d31-93fd-703f-a582-c82e6bd40036	\\x79b9503f2083f5fa7f8a2c0bde56a71bba58a49a6f7104f640663347f174654b	t	f	2026-02-15 11:08:34.858197+08	2026-02-28 23:42:16.34477+08	2026-02-14 23:42:16.400122+08	2026-02-15 11:08:34.902237+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5f45-7aab-703a-9f30-39e671e49d14	019b7d31-93fd-703f-a582-c82e6bd40036	\\x6a17d87d13f1bff4d1147cb8947352ef8fa1b86daf83f8b0507cb390205bb009	t	f	2026-02-15 11:13:27.967196+08	2026-03-01 11:08:34.858258+08	2026-02-15 11:08:34.902237+08	2026-02-15 11:13:27.968223+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5f49-f39f-7147-8687-8855505cca28	019b7d31-93fd-703f-a582-c82e6bd40036	\\x9db44e3920d0f9875a1106fa8e53eaf63eb658db0d93ec3c8ad2be49553cd1bb	t	f	2026-02-15 11:20:20.384375+08	2026-03-01 11:13:27.967196+08	2026-02-15 11:13:27.968223+08	2026-02-15 11:20:20.384606+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5f50-3ea0-724a-9948-eacce5197c7e	019b7d31-93fd-703f-a582-c82e6bd40036	\\xf809ec0a8fb587dd282078a0b2408c72a8bd02ab15ff8bcbf64118da3d138882	t	f	2026-02-15 11:21:07.598504+08	2026-03-01 11:20:20.384375+08	2026-02-15 11:20:20.384606+08	2026-02-15 11:21:07.598666+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5f50-f70e-7154-b29d-e8c2550476cd	019b7d31-93fd-703f-a582-c82e6bd40036	\\x3041915176e8899be408f4a53278ff34d5b2f9728fe78d285a1fe7d58b5c3ef2	t	f	2026-02-15 11:24:07.48394+08	2026-03-01 11:21:07.598504+08	2026-02-15 11:21:07.598666+08	2026-02-15 11:24:07.48412+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c5f53-b5bb-707c-a24d-3b5ad8b22119	019b7d31-93fd-703f-a582-c82e6bd40036	\\xf754c4541a3626a1b919e7ae0895091c14a4ed2b48cd82fb05666476dbf2d315	t	f	2026-02-16 22:58:13.230233+08	2026-03-01 11:24:07.48394+08	2026-02-15 11:24:07.48412+08	2026-02-16 22:58:13.272914+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	2	1
019c66f5-886f-75e7-bde7-5425d5281f21	019b7d31-93fd-703f-a582-c82e6bd40036	\\x49f8b79c36983bed83b47f89a8ab7449e4f37b281e5736ea5a80d7dcbfdb0ad1	f	f	\N	2026-03-02 22:58:13.230297+08	2026-02-16 22:58:13.272914+08	2026-02-16 22:58:13.272914+08	1e5022ef-a866-824a-9e8a-cfbab69f91f7	1	\N
\.


--
-- TOC entry 5346 (class 0 OID 37493)
-- Dependencies: 268
-- Data for Name: users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.users (id, email, email_verified_at, password_hash, time_zone, is_admin, version, created_at, updated_at) FROM stdin;
113ae534-2310-40e3-a895-f3747ea976ca	SuperAdmin@mail.ru	\N	AQAAAAIAAYagAAAAEA+MLlU2KQvPMPQ0RCAWN2iQDElD1+zOUuwLjyXnOlBxsikuTAtogGdY3m5zDWnrXg==	\N	t	1	2025-12-03 10:45:43.769905+08	2025-12-03 10:45:43.769905+08
\.


--
-- TOC entry 5352 (class 0 OID 0)
-- Dependencies: 227
-- Name: base_equipments_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_equipments_id_seq', 9, true);


--
-- TOC entry 5353 (class 0 OID 0)
-- Dependencies: 229
-- Name: base_heroes_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_heroes_id_seq', 6, false);


--
-- TOC entry 5354 (class 0 OID 0)
-- Dependencies: 231
-- Name: creature_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.creature_types_id_seq', 9, false);


--
-- TOC entry 5355 (class 0 OID 0)
-- Dependencies: 233
-- Name: damage_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.damage_types_id_seq', 17, true);


--
-- TOC entry 5356 (class 0 OID 0)
-- Dependencies: 235
-- Name: equipment_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.equipment_types_id_seq', 32, true);


--
-- TOC entry 5357 (class 0 OID 0)
-- Dependencies: 237
-- Name: material_damage_percents_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.material_damage_percents_id_seq', 25, false);


--
-- TOC entry 5358 (class 0 OID 0)
-- Dependencies: 239
-- Name: slot_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slot_types_id_seq', 19, true);


--
-- TOC entry 5359 (class 0 OID 0)
-- Dependencies: 241
-- Name: slots_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slots_id_seq', 12, true);


--
-- TOC entry 5360 (class 0 OID 0)
-- Dependencies: 243
-- Name: smithing_materials_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.smithing_materials_id_seq', 19, true);


--
-- TOC entry 5361 (class 0 OID 0)
-- Dependencies: 251
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_ban_reasons_id_seq', 1, false);


--
-- TOC entry 5362 (class 0 OID 0)
-- Dependencies: 253
-- Name: user_session_inactivation_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_session_inactivation_reasons_id_seq', 8, true);


--
-- TOC entry 5363 (class 0 OID 0)
-- Dependencies: 255
-- Name: asp_net_role_claims_id_seq; Type: SEQUENCE SET; Schema: users; Owner: -
--

SELECT pg_catalog.setval('users.asp_net_role_claims_id_seq', 1, false);


--
-- TOC entry 5364 (class 0 OID 0)
-- Dependencies: 257
-- Name: asp_net_user_claims_id_seq; Type: SEQUENCE SET; Schema: users; Owner: -
--

SELECT pg_catalog.setval('users.asp_net_user_claims_id_seq', 1, false);


--
-- TOC entry 4994 (class 2606 OID 37506)
-- Name: equipments equipments__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4999 (class 2606 OID 37508)
-- Name: heroes heroes__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 5004 (class 2606 OID 37510)
-- Name: base_equipments base_equipments__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 5008 (class 2606 OID 37512)
-- Name: base_heroes base_heroes__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_heroes
    ADD CONSTRAINT base_heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 5011 (class 2606 OID 37514)
-- Name: creature_types creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.creature_types
    ADD CONSTRAINT creature_types__pkey PRIMARY KEY (id);


--
-- TOC entry 5014 (class 2606 OID 37516)
-- Name: damage_types damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.damage_types
    ADD CONSTRAINT damage_types__pkey PRIMARY KEY (id);


--
-- TOC entry 5017 (class 2606 OID 37518)
-- Name: equipment_types equipment_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__pkey PRIMARY KEY (id);


--
-- TOC entry 5021 (class 2606 OID 37520)
-- Name: material_damage_percents material_damage_percents__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__pkey PRIMARY KEY (id);


--
-- TOC entry 5025 (class 2606 OID 37522)
-- Name: slot_types slot_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slot_types
    ADD CONSTRAINT slot_types__pkey PRIMARY KEY (id);


--
-- TOC entry 5028 (class 2606 OID 37524)
-- Name: slots slots__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slots
    ADD CONSTRAINT slots__pkey PRIMARY KEY (id);


--
-- TOC entry 5032 (class 2606 OID 37526)
-- Name: smithing_materials smithing_materials__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.smithing_materials
    ADD CONSTRAINT smithing_materials__pkey PRIMARY KEY (id);


--
-- TOC entry 5035 (class 2606 OID 37528)
-- Name: x_equipment_types_damage_types x_equipment_types_damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_types_damage_types
    ADD CONSTRAINT x_equipment_types_damage_types__pkey PRIMARY KEY (equipment_type_id, damage_type_id);


--
-- TOC entry 5038 (class 2606 OID 37530)
-- Name: x_heroes_creature_types x_heroes_creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_heroes_creature_types
    ADD CONSTRAINT x_heroes_creature_types__pkey PRIMARY KEY (base_hero_id, creature_type_id);


--
-- TOC entry 5040 (class 2606 OID 37532)
-- Name: authentication_logs authentication_logs__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.authentication_logs
    ADD CONSTRAINT authentication_logs__pkey PRIMARY KEY (id);


--
-- TOC entry 5045 (class 2606 OID 37534)
-- Name: registration_logs registration_logs__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.registration_logs
    ADD CONSTRAINT registration_logs__pkey PRIMARY KEY (id);


--
-- TOC entry 5049 (class 2606 OID 37536)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 5052 (class 2606 OID 37538)
-- Name: user_ban_reasons user_ban_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_ban_reasons
    ADD CONSTRAINT user_ban_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 5055 (class 2606 OID 37540)
-- Name: user_session_inactivation_reasons user_session_inactivation_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_session_inactivation_reasons
    ADD CONSTRAINT user_session_inactivation_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 5057 (class 2606 OID 37542)
-- Name: identity_role_claims identity_role_claims__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_role_claims
    ADD CONSTRAINT identity_role_claims__pkey PRIMARY KEY (id);


--
-- TOC entry 5064 (class 2606 OID 37544)
-- Name: identity_roles identity_roles__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_roles
    ADD CONSTRAINT identity_roles__pkey PRIMARY KEY (id);


--
-- TOC entry 5060 (class 2606 OID 37546)
-- Name: identity_user_claims identity_user_claims__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_claims
    ADD CONSTRAINT identity_user_claims__pkey PRIMARY KEY (id);


--
-- TOC entry 5066 (class 2606 OID 37548)
-- Name: identity_user_logins identity_user_logins__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_logins
    ADD CONSTRAINT identity_user_logins__pkey PRIMARY KEY (login_provider, provider_key);


--
-- TOC entry 5069 (class 2606 OID 37550)
-- Name: identity_user_roles identity_user_roles__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__pkey PRIMARY KEY (user_id, role_id);


--
-- TOC entry 5072 (class 2606 OID 37552)
-- Name: identity_user_tokens identity_user_tokens__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_tokens
    ADD CONSTRAINT identity_user_tokens__pkey PRIMARY KEY (user_id, login_provider, name);


--
-- TOC entry 5076 (class 2606 OID 37554)
-- Name: identity_users identity_users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_users
    ADD CONSTRAINT identity_users__pkey PRIMARY KEY (id);


--
-- TOC entry 5078 (class 2606 OID 37556)
-- Name: refresh_tokens refresh_tokens__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.refresh_tokens
    ADD CONSTRAINT refresh_tokens__pkey PRIMARY KEY (id);


--
-- TOC entry 5081 (class 2606 OID 37558)
-- Name: user_accesskeys user_accesskeys__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_accesskeys
    ADD CONSTRAINT user_accesskeys__pkey PRIMARY KEY (id);


--
-- TOC entry 5084 (class 2606 OID 37560)
-- Name: user_bans user_bans__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__pkey PRIMARY KEY (id);


--
-- TOC entry 5088 (class 2606 OID 37562)
-- Name: user_devices user_devices__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_devices
    ADD CONSTRAINT user_devices__pkey PRIMARY KEY (id);


--
-- TOC entry 5090 (class 2606 OID 37564)
-- Name: user_sessions user_sessions__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions__pkey PRIMARY KEY (id);


--
-- TOC entry 5096 (class 2606 OID 37566)
-- Name: users users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users__pkey PRIMARY KEY (id);


--
-- TOC entry 4991 (class 1259 OID 37567)
-- Name: equipments__base_equipment_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__base_equipment_id__idx ON collection.equipments USING btree (base_equipment_id);


--
-- TOC entry 4992 (class 1259 OID 37804)
-- Name: equipments__hero_id__slot_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__hero_id__slot_id__idx ON collection.equipments USING btree (hero_id, slot_id);


--
-- TOC entry 4995 (class 1259 OID 37805)
-- Name: equipments__slot_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__slot_id__idx ON collection.equipments USING btree (slot_id);


--
-- TOC entry 4996 (class 1259 OID 37570)
-- Name: equipments__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__user_id__idx ON collection.equipments USING btree (user_id);


--
-- TOC entry 4997 (class 1259 OID 37571)
-- Name: heroes__base_hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__base_hero_id__idx ON collection.heroes USING btree (base_hero_id);


--
-- TOC entry 5000 (class 1259 OID 37572)
-- Name: heroes__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__user_id__idx ON collection.heroes USING btree (user_id);


--
-- TOC entry 5001 (class 1259 OID 37573)
-- Name: base_equipments__equipment_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__equipment_type_id__idx ON game_data.base_equipments USING btree (equipment_type_id);


--
-- TOC entry 5002 (class 1259 OID 37574)
-- Name: base_equipments__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_equipments__name__idx ON game_data.base_equipments USING btree (name);


--
-- TOC entry 5005 (class 1259 OID 37575)
-- Name: base_equipments__smithing_material_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__smithing_material_id__idx ON game_data.base_equipments USING btree (smithing_material_id);


--
-- TOC entry 5006 (class 1259 OID 37576)
-- Name: base_heroes__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_heroes__name__idx ON game_data.base_heroes USING btree (name);


--
-- TOC entry 5009 (class 1259 OID 37577)
-- Name: creature_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX creature_types__name__idx ON game_data.creature_types USING btree (name);


--
-- TOC entry 5012 (class 1259 OID 37578)
-- Name: damage_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX damage_types__name__idx ON game_data.damage_types USING btree (name);


--
-- TOC entry 5015 (class 1259 OID 37579)
-- Name: equipment_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX equipment_types__name__idx ON game_data.equipment_types USING btree (name);


--
-- TOC entry 5018 (class 1259 OID 37806)
-- Name: equipment_types__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX equipment_types__slot_type_id__idx ON game_data.equipment_types USING btree (slot_type_id);


--
-- TOC entry 5019 (class 1259 OID 37580)
-- Name: material_damage_percents__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__damage_type_id__idx ON game_data.material_damage_percents USING btree (damage_type_id);


--
-- TOC entry 5022 (class 1259 OID 37581)
-- Name: material_damage_percents__smithing_materials_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__smithing_materials_id__idx ON game_data.material_damage_percents USING btree (smithing_materials_id);


--
-- TOC entry 5023 (class 1259 OID 37582)
-- Name: slot_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slot_types__name__idx ON game_data.slot_types USING btree (name);


--
-- TOC entry 5026 (class 1259 OID 37583)
-- Name: slots__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slots__name__idx ON game_data.slots USING btree (name);


--
-- TOC entry 5029 (class 1259 OID 37584)
-- Name: slots__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX slots__slot_type_id__idx ON game_data.slots USING btree (slot_type_id);


--
-- TOC entry 5030 (class 1259 OID 37585)
-- Name: smithing_materials__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX smithing_materials__name__idx ON game_data.smithing_materials USING btree (name);


--
-- TOC entry 5033 (class 1259 OID 37586)
-- Name: x_equipment_types_damage_types__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_equipment_types_damage_types__damage_type_id__idx ON game_data.x_equipment_types_damage_types USING btree (damage_type_id);


--
-- TOC entry 5036 (class 1259 OID 37587)
-- Name: x_heroes_creature_types__creature_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_heroes_creature_types__creature_type_id__idx ON game_data.x_heroes_creature_types USING btree (creature_type_id);


--
-- TOC entry 5041 (class 1259 OID 37588)
-- Name: authentication_logs__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX authentication_logs__user_device_id__idx ON logs.authentication_logs USING btree (user_device_id);


--
-- TOC entry 5042 (class 1259 OID 37589)
-- Name: authentication_logs__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX authentication_logs__user_id__idx ON logs.authentication_logs USING btree (user_id);


--
-- TOC entry 5043 (class 1259 OID 37590)
-- Name: authentication_logs__user_session_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX authentication_logs__user_session_id__idx ON logs.authentication_logs USING btree (user_session_id);


--
-- TOC entry 5046 (class 1259 OID 37591)
-- Name: registration_logs__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX registration_logs__user_device_id__idx ON logs.registration_logs USING btree (user_device_id);


--
-- TOC entry 5047 (class 1259 OID 37592)
-- Name: registration_logs__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX registration_logs__user_id__idx ON logs.registration_logs USING btree (user_id);


--
-- TOC entry 5050 (class 1259 OID 37593)
-- Name: user_ban_reasons__name__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_ban_reasons__name__idx ON server.user_ban_reasons USING btree (name);


--
-- TOC entry 5053 (class 1259 OID 37594)
-- Name: user_session_inactivation_reasons__code__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_session_inactivation_reasons__code__idx ON server.user_session_inactivation_reasons USING btree (code);


--
-- TOC entry 5058 (class 1259 OID 37595)
-- Name: identity_role_claims__role_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_role_claims__role_id__idx ON users.identity_role_claims USING btree (role_id);


--
-- TOC entry 5062 (class 1259 OID 37596)
-- Name: identity_roles__normalized_name__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX identity_roles__normalized_name__idx ON users.identity_roles USING btree (normalized_name);


--
-- TOC entry 5061 (class 1259 OID 37597)
-- Name: identity_user_claims__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_claims__user_id__idx ON users.identity_user_claims USING btree (user_id);


--
-- TOC entry 5067 (class 1259 OID 37598)
-- Name: identity_user_logins__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_logins__user_id__idx ON users.identity_user_logins USING btree (user_id);


--
-- TOC entry 5070 (class 1259 OID 37599)
-- Name: identity_user_roles__role_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_roles__role_id__idx ON users.identity_user_roles USING btree (role_id);


--
-- TOC entry 5073 (class 1259 OID 37600)
-- Name: identity_users__normalized_email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_users__normalized_email__idx ON users.identity_users USING btree (normalized_email);


--
-- TOC entry 5074 (class 1259 OID 37601)
-- Name: identity_users__normalized_user_name__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX identity_users__normalized_user_name__idx ON users.identity_users USING btree (normalized_user_name);


--
-- TOC entry 5079 (class 1259 OID 37602)
-- Name: refresh_tokens__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX refresh_tokens__user_id__idx ON users.refresh_tokens USING btree (user_id);


--
-- TOC entry 5082 (class 1259 OID 37603)
-- Name: user_accesskeys__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_accesskeys__user_id__idx ON users.user_accesskeys USING btree (user_id);


--
-- TOC entry 5085 (class 1259 OID 37604)
-- Name: user_bans__user_ban_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_ban_reason_id__idx ON users.user_bans USING btree (user_ban_reason_id);


--
-- TOC entry 5086 (class 1259 OID 37605)
-- Name: user_bans__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_id__idx ON users.user_bans USING btree (user_id);


--
-- TOC entry 5091 (class 1259 OID 37606)
-- Name: user_sessions__refresh_token_hash__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX user_sessions__refresh_token_hash__idx ON users.user_sessions USING btree (refresh_token_hash) WHERE ((is_used = false) AND (is_revoked = false));


--
-- TOC entry 5092 (class 1259 OID 37607)
-- Name: user_sessions__user_device_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_sessions__user_device_id__idx ON users.user_sessions USING btree (user_device_id);


--
-- TOC entry 5093 (class 1259 OID 37608)
-- Name: user_sessions__user_session_inactivation_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_sessions__user_session_inactivation_reason_id__idx ON users.user_sessions USING btree (user_session_inactivation_reason_id);


--
-- TOC entry 5094 (class 1259 OID 37609)
-- Name: users__email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX users__email__idx ON users.users USING btree (email);


--
-- TOC entry 5130 (class 2620 OID 37610)
-- Name: equipments trg_prevent_id_change; Type: TRIGGER; Schema: collection; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON collection.equipments FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5131 (class 2620 OID 37611)
-- Name: heroes trg_prevent_id_change; Type: TRIGGER; Schema: collection; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON collection.heroes FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5132 (class 2620 OID 37612)
-- Name: base_equipments trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.base_equipments FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5133 (class 2620 OID 37613)
-- Name: base_heroes trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.base_heroes FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5134 (class 2620 OID 37614)
-- Name: creature_types trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.creature_types FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5135 (class 2620 OID 37615)
-- Name: damage_types trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.damage_types FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5136 (class 2620 OID 37616)
-- Name: equipment_types trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.equipment_types FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5137 (class 2620 OID 37617)
-- Name: material_damage_percents trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.material_damage_percents FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5138 (class 2620 OID 37618)
-- Name: slot_types trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.slot_types FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5139 (class 2620 OID 37619)
-- Name: slots trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.slots FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5140 (class 2620 OID 37620)
-- Name: smithing_materials trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.smithing_materials FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5141 (class 2620 OID 37621)
-- Name: authentication_logs trg_prevent_id_change; Type: TRIGGER; Schema: logs; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON logs.authentication_logs FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5142 (class 2620 OID 37622)
-- Name: registration_logs trg_prevent_id_change; Type: TRIGGER; Schema: logs; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON logs.registration_logs FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5143 (class 2620 OID 37623)
-- Name: user_ban_reasons trg_prevent_id_change; Type: TRIGGER; Schema: server; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON server.user_ban_reasons FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5144 (class 2620 OID 37624)
-- Name: user_session_inactivation_reasons trg_prevent_id_change; Type: TRIGGER; Schema: server; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON server.user_session_inactivation_reasons FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5145 (class 2620 OID 37625)
-- Name: identity_role_claims trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.identity_role_claims FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5147 (class 2620 OID 37626)
-- Name: identity_roles trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.identity_roles FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5146 (class 2620 OID 37627)
-- Name: identity_user_claims trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.identity_user_claims FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5148 (class 2620 OID 37628)
-- Name: identity_users trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.identity_users FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5149 (class 2620 OID 37629)
-- Name: refresh_tokens trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.refresh_tokens FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5150 (class 2620 OID 37630)
-- Name: user_accesskeys trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.user_accesskeys FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5151 (class 2620 OID 37631)
-- Name: user_bans trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.user_bans FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5152 (class 2620 OID 37632)
-- Name: user_devices trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.user_devices FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5153 (class 2620 OID 37633)
-- Name: user_sessions trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.user_sessions FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5154 (class 2620 OID 37634)
-- Name: users trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.users FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5097 (class 2606 OID 37635)
-- Name: equipments equipments__base_equipment_id__base_equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__base_equipment_id__base_equipments__fkey FOREIGN KEY (base_equipment_id) REFERENCES game_data.base_equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5098 (class 2606 OID 37640)
-- Name: equipments equipments__hero_id__heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__hero_id__heroes__fkey FOREIGN KEY (hero_id) REFERENCES collection.heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5099 (class 2606 OID 37812)
-- Name: equipments equipments__slot_id__slots__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__slot_id__slots__fkey FOREIGN KEY (slot_id) REFERENCES game_data.slots(id) ON DELETE RESTRICT;


--
-- TOC entry 5100 (class 2606 OID 37650)
-- Name: equipments equipments__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5101 (class 2606 OID 37655)
-- Name: heroes heroes__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5102 (class 2606 OID 37660)
-- Name: heroes heroes__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5103 (class 2606 OID 37665)
-- Name: base_equipments base_equipments__equipment_type_id__equipment_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__equipment_type_id__equipment_types__fkey FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5104 (class 2606 OID 37670)
-- Name: base_equipments base_equipments__smithing_material_id__smithing_materials__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__smithing_material_id__smithing_materials__fkey FOREIGN KEY (smithing_material_id) REFERENCES game_data.smithing_materials(id) ON DELETE RESTRICT;


--
-- TOC entry 5105 (class 2606 OID 37807)
-- Name: equipment_types equipment_types__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5106 (class 2606 OID 37675)
-- Name: material_damage_percents material_damage_percents__damage_type_id__damage_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__damage_type_id__damage_types__fkey FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5107 (class 2606 OID 37680)
-- Name: material_damage_percents material_damage_percents__smithing_materials_id__smithing_mater; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__smithing_materials_id__smithing_mater FOREIGN KEY (smithing_materials_id) REFERENCES game_data.smithing_materials(id) ON DELETE RESTRICT;


--
-- TOC entry 5108 (class 2606 OID 37685)
-- Name: slots slots__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slots
    ADD CONSTRAINT slots__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5109 (class 2606 OID 37690)
-- Name: x_equipment_types_damage_types x_equipment_types_damage_types__damage_type_id__damage_types__f; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_types_damage_types
    ADD CONSTRAINT x_equipment_types_damage_types__damage_type_id__damage_types__f FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5110 (class 2606 OID 37695)
-- Name: x_equipment_types_damage_types x_equipment_types_damage_types__equipment_type_id__equipment_ty; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_types_damage_types
    ADD CONSTRAINT x_equipment_types_damage_types__equipment_type_id__equipment_ty FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5111 (class 2606 OID 37700)
-- Name: x_heroes_creature_types x_heroes_creature_types__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_heroes_creature_types
    ADD CONSTRAINT x_heroes_creature_types__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5112 (class 2606 OID 37705)
-- Name: x_heroes_creature_types x_heroes_creature_types__creature_type_id__creature_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_heroes_creature_types
    ADD CONSTRAINT x_heroes_creature_types__creature_type_id__creature_types__fkey FOREIGN KEY (creature_type_id) REFERENCES game_data.creature_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5113 (class 2606 OID 37710)
-- Name: authentication_logs authentication_logs__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.authentication_logs
    ADD CONSTRAINT authentication_logs__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE RESTRICT;


--
-- TOC entry 5114 (class 2606 OID 37715)
-- Name: authentication_logs authentication_logs__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.authentication_logs
    ADD CONSTRAINT authentication_logs__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE CASCADE;


--
-- TOC entry 5115 (class 2606 OID 37720)
-- Name: authentication_logs authentication_logs__user_session_id__user_sessions__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.authentication_logs
    ADD CONSTRAINT authentication_logs__user_session_id__user_sessions__fkey FOREIGN KEY (user_session_id) REFERENCES users.user_sessions(id) ON DELETE RESTRICT;


--
-- TOC entry 5116 (class 2606 OID 37725)
-- Name: registration_logs registration_logs__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.registration_logs
    ADD CONSTRAINT registration_logs__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE RESTRICT;


--
-- TOC entry 5117 (class 2606 OID 37730)
-- Name: registration_logs registration_logs__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.registration_logs
    ADD CONSTRAINT registration_logs__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5118 (class 2606 OID 37735)
-- Name: identity_role_claims identity_role_claims__role_id__identity_roles__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_role_claims
    ADD CONSTRAINT identity_role_claims__role_id__identity_roles__fkey FOREIGN KEY (role_id) REFERENCES users.identity_roles(id) ON DELETE RESTRICT;


--
-- TOC entry 5119 (class 2606 OID 37740)
-- Name: identity_user_claims identity_user_claims__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_claims
    ADD CONSTRAINT identity_user_claims__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5120 (class 2606 OID 37745)
-- Name: identity_user_logins identity_user_logins__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_logins
    ADD CONSTRAINT identity_user_logins__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5121 (class 2606 OID 37750)
-- Name: identity_user_roles identity_user_roles__role_id__identity_roles__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__role_id__identity_roles__fkey FOREIGN KEY (role_id) REFERENCES users.identity_roles(id) ON DELETE RESTRICT;


--
-- TOC entry 5122 (class 2606 OID 37755)
-- Name: identity_user_roles identity_user_roles__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5123 (class 2606 OID 37760)
-- Name: identity_user_tokens identity_user_tokens__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_tokens
    ADD CONSTRAINT identity_user_tokens__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5124 (class 2606 OID 37765)
-- Name: refresh_tokens refresh_tokens__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.refresh_tokens
    ADD CONSTRAINT refresh_tokens__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5125 (class 2606 OID 37770)
-- Name: user_accesskeys user_accesskeys__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_accesskeys
    ADD CONSTRAINT user_accesskeys__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5126 (class 2606 OID 37775)
-- Name: user_bans user_bans__user_ban_reason_id__user_ban_reasons__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_ban_reason_id__user_ban_reasons__fkey FOREIGN KEY (user_ban_reason_id) REFERENCES server.user_ban_reasons(id) ON DELETE RESTRICT;


--
-- TOC entry 5127 (class 2606 OID 37780)
-- Name: user_bans user_bans__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE CASCADE;


--
-- TOC entry 5128 (class 2606 OID 37785)
-- Name: user_sessions user_sessions__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE RESTRICT;


--
-- TOC entry 5129 (class 2606 OID 37790)
-- Name: user_sessions user_sessions__user_session_inactivation_reason_id__user_sessio; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions__user_session_inactivation_reason_id__user_sessio FOREIGN KEY (user_session_inactivation_reason_id) REFERENCES server.user_session_inactivation_reasons(id) ON DELETE RESTRICT;


--
-- TOC entry 4957 (class 3466 OID 37795)
-- Name: on_ddl_create_table__prevent_id_update; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER on_ddl_create_table__prevent_id_update ON ddl_command_end
         WHEN TAG IN ('CREATE TABLE', 'CREATE TABLE AS')
   EXECUTE FUNCTION public.fn_on_ddl_prevent_id_update();


-- Completed on 2026-02-16 23:22:46

--
-- PostgreSQL database dump complete
--

\unrestrict pSqshW8X6zrqUr0b6JpQ4BRHiaFJbNoloMEOMdg4qGuZ7WR0eGvHtL8j5nb5J2z

