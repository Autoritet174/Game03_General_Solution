--
-- PostgreSQL database dump
--

\restrict ekmz9krHGiIcFwxEUcqPmCzwLSlOQkdWnZS1AqTl1BE2gYbsFsoTWZd937GgUG8

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-12-16 16:09:11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType__HeroId__Heroes__fkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType__CreatureTypeId__CreatureTypes__fkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_EquipmentType_DamageType" DROP CONSTRAINT IF EXISTS "X_EquipmentType_DamageType__EquipmentTypeId__EquipmentTypes__fk";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_EquipmentType_DamageType" DROP CONSTRAINT IF EXISTS "X_EquipmentType_DamageType__DamageTypeId__DamageTypes__fkey";
ALTER TABLE IF EXISTS ONLY _equipment."Weapons" DROP CONSTRAINT IF EXISTS "Weapons__WeaponTypeId__EquipmentTypes__fkey";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercents" DROP CONSTRAINT IF EXISTS "MaterialDamagePercents__SmithingMaterialsId__SmithingMaterials_";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercents" DROP CONSTRAINT IF EXISTS "MaterialDamagePercents__DamageTypeId__DamageTypes__fkey";
ALTER TABLE IF EXISTS ONLY __lists."EquipmentTypes" DROP CONSTRAINT IF EXISTS "EquipmentTypes__SlotTypeId__SlotTypes__fkey";
DROP INDEX IF EXISTS "x_Cross"."X_Hero_CreatureType__CreatureTypeId__idx";
DROP INDEX IF EXISTS "x_Cross"."X_EquipmentType_DamageType__DamageTypeId__idx";
DROP INDEX IF EXISTS _heroes."Heroes__Name__idx";
DROP INDEX IF EXISTS _equipment."Weapons__WeaponTypeId__idx";
DROP INDEX IF EXISTS _equipment."Weapons__Name__idx";
DROP INDEX IF EXISTS __lists."SmithingMaterials__Name__idx";
DROP INDEX IF EXISTS __lists."SlotTypes__Name__idx";
DROP INDEX IF EXISTS __lists."MaterialDamagePercents__SmithingMaterialsId__idx";
DROP INDEX IF EXISTS __lists."MaterialDamagePercents__DamageTypeId__idx";
DROP INDEX IF EXISTS __lists."EquipmentTypes__SlotTypeId__idx";
DROP INDEX IF EXISTS __lists."EquipmentTypes__Name__idx";
DROP INDEX IF EXISTS __lists."DamageTypes__Name__idx";
DROP INDEX IF EXISTS __lists."CreatureTypes__Name__idx";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType__pkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_EquipmentType_DamageType" DROP CONSTRAINT IF EXISTS "X_EquipmentType_DamageType__pkey";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY _heroes."Heroes" DROP CONSTRAINT IF EXISTS "Heroes__pkey";
ALTER TABLE IF EXISTS ONLY _equipment."Weapons" DROP CONSTRAINT IF EXISTS "Weapons__pkey";
ALTER TABLE IF EXISTS ONLY __lists."SmithingMaterials" DROP CONSTRAINT IF EXISTS "SmithingMaterials__pkey";
ALTER TABLE IF EXISTS ONLY __lists."SlotTypes" DROP CONSTRAINT IF EXISTS "SlotTypes__pkey";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercents" DROP CONSTRAINT IF EXISTS "MaterialDamagePercents__pkey";
ALTER TABLE IF EXISTS ONLY __lists."EquipmentTypes" DROP CONSTRAINT IF EXISTS "EquipmentTypes__pkey";
ALTER TABLE IF EXISTS ONLY __lists."DamageTypes" DROP CONSTRAINT IF EXISTS "DamageTypes__pkey";
ALTER TABLE IF EXISTS ONLY __lists."CreatureTypes" DROP CONSTRAINT IF EXISTS "CreatureTypes__pkey";
DROP TABLE IF EXISTS "x_Cross"."X_Hero_CreatureType";
DROP TABLE IF EXISTS "x_Cross"."X_EquipmentType_DamageType";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS _heroes."Heroes";
DROP TABLE IF EXISTS _equipment."Weapons";
DROP TABLE IF EXISTS __lists."SmithingMaterials";
DROP TABLE IF EXISTS __lists."SlotTypes";
DROP TABLE IF EXISTS __lists."MaterialDamagePercents";
DROP TABLE IF EXISTS __lists."EquipmentTypes";
DROP TABLE IF EXISTS __lists."DamageTypes";
DROP TABLE IF EXISTS __lists."CreatureTypes";
DROP SCHEMA IF EXISTS "x_Cross";
DROP SCHEMA IF EXISTS _heroes;
DROP SCHEMA IF EXISTS _equipment;
DROP SCHEMA IF EXISTS __lists;
--
-- TOC entry 6 (class 2615 OID 44699)
-- Name: __lists; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA __lists;


--
-- TOC entry 8 (class 2615 OID 44701)
-- Name: _equipment; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _equipment;


--
-- TOC entry 7 (class 2615 OID 44700)
-- Name: _heroes; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _heroes;


--
-- TOC entry 9 (class 2615 OID 44702)
-- Name: x_Cross; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "x_Cross";


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 225 (class 1259 OID 44704)
-- Name: CreatureTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."CreatureTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 44703)
-- Name: CreatureTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."CreatureTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."CreatureTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 227 (class 1259 OID 44712)
-- Name: DamageTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."DamageTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255),
    "DevHintRu" text
);


--
-- TOC entry 226 (class 1259 OID 44711)
-- Name: DamageTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."DamageTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."DamageTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 44776)
-- Name: EquipmentTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."EquipmentTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255) NOT NULL,
    mass integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    attack character varying(255),
    spend_action_points integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 44775)
-- Name: EquipmentTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."EquipmentTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."EquipmentTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 44801)
-- Name: MaterialDamagePercents; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."MaterialDamagePercents" (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 44800)
-- Name: MaterialDamagePercents_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."MaterialDamagePercents" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."MaterialDamagePercents_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 231 (class 1259 OID 44739)
-- Name: SlotTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."SlotTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 230 (class 1259 OID 44738)
-- Name: SlotTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."SlotTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."SlotTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 233 (class 1259 OID 44749)
-- Name: SmithingMaterials; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."SmithingMaterials" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 232 (class 1259 OID 44748)
-- Name: SmithingMaterials_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."SmithingMaterials" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."SmithingMaterials_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 44821)
-- Name: Weapons; Type: TABLE; Schema: _equipment; Owner: -
--

CREATE TABLE _equipment."Weapons" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    damage character varying(255) NOT NULL,
    weapon_type_id integer NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 44820)
-- Name: Weapons_id_seq; Type: SEQUENCE; Schema: _equipment; Owner: -
--

ALTER TABLE _equipment."Weapons" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME _equipment."Weapons_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 229 (class 1259 OID 44722)
-- Name: Heroes; Type: TABLE; Schema: _heroes; Owner: -
--

CREATE TABLE _heroes."Heroes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    health character varying(255) NOT NULL,
    damage character varying(255) NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 44721)
-- Name: Heroes_id_seq; Type: SEQUENCE; Schema: _heroes; Owner: -
--

ALTER TABLE _heroes."Heroes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME _heroes."Heroes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 223 (class 1259 OID 44692)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 44840)
-- Name: X_EquipmentType_DamageType; Type: TABLE; Schema: x_Cross; Owner: -
--

CREATE TABLE "x_Cross"."X_EquipmentType_DamageType" (
    "EquipmentTypeId" integer NOT NULL,
    "DamageTypeId" integer NOT NULL,
    "DamageCoef" integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 44758)
-- Name: X_Hero_CreatureType; Type: TABLE; Schema: x_Cross; Owner: -
--

CREATE TABLE "x_Cross"."X_Hero_CreatureType" (
    "HeroId" integer NOT NULL,
    "CreatureTypeId" integer NOT NULL
);


--
-- TOC entry 5006 (class 0 OID 44704)
-- Dependencies: 225
-- Data for Name: CreatureTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."CreatureTypes" (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5008 (class 0 OID 44712)
-- Dependencies: 227
-- Data for Name: DamageTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."DamageTypes" (id, name, name_ru, "DevHintRu") FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."
11	Light	Световой	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."
\.


--
-- TOC entry 5017 (class 0 OID 44776)
-- Dependencies: 236
-- Data for Name: EquipmentTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."EquipmentTypes" (id, name, name_ru, mass, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, attack, spend_action_points) FROM stdin;
9	War Fan	Боевой веер	800	11	t	f	5d3_10	0
10	Scimitar	Скимитар	1200	11	t	f	6d4_15	0
11	Katana	Катана	1100	11	t	f	7d3_14	0
14	Morning Star	Моргенштерн	5000	11	t	f	1d123_62	0
1	Sword	Меч	1600	11	t	f	8d4_20	0
18	Bow	Лук	960	11	t	f	4d2_6	0
21	Pike	Пика	2800	11	t	f	24d2_36	0
20	Rapier	Рапира	850	11	t	f	8d2_12	0
19	Trident	Трезубец	3400	11	t	f	28d2_42	0
17	Crossbow	Арбалет	3200	11	t	f	14d2_21	0
7	Shuriken	Сюрикен	180	11	t	f	6d2_9	0
22	Spear	Копьё	2200	11	t	f	20d2_30	0
24	Dagger	Кинжал	400	11	t	f	4d2_6	0
12	Yataghan	Ятаган	1000	11	t	f	6d3_12	0
13	Sabre	Сабля	1100	11	t	f	7d3_14	0
15	Warhammer	Боевой молот	6200	11	t	f	1d153_77	0
16	Mace	Булава	3000	11	t	f	1d73_37	0
3	Halberd	Алебарда	4400	11	t	f	4d27_56	0
5	Poleaxe	Секира	4000	11	t	f	4d24_50	0
23	Broadaxe	Широкий топор	5200	11	t	f	4d32_66	0
2	Axe	Топор	2800	11	t	f	4d17_36	0
4	Berdysh	Бердыш	3800	11	t	f	4d23_48	0
6	Chakram	Чакрам	350	11	t	f	5d3_10	0
8	Scythe	Коса	3200	11	t	f	5d3_10	0
\.


--
-- TOC entry 5019 (class 0 OID 44801)
-- Dependencies: 238
-- Data for Name: MaterialDamagePercents; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."MaterialDamagePercents" (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5012 (class 0 OID 44739)
-- Dependencies: 231
-- Data for Name: SlotTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."SlotTypes" (id, name, name_ru) FROM stdin;
1	Head	Голова
2	Shoulders	Наплечники
3	Chest	Нагрудник
4	Hands	Руки
5	Legs	Поножи
6	Feet	Ступни
7	Waist	Пояс
8	Wrist	Запястья
9	Back	Спина
10	Bracelet	Браслет
11	HandLeftRight	Рука Левая Правая
12	Ring	Кольцо
13	Earring	Серьги
14	Trinket	Аксессуар
\.


--
-- TOC entry 5014 (class 0 OID 44749)
-- Dependencies: 233
-- Data for Name: SmithingMaterials; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."SmithingMaterials" (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5021 (class 0 OID 44821)
-- Dependencies: 240
-- Data for Name: Weapons; Type: TABLE DATA; Schema: _equipment; Owner: -
--

COPY _equipment."Weapons" (id, name, rarity, is_unique, damage, weapon_type_id) FROM stdin;
\.


--
-- TOC entry 5010 (class 0 OID 44722)
-- Dependencies: 229
-- Data for Name: Heroes; Type: TABLE DATA; Schema: _heroes; Owner: -
--

COPY _heroes."Heroes" (id, name, rarity, is_unique, health, damage, main_stat) FROM stdin;
1	Warrior	1	f	16d24_200	4d21_44	0
2	Huntress	1	f	10d28_145	5d21_55	0
3	Hammerman	1	f	11d39_220	3d25_39	0
4	Rogue	1	f	15d21_165	4d23_48	0
5	Battle orc	1	f	16d58_472	4d21_44	0
\.


--
-- TOC entry 5004 (class 0 OID 44692)
-- Dependencies: 223
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251216055053_Init	10.0.1
\.


--
-- TOC entry 5022 (class 0 OID 44840)
-- Dependencies: 241
-- Data for Name: X_EquipmentType_DamageType; Type: TABLE DATA; Schema: x_Cross; Owner: -
--

COPY "x_Cross"."X_EquipmentType_DamageType" ("EquipmentTypeId", "DamageTypeId", "DamageCoef") FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5015 (class 0 OID 44758)
-- Dependencies: 234
-- Data for Name: X_Hero_CreatureType; Type: TABLE DATA; Schema: x_Cross; Owner: -
--

COPY "x_Cross"."X_Hero_CreatureType" ("HeroId", "CreatureTypeId") FROM stdin;
\.


--
-- TOC entry 5028 (class 0 OID 0)
-- Dependencies: 224
-- Name: CreatureTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."CreatureTypes_id_seq"', 9, false);


--
-- TOC entry 5029 (class 0 OID 0)
-- Dependencies: 226
-- Name: DamageTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."DamageTypes_id_seq"', 17, false);


--
-- TOC entry 5030 (class 0 OID 0)
-- Dependencies: 235
-- Name: EquipmentTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."EquipmentTypes_id_seq"', 24, true);


--
-- TOC entry 5031 (class 0 OID 0)
-- Dependencies: 237
-- Name: MaterialDamagePercents_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."MaterialDamagePercents_id_seq"', 1, false);


--
-- TOC entry 5032 (class 0 OID 0)
-- Dependencies: 230
-- Name: SlotTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."SlotTypes_id_seq"', 14, true);


--
-- TOC entry 5033 (class 0 OID 0)
-- Dependencies: 232
-- Name: SmithingMaterials_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."SmithingMaterials_id_seq"', 19, true);


--
-- TOC entry 5034 (class 0 OID 0)
-- Dependencies: 239
-- Name: Weapons_id_seq; Type: SEQUENCE SET; Schema: _equipment; Owner: -
--

SELECT pg_catalog.setval('_equipment."Weapons_id_seq"', 1, false);


--
-- TOC entry 5035 (class 0 OID 0)
-- Dependencies: 228
-- Name: Heroes_id_seq; Type: SEQUENCE SET; Schema: _heroes; Owner: -
--

SELECT pg_catalog.setval('_heroes."Heroes_id_seq"', 6, false);


--
-- TOC entry 4818 (class 2606 OID 44710)
-- Name: CreatureTypes CreatureTypes__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."CreatureTypes"
    ADD CONSTRAINT "CreatureTypes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4821 (class 2606 OID 44720)
-- Name: DamageTypes DamageTypes__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."DamageTypes"
    ADD CONSTRAINT "DamageTypes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4837 (class 2606 OID 44794)
-- Name: EquipmentTypes EquipmentTypes__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."EquipmentTypes"
    ADD CONSTRAINT "EquipmentTypes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4841 (class 2606 OID 44809)
-- Name: MaterialDamagePercents MaterialDamagePercents__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercents"
    ADD CONSTRAINT "MaterialDamagePercents__pkey" PRIMARY KEY (id);


--
-- TOC entry 4827 (class 2606 OID 44747)
-- Name: SlotTypes SlotTypes__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."SlotTypes"
    ADD CONSTRAINT "SlotTypes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4830 (class 2606 OID 44757)
-- Name: SmithingMaterials SmithingMaterials__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."SmithingMaterials"
    ADD CONSTRAINT "SmithingMaterials__pkey" PRIMARY KEY (id);


--
-- TOC entry 4845 (class 2606 OID 44834)
-- Name: Weapons Weapons__pkey; Type: CONSTRAINT; Schema: _equipment; Owner: -
--

ALTER TABLE ONLY _equipment."Weapons"
    ADD CONSTRAINT "Weapons__pkey" PRIMARY KEY (id);


--
-- TOC entry 4824 (class 2606 OID 44737)
-- Name: Heroes Heroes__pkey; Type: CONSTRAINT; Schema: _heroes; Owner: -
--

ALTER TABLE ONLY _heroes."Heroes"
    ADD CONSTRAINT "Heroes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4815 (class 2606 OID 44698)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4848 (class 2606 OID 44848)
-- Name: X_EquipmentType_DamageType X_EquipmentType_DamageType__pkey; Type: CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_EquipmentType_DamageType"
    ADD CONSTRAINT "X_EquipmentType_DamageType__pkey" PRIMARY KEY ("EquipmentTypeId", "DamageTypeId");


--
-- TOC entry 4833 (class 2606 OID 44764)
-- Name: X_Hero_CreatureType X_Hero_CreatureType__pkey; Type: CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType__pkey" PRIMARY KEY ("HeroId", "CreatureTypeId");


--
-- TOC entry 4816 (class 1259 OID 44859)
-- Name: CreatureTypes__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "CreatureTypes__Name__idx" ON __lists."CreatureTypes" USING btree (name);


--
-- TOC entry 4819 (class 1259 OID 44860)
-- Name: DamageTypes__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "DamageTypes__Name__idx" ON __lists."DamageTypes" USING btree (name);


--
-- TOC entry 4834 (class 1259 OID 44861)
-- Name: EquipmentTypes__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "EquipmentTypes__Name__idx" ON __lists."EquipmentTypes" USING btree (name);


--
-- TOC entry 4835 (class 1259 OID 44862)
-- Name: EquipmentTypes__SlotTypeId__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE INDEX "EquipmentTypes__SlotTypeId__idx" ON __lists."EquipmentTypes" USING btree (slot_type_id);


--
-- TOC entry 4838 (class 1259 OID 44864)
-- Name: MaterialDamagePercents__DamageTypeId__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE INDEX "MaterialDamagePercents__DamageTypeId__idx" ON __lists."MaterialDamagePercents" USING btree (damage_type_id);


--
-- TOC entry 4839 (class 1259 OID 44865)
-- Name: MaterialDamagePercents__SmithingMaterialsId__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE INDEX "MaterialDamagePercents__SmithingMaterialsId__idx" ON __lists."MaterialDamagePercents" USING btree (smithing_materials_id);


--
-- TOC entry 4825 (class 1259 OID 44866)
-- Name: SlotTypes__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "SlotTypes__Name__idx" ON __lists."SlotTypes" USING btree (name);


--
-- TOC entry 4828 (class 1259 OID 44867)
-- Name: SmithingMaterials__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "SmithingMaterials__Name__idx" ON __lists."SmithingMaterials" USING btree (name);


--
-- TOC entry 4842 (class 1259 OID 44868)
-- Name: Weapons__Name__idx; Type: INDEX; Schema: _equipment; Owner: -
--

CREATE UNIQUE INDEX "Weapons__Name__idx" ON _equipment."Weapons" USING btree (name);


--
-- TOC entry 4843 (class 1259 OID 44869)
-- Name: Weapons__WeaponTypeId__idx; Type: INDEX; Schema: _equipment; Owner: -
--

CREATE INDEX "Weapons__WeaponTypeId__idx" ON _equipment."Weapons" USING btree (weapon_type_id);


--
-- TOC entry 4822 (class 1259 OID 44863)
-- Name: Heroes__Name__idx; Type: INDEX; Schema: _heroes; Owner: -
--

CREATE UNIQUE INDEX "Heroes__Name__idx" ON _heroes."Heroes" USING btree (name);


--
-- TOC entry 4846 (class 1259 OID 44870)
-- Name: X_EquipmentType_DamageType__DamageTypeId__idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_EquipmentType_DamageType__DamageTypeId__idx" ON "x_Cross"."X_EquipmentType_DamageType" USING btree ("DamageTypeId");


--
-- TOC entry 4831 (class 1259 OID 44871)
-- Name: X_Hero_CreatureType__CreatureTypeId__idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_Hero_CreatureType__CreatureTypeId__idx" ON "x_Cross"."X_Hero_CreatureType" USING btree ("CreatureTypeId");


--
-- TOC entry 4851 (class 2606 OID 44795)
-- Name: EquipmentTypes EquipmentTypes__SlotTypeId__SlotTypes__fkey; Type: FK CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."EquipmentTypes"
    ADD CONSTRAINT "EquipmentTypes__SlotTypeId__SlotTypes__fkey" FOREIGN KEY (slot_type_id) REFERENCES __lists."SlotTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4852 (class 2606 OID 44810)
-- Name: MaterialDamagePercents MaterialDamagePercents__DamageTypeId__DamageTypes__fkey; Type: FK CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercents"
    ADD CONSTRAINT "MaterialDamagePercents__DamageTypeId__DamageTypes__fkey" FOREIGN KEY (damage_type_id) REFERENCES __lists."DamageTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4853 (class 2606 OID 44815)
-- Name: MaterialDamagePercents MaterialDamagePercents__SmithingMaterialsId__SmithingMaterials_; Type: FK CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercents"
    ADD CONSTRAINT "MaterialDamagePercents__SmithingMaterialsId__SmithingMaterials_" FOREIGN KEY (smithing_materials_id) REFERENCES __lists."SmithingMaterials"(id) ON DELETE CASCADE;


--
-- TOC entry 4854 (class 2606 OID 44835)
-- Name: Weapons Weapons__WeaponTypeId__EquipmentTypes__fkey; Type: FK CONSTRAINT; Schema: _equipment; Owner: -
--

ALTER TABLE ONLY _equipment."Weapons"
    ADD CONSTRAINT "Weapons__WeaponTypeId__EquipmentTypes__fkey" FOREIGN KEY (weapon_type_id) REFERENCES __lists."EquipmentTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4855 (class 2606 OID 44849)
-- Name: X_EquipmentType_DamageType X_EquipmentType_DamageType__DamageTypeId__DamageTypes__fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_EquipmentType_DamageType"
    ADD CONSTRAINT "X_EquipmentType_DamageType__DamageTypeId__DamageTypes__fkey" FOREIGN KEY ("DamageTypeId") REFERENCES __lists."DamageTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4856 (class 2606 OID 44854)
-- Name: X_EquipmentType_DamageType X_EquipmentType_DamageType__EquipmentTypeId__EquipmentTypes__fk; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_EquipmentType_DamageType"
    ADD CONSTRAINT "X_EquipmentType_DamageType__EquipmentTypeId__EquipmentTypes__fk" FOREIGN KEY ("EquipmentTypeId") REFERENCES __lists."EquipmentTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4849 (class 2606 OID 44765)
-- Name: X_Hero_CreatureType X_Hero_CreatureType__CreatureTypeId__CreatureTypes__fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType__CreatureTypeId__CreatureTypes__fkey" FOREIGN KEY ("CreatureTypeId") REFERENCES __lists."CreatureTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4850 (class 2606 OID 44770)
-- Name: X_Hero_CreatureType X_Hero_CreatureType__HeroId__Heroes__fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType__HeroId__Heroes__fkey" FOREIGN KEY ("HeroId") REFERENCES _heroes."Heroes"(id) ON DELETE CASCADE;


-- Completed on 2025-12-16 16:09:11

--
-- PostgreSQL database dump complete
--

\unrestrict ekmz9krHGiIcFwxEUcqPmCzwLSlOQkdWnZS1AqTl1BE2gYbsFsoTWZd937GgUG8

