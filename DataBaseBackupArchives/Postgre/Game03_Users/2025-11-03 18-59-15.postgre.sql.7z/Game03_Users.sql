--
-- PostgreSQL database dump
--

\restrict E3XqVCifstXh0C8N2cYgnzncNwcCkx3bCgmMnwBUZhy0zhIwBGK33dHMIGNXtq2

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-11-03 18:59:15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY _main.users_bans DROP CONSTRAINT IF EXISTS users_bans_user_id_users_fkey;
ALTER TABLE IF EXISTS ONLY _main.users_authorization_logs DROP CONSTRAINT IF EXISTS fk_users_authorization_logs_x_users_devices;
ALTER TABLE IF EXISTS ONLY _main.users_authorization_logs DROP CONSTRAINT IF EXISTS fk_users_authorization_logs_x_users;
DROP INDEX IF EXISTS _main.users_email_idx;
DROP INDEX IF EXISTS _main.users_bans_user_id_idx;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY _main.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY _main.users_devices DROP CONSTRAINT IF EXISTS users_devices_pkey;
ALTER TABLE IF EXISTS ONLY _main.users_bans DROP CONSTRAINT IF EXISTS users_bans_pkey;
ALTER TABLE IF EXISTS ONLY _main.users_authorization_logs DROP CONSTRAINT IF EXISTS pk_users_authorization_logs_id;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS _main.users_devices;
DROP TABLE IF EXISTS _main.users_bans;
DROP TABLE IF EXISTS _main.users_authorization_logs;
DROP TABLE IF EXISTS _main.users;
DROP FUNCTION IF EXISTS public.set_timestamp();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pgcrypto;
DROP EXTENSION IF EXISTS citext;
DROP SCHEMA IF EXISTS _main;
--
-- TOC entry 9 (class 2615 OID 18339)
-- Name: _main; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _main;


--
-- TOC entry 2 (class 3079 OID 17743)
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- TOC entry 5147 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- TOC entry 4 (class 3079 OID 18064)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 5148 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 3 (class 3079 OID 17848)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 5149 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 283 (class 1255 OID 17859)
-- Name: set_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.created_at := COALESCE(NEW.created_at, NOW());
        NEW.updated_at := COALESCE(NEW.updated_at, NOW());
    ELSIF TG_OP = 'UPDATE' THEN
        NEW.created_at := OLD.created_at;
        IF NEW.updated_at IS NULL OR NEW.updated_at = OLD.updated_at THEN
            NEW.updated_at := NOW();
        END IF;
    END IF;
    RETURN NEW;
END;
                $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 18340)
-- Name: users; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email character varying(255),
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    time_zone character varying(64)
);


--
-- TOC entry 227 (class 1259 OID 18393)
-- Name: users_authorization_logs; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.users_authorization_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    success boolean NOT NULL,
    email public.citext,
    user_id uuid,
    ip_address inet NOT NULL,
    user_device_id uuid NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 18353)
-- Name: users_bans; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.users_bans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    user_bans_reasons_id uuid
);


--
-- TOC entry 226 (class 1259 OID 18381)
-- Name: users_devices; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.users_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    system_environment_username character varying(255),
    timezone_minutes integer,
    device_unique_identifier character varying(255),
    device_model character varying(255),
    device_type character varying(255),
    operating_system character varying(255),
    processor_type character varying(255),
    processor_count integer,
    system_memory_size integer,
    graphics_device_name character varying(255),
    graphics_memory_size integer,
    system_info_supports_instancing boolean,
    system_info_npot_support character varying(255)
);


--
-- TOC entry 223 (class 1259 OID 17860)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 5138 (class 0 OID 18340)
-- Dependencies: 224
-- Data for Name: users; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.users (id, created_at, updated_at, email, email_verified_at, password_hash, time_zone) FROM stdin;
0197d311-925d-72ed-825d-50e013b50ccf	2025-07-04 09:33:53.978686+08	2025-07-04 10:27:00.158671+08	SuperAdmin@mail.ru	\N	AQAAAAIAAYagAAAAEA+MLlU2KQvPMPQ0RCAWN2iQDElD1+zOUuwLjyXnOlBxsikuTAtogGdY3m5zDWnrXg==	\N
\.


--
-- TOC entry 5141 (class 0 OID 18393)
-- Dependencies: 227
-- Data for Name: users_authorization_logs; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.users_authorization_logs (id, created_at, success, email, user_id, ip_address, user_device_id) FROM stdin;
3358f0c9-aecf-44fb-bffd-78c5a3deb057	2025-11-03 16:23:06.897034+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
3227064a-7c70-4775-b154-560d6f98046b	2025-11-03 16:23:21.834275+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
fa5a4209-e889-4318-a9f8-f49f0763fb0e	2025-11-03 16:23:21.834275+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
232ad521-a234-4285-a3db-7b865c660280	2025-11-03 16:23:26.84118+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
fa9d25d2-f13b-4ae3-91a7-623827735c55	2025-11-03 16:23:26.84118+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
4b97a31d-f442-4a40-9793-a2d6c3951fc6	2025-11-03 16:23:43.144519+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
7cea294d-d020-460a-901d-99ec248abe4b	2025-11-03 16:23:48.08708+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
0efb1038-c2f8-459a-89a5-d84ad749bab2	2025-11-03 16:54:43.396435+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
db22994d-60d9-4e5b-9c21-decd3ce3fe2b	2025-11-03 16:55:28.344116+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
562901d1-ad44-4c0d-97ac-7269f37eca70	2025-11-03 17:01:52.745462+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
80b2ae04-3f53-45bb-a629-cee13627088a	2025-11-03 17:03:12.690769+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
90c0ccdd-879a-4304-9158-ef90d2b18219	2025-11-03 17:03:37.696183+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
f4dc3225-ff11-4737-9bac-ae5e92245dc2	2025-11-03 17:05:02.588765+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
e9342e52-6962-4413-a470-ff3e0a9b5cb1	2025-11-03 17:06:43.947301+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
592c1452-f455-45b4-9852-ebf5decde430	2025-11-03 18:02:32.012028+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
bb6a8a15-e57b-4888-8f93-d193d33f9c0c	2025-11-03 18:02:41.967142+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
a358cf8a-99b0-4630-92c2-01184116edc0	2025-11-03 18:02:41.967142+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
3655d3bd-948a-49fa-b0ab-58bd76691ad7	2025-11-03 18:02:41.967142+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
81140895-fe65-48cd-9c30-46d4a4c443f0	2025-11-03 18:02:46.964521+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
88ba9f48-abd6-4b31-b2fa-95293a02ffc0	2025-11-03 18:04:46.967435+08	f	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
96b56454-5395-42b3-a81d-93c4f1b494ad	2025-11-03 18:55:40.854134+08	t	SUPERADMIN@MAIL.RU	0197d311-925d-72ed-825d-50e013b50ccf	127.0.0.1	47ee0275-bae7-c989-6f87-f8b416a6cfd0
\.


--
-- TOC entry 5139 (class 0 OID 18353)
-- Dependencies: 225
-- Data for Name: users_bans; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.users_bans (id, user_id, created_at, expires_at, user_bans_reasons_id) FROM stdin;
\.


--
-- TOC entry 5140 (class 0 OID 18381)
-- Dependencies: 226
-- Data for Name: users_devices; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.users_devices (id, created_at, system_environment_username, timezone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
47ee0275-bae7-c989-6f87-f8b416a6cfd0	2025-11-03 16:23:06.897034+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
\.


--
-- TOC entry 5137 (class 0 OID 17860)
-- Dependencies: 223
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20250704004607_Init	9.0.6
20250708053934_AddLoggingAuthorization	9.0.6
20251103065602_start	9.0.10
\.


--
-- TOC entry 4986 (class 2606 OID 18406)
-- Name: users_authorization_logs pk_users_authorization_logs_id; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_authorization_logs
    ADD CONSTRAINT pk_users_authorization_logs_id PRIMARY KEY (id);


--
-- TOC entry 4981 (class 2606 OID 18362)
-- Name: users_bans users_bans_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_bans
    ADD CONSTRAINT users_bans_pkey PRIMARY KEY (id);


--
-- TOC entry 4984 (class 2606 OID 18391)
-- Name: users_devices users_devices_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_devices
    ADD CONSTRAINT users_devices_pkey PRIMARY KEY (id);


--
-- TOC entry 4979 (class 2606 OID 18352)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4976 (class 2606 OID 17904)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4982 (class 1259 OID 18369)
-- Name: users_bans_user_id_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE INDEX users_bans_user_id_idx ON _main.users_bans USING btree (user_id);


--
-- TOC entry 4977 (class 1259 OID 18368)
-- Name: users_email_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE UNIQUE INDEX users_email_idx ON _main.users USING btree (email);


--
-- TOC entry 4988 (class 2606 OID 18407)
-- Name: users_authorization_logs fk_users_authorization_logs_x_users; Type: FK CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_authorization_logs
    ADD CONSTRAINT fk_users_authorization_logs_x_users FOREIGN KEY (user_id) REFERENCES _main.users(id);


--
-- TOC entry 4989 (class 2606 OID 18412)
-- Name: users_authorization_logs fk_users_authorization_logs_x_users_devices; Type: FK CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_authorization_logs
    ADD CONSTRAINT fk_users_authorization_logs_x_users_devices FOREIGN KEY (user_device_id) REFERENCES _main.users_devices(id);


--
-- TOC entry 4987 (class 2606 OID 18363)
-- Name: users_bans users_bans_user_id_users_fkey; Type: FK CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_bans
    ADD CONSTRAINT users_bans_user_id_users_fkey FOREIGN KEY (user_id) REFERENCES _main.users(id);


-- Completed on 2025-11-03 18:59:15

--
-- PostgreSQL database dump complete
--

\unrestrict E3XqVCifstXh0C8N2cYgnzncNwcCkx3bCgmMnwBUZhy0zhIwBGK33dHMIGNXtq2

