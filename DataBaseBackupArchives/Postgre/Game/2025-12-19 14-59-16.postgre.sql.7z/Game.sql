--
-- PostgreSQL database dump
--

\restrict 8el387vG7av6gIuIGNjDUbQSymY9G0ytF3rDIjuQxKV7lq7xdh5yHoAoal0Autq

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-12-19 14:59:15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_ban_reason_id__user_ban_reasons__fkey;
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__creature_type_id__creature_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__equipment_type_id__equipment_type;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__damage_type_id__damage_types__fke;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__smithing_materials_id__smithing_mater;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__damage_type_id__damage_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__equipment_type_id__equipment_types__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment9id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment8id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment7id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment6id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment5id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment4id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment3id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment2id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment24id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment23id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment22id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment21id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment20id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment1id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment19id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment18id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment17id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment16id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment15id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment14id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment13id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment12id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment11id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment10id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__base_equipment_id__base_equipments__fkey;
DROP INDEX IF EXISTS users.users__email__idx;
DROP INDEX IF EXISTS users.user_devices__device_unique_identifier__idx;
DROP INDEX IF EXISTS users.user_bans__user_id__idx;
DROP INDEX IF EXISTS users.user_bans__user_ban_reason_id__idx;
DROP INDEX IF EXISTS server.user_ban_reasons__name__idx;
DROP INDEX IF EXISTS logs.user_authorizations__user_id__idx;
DROP INDEX IF EXISTS logs.user_authorizations__user_device_id__idx;
DROP INDEX IF EXISTS game_data.x_hero_creature_type__creature_type_id__idx;
DROP INDEX IF EXISTS game_data.x_equipment_type_damage_type__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.smithing_materials__name__idx;
DROP INDEX IF EXISTS game_data.slot_types__name__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__smithing_materials_id__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__name__idx;
DROP INDEX IF EXISTS game_data.damage_types__name__idx;
DROP INDEX IF EXISTS game_data.creature_types__name__idx;
DROP INDEX IF EXISTS game_data.base_heroes__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__equipment_type_id__idx;
DROP INDEX IF EXISTS collection.heroes__user_id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment9id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment8id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment7id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment6id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment5id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment4id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment3id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment2id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment24id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment23id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment22id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment21id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment20id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment1id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment19id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment18id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment17id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment16id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment15id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment14id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment13id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment12id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment11id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment10id__idx;
DROP INDEX IF EXISTS collection.heroes__base_hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__user_id__idx;
DROP INDEX IF EXISTS collection.equipments__base_equipment_id__idx;
ALTER TABLE IF EXISTS ONLY users.users DROP CONSTRAINT IF EXISTS users__pkey;
ALTER TABLE IF EXISTS ONLY users.user_devices DROP CONSTRAINT IF EXISTS user_devices__pkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__pkey;
ALTER TABLE IF EXISTS ONLY server.user_ban_reasons DROP CONSTRAINT IF EXISTS user_ban_reasons__pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.smithing_materials DROP CONSTRAINT IF EXISTS smithing_materials__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slot_types DROP CONSTRAINT IF EXISTS slot_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__pkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.damage_types DROP CONSTRAINT IF EXISTS damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.creature_types DROP CONSTRAINT IF EXISTS creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_heroes DROP CONSTRAINT IF EXISTS base_heroes__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__pkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__pkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__pkey;
DROP TABLE IF EXISTS users.users;
DROP TABLE IF EXISTS users.user_devices;
DROP TABLE IF EXISTS users.user_bans;
DROP TABLE IF EXISTS server.user_ban_reasons;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS logs.user_authorizations;
DROP TABLE IF EXISTS game_data.x_hero_creature_type;
DROP TABLE IF EXISTS game_data.x_equipment_type_damage_type;
DROP TABLE IF EXISTS game_data.smithing_materials;
DROP TABLE IF EXISTS game_data.slot_types;
DROP TABLE IF EXISTS game_data.material_damage_percents;
DROP TABLE IF EXISTS game_data.equipment_types;
DROP TABLE IF EXISTS game_data.damage_types;
DROP TABLE IF EXISTS game_data.creature_types;
DROP TABLE IF EXISTS game_data.base_heroes;
DROP TABLE IF EXISTS game_data.base_equipments;
DROP TABLE IF EXISTS collection.heroes;
DROP TABLE IF EXISTS collection.equipments;
DROP SCHEMA IF EXISTS users;
DROP SCHEMA IF EXISTS server;
DROP SCHEMA IF EXISTS logs;
DROP SCHEMA IF EXISTS game_data;
DROP SCHEMA IF EXISTS collection;
--
-- TOC entry 10 (class 2615 OID 45122)
-- Name: collection; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA collection;


--
-- TOC entry 6 (class 2615 OID 44873)
-- Name: game_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA game_data;


--
-- TOC entry 7 (class 2615 OID 44874)
-- Name: logs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA logs;


--
-- TOC entry 8 (class 2615 OID 44875)
-- Name: server; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA server;


--
-- TOC entry 9 (class 2615 OID 44876)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 248 (class 1259 OID 45125)
-- Name: equipments; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.equipments (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_equipment_id integer NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 45169)
-- Name: heroes; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.heroes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_hero_id integer NOT NULL,
    health integer NOT NULL,
    attack integer NOT NULL,
    strength integer NOT NULL,
    agility integer NOT NULL,
    intelligence integer NOT NULL,
    crit_chance integer NOT NULL,
    crit_power integer NOT NULL,
    haste integer NOT NULL,
    versality integer NOT NULL,
    endurance_physical integer NOT NULL,
    endurance_magical integer NOT NULL,
    resist_damage_physical integer NOT NULL,
    resist_damage_magical integer NOT NULL,
    equipment1id uuid,
    equipment2id uuid,
    equipment3id uuid,
    equipment4id uuid,
    equipment5id uuid,
    equipment6id uuid,
    equipment7id uuid,
    equipment8id uuid,
    equipment9id uuid,
    equipment10id uuid,
    equipment11id uuid,
    equipment12id uuid,
    equipment13id uuid,
    equipment14id uuid,
    equipment15id uuid,
    equipment16id uuid,
    equipment17id uuid,
    equipment18id uuid,
    equipment19id uuid,
    equipment20id uuid,
    equipment21id uuid,
    equipment22id uuid,
    equipment23id uuid,
    equipment24id uuid
);


--
-- TOC entry 224 (class 1259 OID 44877)
-- Name: base_equipments; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_equipments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    damage character varying(255),
    equipment_type_id integer NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 44888)
-- Name: base_equipments_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_equipments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_equipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 226 (class 1259 OID 44889)
-- Name: base_heroes; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_heroes (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    health character varying(255) NOT NULL,
    damage character varying(255) NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 44903)
-- Name: base_heroes_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_heroes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_heroes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 44904)
-- Name: creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.creature_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 229 (class 1259 OID 44909)
-- Name: creature_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.creature_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.creature_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 44910)
-- Name: damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.damage_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255),
    dev_hint_ru text
);


--
-- TOC entry 231 (class 1259 OID 44917)
-- Name: damage_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.damage_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.damage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 44918)
-- Name: equipment_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.equipment_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255) NOT NULL,
    mass_physical integer DEFAULT 0 NOT NULL,
    mass_magical integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    attack character varying(255),
    spend_action_points integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 44937)
-- Name: equipment_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.equipment_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.equipment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 44938)
-- Name: material_damage_percents; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.material_damage_percents (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 44945)
-- Name: material_damage_percents_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.material_damage_percents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.material_damage_percents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 44946)
-- Name: slot_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slot_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 237 (class 1259 OID 44953)
-- Name: slot_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slot_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slot_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 44954)
-- Name: smithing_materials; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.smithing_materials (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 239 (class 1259 OID 44961)
-- Name: smithing_materials_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.smithing_materials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.smithing_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 44962)
-- Name: x_equipment_type_damage_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_equipment_type_damage_type (
    equipment_type_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    damage_coef integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 44969)
-- Name: x_hero_creature_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_hero_creature_type (
    hero_id integer NOT NULL,
    creature_type_id integer NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 44974)
-- Name: user_authorizations; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.user_authorizations (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    user_id uuid,
    success boolean NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_device_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 44983)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 44988)
-- Name: user_ban_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_ban_reasons (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 44995)
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_ban_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_ban_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 246 (class 1259 OID 44996)
-- Name: user_bans; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_bans (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    user_ban_reason_id integer NOT NULL
);


--
-- TOC entry 249 (class 1259 OID 45147)
-- Name: user_devices; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_devices (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    system_environment_user_name character varying(255) NOT NULL,
    time_zone_minutes integer NOT NULL,
    device_unique_identifier character varying(255) NOT NULL,
    device_model character varying(255) NOT NULL,
    device_type character varying(255) NOT NULL,
    operating_system character varying(255) NOT NULL,
    processor_type character varying(255) NOT NULL,
    processor_count integer NOT NULL,
    system_memory_size integer NOT NULL,
    graphics_device_name character varying(255) NOT NULL,
    graphics_memory_size integer NOT NULL,
    system_info_supports_instancing boolean NOT NULL,
    system_info_npot_support character varying(255) NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 45006)
-- Name: users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.users (
    id uuid NOT NULL,
    email character varying(255),
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    time_zone character varying(255),
    is_admin boolean DEFAULT false NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 5147 (class 0 OID 45125)
-- Dependencies: 248
-- Data for Name: equipments; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.equipments (id, user_id, version, created_at, updated_at, base_equipment_id) FROM stdin;
0f53c74c-89bc-4e66-a9ca-06b903b7df94	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
1464ae64-cd19-421c-b82e-eb9182bd1209	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
149e205d-383c-4f2f-bba2-5fc4d81e5e57	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
1d05be13-4b16-4326-953f-f3d6775de388	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
20d047da-ea6a-442e-a858-68ca4599be13	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
2d843d72-70a2-4646-88d3-eee75976b628	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
35dfdf0d-7c0c-4bdc-a0e9-ea079ee5035b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
41586d09-7b72-4cd5-8f01-374546e14ce8	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
4619ac3b-4dd6-44ec-a329-aae3517a91ae	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
4c7996e3-3f08-4429-ba54-64596e316552	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
4cc12278-a515-48ab-854e-408b255c2b6d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
5f6aad01-9cf3-4cc7-8f95-bb297cc051fe	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
625cff5e-b554-4d70-bb99-7c6808281c28	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
69d8072a-ff08-4dc8-a591-61288dc1cf04	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
6af71542-c4fe-4659-bd99-078c003316aa	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
7062533c-60fc-41b6-a27d-689d33504ba1	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
7c7301e9-086f-4013-9564-c78951448f6f	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
7db6854a-7ff8-40ea-9222-3e2c3b240548	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
8304cb39-03dc-4e85-9ccc-0e4f73f93dc6	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
84ffce6d-ad9c-4e75-ab31-36c7eb0642a6	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
86c3c175-daed-49df-a1d3-5b2cca1291a3	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
89599bd5-fdcc-4ce0-a53d-5786bc5e7cb4	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
8d557b85-a05a-4506-a8d6-066148b52dd2	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
90ec941c-5548-4254-9b55-3b91fab7c382	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
9a33b2e5-e78c-4a5d-8606-5f8e056c7dc5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
9d441537-2e2c-4b7d-9506-11834a094892	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
9e0d5ce4-984a-464b-82c8-ca1e1de39f5f	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
a37a072b-cecd-4116-928f-7149b05ceecd	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
b04fc22c-68f0-4b60-90a9-78cde48261a5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
b0dab54a-99b9-4bd1-8d29-124415760a3b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
b567412a-7701-4075-aeb7-b6baaab6230a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
b770885c-33b6-44d6-bcc8-9c4d3a9ea33b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
b7b73cfd-8c0d-475c-b42f-49cd857513cd	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
ba298f94-24f1-4800-a18d-5553d3723b0c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
bb3b0842-14f8-4896-bc53-8a1a59de92f5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
c216225b-f8a5-4cf7-a702-7b8e1307d767	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
ca4940e0-de48-4a2d-8dc1-9c2a9d02c555	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
d44db2af-1435-4825-a915-d40e45f3b3b8	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
d559a86f-79c9-4acb-95b2-1dedd70d37d0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
d5f34e42-7761-4b1c-adb3-f5a917c69af1	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
df6c6c01-2c26-4f19-b093-946a9408e170	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
df79ba06-1a83-4bcd-af8c-8fda0da1839a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
e29fb270-1b0f-4f7d-880c-dbbed084e87d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
e7dbba8d-5754-4581-ab74-c05724477a88	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
ebdb63b7-14c5-452f-a1f9-31f2d21ef9a4	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
f2a54539-f72c-4bcb-95ae-2ff2dbefa72a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
f64bafb5-7bc8-4fb5-9d1d-349b87ee7d80	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2
f9a5cbb0-71e3-4dbb-9795-c3e82d9ac85c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
fdd8c5a3-3154-4b15-8421-b51813e9d94a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1
05c7c86b-e9c9-4aed-93d6-aa7ce882001b	113ae534-2310-40e3-a895-f3747ea976ca	8	2025-12-19 10:22:04.781589+08	2025-12-19 10:49:01.82747+08	1
\.


--
-- TOC entry 5149 (class 0 OID 45169)
-- Dependencies: 250
-- Data for Name: heroes; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.heroes (id, user_id, version, created_at, updated_at, base_hero_id, health, attack, strength, agility, intelligence, crit_chance, crit_power, haste, versality, endurance_physical, endurance_magical, resist_damage_physical, resist_damage_magical, equipment1id, equipment2id, equipment3id, equipment4id, equipment5id, equipment6id, equipment7id, equipment8id, equipment9id, equipment10id, equipment11id, equipment12id, equipment13id, equipment14id, equipment15id, equipment16id, equipment17id, equipment18id, equipment19id, equipment20id, equipment21id, equipment22id, equipment23id, equipment24id) FROM stdin;
07ca8aa2-1818-4d5d-8e94-550c38781fd6	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
0898028c-387b-4287-bae6-f2c772cb122a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1509d0cc-60b8-4a34-bde9-f3b9c953c346	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
179d9a78-b08a-4066-83a4-44878c0f5fb2	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1a678339-5de4-4158-885f-2a98f3559f87	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
1c3353b7-9d76-4ee3-a643-c38391977357	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
245adf15-4177-472e-b26a-e72b626f7913	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
35d12794-d235-4e17-b63a-de8686ecbbff	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
3a9c4a11-7866-4f07-be28-077c8b92287c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
4157b965-d367-4beb-bb05-e110858bd3dc	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
46059840-ea65-4a09-80d7-8a0ee31d1a7c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5633a525-85f5-4cee-aba2-ea7a0456c7be	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
574d58cd-3556-409f-b71f-d8256813c0f7	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5a0e846c-8d97-494d-9349-808b8240d11b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5e7ef4f3-5478-4379-a404-31d10e41c90f	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
642d2670-60ef-4a23-9fd1-c53f455bc73c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
64611efc-b08d-4d2f-be14-577ff77c58a5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
68afa62f-7590-4f33-87dc-2bb593dd8b71	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6c5c5b0f-bc6d-445d-9c44-b276c6aa1ca7	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6e04e752-046f-4920-b768-02ae3e5d9027	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6e141540-016c-466e-8d37-20712fc22d5d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6f3bdb81-031c-4f29-8e67-ee0597e8226d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7069aabd-3492-4ddd-b169-183227deea19	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
726951f0-964d-45d5-bb75-2d0747aee5a0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
84214c20-5893-4fcc-87f2-9c899acf3304	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
8509518a-83f8-424d-b98b-e137918fe288	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
86bee793-9ca8-4891-8c93-d31d05e98d4e	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
879ea6cc-728c-4534-88dc-210d145c4f93	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
9190bfdb-9859-435b-8698-4bda48110cd2	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
97e422f9-fab2-49f4-9baa-597f0267ecbe	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
a2191a50-eb1e-45ea-9df2-98f8cdfa2c34	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
a6ecb7fa-d9fb-470a-ae38-e54be27111a0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aa3114ef-ebfb-464c-9051-7f4cccdc78db	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
aa31edd3-4170-4a56-aa95-f1512b15ed05	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b075c17b-b766-454e-a6bb-5f1d077d1e97	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b58d2432-9f69-4207-898d-0cbef2a96f9b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b62b12d4-91f7-49bb-a31b-765a5ab42adc	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
b6c097bb-4533-439e-8d92-549944953b68	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
bc29da98-93a8-4ee5-8410-98ff47e8a5c0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
bfd045e4-b18c-42f5-999e-361606e7db36	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
c68bdd39-5c13-4f44-b78e-c3103c15843a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
d3e2d306-2d65-4429-bb73-868cd9e6d49d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
d6a8d5c0-147c-44aa-95a3-26cd1e72da92	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
da9113a3-75c2-4e7f-8f18-4bb2801140f0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
df320eb3-4a55-4285-a56f-d0cb9bbee8b8	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
e646db49-1d8f-4a8e-afbd-4c59132d1fae	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
f0b28a6a-2eff-4fa3-b937-cffe833d9e38	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
f81e4bb5-9d11-485e-a9d9-32f10c7a98a1	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
fa74574f-d388-487d-b22c-afc303586331	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
fb7f80bb-f5d8-4137-99e9-0253d36e5e13	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 5123 (class 0 OID 44877)
-- Dependencies: 224
-- Data for Name: base_equipments; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_equipments (id, name, rarity, is_unique, damage, equipment_type_id) FROM stdin;
2	Usually axe	1	f	\N	2
1	Usually sword	1	f	\N	1
\.


--
-- TOC entry 5125 (class 0 OID 44889)
-- Dependencies: 226
-- Data for Name: base_heroes; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_heroes (id, name, rarity, is_unique, health, damage, main_stat) FROM stdin;
1	Warrior	1	f	16d24_200	4d21_44	0
2	Huntress	1	f	10d28_145	5d21_55	0
3	Hammerman	1	f	11d39_220	3d25_39	0
4	Rogue	1	f	15d21_165	4d23_48	0
5	Battle orc	2	f	16d58_472	4d21_44	0
\.


--
-- TOC entry 5127 (class 0 OID 44904)
-- Dependencies: 228
-- Data for Name: creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.creature_types (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5129 (class 0 OID 44910)
-- Dependencies: 230
-- Data for Name: damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.damage_types (id, name, name_ru, dev_hint_ru) FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."
11	Light	Световой	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."
\.


--
-- TOC entry 5131 (class 0 OID 44918)
-- Dependencies: 232
-- Data for Name: equipment_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.equipment_types (id, name, name_ru, mass_physical, mass_magical, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, attack, spend_action_points) FROM stdin;
9	War Fan	Боевой веер	800	0	11	t	f	5d3_10	0
10	Scimitar	Скимитар	1200	0	11	t	f	6d4_15	0
11	Katana	Катана	1100	0	11	t	f	7d3_14	0
14	Morning Star	Моргенштерн	5000	0	11	t	f	1d123_62	0
1	Sword	Меч	1600	0	11	t	f	8d4_20	0
18	Bow	Лук	960	0	11	t	f	4d2_6	0
21	Pike	Пика	2800	0	11	t	f	24d2_36	0
20	Rapier	Рапира	850	0	11	t	f	8d2_12	0
19	Trident	Трезубец	3400	0	11	t	f	28d2_42	0
17	Crossbow	Арбалет	3200	0	11	t	f	14d2_21	0
7	Shuriken	Сюрикен	180	0	11	t	f	6d2_9	0
22	Spear	Копьё	2200	0	11	t	f	20d2_30	0
24	Dagger	Кинжал	400	0	11	t	f	4d2_6	0
12	Yataghan	Ятаган	1000	0	11	t	f	6d3_12	0
13	Sabre	Сабля	1100	0	11	t	f	7d3_14	0
15	Warhammer	Боевой молот	6200	0	11	t	f	1d153_77	0
16	Mace	Булава	3000	0	11	t	f	1d73_37	0
3	Halberd	Алебарда	4400	0	11	t	f	4d27_56	0
5	Poleaxe	Секира	4000	0	11	t	f	4d24_50	0
23	Broadaxe	Широкий топор	5200	0	11	t	f	4d32_66	0
2	Axe	Топор	2800	0	11	t	f	4d17_36	0
4	Berdysh	Бердыш	3800	0	11	t	f	4d23_48	0
6	Chakram	Чакрам	350	0	11	t	f	5d3_10	0
8	Scythe	Коса	3200	0	11	t	f	5d3_10	0
\.


--
-- TOC entry 5133 (class 0 OID 44938)
-- Dependencies: 234
-- Data for Name: material_damage_percents; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.material_damage_percents (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5135 (class 0 OID 44946)
-- Dependencies: 236
-- Data for Name: slot_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slot_types (id, name, name_ru) FROM stdin;
1	Head	Голова
2	Shoulders	Наплечники
3	Chest	Нагрудник
4	Hands	Руки
5	Legs	Поножи
6	Feet	Ступни
7	Waist	Пояс
8	Wrist	Запястья
9	Back	Спина
10	Bracelet	Браслет
11	HandLeftRight	Рука Левая Правая
12	Ring	Кольцо
13	Earring	Серьги
14	Trinket	Аксессуар
\.


--
-- TOC entry 5137 (class 0 OID 44954)
-- Dependencies: 238
-- Data for Name: smithing_materials; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.smithing_materials (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5139 (class 0 OID 44962)
-- Dependencies: 240
-- Data for Name: x_equipment_type_damage_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_equipment_type_damage_type (equipment_type_id, damage_type_id, damage_coef) FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5140 (class 0 OID 44969)
-- Dependencies: 241
-- Data for Name: x_hero_creature_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_hero_creature_type (hero_id, creature_type_id) FROM stdin;
\.


--
-- TOC entry 5141 (class 0 OID 44974)
-- Dependencies: 242
-- Data for Name: user_authorizations; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.user_authorizations (id, email, user_id, success, version, created_at, user_device_id) FROM stdin;
\.


--
-- TOC entry 5142 (class 0 OID 44983)
-- Dependencies: 243
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251218141532_Init	10.0.1
20251219010850_Fix1	10.0.1
\.


--
-- TOC entry 5143 (class 0 OID 44988)
-- Dependencies: 244
-- Data for Name: user_ban_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_ban_reasons (id, name) FROM stdin;
\.


--
-- TOC entry 5145 (class 0 OID 44996)
-- Dependencies: 246
-- Data for Name: user_bans; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_bans (id, user_id, version, created_at, updated_at, expires_at, user_ban_reason_id) FROM stdin;
\.


--
-- TOC entry 5148 (class 0 OID 45147)
-- Dependencies: 249
-- Data for Name: user_devices; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_devices (id, created_at, system_environment_user_name, time_zone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
\.


--
-- TOC entry 5146 (class 0 OID 45006)
-- Dependencies: 247
-- Data for Name: users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.users (id, email, email_verified_at, password_hash, time_zone, is_admin, version, created_at, updated_at) FROM stdin;
113ae534-2310-40e3-a895-f3747ea976ca	SuperAdmin@mail.ru	\N	AQAAAAIAAYagAAAAEA+MLlU2KQvPMPQ0RCAWN2iQDElD1+zOUuwLjyXnOlBxsikuTAtogGdY3m5zDWnrXg==	\N	t	1	2025-12-03 10:45:43.769905+08	2025-12-03 10:45:43.769905+08
\.


--
-- TOC entry 5155 (class 0 OID 0)
-- Dependencies: 225
-- Name: base_equipments_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_equipments_id_seq', 2, true);


--
-- TOC entry 5156 (class 0 OID 0)
-- Dependencies: 227
-- Name: base_heroes_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_heroes_id_seq', 6, false);


--
-- TOC entry 5157 (class 0 OID 0)
-- Dependencies: 229
-- Name: creature_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.creature_types_id_seq', 9, false);


--
-- TOC entry 5158 (class 0 OID 0)
-- Dependencies: 231
-- Name: damage_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.damage_types_id_seq', 17, false);


--
-- TOC entry 5159 (class 0 OID 0)
-- Dependencies: 233
-- Name: equipment_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.equipment_types_id_seq', 24, true);


--
-- TOC entry 5160 (class 0 OID 0)
-- Dependencies: 235
-- Name: material_damage_percents_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.material_damage_percents_id_seq', 25, false);


--
-- TOC entry 5161 (class 0 OID 0)
-- Dependencies: 237
-- Name: slot_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slot_types_id_seq', 14, true);


--
-- TOC entry 5162 (class 0 OID 0)
-- Dependencies: 239
-- Name: smithing_materials_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.smithing_materials_id_seq', 19, true);


--
-- TOC entry 5163 (class 0 OID 0)
-- Dependencies: 245
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_ban_reasons_id_seq', 1, false);


--
-- TOC entry 4903 (class 2606 OID 45136)
-- Name: equipments equipments__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4934 (class 2606 OID 45193)
-- Name: heroes heroes__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4855 (class 2606 OID 45019)
-- Name: base_equipments base_equipments__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4858 (class 2606 OID 45021)
-- Name: base_heroes base_heroes__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_heroes
    ADD CONSTRAINT base_heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4861 (class 2606 OID 45023)
-- Name: creature_types creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.creature_types
    ADD CONSTRAINT creature_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4864 (class 2606 OID 45025)
-- Name: damage_types damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.damage_types
    ADD CONSTRAINT damage_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4867 (class 2606 OID 45027)
-- Name: equipment_types equipment_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4871 (class 2606 OID 45029)
-- Name: material_damage_percents material_damage_percents__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__pkey PRIMARY KEY (id);


--
-- TOC entry 4875 (class 2606 OID 45031)
-- Name: slot_types slot_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slot_types
    ADD CONSTRAINT slot_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4878 (class 2606 OID 45033)
-- Name: smithing_materials smithing_materials__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.smithing_materials
    ADD CONSTRAINT smithing_materials__pkey PRIMARY KEY (id);


--
-- TOC entry 4881 (class 2606 OID 45035)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__pkey PRIMARY KEY (equipment_type_id, damage_type_id);


--
-- TOC entry 4884 (class 2606 OID 45037)
-- Name: x_hero_creature_type x_hero_creature_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__pkey PRIMARY KEY (hero_id, creature_type_id);


--
-- TOC entry 4886 (class 2606 OID 45039)
-- Name: user_authorizations user_authorizations__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__pkey PRIMARY KEY (id);


--
-- TOC entry 4890 (class 2606 OID 45041)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4893 (class 2606 OID 45043)
-- Name: user_ban_reasons user_ban_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_ban_reasons
    ADD CONSTRAINT user_ban_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 4895 (class 2606 OID 45045)
-- Name: user_bans user_bans__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__pkey PRIMARY KEY (id);


--
-- TOC entry 4907 (class 2606 OID 45168)
-- Name: user_devices user_devices__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_devices
    ADD CONSTRAINT user_devices__pkey PRIMARY KEY (id);


--
-- TOC entry 4900 (class 2606 OID 45047)
-- Name: users users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users__pkey PRIMARY KEY (id);


--
-- TOC entry 4901 (class 1259 OID 45325)
-- Name: equipments__base_equipment_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__base_equipment_id__idx ON collection.equipments USING btree (base_equipment_id);


--
-- TOC entry 4904 (class 1259 OID 45326)
-- Name: equipments__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__user_id__idx ON collection.equipments USING btree (user_id);


--
-- TOC entry 4908 (class 1259 OID 45327)
-- Name: heroes__base_hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__base_hero_id__idx ON collection.heroes USING btree (base_hero_id);


--
-- TOC entry 4909 (class 1259 OID 45328)
-- Name: heroes__equipment10id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment10id__idx ON collection.heroes USING btree (equipment10id);


--
-- TOC entry 4910 (class 1259 OID 45329)
-- Name: heroes__equipment11id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment11id__idx ON collection.heroes USING btree (equipment11id);


--
-- TOC entry 4911 (class 1259 OID 45330)
-- Name: heroes__equipment12id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment12id__idx ON collection.heroes USING btree (equipment12id);


--
-- TOC entry 4912 (class 1259 OID 45331)
-- Name: heroes__equipment13id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment13id__idx ON collection.heroes USING btree (equipment13id);


--
-- TOC entry 4913 (class 1259 OID 45332)
-- Name: heroes__equipment14id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment14id__idx ON collection.heroes USING btree (equipment14id);


--
-- TOC entry 4914 (class 1259 OID 45333)
-- Name: heroes__equipment15id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment15id__idx ON collection.heroes USING btree (equipment15id);


--
-- TOC entry 4915 (class 1259 OID 45334)
-- Name: heroes__equipment16id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment16id__idx ON collection.heroes USING btree (equipment16id);


--
-- TOC entry 4916 (class 1259 OID 45335)
-- Name: heroes__equipment17id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment17id__idx ON collection.heroes USING btree (equipment17id);


--
-- TOC entry 4917 (class 1259 OID 45336)
-- Name: heroes__equipment18id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment18id__idx ON collection.heroes USING btree (equipment18id);


--
-- TOC entry 4918 (class 1259 OID 45337)
-- Name: heroes__equipment19id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment19id__idx ON collection.heroes USING btree (equipment19id);


--
-- TOC entry 4919 (class 1259 OID 45338)
-- Name: heroes__equipment1id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment1id__idx ON collection.heroes USING btree (equipment1id);


--
-- TOC entry 4920 (class 1259 OID 45339)
-- Name: heroes__equipment20id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment20id__idx ON collection.heroes USING btree (equipment20id);


--
-- TOC entry 4921 (class 1259 OID 45340)
-- Name: heroes__equipment21id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment21id__idx ON collection.heroes USING btree (equipment21id);


--
-- TOC entry 4922 (class 1259 OID 45341)
-- Name: heroes__equipment22id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment22id__idx ON collection.heroes USING btree (equipment22id);


--
-- TOC entry 4923 (class 1259 OID 45342)
-- Name: heroes__equipment23id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment23id__idx ON collection.heroes USING btree (equipment23id);


--
-- TOC entry 4924 (class 1259 OID 45343)
-- Name: heroes__equipment24id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment24id__idx ON collection.heroes USING btree (equipment24id);


--
-- TOC entry 4925 (class 1259 OID 45344)
-- Name: heroes__equipment2id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment2id__idx ON collection.heroes USING btree (equipment2id);


--
-- TOC entry 4926 (class 1259 OID 45345)
-- Name: heroes__equipment3id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment3id__idx ON collection.heroes USING btree (equipment3id);


--
-- TOC entry 4927 (class 1259 OID 45346)
-- Name: heroes__equipment4id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment4id__idx ON collection.heroes USING btree (equipment4id);


--
-- TOC entry 4928 (class 1259 OID 45347)
-- Name: heroes__equipment5id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment5id__idx ON collection.heroes USING btree (equipment5id);


--
-- TOC entry 4929 (class 1259 OID 45348)
-- Name: heroes__equipment6id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment6id__idx ON collection.heroes USING btree (equipment6id);


--
-- TOC entry 4930 (class 1259 OID 45349)
-- Name: heroes__equipment7id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment7id__idx ON collection.heroes USING btree (equipment7id);


--
-- TOC entry 4931 (class 1259 OID 45350)
-- Name: heroes__equipment8id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment8id__idx ON collection.heroes USING btree (equipment8id);


--
-- TOC entry 4932 (class 1259 OID 45351)
-- Name: heroes__equipment9id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment9id__idx ON collection.heroes USING btree (equipment9id);


--
-- TOC entry 4935 (class 1259 OID 45352)
-- Name: heroes__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__user_id__idx ON collection.heroes USING btree (user_id);


--
-- TOC entry 4852 (class 1259 OID 45048)
-- Name: base_equipments__equipment_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__equipment_type_id__idx ON game_data.base_equipments USING btree (equipment_type_id);


--
-- TOC entry 4853 (class 1259 OID 45049)
-- Name: base_equipments__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_equipments__name__idx ON game_data.base_equipments USING btree (name);


--
-- TOC entry 4856 (class 1259 OID 45050)
-- Name: base_heroes__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_heroes__name__idx ON game_data.base_heroes USING btree (name);


--
-- TOC entry 4859 (class 1259 OID 45051)
-- Name: creature_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX creature_types__name__idx ON game_data.creature_types USING btree (name);


--
-- TOC entry 4862 (class 1259 OID 45052)
-- Name: damage_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX damage_types__name__idx ON game_data.damage_types USING btree (name);


--
-- TOC entry 4865 (class 1259 OID 45053)
-- Name: equipment_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX equipment_types__name__idx ON game_data.equipment_types USING btree (name);


--
-- TOC entry 4868 (class 1259 OID 45054)
-- Name: equipment_types__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX equipment_types__slot_type_id__idx ON game_data.equipment_types USING btree (slot_type_id);


--
-- TOC entry 4869 (class 1259 OID 45055)
-- Name: material_damage_percents__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__damage_type_id__idx ON game_data.material_damage_percents USING btree (damage_type_id);


--
-- TOC entry 4872 (class 1259 OID 45056)
-- Name: material_damage_percents__smithing_materials_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__smithing_materials_id__idx ON game_data.material_damage_percents USING btree (smithing_materials_id);


--
-- TOC entry 4873 (class 1259 OID 45057)
-- Name: slot_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slot_types__name__idx ON game_data.slot_types USING btree (name);


--
-- TOC entry 4876 (class 1259 OID 45058)
-- Name: smithing_materials__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX smithing_materials__name__idx ON game_data.smithing_materials USING btree (name);


--
-- TOC entry 4879 (class 1259 OID 45059)
-- Name: x_equipment_type_damage_type__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_equipment_type_damage_type__damage_type_id__idx ON game_data.x_equipment_type_damage_type USING btree (damage_type_id);


--
-- TOC entry 4882 (class 1259 OID 45060)
-- Name: x_hero_creature_type__creature_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_hero_creature_type__creature_type_id__idx ON game_data.x_hero_creature_type USING btree (creature_type_id);


--
-- TOC entry 4887 (class 1259 OID 45324)
-- Name: user_authorizations__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX user_authorizations__user_device_id__idx ON logs.user_authorizations USING btree (user_device_id);


--
-- TOC entry 4888 (class 1259 OID 45061)
-- Name: user_authorizations__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX user_authorizations__user_id__idx ON logs.user_authorizations USING btree (user_id);


--
-- TOC entry 4891 (class 1259 OID 45062)
-- Name: user_ban_reasons__name__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_ban_reasons__name__idx ON server.user_ban_reasons USING btree (name);


--
-- TOC entry 4896 (class 1259 OID 45063)
-- Name: user_bans__user_ban_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_ban_reason_id__idx ON users.user_bans USING btree (user_ban_reason_id);


--
-- TOC entry 4897 (class 1259 OID 45064)
-- Name: user_bans__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_id__idx ON users.user_bans USING btree (user_id);


--
-- TOC entry 4905 (class 1259 OID 45353)
-- Name: user_devices__device_unique_identifier__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX user_devices__device_unique_identifier__idx ON users.user_devices USING btree (device_unique_identifier);


--
-- TOC entry 4898 (class 1259 OID 45065)
-- Name: users__email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX users__email__idx ON users.users USING btree (email);


--
-- TOC entry 4948 (class 2606 OID 45137)
-- Name: equipments equipments__base_equipment_id__base_equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__base_equipment_id__base_equipments__fkey FOREIGN KEY (base_equipment_id) REFERENCES game_data.base_equipments(id) ON DELETE CASCADE;


--
-- TOC entry 4949 (class 2606 OID 45142)
-- Name: equipments equipments__user_id__users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


--
-- TOC entry 4950 (class 2606 OID 45194)
-- Name: heroes heroes__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE CASCADE;


--
-- TOC entry 4951 (class 2606 OID 45199)
-- Name: heroes heroes__equipment10id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment10id__equipments__fkey FOREIGN KEY (equipment10id) REFERENCES collection.equipments(id);


--
-- TOC entry 4952 (class 2606 OID 45204)
-- Name: heroes heroes__equipment11id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment11id__equipments__fkey FOREIGN KEY (equipment11id) REFERENCES collection.equipments(id);


--
-- TOC entry 4953 (class 2606 OID 45209)
-- Name: heroes heroes__equipment12id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment12id__equipments__fkey FOREIGN KEY (equipment12id) REFERENCES collection.equipments(id);


--
-- TOC entry 4954 (class 2606 OID 45214)
-- Name: heroes heroes__equipment13id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment13id__equipments__fkey FOREIGN KEY (equipment13id) REFERENCES collection.equipments(id);


--
-- TOC entry 4955 (class 2606 OID 45219)
-- Name: heroes heroes__equipment14id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment14id__equipments__fkey FOREIGN KEY (equipment14id) REFERENCES collection.equipments(id);


--
-- TOC entry 4956 (class 2606 OID 45224)
-- Name: heroes heroes__equipment15id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment15id__equipments__fkey FOREIGN KEY (equipment15id) REFERENCES collection.equipments(id);


--
-- TOC entry 4957 (class 2606 OID 45229)
-- Name: heroes heroes__equipment16id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment16id__equipments__fkey FOREIGN KEY (equipment16id) REFERENCES collection.equipments(id);


--
-- TOC entry 4958 (class 2606 OID 45234)
-- Name: heroes heroes__equipment17id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment17id__equipments__fkey FOREIGN KEY (equipment17id) REFERENCES collection.equipments(id);


--
-- TOC entry 4959 (class 2606 OID 45239)
-- Name: heroes heroes__equipment18id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment18id__equipments__fkey FOREIGN KEY (equipment18id) REFERENCES collection.equipments(id);


--
-- TOC entry 4960 (class 2606 OID 45244)
-- Name: heroes heroes__equipment19id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment19id__equipments__fkey FOREIGN KEY (equipment19id) REFERENCES collection.equipments(id);


--
-- TOC entry 4961 (class 2606 OID 45249)
-- Name: heroes heroes__equipment1id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment1id__equipments__fkey FOREIGN KEY (equipment1id) REFERENCES collection.equipments(id);


--
-- TOC entry 4962 (class 2606 OID 45254)
-- Name: heroes heroes__equipment20id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment20id__equipments__fkey FOREIGN KEY (equipment20id) REFERENCES collection.equipments(id);


--
-- TOC entry 4963 (class 2606 OID 45259)
-- Name: heroes heroes__equipment21id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment21id__equipments__fkey FOREIGN KEY (equipment21id) REFERENCES collection.equipments(id);


--
-- TOC entry 4964 (class 2606 OID 45264)
-- Name: heroes heroes__equipment22id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment22id__equipments__fkey FOREIGN KEY (equipment22id) REFERENCES collection.equipments(id);


--
-- TOC entry 4965 (class 2606 OID 45269)
-- Name: heroes heroes__equipment23id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment23id__equipments__fkey FOREIGN KEY (equipment23id) REFERENCES collection.equipments(id);


--
-- TOC entry 4966 (class 2606 OID 45274)
-- Name: heroes heroes__equipment24id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment24id__equipments__fkey FOREIGN KEY (equipment24id) REFERENCES collection.equipments(id);


--
-- TOC entry 4967 (class 2606 OID 45279)
-- Name: heroes heroes__equipment2id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment2id__equipments__fkey FOREIGN KEY (equipment2id) REFERENCES collection.equipments(id);


--
-- TOC entry 4968 (class 2606 OID 45284)
-- Name: heroes heroes__equipment3id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment3id__equipments__fkey FOREIGN KEY (equipment3id) REFERENCES collection.equipments(id);


--
-- TOC entry 4969 (class 2606 OID 45289)
-- Name: heroes heroes__equipment4id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment4id__equipments__fkey FOREIGN KEY (equipment4id) REFERENCES collection.equipments(id);


--
-- TOC entry 4970 (class 2606 OID 45294)
-- Name: heroes heroes__equipment5id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment5id__equipments__fkey FOREIGN KEY (equipment5id) REFERENCES collection.equipments(id);


--
-- TOC entry 4971 (class 2606 OID 45299)
-- Name: heroes heroes__equipment6id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment6id__equipments__fkey FOREIGN KEY (equipment6id) REFERENCES collection.equipments(id);


--
-- TOC entry 4972 (class 2606 OID 45304)
-- Name: heroes heroes__equipment7id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment7id__equipments__fkey FOREIGN KEY (equipment7id) REFERENCES collection.equipments(id);


--
-- TOC entry 4973 (class 2606 OID 45309)
-- Name: heroes heroes__equipment8id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment8id__equipments__fkey FOREIGN KEY (equipment8id) REFERENCES collection.equipments(id);


--
-- TOC entry 4974 (class 2606 OID 45314)
-- Name: heroes heroes__equipment9id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment9id__equipments__fkey FOREIGN KEY (equipment9id) REFERENCES collection.equipments(id);


--
-- TOC entry 4975 (class 2606 OID 45319)
-- Name: heroes heroes__user_id__users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


--
-- TOC entry 4936 (class 2606 OID 45066)
-- Name: base_equipments base_equipments__equipment_type_id__equipment_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__equipment_type_id__equipment_types__fkey FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE CASCADE;


--
-- TOC entry 4937 (class 2606 OID 45071)
-- Name: equipment_types equipment_types__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE CASCADE;


--
-- TOC entry 4938 (class 2606 OID 45076)
-- Name: material_damage_percents material_damage_percents__damage_type_id__damage_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__damage_type_id__damage_types__fkey FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE CASCADE;


--
-- TOC entry 4939 (class 2606 OID 45081)
-- Name: material_damage_percents material_damage_percents__smithing_materials_id__smithing_mater; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__smithing_materials_id__smithing_mater FOREIGN KEY (smithing_materials_id) REFERENCES game_data.smithing_materials(id) ON DELETE CASCADE;


--
-- TOC entry 4940 (class 2606 OID 45086)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__damage_type_id__damage_types__fke; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__damage_type_id__damage_types__fke FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE CASCADE;


--
-- TOC entry 4941 (class 2606 OID 45091)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__equipment_type_id__equipment_type; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__equipment_type_id__equipment_type FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE CASCADE;


--
-- TOC entry 4942 (class 2606 OID 45096)
-- Name: x_hero_creature_type x_hero_creature_type__creature_type_id__creature_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__creature_type_id__creature_types__fkey FOREIGN KEY (creature_type_id) REFERENCES game_data.creature_types(id) ON DELETE CASCADE;


--
-- TOC entry 4943 (class 2606 OID 45101)
-- Name: x_hero_creature_type x_hero_creature_type__hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__hero_id__base_heroes__fkey FOREIGN KEY (hero_id) REFERENCES game_data.base_heroes(id) ON DELETE CASCADE;


--
-- TOC entry 4944 (class 2606 OID 45354)
-- Name: user_authorizations user_authorizations__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE CASCADE;


--
-- TOC entry 4945 (class 2606 OID 45106)
-- Name: user_authorizations user_authorizations__user_id__users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


--
-- TOC entry 4946 (class 2606 OID 45111)
-- Name: user_bans user_bans__user_ban_reason_id__user_ban_reasons__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_ban_reason_id__user_ban_reasons__fkey FOREIGN KEY (user_ban_reason_id) REFERENCES server.user_ban_reasons(id) ON DELETE CASCADE;


--
-- TOC entry 4947 (class 2606 OID 45116)
-- Name: user_bans user_bans__user_id__users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


-- Completed on 2025-12-19 14:59:16

--
-- PostgreSQL database dump complete
--

\unrestrict 8el387vG7av6gIuIGNjDUbQSymY9G0ytF3rDIjuQxKV7lq7xdh5yHoAoal0Autq

