--
-- PostgreSQL database dump
--

\restrict rvlPmmVIgy4kwRo781sSA1wuFHhEQ5jDyG7tOKQFRXK80pOokchCj4vFalEd7kA

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-11-18 17:14:14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY _main.users_bans DROP CONSTRAINT IF EXISTS users_bans_user_id_users_fkey;
ALTER TABLE IF EXISTS ONLY _main.users_authorization_logs DROP CONSTRAINT IF EXISTS fk_users_authorization_logs_x_users_devices;
ALTER TABLE IF EXISTS ONLY _main.users_authorization_logs DROP CONSTRAINT IF EXISTS fk_users_authorization_logs_x_users;
DROP INDEX IF EXISTS _main.users_email_idx;
DROP INDEX IF EXISTS _main.users_bans_user_id_idx;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY _main.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY _main.users_devices DROP CONSTRAINT IF EXISTS users_devices_pkey;
ALTER TABLE IF EXISTS ONLY _main.users_bans DROP CONSTRAINT IF EXISTS users_bans_pkey;
ALTER TABLE IF EXISTS ONLY _main.users_authorization_logs DROP CONSTRAINT IF EXISTS pk_users_authorization_logs_id;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS _main.users_devices;
DROP TABLE IF EXISTS _main.users_bans;
DROP TABLE IF EXISTS _main.users_authorization_logs;
DROP TABLE IF EXISTS _main.users;
DROP FUNCTION IF EXISTS public.set_timestamp();
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pgcrypto;
DROP EXTENSION IF EXISTS citext;
DROP SCHEMA IF EXISTS _main;
--
-- TOC entry 9 (class 2615 OID 33149)
-- Name: _main; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _main;


--
-- TOC entry 2 (class 3079 OID 33150)
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- TOC entry 5093 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- TOC entry 3 (class 3079 OID 33255)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 5094 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 4 (class 3079 OID 33293)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 5095 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 240 (class 1255 OID 33304)
-- Name: set_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.created_at := COALESCE(NEW.created_at, NOW());
        NEW.updated_at := COALESCE(NEW.updated_at, NOW());
    ELSIF TG_OP = 'UPDATE' THEN
        NEW.created_at := OLD.created_at;
        IF NEW.updated_at IS NULL OR NEW.updated_at = OLD.updated_at THEN
            NEW.updated_at := NOW();
        END IF;
    END IF;
    RETURN NEW;
END;
                $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 223 (class 1259 OID 33305)
-- Name: users; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email character varying(255),
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    time_zone character varying(64),
    is_admin boolean DEFAULT false NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 33316)
-- Name: users_authorization_logs; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.users_authorization_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    success boolean NOT NULL,
    email public.citext,
    user_id uuid,
    ip_address inet NOT NULL,
    user_device_id uuid NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 33328)
-- Name: users_bans; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.users_bans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    user_bans_reasons_id uuid
);


--
-- TOC entry 226 (class 1259 OID 33336)
-- Name: users_devices; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.users_devices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    system_environment_username character varying(255),
    timezone_minutes integer,
    device_unique_identifier character varying(255),
    device_model character varying(255),
    device_type character varying(255),
    operating_system character varying(255),
    processor_type character varying(255),
    processor_count integer,
    system_memory_size integer,
    graphics_device_name character varying(255),
    graphics_memory_size integer,
    system_info_supports_instancing boolean,
    system_info_npot_support character varying(255)
);


--
-- TOC entry 227 (class 1259 OID 33345)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 5083 (class 0 OID 33305)
-- Dependencies: 223
-- Data for Name: users; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.users (id, created_at, updated_at, email, email_verified_at, password_hash, time_zone, is_admin) FROM stdin;
113ae534-2310-40e3-a895-f3747ea976ca	2025-11-06 11:48:37.613578+08	2025-11-06 11:48:37.613578+08	SuperAdmin@mail.ru	\N	AQAAAAIAAYagAAAAEA+MLlU2KQvPMPQ0RCAWN2iQDElD1+zOUuwLjyXnOlBxsikuTAtogGdY3m5zDWnrXg==	\N	t
\.


--
-- TOC entry 5084 (class 0 OID 33316)
-- Dependencies: 224
-- Data for Name: users_authorization_logs; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.users_authorization_logs (id, created_at, success, email, user_id, ip_address, user_device_id) FROM stdin;
81d39c34-70dd-4ce9-bd47-8d2e367558a9	2025-11-07 08:14:28.850704+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
cd9c669d-fbe4-466a-81ab-762be73d375d	2025-11-07 08:15:28.804717+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
50b61f5b-d280-4946-a683-71f2d0494c01	2025-11-07 08:15:48.81737+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
a0161e82-8dc9-47a4-85d3-af8090a2a7b6	2025-11-07 08:15:48.81737+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
46b0c74f-9f76-499c-bf33-4e0224185b55	2025-11-07 09:55:05.295015+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
3082e418-8882-4877-a214-6686a4cd19e7	2025-11-07 09:56:29.138688+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
526c5920-3139-49b5-9d6f-9772e885362f	2025-11-07 09:58:40.510703+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
a8553210-2525-46a3-aa78-8dca02f78a98	2025-11-07 09:59:18.906095+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
1c1d4830-cd61-4d6b-9376-639b04785979	2025-11-07 10:03:59.837202+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
4663427e-0a14-42b5-9652-ffa17e22120b	2025-11-07 10:04:08.149424+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
b66c2667-274e-488b-94ee-11ac89311333	2025-11-12 08:48:18.19208+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
7257264e-bec1-404f-a9c4-b98ad8680711	2025-11-12 08:50:17.25827+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
a162e8b4-d90f-45fa-8ca0-7274006239ca	2025-11-12 08:53:07.262635+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
d6685973-3db9-4441-8666-ade761bc6326	2025-11-12 09:04:58.789311+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
54a49aed-e83e-4c9e-8a07-a40585c7c1fc	2025-11-12 09:06:42.888629+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
78645162-63ff-488c-8210-788d402096b4	2025-11-12 16:56:51.754775+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
f41f8027-497a-4a99-8381-a26c314d4da9	2025-11-12 17:02:31.734963+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
ae305448-8110-4645-974a-43d0f469b8c1	2025-11-12 17:03:01.737167+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
f508f6a4-d140-4531-92aa-64e8ef065924	2025-11-13 12:40:23.023018+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
fb28556e-8612-4b4f-95a1-fed619fd8f1f	2025-11-13 12:42:32.978105+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
81e895e2-8555-4861-b722-a645dee688cb	2025-11-13 12:50:30.933985+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
988ac70e-5ead-4061-a4f1-0f2c6f7c5a5a	2025-11-13 17:06:26.328401+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
f5d61138-7cb5-451d-9158-739c7705724d	2025-11-13 17:07:16.327752+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
fe053872-9046-4509-aeab-a2bf4e0d7518	2025-11-13 17:11:01.338793+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
7eedeeee-8573-4cea-a2ab-2ed59b34caed	2025-11-13 17:12:36.344129+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
501f580e-c9d8-4000-98a8-ea30a7740370	2025-11-13 17:13:36.354928+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
cee1bb09-bff0-49b3-a7e9-30384ab3b046	2025-11-14 13:02:26.7309+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
fcd6bb93-e287-47c5-8fe0-43279db9099a	2025-11-17 10:31:51.564655+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
1469e1b0-a3a5-4ed7-9338-9706181e2b00	2025-11-17 10:41:06.553423+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
53d3b8e5-724f-4a04-8ef9-491e52614cb0	2025-11-17 10:41:26.558957+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
a01b2e88-f032-46c3-b290-4b4580a7ae33	2025-11-17 10:41:56.547649+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
f1396aa7-f7aa-415d-97ce-1c458d0d125f	2025-11-17 10:59:06.593668+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
d0d1a336-f411-4485-ad63-544a8f0fcfa5	2025-11-17 13:06:41.938086+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
173d5e22-b190-4887-984f-7af436b1e71a	2025-11-17 13:09:56.92152+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
dc0f719a-9068-41a5-a548-99c7ad5c51be	2025-11-18 12:56:47.871161+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
ae48eb45-f332-4871-b8e1-a01310d2ab61	2025-11-18 13:05:17.804595+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
515a7482-afe1-4f2b-9c26-2698993ebb35	2025-11-18 13:08:02.814637+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
19349016-b809-41ba-926c-1a12e102858a	2025-11-18 13:17:12.821856+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
00e1046b-9ce3-43f5-91aa-aab3da7c9a57	2025-11-18 13:21:47.82318+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
b2fee07e-41e5-4baf-9b8b-115bb16068f5	2025-11-18 13:22:45.865083+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
121368a6-3270-4c16-8f56-87721dd29819	2025-11-18 13:24:06.438305+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
782c6d82-8de5-4254-be16-ce09e1693069	2025-11-18 13:27:29.07408+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
5ea3410d-9592-4474-9e52-86941b820187	2025-11-18 15:09:50.892161+08	t	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	127.0.0.1	2f3585e2-e396-344a-36d2-8d7079e5cdfc
\.


--
-- TOC entry 5085 (class 0 OID 33328)
-- Dependencies: 225
-- Data for Name: users_bans; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.users_bans (id, user_id, created_at, expires_at, user_bans_reasons_id) FROM stdin;
\.


--
-- TOC entry 5086 (class 0 OID 33336)
-- Dependencies: 226
-- Data for Name: users_devices; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.users_devices (id, created_at, system_environment_username, timezone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
47ee0275-bae7-c989-6f87-f8b416a6cfd0	2025-11-03 16:23:06.897034+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
2f3585e2-e396-344a-36d2-8d7079e5cdfc	2025-11-07 08:14:28.850704+08	adm-shumkov	480	30af10590f9f87bea6b087c950be35295e8eee95	B760 DS3H (Gigabyte Technology Co., Ltd.)	Desktop	Windows 10  (10.0.19045) 64bit	Intel(R) Core(TM) i9-14900K	32	65296	Intel(R) UHD Graphics 770	32648	t	Full
\.


--
-- TOC entry 5087 (class 0 OID 33345)
-- Dependencies: 227
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20250704004607_Init	9.0.6
20250708053934_AddLoggingAuthorization	9.0.6
20251103065602_start	9.0.10
20251105014526_start001	9.0.10
20251105024241_start002	9.0.10
\.


--
-- TOC entry 4925 (class 2606 OID 33351)
-- Name: users_authorization_logs pk_users_authorization_logs_id; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_authorization_logs
    ADD CONSTRAINT pk_users_authorization_logs_id PRIMARY KEY (id);


--
-- TOC entry 4927 (class 2606 OID 33353)
-- Name: users_bans users_bans_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_bans
    ADD CONSTRAINT users_bans_pkey PRIMARY KEY (id);


--
-- TOC entry 4930 (class 2606 OID 33355)
-- Name: users_devices users_devices_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_devices
    ADD CONSTRAINT users_devices_pkey PRIMARY KEY (id);


--
-- TOC entry 4923 (class 2606 OID 33357)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4932 (class 2606 OID 33359)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4928 (class 1259 OID 33360)
-- Name: users_bans_user_id_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE INDEX users_bans_user_id_idx ON _main.users_bans USING btree (user_id);


--
-- TOC entry 4921 (class 1259 OID 33361)
-- Name: users_email_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE UNIQUE INDEX users_email_idx ON _main.users USING btree (email);


--
-- TOC entry 4933 (class 2606 OID 33362)
-- Name: users_authorization_logs fk_users_authorization_logs_x_users; Type: FK CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_authorization_logs
    ADD CONSTRAINT fk_users_authorization_logs_x_users FOREIGN KEY (user_id) REFERENCES _main.users(id);


--
-- TOC entry 4934 (class 2606 OID 33367)
-- Name: users_authorization_logs fk_users_authorization_logs_x_users_devices; Type: FK CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_authorization_logs
    ADD CONSTRAINT fk_users_authorization_logs_x_users_devices FOREIGN KEY (user_device_id) REFERENCES _main.users_devices(id);


--
-- TOC entry 4935 (class 2606 OID 33372)
-- Name: users_bans users_bans_user_id_users_fkey; Type: FK CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.users_bans
    ADD CONSTRAINT users_bans_user_id_users_fkey FOREIGN KEY (user_id) REFERENCES _main.users(id);


-- Completed on 2025-11-18 17:14:14

--
-- PostgreSQL database dump complete
--

\unrestrict rvlPmmVIgy4kwRo781sSA1wuFHhEQ5jDyG7tOKQFRXK80pOokchCj4vFalEd7kA

