--
-- PostgreSQL database dump
--

\restrict jczgBPjSHYJLOVkDL4M6dx6ROgFZUsTNDVKsEbyWPIFLOxRin6bFIvGdVTrI10R

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-12-22 22:29:58

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_ban_reason_id__user_ban_reasons__fkey;
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__creature_type_id__creature_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__equipment_type_id__equipment_type;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__damage_type_id__damage_types__fke;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__smithing_materials_id__smithing_mater;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__damage_type_id__damage_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__equipment_type_id__equipment_types__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment9id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment8id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment7id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment6id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment5id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment4id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment3id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment2id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment24id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment23id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment22id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment21id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment20id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment1id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment19id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment18id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment17id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment16id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment15id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment14id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment13id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment12id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment11id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment10id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__base_equipment_id__base_equipments__fkey;
DROP INDEX IF EXISTS users.users__email__idx;
DROP INDEX IF EXISTS users.user_bans__user_id__idx;
DROP INDEX IF EXISTS users.user_bans__user_ban_reason_id__idx;
DROP INDEX IF EXISTS server.user_ban_reasons__name__idx;
DROP INDEX IF EXISTS logs.user_authorizations__user_id__idx;
DROP INDEX IF EXISTS logs.user_authorizations__user_device_id__idx;
DROP INDEX IF EXISTS game_data.x_hero_creature_type__creature_type_id__idx;
DROP INDEX IF EXISTS game_data.x_equipment_type_damage_type__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.smithing_materials__name__idx;
DROP INDEX IF EXISTS game_data.slot_types__name__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__smithing_materials_id__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__name__idx;
DROP INDEX IF EXISTS game_data.damage_types__name__idx;
DROP INDEX IF EXISTS game_data.creature_types__name__idx;
DROP INDEX IF EXISTS game_data.base_heroes__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__equipment_type_id__idx;
DROP INDEX IF EXISTS collection.heroes__user_id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment9id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment8id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment7id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment6id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment5id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment4id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment3id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment2id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment24id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment23id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment22id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment21id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment20id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment1id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment19id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment18id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment17id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment16id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment15id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment14id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment13id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment12id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment11id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment10id__idx;
DROP INDEX IF EXISTS collection.heroes__base_hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__user_id__idx;
DROP INDEX IF EXISTS collection.equipments__base_equipment_id__idx;
ALTER TABLE IF EXISTS ONLY users.users DROP CONSTRAINT IF EXISTS users__pkey;
ALTER TABLE IF EXISTS ONLY users.user_devices DROP CONSTRAINT IF EXISTS user_devices__pkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__pkey;
ALTER TABLE IF EXISTS ONLY server.user_ban_reasons DROP CONSTRAINT IF EXISTS user_ban_reasons__pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.smithing_materials DROP CONSTRAINT IF EXISTS smithing_materials__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slot_types DROP CONSTRAINT IF EXISTS slot_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__pkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.damage_types DROP CONSTRAINT IF EXISTS damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.creature_types DROP CONSTRAINT IF EXISTS creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_heroes DROP CONSTRAINT IF EXISTS base_heroes__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__pkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__pkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__pkey;
DROP TABLE IF EXISTS users.users;
DROP TABLE IF EXISTS users.user_devices;
DROP TABLE IF EXISTS users.user_bans;
DROP TABLE IF EXISTS server.user_ban_reasons;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS logs.user_authorizations;
DROP TABLE IF EXISTS game_data.x_hero_creature_type;
DROP TABLE IF EXISTS game_data.x_equipment_type_damage_type;
DROP TABLE IF EXISTS game_data.smithing_materials;
DROP TABLE IF EXISTS game_data.slot_types;
DROP TABLE IF EXISTS game_data.material_damage_percents;
DROP TABLE IF EXISTS game_data.equipment_types;
DROP TABLE IF EXISTS game_data.damage_types;
DROP TABLE IF EXISTS game_data.creature_types;
DROP TABLE IF EXISTS game_data.base_heroes;
DROP TABLE IF EXISTS game_data.base_equipments;
DROP TABLE IF EXISTS collection.heroes;
DROP TABLE IF EXISTS collection.equipments;
DROP SCHEMA IF EXISTS users;
DROP SCHEMA IF EXISTS server;
DROP SCHEMA IF EXISTS logs;
DROP SCHEMA IF EXISTS game_data;
DROP SCHEMA IF EXISTS collection;
--
-- TOC entry 6 (class 2615 OID 22402)
-- Name: collection; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA collection;


--
-- TOC entry 7 (class 2615 OID 22403)
-- Name: game_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA game_data;


--
-- TOC entry 8 (class 2615 OID 22404)
-- Name: logs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA logs;


--
-- TOC entry 9 (class 2615 OID 22405)
-- Name: server; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA server;


--
-- TOC entry 10 (class 2615 OID 22406)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 22407)
-- Name: equipments; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.equipments (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_equipment_id integer NOT NULL,
    group_name character varying(255)
);


--
-- TOC entry 225 (class 1259 OID 22417)
-- Name: heroes; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.heroes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_hero_id integer NOT NULL,
    health1000 bigint CONSTRAINT heroes_health_not_null NOT NULL,
    strength integer NOT NULL,
    agility integer NOT NULL,
    intelligence integer NOT NULL,
    crit_chance integer NOT NULL,
    crit_power integer NOT NULL,
    haste integer NOT NULL,
    versality integer NOT NULL,
    endurance_physical integer NOT NULL,
    endurance_magical integer NOT NULL,
    resist_damage_physical integer NOT NULL,
    resist_damage_magical integer NOT NULL,
    equipment1id uuid,
    equipment2id uuid,
    equipment3id uuid,
    equipment4id uuid,
    equipment5id uuid,
    equipment6id uuid,
    equipment7id uuid,
    equipment8id uuid,
    equipment9id uuid,
    equipment10id uuid,
    equipment11id uuid,
    equipment12id uuid,
    equipment13id uuid,
    equipment14id uuid,
    equipment15id uuid,
    equipment16id uuid,
    equipment17id uuid,
    equipment18id uuid,
    equipment19id uuid,
    equipment20id uuid,
    equipment21id uuid,
    equipment22id uuid,
    equipment23id uuid,
    equipment24id uuid,
    experience_now bigint DEFAULT 0 NOT NULL,
    group_name character varying(255),
    level integer DEFAULT 1 NOT NULL,
    rarity integer DEFAULT 1 NOT NULL,
    damage jsonb
);


--
-- TOC entry 226 (class 1259 OID 22447)
-- Name: base_equipments; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_equipments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    equipment_type_id integer NOT NULL,
    stats jsonb
);


--
-- TOC entry 227 (class 1259 OID 22458)
-- Name: base_equipments_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_equipments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_equipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 22459)
-- Name: base_heroes; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_heroes (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL,
    stats jsonb
);


--
-- TOC entry 229 (class 1259 OID 22471)
-- Name: base_heroes_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_heroes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_heroes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 22472)
-- Name: creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.creature_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 22477)
-- Name: creature_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.creature_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.creature_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 22478)
-- Name: damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.damage_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255),
    dev_hint_ru text
);


--
-- TOC entry 233 (class 1259 OID 22485)
-- Name: damage_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.damage_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.damage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 22486)
-- Name: equipment_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.equipment_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255) NOT NULL,
    mass_physical integer DEFAULT 0 NOT NULL,
    mass_magical integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    attack_old character varying(255),
    spend_action_points integer DEFAULT 0 NOT NULL,
    block_other_hand boolean
);


--
-- TOC entry 235 (class 1259 OID 22505)
-- Name: equipment_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.equipment_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.equipment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 22506)
-- Name: material_damage_percents; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.material_damage_percents (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 22513)
-- Name: material_damage_percents_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.material_damage_percents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.material_damage_percents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 22514)
-- Name: slot_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slot_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 239 (class 1259 OID 22521)
-- Name: slot_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slot_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slot_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 22522)
-- Name: smithing_materials; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.smithing_materials (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 241 (class 1259 OID 22529)
-- Name: smithing_materials_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.smithing_materials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.smithing_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 22530)
-- Name: x_equipment_type_damage_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_equipment_type_damage_type (
    equipment_type_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    damage_coef integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 22537)
-- Name: x_hero_creature_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_hero_creature_type (
    hero_id integer NOT NULL,
    creature_type_id integer NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 22542)
-- Name: user_authorizations; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.user_authorizations (
    id uuid NOT NULL,
    email character varying(255),
    user_id uuid,
    success boolean NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_device_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid,
    ip inet
);


--
-- TOC entry 245 (class 1259 OID 22553)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 22558)
-- Name: user_ban_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_ban_reasons (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 22565)
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_ban_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_ban_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 248 (class 1259 OID 22566)
-- Name: user_bans; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_bans (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    user_ban_reason_id integer NOT NULL
);


--
-- TOC entry 249 (class 1259 OID 22576)
-- Name: user_devices; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_devices (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    system_environment_user_name character varying(255),
    time_zone_minutes integer,
    device_unique_identifier character varying(255),
    device_model character varying(255),
    device_type character varying(255),
    operating_system character varying(255),
    processor_type character varying(255),
    processor_count integer,
    system_memory_size integer,
    graphics_device_name character varying(255),
    graphics_memory_size integer,
    system_info_supports_instancing boolean,
    system_info_npot_support character varying(255)
);


--
-- TOC entry 250 (class 1259 OID 22583)
-- Name: users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.users (
    id uuid NOT NULL,
    email character varying(255),
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    time_zone character varying(255),
    is_admin boolean DEFAULT false NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 5180 (class 0 OID 22407)
-- Dependencies: 224
-- Data for Name: equipments; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.equipments (id, user_id, version, created_at, updated_at, base_equipment_id, group_name) FROM stdin;
0f53c74c-89bc-4e66-a9ca-06b903b7df94	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
1464ae64-cd19-421c-b82e-eb9182bd1209	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
149e205d-383c-4f2f-bba2-5fc4d81e5e57	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
1d05be13-4b16-4326-953f-f3d6775de388	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
20d047da-ea6a-442e-a858-68ca4599be13	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
2d843d72-70a2-4646-88d3-eee75976b628	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
35dfdf0d-7c0c-4bdc-a0e9-ea079ee5035b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
41586d09-7b72-4cd5-8f01-374546e14ce8	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
4619ac3b-4dd6-44ec-a329-aae3517a91ae	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
4c7996e3-3f08-4429-ba54-64596e316552	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
4cc12278-a515-48ab-854e-408b255c2b6d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
5f6aad01-9cf3-4cc7-8f95-bb297cc051fe	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
625cff5e-b554-4d70-bb99-7c6808281c28	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
69d8072a-ff08-4dc8-a591-61288dc1cf04	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
6af71542-c4fe-4659-bd99-078c003316aa	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
7062533c-60fc-41b6-a27d-689d33504ba1	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
7c7301e9-086f-4013-9564-c78951448f6f	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
7db6854a-7ff8-40ea-9222-3e2c3b240548	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
8304cb39-03dc-4e85-9ccc-0e4f73f93dc6	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
84ffce6d-ad9c-4e75-ab31-36c7eb0642a6	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
86c3c175-daed-49df-a1d3-5b2cca1291a3	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
89599bd5-fdcc-4ce0-a53d-5786bc5e7cb4	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
8d557b85-a05a-4506-a8d6-066148b52dd2	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
90ec941c-5548-4254-9b55-3b91fab7c382	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
9a33b2e5-e78c-4a5d-8606-5f8e056c7dc5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
9d441537-2e2c-4b7d-9506-11834a094892	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
9e0d5ce4-984a-464b-82c8-ca1e1de39f5f	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
a37a072b-cecd-4116-928f-7149b05ceecd	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
b04fc22c-68f0-4b60-90a9-78cde48261a5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
b0dab54a-99b9-4bd1-8d29-124415760a3b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
b567412a-7701-4075-aeb7-b6baaab6230a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
b770885c-33b6-44d6-bcc8-9c4d3a9ea33b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
b7b73cfd-8c0d-475c-b42f-49cd857513cd	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
ba298f94-24f1-4800-a18d-5553d3723b0c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
bb3b0842-14f8-4896-bc53-8a1a59de92f5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
c216225b-f8a5-4cf7-a702-7b8e1307d767	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
ca4940e0-de48-4a2d-8dc1-9c2a9d02c555	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
d44db2af-1435-4825-a915-d40e45f3b3b8	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
d559a86f-79c9-4acb-95b2-1dedd70d37d0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
d5f34e42-7761-4b1c-adb3-f5a917c69af1	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
df6c6c01-2c26-4f19-b093-946a9408e170	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
df79ba06-1a83-4bcd-af8c-8fda0da1839a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
e29fb270-1b0f-4f7d-880c-dbbed084e87d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
e7dbba8d-5754-4581-ab74-c05724477a88	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
ebdb63b7-14c5-452f-a1f9-31f2d21ef9a4	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
f2a54539-f72c-4bcb-95ae-2ff2dbefa72a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
f64bafb5-7bc8-4fb5-9d1d-349b87ee7d80	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	2	\N
f9a5cbb0-71e3-4dbb-9795-c3e82d9ac85c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
fdd8c5a3-3154-4b15-8421-b51813e9d94a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	1	\N
05c7c86b-e9c9-4aed-93d6-aa7ce882001b	113ae534-2310-40e3-a895-f3747ea976ca	8	2025-12-19 10:22:04.781589+08	2025-12-19 10:49:01.82747+08	1	\N
\.


--
-- TOC entry 5181 (class 0 OID 22417)
-- Dependencies: 225
-- Data for Name: heroes; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.heroes (id, user_id, version, created_at, updated_at, base_hero_id, health1000, strength, agility, intelligence, crit_chance, crit_power, haste, versality, endurance_physical, endurance_magical, resist_damage_physical, resist_damage_magical, equipment1id, equipment2id, equipment3id, equipment4id, equipment5id, equipment6id, equipment7id, equipment8id, equipment9id, equipment10id, equipment11id, equipment12id, equipment13id, equipment14id, equipment15id, equipment16id, equipment17id, equipment18id, equipment19id, equipment20id, equipment21id, equipment22id, equipment23id, equipment24id, experience_now, group_name, level, rarity, damage) FROM stdin;
6e04e752-046f-4920-b768-02ae3e5d9027	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
7069aabd-3492-4ddd-b169-183227deea19	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
726951f0-964d-45d5-bb75-2d0747aee5a0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
84214c20-5893-4fcc-87f2-9c899acf3304	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8509518a-83f8-424d-b98b-e137918fe288	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
86bee793-9ca8-4891-8c93-d31d05e98d4e	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
9190bfdb-9859-435b-8698-4bda48110cd2	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
97e422f9-fab2-49f4-9baa-597f0267ecbe	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
aa31edd3-4170-4a56-aa95-f1512b15ed05	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b075c17b-b766-454e-a6bb-5f1d077d1e97	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b58d2432-9f69-4207-898d-0cbef2a96f9b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b6c097bb-4533-439e-8d92-549944953b68	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bc29da98-93a8-4ee5-8410-98ff47e8a5c0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bfd045e4-b18c-42f5-999e-361606e7db36	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c68bdd39-5c13-4f44-b78e-c3103c15843a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d3e2d306-2d65-4429-bb73-868cd9e6d49d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d6a8d5c0-147c-44aa-95a3-26cd1e72da92	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
da9113a3-75c2-4e7f-8f18-4bb2801140f0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
df320eb3-4a55-4285-a56f-d0cb9bbee8b8	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
e646db49-1d8f-4a8e-afbd-4c59132d1fae	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f0b28a6a-2eff-4fa3-b937-cffe833d9e38	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f81e4bb5-9d11-485e-a9d9-32f10c7a98a1	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
fa74574f-d388-487d-b22c-afc303586331	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
07ca8aa2-1818-4d5d-8e94-550c38781fd6	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1509d0cc-60b8-4a34-bde9-f3b9c953c346	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1a678339-5de4-4158-885f-2a98f3559f87	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
1c3353b7-9d76-4ee3-a643-c38391977357	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
245adf15-4177-472e-b26a-e72b626f7913	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
35d12794-d235-4e17-b63a-de8686ecbbff	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3a9c4a11-7866-4f07-be28-077c8b92287c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
46059840-ea65-4a09-80d7-8a0ee31d1a7c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5633a525-85f5-4cee-aba2-ea7a0456c7be	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
fb7f80bb-f5d8-4137-99e9-0253d36e5e13	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0898028c-387b-4287-bae6-f2c772cb122a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
179d9a78-b08a-4066-83a4-44878c0f5fb2	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4157b965-d367-4beb-bb05-e110858bd3dc	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6e141540-016c-466e-8d37-20712fc22d5d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6f3bdb81-031c-4f29-8e67-ee0597e8226d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
879ea6cc-728c-4534-88dc-210d145c4f93	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a2191a50-eb1e-45ea-9df2-98f8cdfa2c34	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a6ecb7fa-d9fb-470a-ae38-e54be27111a0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
aa3114ef-ebfb-464c-9051-7f4cccdc78db	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b62b12d4-91f7-49bb-a31b-765a5ab42adc	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
574d58cd-3556-409f-b71f-d8256813c0f7	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5a0e846c-8d97-494d-9349-808b8240d11b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5e7ef4f3-5478-4379-a404-31d10e41c90f	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
642d2670-60ef-4a23-9fd1-c53f455bc73c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
64611efc-b08d-4d2f-be14-577ff77c58a5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
68afa62f-7590-4f33-87dc-2bb593dd8b71	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6c5c5b0f-bc6d-445d-9c44-b276c6aa1ca7	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
\.


--
-- TOC entry 5182 (class 0 OID 22447)
-- Dependencies: 226
-- Data for Name: base_equipments; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_equipments (id, name, rarity, is_unique, equipment_type_id, stats) FROM stdin;
2	Usually axe	1	f	2	\N
1	Usually sword	1	f	1	\N
\.


--
-- TOC entry 5184 (class 0 OID 22459)
-- Dependencies: 228
-- Data for Name: base_heroes; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_heroes (id, name, rarity, is_unique, main_stat, stats) FROM stdin;
1	Warrior	1	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 24}}
2	Huntress	1	f	2	{"damage": {"c": 5, "s": 21}, "health": {"c": 10, "s": 28}}
3	Hammerman	1	f	1	{"damage": {"c": 3, "s": 25}, "health": {"c": 11, "s": 39}}
4	Rogue	1	f	2	{"damage": {"c": 4, "s": 23}, "health": {"c": 15, "s": 21}}
5	Battle orc	2	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 58}}
\.


--
-- TOC entry 5186 (class 0 OID 22472)
-- Dependencies: 230
-- Data for Name: creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.creature_types (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5188 (class 0 OID 22478)
-- Dependencies: 232
-- Data for Name: damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.damage_types (id, name, name_ru, dev_hint_ru) FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."
11	Light	Световой	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."
\.


--
-- TOC entry 5190 (class 0 OID 22486)
-- Dependencies: 234
-- Data for Name: equipment_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.equipment_types (id, name, name_ru, mass_physical, mass_magical, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, attack_old, spend_action_points, block_other_hand) FROM stdin;
9	War Fan	Боевой веер	800	0	1	t	f	5d3_10	0	\N
10	Scimitar	Скимитар	1200	0	1	t	f	6d4_15	0	\N
11	Katana	Катана	1100	0	1	t	f	7d3_14	0	\N
14	Morning Star	Моргенштерн	5000	0	1	t	f	1d123_62	0	\N
21	Pike	Пика	2800	0	1	t	f	24d2_36	0	\N
20	Rapier	Рапира	850	0	1	t	f	8d2_12	0	\N
19	Trident	Трезубец	3400	0	1	t	f	28d2_42	0	\N
7	Shuriken	Сюрикен	180	0	1	t	f	6d2_9	0	\N
22	Spear	Копьё	2200	0	1	t	f	20d2_30	0	\N
24	Dagger	Кинжал	400	0	1	t	f	4d2_6	0	\N
12	Yataghan	Ятаган	1000	0	1	t	f	6d3_12	0	\N
13	Sabre	Сабля	1100	0	1	t	f	7d3_14	0	\N
15	Warhammer	Боевой молот	6200	0	1	t	f	1d153_77	0	\N
16	Mace	Булава	3000	0	1	t	f	1d73_37	0	\N
3	Halberd	Алебарда	4400	0	1	t	f	4d27_56	0	\N
5	Poleaxe	Секира	4000	0	1	t	f	4d24_50	0	\N
23	Broadaxe	Широкий топор	5200	0	1	t	f	4d32_66	0	\N
2	Axe	Топор	2800	0	1	t	f	4d17_36	0	\N
4	Berdysh	Бердыш	3800	0	1	t	f	4d23_48	0	\N
6	Chakram	Чакрам	350	0	1	t	f	5d3_10	0	\N
8	Scythe	Коса	3200	0	1	t	f	5d3_10	0	\N
17	Crossbow	Арбалет	3200	0	1	t	f	14d2_21	0	\N
18	Bow	Лук	960	0	3	t	f	4d2_6	0	t
1	Sword	Меч	1600	0	1	t	f	8d4_20	0	\N
\.


--
-- TOC entry 5192 (class 0 OID 22506)
-- Dependencies: 236
-- Data for Name: material_damage_percents; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.material_damage_percents (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5194 (class 0 OID 22514)
-- Dependencies: 238
-- Data for Name: slot_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slot_types (id, name, name_ru) FROM stdin;
9	Feet	Ступни
10	Waist	Пояс
11	Wrist	Запястья
12	Back	Спина
13	Bracelet	Браслет
14	Ring	Кольцо
15	Earring	Серьга
16	Trinket	Аксессуар
1	HandLeftOrRight	Рука Левая или Правая
4	Head	Голова
5	Shoulders	Наплечники
6	Chest	Нагрудник
7	Hands	Руки
8	Legs	Поножи
2	HandRight	Рука Правая
3	HandLeft	Рука Левая
\.


--
-- TOC entry 5196 (class 0 OID 22522)
-- Dependencies: 240
-- Data for Name: smithing_materials; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.smithing_materials (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5198 (class 0 OID 22530)
-- Dependencies: 242
-- Data for Name: x_equipment_type_damage_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_equipment_type_damage_type (equipment_type_id, damage_type_id, damage_coef) FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5199 (class 0 OID 22537)
-- Dependencies: 243
-- Data for Name: x_hero_creature_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_hero_creature_type (hero_id, creature_type_id) FROM stdin;
\.


--
-- TOC entry 5200 (class 0 OID 22542)
-- Dependencies: 244
-- Data for Name: user_authorizations; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.user_authorizations (id, email, user_id, success, version, created_at, user_device_id, ip) FROM stdin;
166dea33-90ad-4614-847a-d3856731a681	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	f	1	2025-12-19 22:55:44.844376+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
a13f9f9d-3a07-481c-a1f3-264aedb92f66	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	f	1	2025-12-19 22:56:04.849562+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
74dd7b84-ed79-4eb3-97c5-84b71b4a2eb5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-19 22:56:34.849562+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
4f79d7a8-c7a1-4896-8326-64ca4f8bfef2	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:04:50.644044+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
9ee8120d-bb22-48aa-82ad-c143e3549067	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:07:05.505557+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
04b14bd1-5d84-46c3-a434-93e3abd9316b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:07:42.79347+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
3eebd86a-a994-499f-886a-df03bc23b326	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:10:57.703253+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
eb5b88ed-904d-478b-a839-dd64eda2e2d4	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:11:27.707658+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
bdf67461-7ddc-4002-88a1-fa690790e54c	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:13:17.698237+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
50df87b1-0f74-461f-924e-1c77e507c8f5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:13:44.752459+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
468b4b7e-1786-496e-b047-2fcab968af27	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:15:39.671995+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
284f47a7-9d8c-41c5-9ceb-dfdd225fc01f	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:19:46.866552+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
94192ddf-adeb-4023-a54f-dbd217b35842	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:20:56.76968+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f4602676-e5ef-4840-aea8-efdd2c2a8026	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:22:22.456088+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f4a91bb3-58dc-4d56-82f5-0d4b9012afcc	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:23:20.82107+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
1121435d-924e-4e37-92d2-e0c06de96835	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:24:30.735273+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
43192cf8-352c-4156-937f-f119608bac35	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:25:44.620405+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
c1e31780-465a-4e3c-8372-497442c011c4	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:35:34.529348+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
eada9055-f59d-49ff-8c04-fd3986fd3a45	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:35:54.525534+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
2b3b5b39-6c10-43cb-96f0-8ae60b73783d	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:45:04.527987+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
95e8c1ba-99e2-4d07-b259-6b9e748fb5c7	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:52:19.528408+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
e0fd014a-9062-439f-98ae-be274e6ac45b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:54:03.43298+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
6112be84-2e3d-4549-ad0e-a8546de803e3	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 20:12:18.347252+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
2e95118a-5ec5-462c-b8b5-039a5ddb7aa2	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 20:16:13.334472+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f557836a-bd0e-4981-9093-5936b4ff0909	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 20:18:28.33651+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
d7708120-908c-48c0-9078-9c990752ccaa	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 20:19:08.346365+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
ce7db772-9fe5-48d5-aee2-cc8bebe0c954	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:23:32.052081+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
b108e92f-22c3-41d4-8f53-1f0a822e2149	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:25:04.759962+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
c4a7ec3f-7ba2-40c9-8d10-5eda57da93b1	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:25:54.708643+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
5b0862ce-ff50-45ef-bda7-7980f8b39e8e	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:27:39.883947+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
4a3f5217-be04-44a0-af7f-206f01def6de	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:28:42.128968+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
28def4ab-d4f2-49d9-a949-f770ea20dcf6	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:29:02.064135+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f29e85f7-1c19-4c5c-a328-2cf765e1645a	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:29:56.739072+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
a165b86b-d8b2-4695-a120-df3d87ddc687	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:31:10.405265+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
64b4a800-21b8-42b3-99bc-af89e4b60a31	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:33:34.613595+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
d6bb5dab-595a-4f40-b218-0d48c7935219	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:36:43.582073+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f62f9ed7-24f8-420e-ba30-23212f54b544	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:38:38.483075+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
35f61632-9cf2-4c8e-8cff-60de0dd1bb82	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:39:41.543994+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
6f1c0a96-f8c5-4a0f-8444-52e7c1b52037	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 16:55:08.615268+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
97981dcd-13e6-4a98-bad2-089af5ea91af	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 16:55:28.561697+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
971618bf-6d30-4912-8a58-587056f3fbbf	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:16:28.596933+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
836cf87d-4180-4284-a264-109e869b9990	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:17:53.496633+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
cda12320-db0c-4406-ab94-8c08faeca416	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:18:48.491335+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
a8f27201-7dd1-4f02-8ccb-8a32efbb78a5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:19:13.49068+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
d812123b-b210-4640-997c-fadce6f51007	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:21:14.003477+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
6658b017-a677-4a6c-b527-d5384f235d6b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:21:28.905734+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
a68939e8-fa6f-4624-9652-64a91873db6b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:21:58.899557+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
dd4314e8-1ff9-4c35-81f4-2fd2fb8c3c78	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:22:08.895427+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
e9eadb65-e0ed-4b41-bb98-dde5e8d4381b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:22:28.891867+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
5eaa521e-8bfb-40a8-9763-625947c444f3	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:23:08.902228+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
7fb69044-5227-4b72-bc66-5660e6c5dfce	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:23:33.904234+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
31a0ac30-bec9-474d-bbf6-f4ec8f4dee87	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:28:33.874637+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
\.


--
-- TOC entry 5201 (class 0 OID 22553)
-- Dependencies: 245
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251218141532_Init	10.0.1
20251219010850_Fix1	10.0.1
20251219104853_Fix2	10.0.1
20251219125100_Fix3	10.0.1
20251219144649_Fix4	10.0.1
20251219145307_Fix5	10.0.1
20251220111640_Fix6	10.0.1
20251220140152_Fix7	10.0.1
20251221062947_Fix8	10.0.1
20251221115503_Fix9	10.0.1
20251221115727_Fix10	10.0.1
20251222005509_Fix11	10.0.1
20251222005528_Fix12	10.0.1
20251222012124_Fix13	10.0.1
20251222014603_Fix14	10.0.1
20251222032345_Fix15	10.0.1
20251222082512_Fix16	10.0.1
20251222142042_Fix17	10.0.1
\.


--
-- TOC entry 5202 (class 0 OID 22558)
-- Dependencies: 246
-- Data for Name: user_ban_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_ban_reasons (id, name) FROM stdin;
\.


--
-- TOC entry 5204 (class 0 OID 22566)
-- Dependencies: 248
-- Data for Name: user_bans; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_bans (id, user_id, version, created_at, updated_at, expires_at, user_ban_reason_id) FROM stdin;
\.


--
-- TOC entry 5205 (class 0 OID 22576)
-- Dependencies: 249
-- Data for Name: user_devices; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_devices (id, created_at, system_environment_user_name, time_zone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
47ee0275-bae7-c959-af87-f8b416a6cfd0	2025-12-19 22:55:44.844376+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
2f3585e2-e396-345a-b6d2-8d7079e5cdfc	2025-12-22 14:23:32.052081+08	adm-shumkov	480	30af10590f9f87bea6b087c950be35295e8eee95	B760 DS3H (Gigabyte Technology Co., Ltd.)	Desktop	Windows 10  (10.0.19045) 64bit	Intel(R) Core(TM) i9-14900K	32	65296	Intel(R) UHD Graphics 770	32648	t	Full
\.


--
-- TOC entry 5206 (class 0 OID 22583)
-- Dependencies: 250
-- Data for Name: users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.users (id, email, email_verified_at, password_hash, time_zone, is_admin, version, created_at, updated_at) FROM stdin;
113ae534-2310-40e3-a895-f3747ea976ca	SuperAdmin@mail.ru	\N	AQAAAAIAAYagAAAAEA+MLlU2KQvPMPQ0RCAWN2iQDElD1+zOUuwLjyXnOlBxsikuTAtogGdY3m5zDWnrXg==	\N	t	1	2025-12-03 10:45:43.769905+08	2025-12-03 10:45:43.769905+08
\.


--
-- TOC entry 5212 (class 0 OID 0)
-- Dependencies: 227
-- Name: base_equipments_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_equipments_id_seq', 2, true);


--
-- TOC entry 5213 (class 0 OID 0)
-- Dependencies: 229
-- Name: base_heroes_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_heroes_id_seq', 6, false);


--
-- TOC entry 5214 (class 0 OID 0)
-- Dependencies: 231
-- Name: creature_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.creature_types_id_seq', 9, false);


--
-- TOC entry 5215 (class 0 OID 0)
-- Dependencies: 233
-- Name: damage_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.damage_types_id_seq', 17, false);


--
-- TOC entry 5216 (class 0 OID 0)
-- Dependencies: 235
-- Name: equipment_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.equipment_types_id_seq', 24, true);


--
-- TOC entry 5217 (class 0 OID 0)
-- Dependencies: 237
-- Name: material_damage_percents_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.material_damage_percents_id_seq', 25, false);


--
-- TOC entry 5218 (class 0 OID 0)
-- Dependencies: 239
-- Name: slot_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slot_types_id_seq', 16, true);


--
-- TOC entry 5219 (class 0 OID 0)
-- Dependencies: 241
-- Name: smithing_materials_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.smithing_materials_id_seq', 19, true);


--
-- TOC entry 5220 (class 0 OID 0)
-- Dependencies: 247
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_ban_reasons_id_seq', 1, false);


--
-- TOC entry 4912 (class 2606 OID 22596)
-- Name: equipments equipments__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4940 (class 2606 OID 22598)
-- Name: heroes heroes__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4945 (class 2606 OID 22600)
-- Name: base_equipments base_equipments__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4948 (class 2606 OID 22602)
-- Name: base_heroes base_heroes__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_heroes
    ADD CONSTRAINT base_heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4951 (class 2606 OID 22604)
-- Name: creature_types creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.creature_types
    ADD CONSTRAINT creature_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4954 (class 2606 OID 22606)
-- Name: damage_types damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.damage_types
    ADD CONSTRAINT damage_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4957 (class 2606 OID 22608)
-- Name: equipment_types equipment_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4961 (class 2606 OID 22610)
-- Name: material_damage_percents material_damage_percents__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__pkey PRIMARY KEY (id);


--
-- TOC entry 4965 (class 2606 OID 22612)
-- Name: slot_types slot_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slot_types
    ADD CONSTRAINT slot_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4968 (class 2606 OID 22614)
-- Name: smithing_materials smithing_materials__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.smithing_materials
    ADD CONSTRAINT smithing_materials__pkey PRIMARY KEY (id);


--
-- TOC entry 4971 (class 2606 OID 22616)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__pkey PRIMARY KEY (equipment_type_id, damage_type_id);


--
-- TOC entry 4974 (class 2606 OID 22618)
-- Name: x_hero_creature_type x_hero_creature_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__pkey PRIMARY KEY (hero_id, creature_type_id);


--
-- TOC entry 4976 (class 2606 OID 22620)
-- Name: user_authorizations user_authorizations__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__pkey PRIMARY KEY (id);


--
-- TOC entry 4980 (class 2606 OID 22622)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4983 (class 2606 OID 22624)
-- Name: user_ban_reasons user_ban_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_ban_reasons
    ADD CONSTRAINT user_ban_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 4985 (class 2606 OID 22626)
-- Name: user_bans user_bans__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__pkey PRIMARY KEY (id);


--
-- TOC entry 4989 (class 2606 OID 22628)
-- Name: user_devices user_devices__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_devices
    ADD CONSTRAINT user_devices__pkey PRIMARY KEY (id);


--
-- TOC entry 4992 (class 2606 OID 22630)
-- Name: users users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users__pkey PRIMARY KEY (id);


--
-- TOC entry 4910 (class 1259 OID 22631)
-- Name: equipments__base_equipment_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__base_equipment_id__idx ON collection.equipments USING btree (base_equipment_id);


--
-- TOC entry 4913 (class 1259 OID 22632)
-- Name: equipments__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__user_id__idx ON collection.equipments USING btree (user_id);


--
-- TOC entry 4914 (class 1259 OID 22633)
-- Name: heroes__base_hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__base_hero_id__idx ON collection.heroes USING btree (base_hero_id);


--
-- TOC entry 4915 (class 1259 OID 22634)
-- Name: heroes__equipment10id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment10id__idx ON collection.heroes USING btree (equipment10id);


--
-- TOC entry 4916 (class 1259 OID 22635)
-- Name: heroes__equipment11id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment11id__idx ON collection.heroes USING btree (equipment11id);


--
-- TOC entry 4917 (class 1259 OID 22636)
-- Name: heroes__equipment12id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment12id__idx ON collection.heroes USING btree (equipment12id);


--
-- TOC entry 4918 (class 1259 OID 22637)
-- Name: heroes__equipment13id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment13id__idx ON collection.heroes USING btree (equipment13id);


--
-- TOC entry 4919 (class 1259 OID 22638)
-- Name: heroes__equipment14id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment14id__idx ON collection.heroes USING btree (equipment14id);


--
-- TOC entry 4920 (class 1259 OID 22639)
-- Name: heroes__equipment15id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment15id__idx ON collection.heroes USING btree (equipment15id);


--
-- TOC entry 4921 (class 1259 OID 22640)
-- Name: heroes__equipment16id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment16id__idx ON collection.heroes USING btree (equipment16id);


--
-- TOC entry 4922 (class 1259 OID 22641)
-- Name: heroes__equipment17id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment17id__idx ON collection.heroes USING btree (equipment17id);


--
-- TOC entry 4923 (class 1259 OID 22642)
-- Name: heroes__equipment18id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment18id__idx ON collection.heroes USING btree (equipment18id);


--
-- TOC entry 4924 (class 1259 OID 22643)
-- Name: heroes__equipment19id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment19id__idx ON collection.heroes USING btree (equipment19id);


--
-- TOC entry 4925 (class 1259 OID 22644)
-- Name: heroes__equipment1id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment1id__idx ON collection.heroes USING btree (equipment1id);


--
-- TOC entry 4926 (class 1259 OID 22645)
-- Name: heroes__equipment20id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment20id__idx ON collection.heroes USING btree (equipment20id);


--
-- TOC entry 4927 (class 1259 OID 22646)
-- Name: heroes__equipment21id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment21id__idx ON collection.heroes USING btree (equipment21id);


--
-- TOC entry 4928 (class 1259 OID 22647)
-- Name: heroes__equipment22id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment22id__idx ON collection.heroes USING btree (equipment22id);


--
-- TOC entry 4929 (class 1259 OID 22648)
-- Name: heroes__equipment23id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment23id__idx ON collection.heroes USING btree (equipment23id);


--
-- TOC entry 4930 (class 1259 OID 22649)
-- Name: heroes__equipment24id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment24id__idx ON collection.heroes USING btree (equipment24id);


--
-- TOC entry 4931 (class 1259 OID 22650)
-- Name: heroes__equipment2id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment2id__idx ON collection.heroes USING btree (equipment2id);


--
-- TOC entry 4932 (class 1259 OID 22651)
-- Name: heroes__equipment3id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment3id__idx ON collection.heroes USING btree (equipment3id);


--
-- TOC entry 4933 (class 1259 OID 22652)
-- Name: heroes__equipment4id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment4id__idx ON collection.heroes USING btree (equipment4id);


--
-- TOC entry 4934 (class 1259 OID 22653)
-- Name: heroes__equipment5id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment5id__idx ON collection.heroes USING btree (equipment5id);


--
-- TOC entry 4935 (class 1259 OID 22654)
-- Name: heroes__equipment6id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment6id__idx ON collection.heroes USING btree (equipment6id);


--
-- TOC entry 4936 (class 1259 OID 22655)
-- Name: heroes__equipment7id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment7id__idx ON collection.heroes USING btree (equipment7id);


--
-- TOC entry 4937 (class 1259 OID 22656)
-- Name: heroes__equipment8id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment8id__idx ON collection.heroes USING btree (equipment8id);


--
-- TOC entry 4938 (class 1259 OID 22657)
-- Name: heroes__equipment9id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment9id__idx ON collection.heroes USING btree (equipment9id);


--
-- TOC entry 4941 (class 1259 OID 22658)
-- Name: heroes__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__user_id__idx ON collection.heroes USING btree (user_id);


--
-- TOC entry 4942 (class 1259 OID 22659)
-- Name: base_equipments__equipment_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__equipment_type_id__idx ON game_data.base_equipments USING btree (equipment_type_id);


--
-- TOC entry 4943 (class 1259 OID 22660)
-- Name: base_equipments__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_equipments__name__idx ON game_data.base_equipments USING btree (name);


--
-- TOC entry 4946 (class 1259 OID 22661)
-- Name: base_heroes__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_heroes__name__idx ON game_data.base_heroes USING btree (name);


--
-- TOC entry 4949 (class 1259 OID 22662)
-- Name: creature_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX creature_types__name__idx ON game_data.creature_types USING btree (name);


--
-- TOC entry 4952 (class 1259 OID 22663)
-- Name: damage_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX damage_types__name__idx ON game_data.damage_types USING btree (name);


--
-- TOC entry 4955 (class 1259 OID 22664)
-- Name: equipment_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX equipment_types__name__idx ON game_data.equipment_types USING btree (name);


--
-- TOC entry 4958 (class 1259 OID 22665)
-- Name: equipment_types__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX equipment_types__slot_type_id__idx ON game_data.equipment_types USING btree (slot_type_id);


--
-- TOC entry 4959 (class 1259 OID 22666)
-- Name: material_damage_percents__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__damage_type_id__idx ON game_data.material_damage_percents USING btree (damage_type_id);


--
-- TOC entry 4962 (class 1259 OID 22667)
-- Name: material_damage_percents__smithing_materials_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__smithing_materials_id__idx ON game_data.material_damage_percents USING btree (smithing_materials_id);


--
-- TOC entry 4963 (class 1259 OID 22668)
-- Name: slot_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slot_types__name__idx ON game_data.slot_types USING btree (name);


--
-- TOC entry 4966 (class 1259 OID 22669)
-- Name: smithing_materials__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX smithing_materials__name__idx ON game_data.smithing_materials USING btree (name);


--
-- TOC entry 4969 (class 1259 OID 22670)
-- Name: x_equipment_type_damage_type__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_equipment_type_damage_type__damage_type_id__idx ON game_data.x_equipment_type_damage_type USING btree (damage_type_id);


--
-- TOC entry 4972 (class 1259 OID 22671)
-- Name: x_hero_creature_type__creature_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_hero_creature_type__creature_type_id__idx ON game_data.x_hero_creature_type USING btree (creature_type_id);


--
-- TOC entry 4977 (class 1259 OID 22672)
-- Name: user_authorizations__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX user_authorizations__user_device_id__idx ON logs.user_authorizations USING btree (user_device_id);


--
-- TOC entry 4978 (class 1259 OID 22673)
-- Name: user_authorizations__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX user_authorizations__user_id__idx ON logs.user_authorizations USING btree (user_id);


--
-- TOC entry 4981 (class 1259 OID 22674)
-- Name: user_ban_reasons__name__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_ban_reasons__name__idx ON server.user_ban_reasons USING btree (name);


--
-- TOC entry 4986 (class 1259 OID 22675)
-- Name: user_bans__user_ban_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_ban_reason_id__idx ON users.user_bans USING btree (user_ban_reason_id);


--
-- TOC entry 4987 (class 1259 OID 22676)
-- Name: user_bans__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_id__idx ON users.user_bans USING btree (user_id);


--
-- TOC entry 4990 (class 1259 OID 22677)
-- Name: users__email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX users__email__idx ON users.users USING btree (email);


--
-- TOC entry 4993 (class 2606 OID 22678)
-- Name: equipments equipments__base_equipment_id__base_equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__base_equipment_id__base_equipments__fkey FOREIGN KEY (base_equipment_id) REFERENCES game_data.base_equipments(id) ON DELETE CASCADE;


--
-- TOC entry 4994 (class 2606 OID 22683)
-- Name: equipments equipments__user_id__users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


--
-- TOC entry 4995 (class 2606 OID 22688)
-- Name: heroes heroes__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE CASCADE;


--
-- TOC entry 4996 (class 2606 OID 22693)
-- Name: heroes heroes__equipment10id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment10id__equipments__fkey FOREIGN KEY (equipment10id) REFERENCES collection.equipments(id);


--
-- TOC entry 4997 (class 2606 OID 22698)
-- Name: heroes heroes__equipment11id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment11id__equipments__fkey FOREIGN KEY (equipment11id) REFERENCES collection.equipments(id);


--
-- TOC entry 4998 (class 2606 OID 22703)
-- Name: heroes heroes__equipment12id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment12id__equipments__fkey FOREIGN KEY (equipment12id) REFERENCES collection.equipments(id);


--
-- TOC entry 4999 (class 2606 OID 22708)
-- Name: heroes heroes__equipment13id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment13id__equipments__fkey FOREIGN KEY (equipment13id) REFERENCES collection.equipments(id);


--
-- TOC entry 5000 (class 2606 OID 22713)
-- Name: heroes heroes__equipment14id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment14id__equipments__fkey FOREIGN KEY (equipment14id) REFERENCES collection.equipments(id);


--
-- TOC entry 5001 (class 2606 OID 22718)
-- Name: heroes heroes__equipment15id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment15id__equipments__fkey FOREIGN KEY (equipment15id) REFERENCES collection.equipments(id);


--
-- TOC entry 5002 (class 2606 OID 22723)
-- Name: heroes heroes__equipment16id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment16id__equipments__fkey FOREIGN KEY (equipment16id) REFERENCES collection.equipments(id);


--
-- TOC entry 5003 (class 2606 OID 22728)
-- Name: heroes heroes__equipment17id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment17id__equipments__fkey FOREIGN KEY (equipment17id) REFERENCES collection.equipments(id);


--
-- TOC entry 5004 (class 2606 OID 22733)
-- Name: heroes heroes__equipment18id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment18id__equipments__fkey FOREIGN KEY (equipment18id) REFERENCES collection.equipments(id);


--
-- TOC entry 5005 (class 2606 OID 22738)
-- Name: heroes heroes__equipment19id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment19id__equipments__fkey FOREIGN KEY (equipment19id) REFERENCES collection.equipments(id);


--
-- TOC entry 5006 (class 2606 OID 22743)
-- Name: heroes heroes__equipment1id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment1id__equipments__fkey FOREIGN KEY (equipment1id) REFERENCES collection.equipments(id);


--
-- TOC entry 5007 (class 2606 OID 22748)
-- Name: heroes heroes__equipment20id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment20id__equipments__fkey FOREIGN KEY (equipment20id) REFERENCES collection.equipments(id);


--
-- TOC entry 5008 (class 2606 OID 22753)
-- Name: heroes heroes__equipment21id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment21id__equipments__fkey FOREIGN KEY (equipment21id) REFERENCES collection.equipments(id);


--
-- TOC entry 5009 (class 2606 OID 22758)
-- Name: heroes heroes__equipment22id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment22id__equipments__fkey FOREIGN KEY (equipment22id) REFERENCES collection.equipments(id);


--
-- TOC entry 5010 (class 2606 OID 22763)
-- Name: heroes heroes__equipment23id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment23id__equipments__fkey FOREIGN KEY (equipment23id) REFERENCES collection.equipments(id);


--
-- TOC entry 5011 (class 2606 OID 22768)
-- Name: heroes heroes__equipment24id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment24id__equipments__fkey FOREIGN KEY (equipment24id) REFERENCES collection.equipments(id);


--
-- TOC entry 5012 (class 2606 OID 22773)
-- Name: heroes heroes__equipment2id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment2id__equipments__fkey FOREIGN KEY (equipment2id) REFERENCES collection.equipments(id);


--
-- TOC entry 5013 (class 2606 OID 22778)
-- Name: heroes heroes__equipment3id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment3id__equipments__fkey FOREIGN KEY (equipment3id) REFERENCES collection.equipments(id);


--
-- TOC entry 5014 (class 2606 OID 22783)
-- Name: heroes heroes__equipment4id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment4id__equipments__fkey FOREIGN KEY (equipment4id) REFERENCES collection.equipments(id);


--
-- TOC entry 5015 (class 2606 OID 22788)
-- Name: heroes heroes__equipment5id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment5id__equipments__fkey FOREIGN KEY (equipment5id) REFERENCES collection.equipments(id);


--
-- TOC entry 5016 (class 2606 OID 22793)
-- Name: heroes heroes__equipment6id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment6id__equipments__fkey FOREIGN KEY (equipment6id) REFERENCES collection.equipments(id);


--
-- TOC entry 5017 (class 2606 OID 22798)
-- Name: heroes heroes__equipment7id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment7id__equipments__fkey FOREIGN KEY (equipment7id) REFERENCES collection.equipments(id);


--
-- TOC entry 5018 (class 2606 OID 22803)
-- Name: heroes heroes__equipment8id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment8id__equipments__fkey FOREIGN KEY (equipment8id) REFERENCES collection.equipments(id);


--
-- TOC entry 5019 (class 2606 OID 22808)
-- Name: heroes heroes__equipment9id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment9id__equipments__fkey FOREIGN KEY (equipment9id) REFERENCES collection.equipments(id);


--
-- TOC entry 5020 (class 2606 OID 22813)
-- Name: heroes heroes__user_id__users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


--
-- TOC entry 5021 (class 2606 OID 22818)
-- Name: base_equipments base_equipments__equipment_type_id__equipment_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__equipment_type_id__equipment_types__fkey FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE CASCADE;


--
-- TOC entry 5022 (class 2606 OID 22823)
-- Name: equipment_types equipment_types__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE CASCADE;


--
-- TOC entry 5023 (class 2606 OID 22828)
-- Name: material_damage_percents material_damage_percents__damage_type_id__damage_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__damage_type_id__damage_types__fkey FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE CASCADE;


--
-- TOC entry 5024 (class 2606 OID 22833)
-- Name: material_damage_percents material_damage_percents__smithing_materials_id__smithing_mater; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__smithing_materials_id__smithing_mater FOREIGN KEY (smithing_materials_id) REFERENCES game_data.smithing_materials(id) ON DELETE CASCADE;


--
-- TOC entry 5025 (class 2606 OID 22838)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__damage_type_id__damage_types__fke; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__damage_type_id__damage_types__fke FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE CASCADE;


--
-- TOC entry 5026 (class 2606 OID 22843)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__equipment_type_id__equipment_type; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__equipment_type_id__equipment_type FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE CASCADE;


--
-- TOC entry 5027 (class 2606 OID 22848)
-- Name: x_hero_creature_type x_hero_creature_type__creature_type_id__creature_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__creature_type_id__creature_types__fkey FOREIGN KEY (creature_type_id) REFERENCES game_data.creature_types(id) ON DELETE CASCADE;


--
-- TOC entry 5028 (class 2606 OID 22853)
-- Name: x_hero_creature_type x_hero_creature_type__hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__hero_id__base_heroes__fkey FOREIGN KEY (hero_id) REFERENCES game_data.base_heroes(id) ON DELETE CASCADE;


--
-- TOC entry 5029 (class 2606 OID 22858)
-- Name: user_authorizations user_authorizations__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id);


--
-- TOC entry 5030 (class 2606 OID 22863)
-- Name: user_authorizations user_authorizations__user_id__users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


--
-- TOC entry 5031 (class 2606 OID 22868)
-- Name: user_bans user_bans__user_ban_reason_id__user_ban_reasons__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_ban_reason_id__user_ban_reasons__fkey FOREIGN KEY (user_ban_reason_id) REFERENCES server.user_ban_reasons(id) ON DELETE CASCADE;


--
-- TOC entry 5032 (class 2606 OID 22873)
-- Name: user_bans user_bans__user_id__users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


-- Completed on 2025-12-22 22:29:58

--
-- PostgreSQL database dump complete
--

\unrestrict jczgBPjSHYJLOVkDL4M6dx6ROgFZUsTNDVKsEbyWPIFLOxRin6bFIvGdVTrI10R

