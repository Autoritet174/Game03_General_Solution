--
-- PostgreSQL database dump
--

\restrict W9YaZbPQ6EJiJEkXOe56iyYzaYfEbbIED7HBRodFKjk0YeGhGLaxnYfVkW2bSXa

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-12-18 22:43:29

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_ban_reason_id__user_ban_reasons__fkey;
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__creature_type_id__creature_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__equipment_type_id__equipment_type;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__damage_type_id__damage_types__fke;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__smithing_materials_id__smithing_mater;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__damage_type_id__damage_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__equipment_type_id__equipment_types__fkey;
DROP INDEX IF EXISTS users.users__email__idx;
DROP INDEX IF EXISTS users.user_bans__user_id__idx;
DROP INDEX IF EXISTS users.user_bans__user_ban_reason_id__idx;
DROP INDEX IF EXISTS server.user_ban_reasons__name__idx;
DROP INDEX IF EXISTS logs.user_authorizations__user_id__idx;
DROP INDEX IF EXISTS game_data.x_hero_creature_type__creature_type_id__idx;
DROP INDEX IF EXISTS game_data.x_equipment_type_damage_type__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.smithing_materials__name__idx;
DROP INDEX IF EXISTS game_data.slot_types__name__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__smithing_materials_id__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__name__idx;
DROP INDEX IF EXISTS game_data.damage_types__name__idx;
DROP INDEX IF EXISTS game_data.creature_types__name__idx;
DROP INDEX IF EXISTS game_data.base_heroes__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__equipment_type_id__idx;
ALTER TABLE IF EXISTS ONLY users.users DROP CONSTRAINT IF EXISTS users__pkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__pkey;
ALTER TABLE IF EXISTS ONLY server.user_ban_reasons DROP CONSTRAINT IF EXISTS user_ban_reasons__pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.smithing_materials DROP CONSTRAINT IF EXISTS smithing_materials__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slot_types DROP CONSTRAINT IF EXISTS slot_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__pkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.damage_types DROP CONSTRAINT IF EXISTS damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.creature_types DROP CONSTRAINT IF EXISTS creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_heroes DROP CONSTRAINT IF EXISTS base_heroes__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__pkey;
DROP TABLE IF EXISTS users.users;
DROP TABLE IF EXISTS users.user_bans;
DROP TABLE IF EXISTS server.user_ban_reasons;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS logs.user_authorizations;
DROP TABLE IF EXISTS game_data.x_hero_creature_type;
DROP TABLE IF EXISTS game_data.x_equipment_type_damage_type;
DROP TABLE IF EXISTS game_data.smithing_materials;
DROP TABLE IF EXISTS game_data.slot_types;
DROP TABLE IF EXISTS game_data.material_damage_percents;
DROP TABLE IF EXISTS game_data.equipment_types;
DROP TABLE IF EXISTS game_data.damage_types;
DROP TABLE IF EXISTS game_data.creature_types;
DROP TABLE IF EXISTS game_data.base_heroes;
DROP TABLE IF EXISTS game_data.base_equipments;
DROP SCHEMA IF EXISTS users;
DROP SCHEMA IF EXISTS server;
DROP SCHEMA IF EXISTS logs;
DROP SCHEMA IF EXISTS game_data;
--
-- TOC entry 6 (class 2615 OID 21218)
-- Name: game_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA game_data;


--
-- TOC entry 7 (class 2615 OID 21219)
-- Name: logs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA logs;


--
-- TOC entry 8 (class 2615 OID 21220)
-- Name: server; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA server;


--
-- TOC entry 9 (class 2615 OID 21221)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 245 (class 1259 OID 21404)
-- Name: base_equipments; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_equipments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    damage character varying(255),
    equipment_type_id integer NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 21403)
-- Name: base_equipments_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_equipments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_equipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 225 (class 1259 OID 21223)
-- Name: base_heroes; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_heroes (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    health character varying(255) NOT NULL,
    damage character varying(255) NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 21222)
-- Name: base_heroes_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_heroes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_heroes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 227 (class 1259 OID 21240)
-- Name: creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.creature_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 21239)
-- Name: creature_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.creature_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.creature_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 229 (class 1259 OID 21248)
-- Name: damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.damage_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255),
    dev_hint_ru text
);


--
-- TOC entry 228 (class 1259 OID 21247)
-- Name: damage_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.damage_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.damage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 239 (class 1259 OID 21319)
-- Name: equipment_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.equipment_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255) NOT NULL,
    mass_physical integer DEFAULT 0 NOT NULL,
    mass_magical integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    attack character varying(255),
    spend_action_points integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 21318)
-- Name: equipment_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.equipment_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.equipment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 241 (class 1259 OID 21346)
-- Name: material_damage_percents; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.material_damage_percents (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 240 (class 1259 OID 21345)
-- Name: material_damage_percents_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.material_damage_percents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.material_damage_percents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 231 (class 1259 OID 21258)
-- Name: slot_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slot_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 230 (class 1259 OID 21257)
-- Name: slot_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slot_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slot_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 233 (class 1259 OID 21268)
-- Name: smithing_materials; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.smithing_materials (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 232 (class 1259 OID 21267)
-- Name: smithing_materials_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.smithing_materials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.smithing_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 246 (class 1259 OID 21422)
-- Name: x_equipment_type_damage_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_equipment_type_damage_type (
    equipment_type_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    damage_coef integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 21301)
-- Name: x_hero_creature_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_hero_creature_type (
    hero_id integer NOT NULL,
    creature_type_id integer NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 21365)
-- Name: user_authorizations; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.user_authorizations (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    user_id uuid,
    success boolean NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 21211)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 21278)
-- Name: user_ban_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_ban_reasons (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 21277)
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_ban_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_ban_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 243 (class 1259 OID 21381)
-- Name: user_bans; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_bans (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    user_ban_reason_id integer NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 21287)
-- Name: users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.users (
    id uuid NOT NULL,
    email character varying(255),
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    time_zone character varying(255),
    is_admin boolean DEFAULT false NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 5119 (class 0 OID 21404)
-- Dependencies: 245
-- Data for Name: base_equipments; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_equipments (id, name, rarity, is_unique, damage, equipment_type_id) FROM stdin;
\.


--
-- TOC entry 5099 (class 0 OID 21223)
-- Dependencies: 225
-- Data for Name: base_heroes; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_heroes (id, name, rarity, is_unique, health, damage, main_stat) FROM stdin;
1	Warrior	1	f	16d24_200	4d21_44	0
2	Huntress	1	f	10d28_145	5d21_55	0
3	Hammerman	1	f	11d39_220	3d25_39	0
4	Rogue	1	f	15d21_165	4d23_48	0
5	Battle orc	1	f	16d58_472	4d21_44	0
\.


--
-- TOC entry 5101 (class 0 OID 21240)
-- Dependencies: 227
-- Data for Name: creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.creature_types (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5103 (class 0 OID 21248)
-- Dependencies: 229
-- Data for Name: damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.damage_types (id, name, name_ru, dev_hint_ru) FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."
11	Light	Световой	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."
\.


--
-- TOC entry 5113 (class 0 OID 21319)
-- Dependencies: 239
-- Data for Name: equipment_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.equipment_types (id, name, name_ru, mass_physical, mass_magical, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, attack, spend_action_points) FROM stdin;
9	War Fan	Боевой веер	800	0	11	t	f	5d3_10	0
10	Scimitar	Скимитар	1200	0	11	t	f	6d4_15	0
11	Katana	Катана	1100	0	11	t	f	7d3_14	0
14	Morning Star	Моргенштерн	5000	0	11	t	f	1d123_62	0
1	Sword	Меч	1600	0	11	t	f	8d4_20	0
18	Bow	Лук	960	0	11	t	f	4d2_6	0
21	Pike	Пика	2800	0	11	t	f	24d2_36	0
20	Rapier	Рапира	850	0	11	t	f	8d2_12	0
19	Trident	Трезубец	3400	0	11	t	f	28d2_42	0
17	Crossbow	Арбалет	3200	0	11	t	f	14d2_21	0
7	Shuriken	Сюрикен	180	0	11	t	f	6d2_9	0
22	Spear	Копьё	2200	0	11	t	f	20d2_30	0
24	Dagger	Кинжал	400	0	11	t	f	4d2_6	0
12	Yataghan	Ятаган	1000	0	11	t	f	6d3_12	0
13	Sabre	Сабля	1100	0	11	t	f	7d3_14	0
15	Warhammer	Боевой молот	6200	0	11	t	f	1d153_77	0
16	Mace	Булава	3000	0	11	t	f	1d73_37	0
3	Halberd	Алебарда	4400	0	11	t	f	4d27_56	0
5	Poleaxe	Секира	4000	0	11	t	f	4d24_50	0
23	Broadaxe	Широкий топор	5200	0	11	t	f	4d32_66	0
2	Axe	Топор	2800	0	11	t	f	4d17_36	0
4	Berdysh	Бердыш	3800	0	11	t	f	4d23_48	0
6	Chakram	Чакрам	350	0	11	t	f	5d3_10	0
8	Scythe	Коса	3200	0	11	t	f	5d3_10	0
\.


--
-- TOC entry 5115 (class 0 OID 21346)
-- Dependencies: 241
-- Data for Name: material_damage_percents; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.material_damage_percents (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5105 (class 0 OID 21258)
-- Dependencies: 231
-- Data for Name: slot_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slot_types (id, name, name_ru) FROM stdin;
1	Head	Голова
2	Shoulders	Наплечники
3	Chest	Нагрудник
4	Hands	Руки
5	Legs	Поножи
6	Feet	Ступни
7	Waist	Пояс
8	Wrist	Запястья
9	Back	Спина
10	Bracelet	Браслет
11	HandLeftRight	Рука Левая Правая
12	Ring	Кольцо
13	Earring	Серьги
14	Trinket	Аксессуар
\.


--
-- TOC entry 5107 (class 0 OID 21268)
-- Dependencies: 233
-- Data for Name: smithing_materials; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.smithing_materials (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5120 (class 0 OID 21422)
-- Dependencies: 246
-- Data for Name: x_equipment_type_damage_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_equipment_type_damage_type (equipment_type_id, damage_type_id, damage_coef) FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5111 (class 0 OID 21301)
-- Dependencies: 237
-- Data for Name: x_hero_creature_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_hero_creature_type (hero_id, creature_type_id) FROM stdin;
\.


--
-- TOC entry 5116 (class 0 OID 21365)
-- Dependencies: 242
-- Data for Name: user_authorizations; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.user_authorizations (id, email, user_id, success, version, created_at) FROM stdin;
\.


--
-- TOC entry 5097 (class 0 OID 21211)
-- Dependencies: 223
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251218141532_Init	10.0.1
\.


--
-- TOC entry 5109 (class 0 OID 21278)
-- Dependencies: 235
-- Data for Name: user_ban_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_ban_reasons (id, name) FROM stdin;
\.


--
-- TOC entry 5117 (class 0 OID 21381)
-- Dependencies: 243
-- Data for Name: user_bans; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_bans (id, user_id, version, created_at, updated_at, expires_at, user_ban_reason_id) FROM stdin;
\.


--
-- TOC entry 5110 (class 0 OID 21287)
-- Dependencies: 236
-- Data for Name: users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.users (id, email, email_verified_at, password_hash, time_zone, is_admin, version, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 5126 (class 0 OID 0)
-- Dependencies: 244
-- Name: base_equipments_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_equipments_id_seq', 1, false);


--
-- TOC entry 5127 (class 0 OID 0)
-- Dependencies: 224
-- Name: base_heroes_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_heroes_id_seq', 6, false);


--
-- TOC entry 5128 (class 0 OID 0)
-- Dependencies: 226
-- Name: creature_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.creature_types_id_seq', 9, false);


--
-- TOC entry 5129 (class 0 OID 0)
-- Dependencies: 228
-- Name: damage_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.damage_types_id_seq', 17, false);


--
-- TOC entry 5130 (class 0 OID 0)
-- Dependencies: 238
-- Name: equipment_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.equipment_types_id_seq', 24, true);


--
-- TOC entry 5131 (class 0 OID 0)
-- Dependencies: 240
-- Name: material_damage_percents_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.material_damage_percents_id_seq', 25, false);


--
-- TOC entry 5132 (class 0 OID 0)
-- Dependencies: 230
-- Name: slot_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slot_types_id_seq', 14, true);


--
-- TOC entry 5133 (class 0 OID 0)
-- Dependencies: 232
-- Name: smithing_materials_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.smithing_materials_id_seq', 19, true);


--
-- TOC entry 5134 (class 0 OID 0)
-- Dependencies: 234
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_ban_reasons_id_seq', 1, false);


--
-- TOC entry 4935 (class 2606 OID 21416)
-- Name: base_equipments base_equipments__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4895 (class 2606 OID 21238)
-- Name: base_heroes base_heroes__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_heroes
    ADD CONSTRAINT base_heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4898 (class 2606 OID 21246)
-- Name: creature_types creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.creature_types
    ADD CONSTRAINT creature_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4901 (class 2606 OID 21256)
-- Name: damage_types damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.damage_types
    ADD CONSTRAINT damage_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4919 (class 2606 OID 21339)
-- Name: equipment_types equipment_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4923 (class 2606 OID 21354)
-- Name: material_damage_percents material_damage_percents__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__pkey PRIMARY KEY (id);


--
-- TOC entry 4904 (class 2606 OID 21266)
-- Name: slot_types slot_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slot_types
    ADD CONSTRAINT slot_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4907 (class 2606 OID 21276)
-- Name: smithing_materials smithing_materials__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.smithing_materials
    ADD CONSTRAINT smithing_materials__pkey PRIMARY KEY (id);


--
-- TOC entry 4938 (class 2606 OID 21430)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__pkey PRIMARY KEY (equipment_type_id, damage_type_id);


--
-- TOC entry 4916 (class 2606 OID 21307)
-- Name: x_hero_creature_type x_hero_creature_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__pkey PRIMARY KEY (hero_id, creature_type_id);


--
-- TOC entry 4926 (class 2606 OID 21375)
-- Name: user_authorizations user_authorizations__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__pkey PRIMARY KEY (id);


--
-- TOC entry 4892 (class 2606 OID 21217)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4910 (class 2606 OID 21286)
-- Name: user_ban_reasons user_ban_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_ban_reasons
    ADD CONSTRAINT user_ban_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 4929 (class 2606 OID 21392)
-- Name: user_bans user_bans__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__pkey PRIMARY KEY (id);


--
-- TOC entry 4913 (class 2606 OID 21300)
-- Name: users users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users__pkey PRIMARY KEY (id);


--
-- TOC entry 4932 (class 1259 OID 21441)
-- Name: base_equipments__equipment_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__equipment_type_id__idx ON game_data.base_equipments USING btree (equipment_type_id);


--
-- TOC entry 4933 (class 1259 OID 21442)
-- Name: base_equipments__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_equipments__name__idx ON game_data.base_equipments USING btree (name);


--
-- TOC entry 4893 (class 1259 OID 21443)
-- Name: base_heroes__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_heroes__name__idx ON game_data.base_heroes USING btree (name);


--
-- TOC entry 4896 (class 1259 OID 21444)
-- Name: creature_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX creature_types__name__idx ON game_data.creature_types USING btree (name);


--
-- TOC entry 4899 (class 1259 OID 21445)
-- Name: damage_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX damage_types__name__idx ON game_data.damage_types USING btree (name);


--
-- TOC entry 4917 (class 1259 OID 21446)
-- Name: equipment_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX equipment_types__name__idx ON game_data.equipment_types USING btree (name);


--
-- TOC entry 4920 (class 1259 OID 21447)
-- Name: equipment_types__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX equipment_types__slot_type_id__idx ON game_data.equipment_types USING btree (slot_type_id);


--
-- TOC entry 4921 (class 1259 OID 21448)
-- Name: material_damage_percents__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__damage_type_id__idx ON game_data.material_damage_percents USING btree (damage_type_id);


--
-- TOC entry 4924 (class 1259 OID 21449)
-- Name: material_damage_percents__smithing_materials_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__smithing_materials_id__idx ON game_data.material_damage_percents USING btree (smithing_materials_id);


--
-- TOC entry 4902 (class 1259 OID 21450)
-- Name: slot_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slot_types__name__idx ON game_data.slot_types USING btree (name);


--
-- TOC entry 4905 (class 1259 OID 21451)
-- Name: smithing_materials__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX smithing_materials__name__idx ON game_data.smithing_materials USING btree (name);


--
-- TOC entry 4936 (class 1259 OID 21457)
-- Name: x_equipment_type_damage_type__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_equipment_type_damage_type__damage_type_id__idx ON game_data.x_equipment_type_damage_type USING btree (damage_type_id);


--
-- TOC entry 4914 (class 1259 OID 21458)
-- Name: x_hero_creature_type__creature_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_hero_creature_type__creature_type_id__idx ON game_data.x_hero_creature_type USING btree (creature_type_id);


--
-- TOC entry 4927 (class 1259 OID 21452)
-- Name: user_authorizations__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX user_authorizations__user_id__idx ON logs.user_authorizations USING btree (user_id);


--
-- TOC entry 4908 (class 1259 OID 21453)
-- Name: user_ban_reasons__name__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_ban_reasons__name__idx ON server.user_ban_reasons USING btree (name);


--
-- TOC entry 4930 (class 1259 OID 21454)
-- Name: user_bans__user_ban_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_ban_reason_id__idx ON users.user_bans USING btree (user_ban_reason_id);


--
-- TOC entry 4931 (class 1259 OID 21455)
-- Name: user_bans__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_id__idx ON users.user_bans USING btree (user_id);


--
-- TOC entry 4911 (class 1259 OID 21456)
-- Name: users__email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX users__email__idx ON users.users USING btree (email);


--
-- TOC entry 4947 (class 2606 OID 21417)
-- Name: base_equipments base_equipments__equipment_type_id__equipment_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__equipment_type_id__equipment_types__fkey FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE CASCADE;


--
-- TOC entry 4941 (class 2606 OID 21340)
-- Name: equipment_types equipment_types__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE CASCADE;


--
-- TOC entry 4942 (class 2606 OID 21355)
-- Name: material_damage_percents material_damage_percents__damage_type_id__damage_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__damage_type_id__damage_types__fkey FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE CASCADE;


--
-- TOC entry 4943 (class 2606 OID 21360)
-- Name: material_damage_percents material_damage_percents__smithing_materials_id__smithing_mater; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__smithing_materials_id__smithing_mater FOREIGN KEY (smithing_materials_id) REFERENCES game_data.smithing_materials(id) ON DELETE CASCADE;


--
-- TOC entry 4948 (class 2606 OID 21431)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__damage_type_id__damage_types__fke; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__damage_type_id__damage_types__fke FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE CASCADE;


--
-- TOC entry 4949 (class 2606 OID 21436)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__equipment_type_id__equipment_type; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__equipment_type_id__equipment_type FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE CASCADE;


--
-- TOC entry 4939 (class 2606 OID 21308)
-- Name: x_hero_creature_type x_hero_creature_type__creature_type_id__creature_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__creature_type_id__creature_types__fkey FOREIGN KEY (creature_type_id) REFERENCES game_data.creature_types(id) ON DELETE CASCADE;


--
-- TOC entry 4940 (class 2606 OID 21313)
-- Name: x_hero_creature_type x_hero_creature_type__hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__hero_id__base_heroes__fkey FOREIGN KEY (hero_id) REFERENCES game_data.base_heroes(id) ON DELETE CASCADE;


--
-- TOC entry 4944 (class 2606 OID 21376)
-- Name: user_authorizations user_authorizations__user_id__users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


--
-- TOC entry 4945 (class 2606 OID 21393)
-- Name: user_bans user_bans__user_ban_reason_id__user_ban_reasons__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_ban_reason_id__user_ban_reasons__fkey FOREIGN KEY (user_ban_reason_id) REFERENCES server.user_ban_reasons(id) ON DELETE CASCADE;


--
-- TOC entry 4946 (class 2606 OID 21398)
-- Name: user_bans user_bans__user_id__users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


-- Completed on 2025-12-18 22:43:29

--
-- PostgreSQL database dump complete
--

\unrestrict W9YaZbPQ6EJiJEkXOe56iyYzaYfEbbIED7HBRodFKjk0YeGhGLaxnYfVkW2bSXa

