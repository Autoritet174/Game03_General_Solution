--
-- PostgreSQL database dump
--

\restrict IOOjuJNJXtyDoe974W9SKI5VQQbjdowIwSAScDLCn8wlnmYzVDpuSEx28C99toC

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-12-12 15:56:30

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType__HeroId__Heroes__fkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType__CreatureTypeId__CreatureTypes__fkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_EquipmentType_DamageType" DROP CONSTRAINT IF EXISTS "X_EquipmentType_DamageType__EquipmentTypeId__EquipmentTypes__fk";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_EquipmentType_DamageType" DROP CONSTRAINT IF EXISTS "X_EquipmentType_DamageType__DamageTypeId__DamageTypes__fkey";
ALTER TABLE IF EXISTS ONLY _equipment."Weapons" DROP CONSTRAINT IF EXISTS "Weapons__WeaponTypeId__EquipmentTypes__fkey";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercents" DROP CONSTRAINT IF EXISTS "MaterialDamagePercents__SmithingMaterialsId__SmithingMaterials_";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercents" DROP CONSTRAINT IF EXISTS "MaterialDamagePercents__DamageTypeId__DamageTypes__fkey";
ALTER TABLE IF EXISTS ONLY __lists."EquipmentTypes" DROP CONSTRAINT IF EXISTS "EquipmentTypes__SlotTypeId__SlotTypes__fkey";
DROP TRIGGER IF EXISTS set_timestamps_trigger ON _main.heroes;
DROP TRIGGER IF EXISTS set_timestamps_trigger ON _main.creature_types;
DROP INDEX IF EXISTS "x_Cross"."X_Hero_CreatureType__HeroId__idx";
DROP INDEX IF EXISTS "x_Cross"."X_Hero_CreatureType__CreatureTypeId__idx";
DROP INDEX IF EXISTS "x_Cross"."X_EquipmentType_DamageType__EquipmentTypeId__idx";
DROP INDEX IF EXISTS "x_Cross"."X_EquipmentType_DamageType__DamageTypeId__idx";
DROP INDEX IF EXISTS _main.heroes_name_idx;
DROP INDEX IF EXISTS _main.creature_types_name_idx;
DROP INDEX IF EXISTS _heroes."Heroes__Name__idx";
DROP INDEX IF EXISTS _equipment."Weapons__WeaponTypeId__idx";
DROP INDEX IF EXISTS _equipment."Weapons__Name__idx";
DROP INDEX IF EXISTS __lists."SmithingMaterials__Name__idx";
DROP INDEX IF EXISTS __lists."SlotTypes__Name__idx";
DROP INDEX IF EXISTS __lists."MaterialDamagePercents__SmithingMaterialsId__idx";
DROP INDEX IF EXISTS __lists."MaterialDamagePercents__DamageTypeId__idx";
DROP INDEX IF EXISTS __lists."EquipmentTypes__SlotTypeId__idx";
DROP INDEX IF EXISTS __lists."EquipmentTypes__Name__idx";
DROP INDEX IF EXISTS __lists."DamageTypes__Name__idx";
DROP INDEX IF EXISTS __lists."CreatureTypes__Name__idx";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType__pkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_EquipmentType_DamageType" DROP CONSTRAINT IF EXISTS "X_EquipmentType_DamageType__pkey";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY _main.heroes DROP CONSTRAINT IF EXISTS heroes_pkey;
ALTER TABLE IF EXISTS ONLY _main.creature_types DROP CONSTRAINT IF EXISTS creature_types_pkey;
ALTER TABLE IF EXISTS ONLY _heroes."Heroes" DROP CONSTRAINT IF EXISTS "Heroes__pkey";
ALTER TABLE IF EXISTS ONLY _equipment."Weapons" DROP CONSTRAINT IF EXISTS "Weapons__pkey";
ALTER TABLE IF EXISTS ONLY __lists."SmithingMaterials" DROP CONSTRAINT IF EXISTS "SmithingMaterials__pkey";
ALTER TABLE IF EXISTS ONLY __lists."SlotTypes" DROP CONSTRAINT IF EXISTS "SlotTypes__pkey";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercents" DROP CONSTRAINT IF EXISTS "MaterialDamagePercents__pkey";
ALTER TABLE IF EXISTS ONLY __lists."EquipmentTypes" DROP CONSTRAINT IF EXISTS "EquipmentTypes__pkey";
ALTER TABLE IF EXISTS ONLY __lists."DamageTypes" DROP CONSTRAINT IF EXISTS "DamageTypes__pkey";
ALTER TABLE IF EXISTS ONLY __lists."CreatureTypes" DROP CONSTRAINT IF EXISTS "CreatureTypes__pkey";
DROP TABLE IF EXISTS "x_Cross"."X_Hero_CreatureType";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS _main.heroes;
DROP TABLE IF EXISTS _main.creature_types;
DROP TABLE IF EXISTS _heroes."Heroes";
DROP TABLE IF EXISTS _equipment."Weapons";
DROP VIEW IF EXISTS __lists."v_WeaponTypes";
DROP TABLE IF EXISTS "x_Cross"."X_EquipmentType_DamageType";
DROP TABLE IF EXISTS __lists."SmithingMaterials";
DROP TABLE IF EXISTS __lists."SlotTypes";
DROP TABLE IF EXISTS __lists."MaterialDamagePercents";
DROP TABLE IF EXISTS __lists."EquipmentTypes";
DROP TABLE IF EXISTS __lists."DamageTypes";
DROP TABLE IF EXISTS __lists."CreatureTypes";
DROP FUNCTION IF EXISTS public.set_timestamp();
DROP PROCEDURE IF EXISTS _main.add_hero_creature_type(IN p_hero_name text, IN p_creature_type_name text);
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP SCHEMA IF EXISTS "x_Cross";
DROP SCHEMA IF EXISTS _main;
DROP SCHEMA IF EXISTS _heroes;
DROP SCHEMA IF EXISTS _equipment;
DROP SCHEMA IF EXISTS __lists;
--
-- TOC entry 7 (class 2615 OID 42279)
-- Name: __lists; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA __lists;


--
-- TOC entry 8 (class 2615 OID 42280)
-- Name: _equipment; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _equipment;


--
-- TOC entry 9 (class 2615 OID 42281)
-- Name: _heroes; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _heroes;


--
-- TOC entry 10 (class 2615 OID 42282)
-- Name: _main; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _main;


--
-- TOC entry 11 (class 2615 OID 42283)
-- Name: x_Cross; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "x_Cross";


--
-- TOC entry 2 (class 3079 OID 42285)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 5072 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 268 (class 1255 OID 42296)
-- Name: add_hero_creature_type(text, text); Type: PROCEDURE; Schema: _main; Owner: -
--

CREATE PROCEDURE _main.add_hero_creature_type(IN p_hero_name text, IN p_creature_type_name text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_hero_id         uuid;
    v_creature_type_id uuid;
    v_link_exists     boolean;
BEGIN
    -- Получаем ID героя
    SELECT id INTO v_hero_id
    FROM _main.heroes
    WHERE name ILIKE p_hero_name
    LIMIT 1;

    IF v_hero_id IS NULL THEN
        RAISE EXCEPTION 'Ошибка: Герой "%" не найден', p_hero_name;
    END IF;

    -- Получаем ID типа существа
    SELECT id INTO v_creature_type_id
    FROM _main.creature_types
    WHERE name ILIKE p_creature_type_name
    LIMIT 1;

    IF v_creature_type_id IS NULL THEN
        RAISE EXCEPTION 'Ошибка: Тип существа "%" не найден', p_creature_type_name;
    END IF;

    -- Проверяем существование связи
    SELECT EXISTS (
        SELECT 1
        FROM xcross.x_hero_creature_type
        WHERE hero_id = v_hero_id
          AND creature_type_id = v_creature_type_id
    ) INTO v_link_exists;

    -- Добавляем связь если её нет
    IF NOT v_link_exists THEN
        INSERT INTO xcross.x_hero_creature_type (hero_id, creature_type_id)
        VALUES (v_hero_id, v_creature_type_id);

        RAISE NOTICE 'Успех: Связь добавлена - герой "%" → тип "%"', p_hero_name, p_creature_type_name;
    ELSE
        RAISE NOTICE 'Информация: Связь уже существует - герой "%" → тип "%"', p_hero_name, p_creature_type_name;
    END IF;
END;
$$;


--
-- TOC entry 269 (class 1255 OID 42297)
-- Name: set_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.created_at := COALESCE(NEW.created_at, NOW());
        NEW.updated_at := COALESCE(NEW.updated_at, NOW());
    ELSIF TG_OP = 'UPDATE' THEN
        NEW.created_at := OLD.created_at;
        IF NEW.updated_at IS NULL OR NEW.updated_at = OLD.updated_at THEN
            NEW.updated_at := NOW();
        END IF;
    END IF;
    RETURN NEW;
END;$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 225 (class 1259 OID 42298)
-- Name: CreatureTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."CreatureTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 42303)
-- Name: CreatureTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."CreatureTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."CreatureTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 227 (class 1259 OID 42304)
-- Name: DamageTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."DamageTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255),
    "DevHintRu" text
);


--
-- TOC entry 228 (class 1259 OID 42311)
-- Name: DamageTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."DamageTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."DamageTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 233 (class 1259 OID 42328)
-- Name: EquipmentTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."EquipmentTypes" (
    id integer CONSTRAINT "WeaponTypes_id_not_null" NOT NULL,
    name character varying(255) CONSTRAINT "WeaponTypes_name_not_null" NOT NULL,
    name_ru character varying(255) DEFAULT ''::character varying CONSTRAINT "WeaponTypes_name_ru_not_null" NOT NULL,
    mass integer DEFAULT 0 CONSTRAINT "WeaponTypes_mass_not_null" NOT NULL,
    slot_type_id integer DEFAULT 0 CONSTRAINT "EquipmentType_slot_type_id_not_null" NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false CONSTRAINT "EquipmentType_can_craft_jewelcrafting_not_null" NOT NULL,
    can_craft_smithing boolean DEFAULT false CONSTRAINT "EquipmentType_can_craft_smithing_not_null" NOT NULL,
    attack character varying(255),
    spend_action_points character varying(255)
);


--
-- TOC entry 229 (class 1259 OID 42312)
-- Name: MaterialDamagePercents; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."MaterialDamagePercents" (
    id integer CONSTRAINT "MaterialDamagePercent_id_not_null" NOT NULL,
    smithing_materials_id integer CONSTRAINT "MaterialDamagePercent_smithing_materials_id_not_null" NOT NULL,
    damage_type_id integer CONSTRAINT "MaterialDamagePercent_damage_type_id_not_null" NOT NULL,
    percent integer CONSTRAINT "MaterialDamagePercent_percent_not_null" NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 42319)
-- Name: MaterialDamagePercent_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."MaterialDamagePercents" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."MaterialDamagePercent_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 246 (class 1259 OID 42569)
-- Name: SlotTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."SlotTypes" (
    id integer CONSTRAINT "SlotType_id_not_null" NOT NULL,
    name character varying(255) CONSTRAINT "SlotType_name_not_null" NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 245 (class 1259 OID 42568)
-- Name: SlotType_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."SlotTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."SlotType_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 231 (class 1259 OID 42320)
-- Name: SmithingMaterials; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."SmithingMaterials" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 232 (class 1259 OID 42327)
-- Name: SmithingMaterials_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."SmithingMaterials" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."SmithingMaterials_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 42339)
-- Name: WeaponTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."EquipmentTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."WeaponTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 235 (class 1259 OID 42340)
-- Name: X_EquipmentType_DamageType; Type: TABLE; Schema: x_Cross; Owner: -
--

CREATE TABLE "x_Cross"."X_EquipmentType_DamageType" (
    "EquipmentTypeId" integer CONSTRAINT "X_WeaponType_DamageType_WeaponTypeId_not_null" NOT NULL,
    "DamageTypeId" integer CONSTRAINT "X_WeaponType_DamageType_DamageTypeId_not_null" NOT NULL,
    "DamageCoef" integer DEFAULT 0 CONSTRAINT "X_WeaponType_DamageType_DamageCoef_not_null" NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 42347)
-- Name: v_WeaponTypes; Type: VIEW; Schema: __lists; Owner: -
--

CREATE VIEW __lists."v_WeaponTypes" AS
 SELECT id,
    name,
    name_ru,
    ( SELECT string_agg(((((d.name_ru)::text || '('::text) || wd."DamageCoef") || ')'::text), ', '::text ORDER BY wd."DamageCoef" DESC, wd."DamageTypeId") AS string_agg
           FROM ("x_Cross"."X_EquipmentType_DamageType" wd
             LEFT JOIN __lists."DamageTypes" d ON ((d.id = wd."DamageTypeId")))
          WHERE (wd."EquipmentTypeId" = w.id)) AS damagetypes
   FROM __lists."EquipmentTypes" w
  ORDER BY id;


--
-- TOC entry 237 (class 1259 OID 42352)
-- Name: Weapons; Type: TABLE; Schema: _equipment; Owner: -
--

CREATE TABLE _equipment."Weapons" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    damage character varying(255) NOT NULL,
    weapon_type_id integer NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 42364)
-- Name: Weapons_id_seq; Type: SEQUENCE; Schema: _equipment; Owner: -
--

ALTER TABLE _equipment."Weapons" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME _equipment."Weapons_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 239 (class 1259 OID 42365)
-- Name: Heroes; Type: TABLE; Schema: _heroes; Owner: -
--

CREATE TABLE _heroes."Heroes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean NOT NULL,
    health character varying(255) NOT NULL,
    damage character varying(255) NOT NULL
);


--
-- TOC entry 240 (class 1259 OID 42376)
-- Name: Heroes_id_seq; Type: SEQUENCE; Schema: _heroes; Owner: -
--

ALTER TABLE _heroes."Heroes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME _heroes."Heroes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 241 (class 1259 OID 42377)
-- Name: creature_types; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.creature_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 42387)
-- Name: heroes; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.heroes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer CONSTRAINT heroes__rarity_not_null NOT NULL,
    base_health real NOT NULL,
    base_attack real NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 42404)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 42409)
-- Name: X_Hero_CreatureType; Type: TABLE; Schema: x_Cross; Owner: -
--

CREATE TABLE "x_Cross"."X_Hero_CreatureType" (
    "HeroId" integer NOT NULL,
    "CreatureTypeId" integer NOT NULL
);


--
-- TOC entry 5046 (class 0 OID 42298)
-- Dependencies: 225
-- Data for Name: CreatureTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."CreatureTypes" (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5048 (class 0 OID 42304)
-- Dependencies: 227
-- Data for Name: DamageTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."DamageTypes" (id, name, name_ru, "DevHintRu") FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\r\n\r\nУязвимы: Призраки, астральные существа (иногда).\r\n\r\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\r\n\r\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\r\n\r\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\r\n\r\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\r\n\r\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\r\n\r\n"
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\r\n\r\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\r\n\r\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\r\n\r\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\r\n\r\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\r\n\r\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\r\n\r\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\r\n\r\nУязвимы: Органические, живые существа (люди, звери, растения).\r\n\r\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\r\n\r\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\r\n\r\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\r\n\r\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\r\n\r\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."
11	Light	Световой	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\r\n\r\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\r\n\r\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\r\n\r\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\r\n\r\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\r\n\r\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\r\n\r\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\r\n\r\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\r\n\r\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\r\n\r\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\r\n\r\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\r\n\r\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\r\n\r\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\r\n\r\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\r\n\r\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\r\n\r\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\r\n\r\nУязвимы: ВСЕ. По определению.\r\n\r\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\r\n\r\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\r\n\r\nУльтимативные способности с долгим откатом.\r\n\r\nЛегендарные/божественные артефакты.\r\n\r\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\r\n\r\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."
\.


--
-- TOC entry 5054 (class 0 OID 42328)
-- Dependencies: 233
-- Data for Name: EquipmentTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."EquipmentTypes" (id, name, name_ru, mass, slot_type_id, can_craft_jewelcrafting, can_craft_smithing, attack, spend_action_points) FROM stdin;
9	War Fan	Боевой веер	800	11	f	t	5d3_10	\N
10	Scimitar	Скимитар	1200	11	f	t	6d4_15	\N
11	Katana	Катана	1100	11	f	t	7d3_14	\N
14	Morning Star	Моргенштерн	5000	11	f	t	1d123_62	\N
1	Sword	Меч	1600	11	f	t	8d4_20	\N
18	Bow	Лук	960	11	f	t	4d2_6	\N
21	Pike	Пика	2800	11	f	t	24d2_36	\N
20	Rapier	Рапира	850	11	f	t	8d2_12	\N
19	Trident	Трезубец	3400	11	f	t	28d2_42	\N
17	Crossbow	Арбалет	3200	11	f	t	14d2_21	\N
7	Shuriken	Сюрикен	180	11	f	t	6d2_9	\N
22	Spear	Копьё	2200	11	f	t	20d2_30	\N
24	Dagger	Кинжал	400	11	f	t	4d2_6	\N
12	Yataghan	Ятаган	1000	11	f	t	6d3_12	\N
13	Sabre	Сабля	1100	11	f	t	7d3_14	\N
15	Warhammer	Боевой молот	6200	11	f	t	1d153_77	\N
16	Mace	Булава	3000	11	f	t	1d73_37	\N
3	Halberd	Алебарда	4400	11	f	t	4d27_56	\N
5	Poleaxe	Секира	4000	11	f	t	4d24_50	\N
23	Broadaxe	Широкий топор	5200	11	f	t	4d32_66	\N
2	Axe	Топор	2800	11	f	t	4d17_36	\N
4	Berdysh	Бердыш	3800	11	f	t	4d23_48	\N
6	Chakram	Чакрам	350	11	f	t	5d3_10	\N
8	Scythe	Коса	3200	11	f	t	5d3_10	\N
\.


--
-- TOC entry 5050 (class 0 OID 42312)
-- Dependencies: 229
-- Data for Name: MaterialDamagePercents; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."MaterialDamagePercents" (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5066 (class 0 OID 42569)
-- Dependencies: 246
-- Data for Name: SlotTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."SlotTypes" (id, name, name_ru) FROM stdin;
1	Head	Голова
2	Shoulders	Наплечники
3	Chest	Нагрудник
4	Hands	Руки
5	Legs	Поножи
6	Feet	Ступни
7	Waist	Пояс
8	Wrist	Запястья
9	Back	Спина
10	Bracelet	Браслет
11	HandLeftRight	Рука Левая Правая
12	Ring	Кольцо
13	Earring	Серьги
14	Trinket	Аксессуар
\.


--
-- TOC entry 5052 (class 0 OID 42320)
-- Dependencies: 231
-- Data for Name: SmithingMaterials; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."SmithingMaterials" (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5057 (class 0 OID 42352)
-- Dependencies: 237
-- Data for Name: Weapons; Type: TABLE DATA; Schema: _equipment; Owner: -
--

COPY _equipment."Weapons" (id, name, rarity, is_unique, damage, weapon_type_id) FROM stdin;
\.


--
-- TOC entry 5059 (class 0 OID 42365)
-- Dependencies: 239
-- Data for Name: Heroes; Type: TABLE DATA; Schema: _heroes; Owner: -
--

COPY _heroes."Heroes" (id, name, rarity, is_unique, health, damage) FROM stdin;
1	Warrior	1	f	16d24_200	4d21_44
2	Huntress	1	f	10d28_145	5d21_55
3	Hammerman	1	f	11d39_220	3d25_39
4	Rogue	1	f	15d21_165	4d23_48
5	Battle orc	1	f	16d58_472	4d21_44
\.


--
-- TOC entry 5061 (class 0 OID 42377)
-- Dependencies: 241
-- Data for Name: creature_types; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.creature_types (id, created_at, updated_at, name) FROM stdin;
40bcd67a-2fb7-4ddd-b194-f496464aea14	2025-07-31 14:35:56.034856+08	2025-07-31 14:35:56.034856+08	Wolf
52b2c4d8-977c-4dc3-967a-5bfc320a232a	2025-07-31 14:36:13.53242+08	2025-07-31 14:36:13.53242+08	Bear
550d1671-3f32-4041-a27a-217f157722b3	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Skeleton
710bda30-8522-4a6f-bcc2-f06ab5d175ab	2025-07-31 14:36:36.443478+08	2025-07-31 14:36:36.443478+08	Vampire
c79ce293-b425-4b64-85a4-61108433b13f	2025-07-31 14:36:36.443478+08	2025-07-31 14:36:36.443478+08	Zombie
cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-07-31 14:35:37.323451+08	2025-07-31 14:35:37.323451+08	Humanoid
d95ca0ae-6236-4dd6-a239-1c3d727e6230	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Orc
df0e65a9-5dc6-44c2-ae40-ab76ec162aa1	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Goblin
\.


--
-- TOC entry 5062 (class 0 OID 42387)
-- Dependencies: 242
-- Data for Name: heroes; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.heroes (id, created_at, updated_at, name, rarity, base_health, base_attack) FROM stdin;
58e860c7-3819-4f5b-bdff-f36850411498	2025-11-03 13:45:04.074396+08	2025-11-06 11:00:56.868871+08	warrior	1	100	10
64ec68ff-ee4d-4204-a830-5f992f64fae9	2025-11-03 13:45:04.074396+08	2025-11-06 11:00:56.868871+08	huntress	1	60	18
b582d3e8-d673-462f-80ad-f59b0deb1373	2025-11-03 13:45:04.074396+08	2025-11-06 11:17:06.136185+08	orc with axes	2	180	25
eb93675d-d05f-43ad-857f-e47d43152e43	2025-11-03 13:45:04.074396+08	2025-11-06 11:17:06.136185+08	rogue	1	70	21
c5c4aaa5-a4d3-4f4b-ac8c-26d77f6ea198	2025-11-03 13:45:04.074396+08	2025-11-06 11:19:53.052512+08	hammerman	1	110	16
\.


--
-- TOC entry 5063 (class 0 OID 42404)
-- Dependencies: 243
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251205052813_Init	9.0.10
20251206063518_Fix2	10.0.0
20251206074050_Fix3	10.0.0
20251206175439_Fix4	10.0.0
20251210093206_SmithingMaterials	10.0.0
20251210113701_SmithingMaterials_Fix	10.0.0
20251210115042_SmithingMaterials_Fix2	10.0.0
20251210115307_SmithingMaterials_Fix3	10.0.0
20251210133152_SmithingMaterials_Fix4	10.0.0
20251210133802_SmithingMaterials_Fix5	10.0.0
20251212010239_SmithingMaterials_Fix6	10.0.0
20251212022506_SlotType	10.0.0
20251212023349_SlotType_Fix1	10.0.0
20251212030458_SlotType_Fix2	10.0.0
20251212042506_SlotType_Fix3	10.0.0
20251212044157_SlotType_Fix4	10.0.0
20251212074701_Names_Fix1	10.0.1
\.


--
-- TOC entry 5056 (class 0 OID 42340)
-- Dependencies: 235
-- Data for Name: X_EquipmentType_DamageType; Type: TABLE DATA; Schema: x_Cross; Owner: -
--

COPY "x_Cross"."X_EquipmentType_DamageType" ("EquipmentTypeId", "DamageTypeId", "DamageCoef") FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5064 (class 0 OID 42409)
-- Dependencies: 244
-- Data for Name: X_Hero_CreatureType; Type: TABLE DATA; Schema: x_Cross; Owner: -
--

COPY "x_Cross"."X_Hero_CreatureType" ("HeroId", "CreatureTypeId") FROM stdin;
\.


--
-- TOC entry 5073 (class 0 OID 0)
-- Dependencies: 226
-- Name: CreatureTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."CreatureTypes_id_seq"', 9, false);


--
-- TOC entry 5074 (class 0 OID 0)
-- Dependencies: 228
-- Name: DamageTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."DamageTypes_id_seq"', 17, false);


--
-- TOC entry 5075 (class 0 OID 0)
-- Dependencies: 230
-- Name: MaterialDamagePercent_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."MaterialDamagePercent_id_seq"', 24, true);


--
-- TOC entry 5076 (class 0 OID 0)
-- Dependencies: 245
-- Name: SlotType_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."SlotType_id_seq"', 14, true);


--
-- TOC entry 5077 (class 0 OID 0)
-- Dependencies: 232
-- Name: SmithingMaterials_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."SmithingMaterials_id_seq"', 19, true);


--
-- TOC entry 5078 (class 0 OID 0)
-- Dependencies: 234
-- Name: WeaponTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."WeaponTypes_id_seq"', 24, true);


--
-- TOC entry 5079 (class 0 OID 0)
-- Dependencies: 238
-- Name: Weapons_id_seq; Type: SEQUENCE SET; Schema: _equipment; Owner: -
--

SELECT pg_catalog.setval('_equipment."Weapons_id_seq"', 1, false);


--
-- TOC entry 5080 (class 0 OID 0)
-- Dependencies: 240
-- Name: Heroes_id_seq; Type: SEQUENCE SET; Schema: _heroes; Owner: -
--

SELECT pg_catalog.setval('_heroes."Heroes_id_seq"', 6, false);


--
-- TOC entry 4847 (class 2606 OID 42625)
-- Name: CreatureTypes CreatureTypes__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."CreatureTypes"
    ADD CONSTRAINT "CreatureTypes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4850 (class 2606 OID 42623)
-- Name: DamageTypes DamageTypes__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."DamageTypes"
    ADD CONSTRAINT "DamageTypes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4861 (class 2606 OID 42631)
-- Name: EquipmentTypes EquipmentTypes__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."EquipmentTypes"
    ADD CONSTRAINT "EquipmentTypes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4854 (class 2606 OID 42629)
-- Name: MaterialDamagePercents MaterialDamagePercents__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercents"
    ADD CONSTRAINT "MaterialDamagePercents__pkey" PRIMARY KEY (id);


--
-- TOC entry 4887 (class 2606 OID 42627)
-- Name: SlotTypes SlotTypes__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."SlotTypes"
    ADD CONSTRAINT "SlotTypes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4857 (class 2606 OID 42619)
-- Name: SmithingMaterials SmithingMaterials__pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."SmithingMaterials"
    ADD CONSTRAINT "SmithingMaterials__pkey" PRIMARY KEY (id);


--
-- TOC entry 4869 (class 2606 OID 42617)
-- Name: Weapons Weapons__pkey; Type: CONSTRAINT; Schema: _equipment; Owner: -
--

ALTER TABLE ONLY _equipment."Weapons"
    ADD CONSTRAINT "Weapons__pkey" PRIMARY KEY (id);


--
-- TOC entry 4872 (class 2606 OID 42621)
-- Name: Heroes Heroes__pkey; Type: CONSTRAINT; Schema: _heroes; Owner: -
--

ALTER TABLE ONLY _heroes."Heroes"
    ADD CONSTRAINT "Heroes__pkey" PRIMARY KEY (id);


--
-- TOC entry 4875 (class 2606 OID 42436)
-- Name: creature_types creature_types_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.creature_types
    ADD CONSTRAINT creature_types_pkey PRIMARY KEY (id);


--
-- TOC entry 4878 (class 2606 OID 42438)
-- Name: heroes heroes_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.heroes
    ADD CONSTRAINT heroes_pkey PRIMARY KEY (id);


--
-- TOC entry 4880 (class 2606 OID 42440)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4865 (class 2606 OID 42615)
-- Name: X_EquipmentType_DamageType X_EquipmentType_DamageType__pkey; Type: CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_EquipmentType_DamageType"
    ADD CONSTRAINT "X_EquipmentType_DamageType__pkey" PRIMARY KEY ("EquipmentTypeId", "DamageTypeId");


--
-- TOC entry 4884 (class 2606 OID 42613)
-- Name: X_Hero_CreatureType X_Hero_CreatureType__pkey; Type: CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType__pkey" PRIMARY KEY ("HeroId", "CreatureTypeId");


--
-- TOC entry 4845 (class 1259 OID 42447)
-- Name: CreatureTypes__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "CreatureTypes__Name__idx" ON __lists."CreatureTypes" USING btree (name);


--
-- TOC entry 4848 (class 1259 OID 42448)
-- Name: DamageTypes__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "DamageTypes__Name__idx" ON __lists."DamageTypes" USING btree (name);


--
-- TOC entry 4858 (class 1259 OID 42452)
-- Name: EquipmentTypes__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "EquipmentTypes__Name__idx" ON __lists."EquipmentTypes" USING btree (name);


--
-- TOC entry 4859 (class 1259 OID 42578)
-- Name: EquipmentTypes__SlotTypeId__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE INDEX "EquipmentTypes__SlotTypeId__idx" ON __lists."EquipmentTypes" USING btree (slot_type_id);


--
-- TOC entry 4851 (class 1259 OID 42449)
-- Name: MaterialDamagePercents__DamageTypeId__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE INDEX "MaterialDamagePercents__DamageTypeId__idx" ON __lists."MaterialDamagePercents" USING btree (damage_type_id);


--
-- TOC entry 4852 (class 1259 OID 42450)
-- Name: MaterialDamagePercents__SmithingMaterialsId__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE INDEX "MaterialDamagePercents__SmithingMaterialsId__idx" ON __lists."MaterialDamagePercents" USING btree (smithing_materials_id);


--
-- TOC entry 4885 (class 1259 OID 42579)
-- Name: SlotTypes__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "SlotTypes__Name__idx" ON __lists."SlotTypes" USING btree (name);


--
-- TOC entry 4855 (class 1259 OID 42451)
-- Name: SmithingMaterials__Name__idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "SmithingMaterials__Name__idx" ON __lists."SmithingMaterials" USING btree (name);


--
-- TOC entry 4866 (class 1259 OID 42453)
-- Name: Weapons__Name__idx; Type: INDEX; Schema: _equipment; Owner: -
--

CREATE UNIQUE INDEX "Weapons__Name__idx" ON _equipment."Weapons" USING btree (name);


--
-- TOC entry 4867 (class 1259 OID 42454)
-- Name: Weapons__WeaponTypeId__idx; Type: INDEX; Schema: _equipment; Owner: -
--

CREATE INDEX "Weapons__WeaponTypeId__idx" ON _equipment."Weapons" USING btree (weapon_type_id);


--
-- TOC entry 4870 (class 1259 OID 42455)
-- Name: Heroes__Name__idx; Type: INDEX; Schema: _heroes; Owner: -
--

CREATE UNIQUE INDEX "Heroes__Name__idx" ON _heroes."Heroes" USING btree (name);


--
-- TOC entry 4873 (class 1259 OID 42456)
-- Name: creature_types_name_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE UNIQUE INDEX creature_types_name_idx ON _main.creature_types USING btree (name);


--
-- TOC entry 4876 (class 1259 OID 42457)
-- Name: heroes_name_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE UNIQUE INDEX heroes_name_idx ON _main.heroes USING btree (name);


--
-- TOC entry 4862 (class 1259 OID 42460)
-- Name: X_EquipmentType_DamageType__DamageTypeId__idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_EquipmentType_DamageType__DamageTypeId__idx" ON "x_Cross"."X_EquipmentType_DamageType" USING btree ("DamageTypeId");


--
-- TOC entry 4863 (class 1259 OID 42461)
-- Name: X_EquipmentType_DamageType__EquipmentTypeId__idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_EquipmentType_DamageType__EquipmentTypeId__idx" ON "x_Cross"."X_EquipmentType_DamageType" USING btree ("EquipmentTypeId");


--
-- TOC entry 4881 (class 1259 OID 42458)
-- Name: X_Hero_CreatureType__CreatureTypeId__idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_Hero_CreatureType__CreatureTypeId__idx" ON "x_Cross"."X_Hero_CreatureType" USING btree ("CreatureTypeId");


--
-- TOC entry 4882 (class 1259 OID 42459)
-- Name: X_Hero_CreatureType__HeroId__idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_Hero_CreatureType__HeroId__idx" ON "x_Cross"."X_Hero_CreatureType" USING btree ("HeroId");


--
-- TOC entry 4896 (class 2620 OID 42465)
-- Name: creature_types set_timestamps_trigger; Type: TRIGGER; Schema: _main; Owner: -
--

CREATE TRIGGER set_timestamps_trigger BEFORE INSERT OR UPDATE ON _main.creature_types FOR EACH ROW EXECUTE FUNCTION public.set_timestamp();


--
-- TOC entry 4897 (class 2620 OID 42466)
-- Name: heroes set_timestamps_trigger; Type: TRIGGER; Schema: _main; Owner: -
--

CREATE TRIGGER set_timestamps_trigger BEFORE INSERT OR UPDATE ON _main.heroes FOR EACH ROW EXECUTE FUNCTION public.set_timestamp();


--
-- TOC entry 4890 (class 2606 OID 42632)
-- Name: EquipmentTypes EquipmentTypes__SlotTypeId__SlotTypes__fkey; Type: FK CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."EquipmentTypes"
    ADD CONSTRAINT "EquipmentTypes__SlotTypeId__SlotTypes__fkey" FOREIGN KEY (slot_type_id) REFERENCES __lists."SlotTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4888 (class 2606 OID 42637)
-- Name: MaterialDamagePercents MaterialDamagePercents__DamageTypeId__DamageTypes__fkey; Type: FK CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercents"
    ADD CONSTRAINT "MaterialDamagePercents__DamageTypeId__DamageTypes__fkey" FOREIGN KEY (damage_type_id) REFERENCES __lists."DamageTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4889 (class 2606 OID 42642)
-- Name: MaterialDamagePercents MaterialDamagePercents__SmithingMaterialsId__SmithingMaterials_; Type: FK CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercents"
    ADD CONSTRAINT "MaterialDamagePercents__SmithingMaterialsId__SmithingMaterials_" FOREIGN KEY (smithing_materials_id) REFERENCES __lists."SmithingMaterials"(id) ON DELETE CASCADE;


--
-- TOC entry 4893 (class 2606 OID 42647)
-- Name: Weapons Weapons__WeaponTypeId__EquipmentTypes__fkey; Type: FK CONSTRAINT; Schema: _equipment; Owner: -
--

ALTER TABLE ONLY _equipment."Weapons"
    ADD CONSTRAINT "Weapons__WeaponTypeId__EquipmentTypes__fkey" FOREIGN KEY (weapon_type_id) REFERENCES __lists."EquipmentTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4891 (class 2606 OID 42652)
-- Name: X_EquipmentType_DamageType X_EquipmentType_DamageType__DamageTypeId__DamageTypes__fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_EquipmentType_DamageType"
    ADD CONSTRAINT "X_EquipmentType_DamageType__DamageTypeId__DamageTypes__fkey" FOREIGN KEY ("DamageTypeId") REFERENCES __lists."DamageTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4892 (class 2606 OID 42657)
-- Name: X_EquipmentType_DamageType X_EquipmentType_DamageType__EquipmentTypeId__EquipmentTypes__fk; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_EquipmentType_DamageType"
    ADD CONSTRAINT "X_EquipmentType_DamageType__EquipmentTypeId__EquipmentTypes__fk" FOREIGN KEY ("EquipmentTypeId") REFERENCES __lists."EquipmentTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4894 (class 2606 OID 42662)
-- Name: X_Hero_CreatureType X_Hero_CreatureType__CreatureTypeId__CreatureTypes__fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType__CreatureTypeId__CreatureTypes__fkey" FOREIGN KEY ("CreatureTypeId") REFERENCES __lists."CreatureTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4895 (class 2606 OID 42667)
-- Name: X_Hero_CreatureType X_Hero_CreatureType__HeroId__Heroes__fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType__HeroId__Heroes__fkey" FOREIGN KEY ("HeroId") REFERENCES _heroes."Heroes"(id) ON DELETE CASCADE;


-- Completed on 2025-12-12 15:56:30

--
-- PostgreSQL database dump complete
--

\unrestrict IOOjuJNJXtyDoe974W9SKI5VQQbjdowIwSAScDLCn8wlnmYzVDpuSEx28C99toC

