--
-- PostgreSQL database dump
--

\restrict o8oSx1VfS11TFfCQOMcNYMe9jezdb2vphp0ljcMogpTdzXNGwmUWEUDW1sOyysW

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2026-01-04 02:17:01

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_ban_reason_id__user_ban_reasons__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_tokens DROP CONSTRAINT IF EXISTS identity_user_tokens__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__role_id__identity_roles__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_logins DROP CONSTRAINT IF EXISTS identity_user_logins__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_claims DROP CONSTRAINT IF EXISTS identity_user_claims__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_role_claims DROP CONSTRAINT IF EXISTS identity_role_claims__role_id__identity_roles__fkey;
ALTER TABLE IF EXISTS ONLY logs.auth_reg_logs DROP CONSTRAINT IF EXISTS auth_reg_logs__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY logs.auth_reg_logs DROP CONSTRAINT IF EXISTS auth_reg_logs__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__creature_type_id__creature_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__equipment_type_id__equipment_type;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__damage_type_id__damage_types__fke;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__smithing_materials_id__smithing_mater;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__damage_type_id__damage_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__smithing_material_id__smithing_materials__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__equipment_type_id__equipment_types__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment9id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment8id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment7id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment6id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment5id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment4id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment3id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment2id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment1id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment12id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment11id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment10id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__base_equipment_id__base_equipments__fkey;
DROP INDEX IF EXISTS users.user_bans__user_id__idx;
DROP INDEX IF EXISTS users.user_bans__user_ban_reason_id__idx;
DROP INDEX IF EXISTS users.identity_users__normalized_user_name__idx;
DROP INDEX IF EXISTS users.identity_users__normalized_email__idx;
DROP INDEX IF EXISTS users.identity_user_roles__role_id__idx;
DROP INDEX IF EXISTS users.identity_user_logins__user_id__idx;
DROP INDEX IF EXISTS users.identity_user_claims__user_id__idx;
DROP INDEX IF EXISTS users.identity_roles__normalized_name__idx;
DROP INDEX IF EXISTS users.identity_role_claims__role_id__idx;
DROP INDEX IF EXISTS server.user_ban_reasons__name__idx;
DROP INDEX IF EXISTS logs.auth_reg_logs__user_id__idx;
DROP INDEX IF EXISTS logs.auth_reg_logs__user_device_id__idx;
DROP INDEX IF EXISTS game_data.x_hero_creature_type__creature_type_id__idx;
DROP INDEX IF EXISTS game_data.x_equipment_type_damage_type__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.smithing_materials__name__idx;
DROP INDEX IF EXISTS game_data.slot_types__name__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__smithing_materials_id__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__name__idx;
DROP INDEX IF EXISTS game_data.damage_types__name__idx;
DROP INDEX IF EXISTS game_data.creature_types__name__idx;
DROP INDEX IF EXISTS game_data.base_heroes__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__smithing_material_id__idx;
DROP INDEX IF EXISTS game_data.base_equipments__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__equipment_type_id__idx;
DROP INDEX IF EXISTS collection.heroes__user_id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment9id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment8id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment7id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment6id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment5id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment4id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment3id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment2id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment1id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment12id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment11id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment10id__idx;
DROP INDEX IF EXISTS collection.heroes__base_hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__user_id__idx;
DROP INDEX IF EXISTS collection.equipments__base_equipment_id__idx;
ALTER TABLE IF EXISTS ONLY users.user_devices DROP CONSTRAINT IF EXISTS user_devices__pkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_users DROP CONSTRAINT IF EXISTS identity_users__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_tokens DROP CONSTRAINT IF EXISTS identity_user_tokens__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_logins DROP CONSTRAINT IF EXISTS identity_user_logins__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_claims DROP CONSTRAINT IF EXISTS identity_user_claims__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_roles DROP CONSTRAINT IF EXISTS identity_roles__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_role_claims DROP CONSTRAINT IF EXISTS identity_role_claims__pkey;
ALTER TABLE IF EXISTS ONLY server.user_ban_reasons DROP CONSTRAINT IF EXISTS user_ban_reasons__pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY logs.auth_reg_logs DROP CONSTRAINT IF EXISTS auth_reg_logs__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.smithing_materials DROP CONSTRAINT IF EXISTS smithing_materials__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slot_types DROP CONSTRAINT IF EXISTS slot_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__pkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.damage_types DROP CONSTRAINT IF EXISTS damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.creature_types DROP CONSTRAINT IF EXISTS creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_heroes DROP CONSTRAINT IF EXISTS base_heroes__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__pkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__pkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__pkey;
DROP TABLE IF EXISTS users.user_devices;
DROP TABLE IF EXISTS users.user_bans;
DROP TABLE IF EXISTS users.identity_users;
DROP TABLE IF EXISTS users.identity_user_tokens;
DROP TABLE IF EXISTS users.identity_user_roles;
DROP TABLE IF EXISTS users.identity_user_logins;
DROP TABLE IF EXISTS users.identity_roles;
DROP TABLE IF EXISTS users.identity_user_claims;
DROP TABLE IF EXISTS users.identity_role_claims;
DROP TABLE IF EXISTS server.user_ban_reasons;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS logs.auth_reg_logs;
DROP TABLE IF EXISTS game_data.x_hero_creature_type;
DROP TABLE IF EXISTS game_data.x_equipment_type_damage_type;
DROP TABLE IF EXISTS game_data.smithing_materials;
DROP TABLE IF EXISTS game_data.slot_types;
DROP TABLE IF EXISTS game_data.material_damage_percents;
DROP TABLE IF EXISTS game_data.equipment_types;
DROP TABLE IF EXISTS game_data.damage_types;
DROP TABLE IF EXISTS game_data.creature_types;
DROP TABLE IF EXISTS game_data.base_heroes;
DROP TABLE IF EXISTS game_data.base_equipments;
DROP TABLE IF EXISTS collection.heroes;
DROP TABLE IF EXISTS collection.equipments;
DROP SCHEMA IF EXISTS users;
DROP SCHEMA IF EXISTS server;
DROP SCHEMA IF EXISTS logs;
DROP SCHEMA IF EXISTS game_data;
DROP SCHEMA IF EXISTS collection;
--
-- TOC entry 6 (class 2615 OID 26435)
-- Name: collection; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA collection;


--
-- TOC entry 7 (class 2615 OID 26436)
-- Name: game_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA game_data;


--
-- TOC entry 8 (class 2615 OID 26437)
-- Name: logs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA logs;


--
-- TOC entry 9 (class 2615 OID 26438)
-- Name: server; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA server;


--
-- TOC entry 10 (class 2615 OID 26439)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 26440)
-- Name: equipments; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.equipments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    base_equipment_id integer NOT NULL,
    group_name character varying(256)
);


--
-- TOC entry 225 (class 1259 OID 26453)
-- Name: heroes; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.heroes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_hero_id integer NOT NULL,
    health1000 bigint CONSTRAINT heroes_health_not_null NOT NULL,
    strength integer NOT NULL,
    agility integer NOT NULL,
    intelligence integer NOT NULL,
    crit_chance integer NOT NULL,
    crit_power integer NOT NULL,
    haste integer NOT NULL,
    versality integer NOT NULL,
    endurance_physical integer NOT NULL,
    endurance_magical integer NOT NULL,
    resist_damage_physical integer NOT NULL,
    resist_damage_magical integer NOT NULL,
    equipment1id uuid,
    equipment2id uuid,
    equipment3id uuid,
    equipment4id uuid,
    equipment5id uuid,
    equipment6id uuid,
    equipment7id uuid,
    equipment8id uuid,
    equipment9id uuid,
    equipment10id uuid,
    equipment11id uuid,
    equipment12id uuid,
    experience_now bigint DEFAULT 0 NOT NULL,
    group_name character varying(256),
    level integer DEFAULT 1 NOT NULL,
    rarity integer DEFAULT 1 NOT NULL,
    damage jsonb
);


--
-- TOC entry 226 (class 1259 OID 26483)
-- Name: base_equipments; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_equipments (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    equipment_type_id integer NOT NULL,
    health jsonb,
    damage jsonb,
    smithing_material_id integer
);


--
-- TOC entry 227 (class 1259 OID 26494)
-- Name: base_equipments_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_equipments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_equipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 26495)
-- Name: base_heroes; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_heroes (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL,
    health jsonb,
    damage jsonb
);


--
-- TOC entry 229 (class 1259 OID 26507)
-- Name: base_heroes_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_heroes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_heroes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 26508)
-- Name: creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.creature_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 26513)
-- Name: creature_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.creature_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.creature_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 26514)
-- Name: damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.damage_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256),
    dev_hint_ru text,
    category integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 26523)
-- Name: damage_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.damage_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.damage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 26524)
-- Name: equipment_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.equipment_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256) NOT NULL,
    mass_physical integer DEFAULT 0 NOT NULL,
    mass_magical integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    spend_action_points integer DEFAULT 0 NOT NULL,
    block_other_hand boolean,
    damage jsonb
);


--
-- TOC entry 235 (class 1259 OID 26543)
-- Name: equipment_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.equipment_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.equipment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 26544)
-- Name: material_damage_percents; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.material_damage_percents (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 26551)
-- Name: material_damage_percents_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.material_damage_percents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.material_damage_percents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 26552)
-- Name: slot_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slot_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256)
);


--
-- TOC entry 239 (class 1259 OID 26559)
-- Name: slot_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slot_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slot_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 26560)
-- Name: smithing_materials; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.smithing_materials (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256)
);


--
-- TOC entry 241 (class 1259 OID 26567)
-- Name: smithing_materials_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.smithing_materials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.smithing_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 26568)
-- Name: x_equipment_type_damage_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_equipment_type_damage_type (
    equipment_type_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    damage_coef integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 26575)
-- Name: x_hero_creature_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_hero_creature_type (
    base_hero_id integer CONSTRAINT x_hero_creature_type_hero_id_not_null NOT NULL,
    creature_type_id integer NOT NULL
);


--
-- TOC entry 258 (class 1259 OID 27014)
-- Name: auth_reg_logs; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.auth_reg_logs (
    id uuid NOT NULL,
    email character varying(256),
    user_id uuid,
    success boolean NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_device_id uuid,
    ip inet,
    action_is_authentication boolean DEFAULT true NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 26591)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 26596)
-- Name: user_ban_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_ban_reasons (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 26603)
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_ban_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_ban_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 252 (class 1259 OID 26875)
-- Name: identity_role_claims; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_role_claims (
    id integer CONSTRAINT asp_net_role_claims_id_not_null NOT NULL,
    role_id uuid CONSTRAINT asp_net_role_claims_role_id_not_null NOT NULL,
    claim_type text,
    claim_value text
);


--
-- TOC entry 251 (class 1259 OID 26874)
-- Name: asp_net_role_claims_id_seq; Type: SEQUENCE; Schema: users; Owner: -
--

ALTER TABLE users.identity_role_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME users.asp_net_role_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 254 (class 1259 OID 26890)
-- Name: identity_user_claims; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_claims (
    id integer CONSTRAINT asp_net_user_claims_id_not_null NOT NULL,
    user_id uuid CONSTRAINT asp_net_user_claims_user_id_not_null NOT NULL,
    claim_type text,
    claim_value text
);


--
-- TOC entry 253 (class 1259 OID 26889)
-- Name: asp_net_user_claims_id_seq; Type: SEQUENCE; Schema: users; Owner: -
--

ALTER TABLE users.identity_user_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME users.asp_net_user_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 249 (class 1259 OID 26852)
-- Name: identity_roles; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_roles (
    id uuid CONSTRAINT asp_net_roles_id_not_null NOT NULL,
    name character varying(256),
    normalized_name character varying(256),
    concurrency_stamp text
);


--
-- TOC entry 255 (class 1259 OID 26904)
-- Name: identity_user_logins; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_logins (
    login_provider text CONSTRAINT asp_net_user_logins_login_provider_not_null NOT NULL,
    provider_key text CONSTRAINT asp_net_user_logins_provider_key_not_null NOT NULL,
    provider_display_name text,
    user_id uuid CONSTRAINT asp_net_user_logins_user_id_not_null NOT NULL
);


--
-- TOC entry 256 (class 1259 OID 26919)
-- Name: identity_user_roles; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_roles (
    user_id uuid CONSTRAINT asp_net_user_roles_user_id_not_null NOT NULL,
    role_id uuid CONSTRAINT asp_net_user_roles_role_id_not_null NOT NULL
);


--
-- TOC entry 257 (class 1259 OID 26936)
-- Name: identity_user_tokens; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_tokens (
    user_id uuid CONSTRAINT asp_net_user_tokens_user_id_not_null NOT NULL,
    login_provider text CONSTRAINT asp_net_user_tokens_login_provider_not_null NOT NULL,
    name text CONSTRAINT asp_net_user_tokens_name_not_null NOT NULL,
    value text
);


--
-- TOC entry 250 (class 1259 OID 26860)
-- Name: identity_users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_users (
    id uuid CONSTRAINT asp_net_users_id_not_null NOT NULL,
    user_name character varying(256),
    normalized_user_name character varying(256),
    email character varying(256),
    normalized_email character varying(256),
    email_confirmed boolean CONSTRAINT asp_net_users_email_confirmed_not_null NOT NULL,
    password_hash text,
    security_stamp text,
    concurrency_stamp text,
    phone_number text,
    phone_number_confirmed boolean CONSTRAINT asp_net_users_phone_number_confirmed_not_null NOT NULL,
    two_factor_enabled boolean CONSTRAINT asp_net_users_two_factor_enabled_not_null NOT NULL,
    lockout_end timestamp with time zone,
    lockout_enabled boolean CONSTRAINT asp_net_users_lockout_enabled_not_null NOT NULL,
    access_failed_count integer CONSTRAINT asp_net_users_access_failed_count_not_null NOT NULL,
    created_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone CONSTRAINT asp_net_users_created_at_not_null NOT NULL,
    time_zone character varying(256),
    updated_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone CONSTRAINT asp_net_users_updated_at_not_null NOT NULL,
    version bigint DEFAULT 1 CONSTRAINT asp_net_users_version_not_null NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 26604)
-- Name: user_bans; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_bans (
    id uuid NOT NULL,
    user_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    user_ban_reason_id integer NOT NULL
);


--
-- TOC entry 248 (class 1259 OID 26614)
-- Name: user_devices; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_devices (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    system_environment_user_name character varying(256),
    time_zone_minutes integer,
    device_unique_identifier character varying(256),
    device_model character varying(256),
    device_type character varying(256),
    operating_system character varying(256),
    processor_type character varying(256),
    processor_count integer,
    system_memory_size integer,
    graphics_device_name character varying(256),
    graphics_memory_size integer,
    system_info_supports_instancing boolean,
    system_info_npot_support character varying(256)
);


--
-- TOC entry 5214 (class 0 OID 26440)
-- Dependencies: 224
-- Data for Name: equipments; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.equipments (id, user_id, version, created_at, updated_at, base_equipment_id, group_name) FROM stdin;
bc658f5b-271e-413d-8772-01e5b007fe3d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 15:52:42.946044+08	2026-01-02 15:52:42.946044+08	1	\N
d93c1740-5cbb-4999-9111-d6d3e911438f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 16:31:49.146447+08	2026-01-02 16:31:49.146447+08	1	\N
004eac23-45a7-4c23-bc9a-f5cface0724e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
03c21165-35ea-40eb-93d4-c8e0a21f12c2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
0728f0a9-4467-4b19-8327-ad7a38b999d6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
0818ce4d-a550-4af1-9720-47e6e34d93f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
0941dcf5-f725-43ee-93c5-99025a0749f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
09d32c97-4701-4285-aed0-5bc2e8900dd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
0b8705ad-b51f-4150-b348-61fe3d5022e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
0baea179-2ced-4c5f-98bf-db2e215756fa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
0d60e004-045f-4814-9815-d865dcc4d78c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
0d68e344-00f9-49a9-a58f-4bd6f4c709cf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
0fc1b8ea-793b-4e45-a9a7-11f96111ad33	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
14e5a55d-bbb1-4725-9e64-f6534c6a243f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
15532ac5-f5a5-4859-bd84-3386a4423c60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
16228250-1463-4aa3-be37-8d392c72c9c2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
1772726b-5e3b-44bb-8bd4-e38bb4d6911d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
177aff17-7de1-4e0c-a925-6cfda50b6d2f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
1911011e-f51a-4740-9825-dd30b75b9f60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
1beb3870-caa1-4ca5-8ced-d3087f00cf06	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
1c292258-50ca-495d-ade8-96f2c806ea4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
1e56081d-2f18-4021-b38e-56c04e5125a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
21206d91-cccf-498c-b98d-a2164f3316fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
24250502-0844-49bb-917d-d60a7de3b879	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
281160a4-1d0a-49a4-9da8-b453658ba7c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
2a6666b9-c75f-4dff-a49f-f67390cc7929	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
2b4980ab-cbea-4819-ab36-6882f53269a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
2e297eb9-73b5-4f3c-9165-bd031d2b1164	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
2ee52ff8-2437-4b40-8a93-45bd812c2510	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
2f0d86f4-1d9f-4afb-a5cd-9a86c8c7443d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
3172af51-2883-4939-bb6e-7728690886e2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
404201c5-0458-4bc4-aca1-5f4b4de403c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
4374af37-05eb-4649-864c-7db43de733f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
44905d22-b651-4015-a946-77d1fb3da0a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
4858af6f-c03d-4b5d-8e51-a118ada986fe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
486b8fb7-86f9-4355-8c1e-7402453b8233	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
4abadd00-2a20-4865-80a9-466dd1593f9e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
4ad6fea0-cd58-4596-8f0a-57ade89f6a4d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
4cd987bf-ff00-477a-94b6-ce5ff050e320	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
4cfd6971-54bb-4214-81b7-238ba51c6b03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
54551190-5dc3-4992-b3f3-4b52a9c5af0d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
5e572c90-cd06-4716-b948-e46743a7f084	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
62c00c46-355c-4c81-bf5d-78c30f63e317	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
662b725f-5d76-461a-b43f-fe245e0e6938	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
6bdda9c4-819a-4eff-a08e-43d70272a0fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
6f2b1238-3a32-4ac4-8160-d7fabdc8e055	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
70242065-3ee0-4068-b703-4675e62cfd8c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
7582f03b-0c80-4d43-80c4-6252293d14e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
76092f4e-9590-4449-a084-4d089e6c2537	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
7b3a1271-d793-49f1-a25e-632e0904ecbc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
80c1d388-8e54-44a0-9689-15a4ea28d124	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
80e2b06e-361c-4981-8b54-3d252a3909c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
88fe39a3-1753-48db-8648-062434eb4943	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
89a62f9c-02e3-43c3-b43c-e85ed404f905	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
8becde0f-700c-4085-be4c-62b0d597c0e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
90d42bde-ee4e-4f2d-8e12-f2c111f15b26	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
921258a5-6bd4-482b-aed7-ad1d5423f108	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
9335f1fa-78b9-4271-a26b-71bfa80e569a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
93470745-5108-441f-b23e-5601e2007e3a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
98b0da3a-2bcc-4329-a36a-26cb6bc13633	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
990971b2-89ed-4b92-a751-810da143ad5a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
9f72c879-f5eb-4636-b78a-98682b0a071e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
a0fd5a82-5969-4f3d-83ca-7678b13c74ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
a2a63ce0-bcba-4570-989d-a81ff4f56531	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
a2bb8afa-4b0b-488f-9e62-a20c634b729d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
a834c17f-3188-48b4-8025-86e3cc0bdf0a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
a8cb9a26-6249-439e-aed7-f55e0e90399f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
a91ee17e-74d2-498b-a6c3-326a3ff43a10	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
ab351ca9-1f4c-4f49-80ff-d33a3b6860d2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
abf7d895-5486-4398-97fc-447e5c1d5c94	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
b0b60e7d-99de-4d36-9f75-34011a398acf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
b3109a89-a033-4aa7-9e3f-3c6ec8fa509e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
b44b6bc8-ff3f-462a-919c-d47719dd8962	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
b4a46daa-eb71-4e9f-9547-e3c2cb405ddb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
b8e8291e-bd33-45d0-94f4-0ca449b2a8a9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
b938d21a-8951-46ea-9bf9-dafceb3ccf47	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
be6022b8-d505-4986-8900-a0bad47cbc25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
bfdbe6aa-1915-4ecf-860a-6c6c2c939334	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
c1970acb-ae5e-4e04-8b79-a89f5af3478a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
c1fc4653-b96a-4100-a0cd-2d0d42eace5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
c2e4c3ad-659b-4ce0-8fbd-002ded27d18e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
c79c3d53-06e3-4135-9592-f255c3979322	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
c811abc5-dcac-426d-8774-0eff73e52af6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
c811f6b7-04b3-427d-b594-1d2cf2bc9d79	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
c852cf2c-79bd-4549-a7de-dc5b47790aea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
c8e8b107-dbbd-41a2-923e-04c5b83e737a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
cdacef26-5c67-49c0-99e3-8969deeb1012	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
d0e066e0-cacb-4927-a207-975e23e6be98	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
d4df6bae-9bfa-4f0d-aa4a-e17aa3748f9b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N
d4fb341b-d7de-44f7-9e1a-e50d39816ef1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
d5d3cafc-eb45-43cf-8757-5eb4dcdaa86c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
d903e974-c37e-417d-9e68-36a7fbb10279	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
da5a7832-bd3f-463e-87e2-4b766b7fe11f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
dffa4c5c-fd2a-4bb9-a27c-45f7fa553852	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
e2eabb23-3dcf-4b57-89d4-f0ce03337c22	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N
e5d8cc10-0f19-4677-9768-7c0b8fa6c815	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N
e60484c7-e027-4f17-becb-3482576fc50c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N
eb3fb02e-4351-47e4-bc2e-57c252962833	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
ef649618-6fc3-4b29-94c8-1f2ccd11c5d8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N
f848e76d-0abd-486a-b098-43ae740ef2c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
f8f02643-b4c6-4fc1-81a4-da2ec5c3b6cb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N
f9074397-5296-4dc7-a21a-9170c04a76de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N
007fb8ff-635b-44fd-91c7-5f90d9929fbd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
06215d30-a645-434c-b01a-d79e9119b26a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
06f621e6-5898-4c10-a8ef-ee81be6938e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
083f7830-321a-435f-8b63-b821a789049a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
0a94e05f-8b3e-4997-b3a1-edf586a71c8e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
0ea2b2b1-cff4-466a-add8-b3327463cde6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
117f3921-7c47-40b0-8f0e-c9eb7d857082	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
11f98e9d-2abd-4c50-b29e-a5e1798dd14f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
16a0117c-f84c-4154-abea-889dba76dee6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
1a43fcf1-b6f7-4fd2-a0ad-8ace9631c62f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
1c8e67b9-20b8-4bbc-8a48-5b764cc90527	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
290e124f-0b1d-4675-8710-6cc68c61897d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
2a5d7295-91b3-4eb3-a7e1-76dafea76a76	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
2f3f4082-cd7a-4453-9eca-291012762956	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
31ce9a1a-200c-4112-b138-d378f8f3af91	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
3305df7d-a699-4d6a-beb3-b14a4aa3deac	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
3a44dda9-77ba-4491-91a1-cc9dcd1429bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
3cc5ee0b-958e-436c-8ed6-8f678c22d401	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
3fc37e1b-9b3d-4ff1-b225-974a0174aeb2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
3fd3050b-5124-43fc-b3a1-21d7a2cef715	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
40723513-6b5d-4cb8-9309-3145630b690c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
43980a85-0963-40c0-99fb-76ea962556ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
49533fe0-41ec-4068-a55d-9cd7c58591b5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
4c722bc1-482e-4251-a99d-efe04ddfb59f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
4d05a739-acd1-411e-b209-155907bb31a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
4d976284-a6dc-48cd-83e4-d7f2f894344e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
4e7f7b5a-f072-4296-920a-7611ba5f8b49	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
4f8c1255-be27-4d37-b63d-0b44cdd035ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
51eaae7d-216a-4cd1-ae5c-2032338608ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
5382ca7f-7558-441d-9d8d-e80f7a21d501	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
5419e4ed-45d9-4c11-aed7-11e56d31f7e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
5523751a-5dda-4e28-9cad-762f598a1cb7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
55773bc3-50ff-4269-a8ad-7a55f8b1ae5b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
56c2c02b-a474-4d61-97d4-0269d6469fe0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
59150023-2912-4d0b-8a52-789c55d88f25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
59f16175-b77a-47b8-86b0-da960c018e5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
5b067d42-bd9b-4354-94b3-7197ab48c35e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
5b563efe-67f1-4d1f-8af1-1f6b88fa714a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
5d8b8fcf-b60b-4597-ae3a-c1452a4c07e8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
5e076804-ba23-4a08-80be-dd5cf23d5e45	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
5e63a3ef-0a0d-4f73-b0cd-9549c630fd36	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
602ae1f0-ef45-4f51-b2d1-3c8ef93f6638	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
6aa8dd70-f3d0-410f-ad64-ab7a62907c32	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
71ccc8eb-05b6-4709-a740-3b615194c9c8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
76e72ba0-b270-4d23-9704-f319c101a1fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
774d5117-2628-4e8c-90c6-0ddaf398b1c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
777a0401-45b0-418a-80bc-3425e95db6b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
78830dd5-3adc-4278-83ed-e55fe0f452c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
7e1e1850-f912-499b-993e-74d764089129	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
7ecf1025-781e-4629-9595-defb4ab1b6bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
82714929-210d-458c-9d89-1b8aaa9577aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
82e015ff-8374-4440-a7bd-b101203d00b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
834b96da-8144-4336-a3d3-f192471b4214	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
89f608fa-db98-454c-9fcc-85fbb8f42d21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
8fc09204-0f4f-4118-8ec9-dd8c85de2d9f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
93dffad3-c0a4-484b-a56e-b7477db9a9b3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
97131b87-bce4-4c52-aafc-ef8378f78ea7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
995572df-5ba3-4377-b694-d6e9fe017bc9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
99e584cb-5ec5-4de1-9d0d-91b8759e8b18	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
9e765e4c-7048-4484-9e41-968019c87f39	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
9edde83b-bf78-4bf9-b1e2-c893c1a20d3b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
a0060589-5283-4f2e-adda-64cb31ca61b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
a1858b11-e636-4f3f-8f19-3829c69f1da0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
a262216e-373b-4231-988b-8966717879db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
a3952170-bbc6-44df-908b-2ddd4aec18c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
a51eb0c0-b5b5-4578-946d-e5b90f3b1cf5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
a60152ac-7ffa-4307-835a-8f5d3e74045d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
a7e22674-3d61-475d-9e84-acfa44994e24	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
a85a52b9-c269-4efc-aac5-6c6d47f93654	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
a9c2a338-7c08-4255-94fb-0bd7c45c283a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
ab56d6ec-fdf1-4d64-9293-db7f571be8c7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
ac2783e6-48ab-45ad-abf9-e0fd3e73c337	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
ac3723f8-9be6-4893-9083-e15f61bd4df9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
b1372774-7834-428f-adbd-a65416fb0667	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
b22b1c17-d3dc-4691-b735-867cfc07169b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
b5cdedca-ae41-4208-8bac-dcb50c82e085	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
b6297efb-c9b6-4aa4-95d9-d868fca7eb9d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
b700eb7d-c2d4-445f-b66f-1949f20d45cc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
ba0e4120-ce83-4b6b-a773-a7608c9ab6fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
ba9f89c5-bca8-4060-9c25-2b24b188c45a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
c581f993-c590-40c2-8ba4-60577d3776b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
c6afcce0-cc91-49c6-a5ce-e31715423c08	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
ce711283-f774-469d-a311-9046810c12b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
d52c707e-f2ac-4694-8aea-11170130b2ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N
d6b4bc72-8e32-4ee8-86bc-2fadfebe918b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N
d89f0aa3-d3cc-436e-b609-4aa5d7cea7b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
da03d703-2058-4553-bb88-99cf9edfeacd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
dba4c117-51d3-4aac-a1a9-8e32506f3e11	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
dc370da0-6cfe-4fa4-be72-fa06f177bdca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
dcf95c24-5efe-4917-a254-a976fa0782b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
de47d95b-6ff3-4f77-a4e0-6baefc36d21d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
de9b6a2e-d425-426d-bf8a-6bfc8818d66d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
e331c1a9-498a-4657-b488-ea3f8292ac3f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N
e621af9b-7976-4c6c-8bd9-e45ac4fc96e6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N
e68754c3-407c-4c8d-9c76-440cd5c85284	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
e7004cad-dfbf-4baf-ad59-8f87c3a727aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
eae8115b-4db6-48dd-8182-019f4dc44b2c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N
f04a2861-811b-4bdf-9cda-f2028e45eff6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N
f97ceaaa-0679-4f84-9c68-8f93257735a0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
fa4965b4-4fea-4895-a862-5ced93c5d226	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N
\.


--
-- TOC entry 5215 (class 0 OID 26453)
-- Dependencies: 225
-- Data for Name: heroes; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.heroes (id, user_id, version, created_at, updated_at, base_hero_id, health1000, strength, agility, intelligence, crit_chance, crit_power, haste, versality, endurance_physical, endurance_magical, resist_damage_physical, resist_damage_magical, equipment1id, equipment2id, equipment3id, equipment4id, equipment5id, equipment6id, equipment7id, equipment8id, equipment9id, equipment10id, equipment11id, equipment12id, experience_now, group_name, level, rarity, damage) FROM stdin;
00d15172-a3af-4d5b-b74a-afff5e4f40ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
0266366e-b12a-469c-803f-b7ee15b27873	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
04656b9b-054e-46e5-a1e9-37a89f7a567c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
05dffd34-79a7-4ff1-acf2-21fd50813567	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
0754256d-73cf-491b-9db5-6d602d5f6d85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
07a88b06-e936-47ad-a6b6-3a7bcbc9b2ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
08408de3-dae4-4f8c-9d2e-0a51f2a7f2c7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
08e3971a-f82b-495d-99d8-500b901ef8a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0aeef53d-4cd4-418b-afbb-f5410a3f3928	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
0b643d98-6e79-435f-933d-e5509760dd1a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0cf13183-5006-4ec3-be7d-b5c6baf97f32	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0dfbeb24-96fc-486e-8a45-8e07a6c40aa0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
0ed634b5-ecc9-43cb-835d-4be0cfe2d7fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
143d2a3b-b95e-4d37-8c43-469d7adb0bd4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
14b74ba6-ac36-4175-a598-a1635ac7d990	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
15997452-6402-4b73-9e45-317bf4175749	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
15a600d4-bd74-46b8-b517-7aef13bf8409	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
164918fa-e22a-4967-98b5-133fcf95a176	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
17e05720-b2b4-42c4-86fc-e07b7a110099	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
18cbf529-1ff3-4207-9471-7fc56481c5b0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
1bf8858e-4976-4c1e-a1ca-4536fedcd9f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
1c126ec2-7da6-4336-99e2-193f91ee4ef3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
1c668c54-9a1a-42dc-8cde-0726b2e3c3e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
1eca8648-1ee4-4a2f-85f9-bfddb1d553c4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
21b8d7da-a0d5-464b-a845-4afb764f9314	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
2338b545-48d8-41f0-bb27-1706937571c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
235a0901-ad04-48ed-96a2-1cfa40889ba3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
24217f56-f036-4aa6-9903-28891644aefc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
260dc441-c013-4e75-8e4a-8d131d2f37e2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
26953a41-ac9b-4a74-851b-483d85cfdada	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
27ab0120-3d47-484f-ad6a-3417ce5562cf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
28b197a1-4e7e-4dd4-9b80-1634ae196c03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
28b6618a-e460-4a11-a1db-0006e70a8a03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
29149a2a-f227-4e48-b3d8-45784b5f5fe5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
2994039f-7818-4bc3-8496-40b1908b048e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
299b966a-b4d9-41fc-a78c-5dcf9d55e176	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
2a2dc63e-0ad8-48fe-9544-bcab07ae160a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
2ab86ee2-ae56-4008-9b1a-d034c1790977	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
2d8330a3-ee74-401a-82a9-b738dd4a13a2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
2daf9231-5dd6-4957-b81b-734092b3e3d2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
2e0d1dd3-3445-462a-82b9-291d67f5dba0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
2eb96905-9161-4046-b21c-ea225a83c57e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
2ef1f600-ff3a-4fee-a4cc-3c156cc8879c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
33136c07-231f-4e3a-9d28-754750e34c82	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
347c32b1-be4c-424c-b9f2-26f0b6e7b8f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
352f4318-ab60-4d8f-8733-b4a06b837a28	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3554516d-5d1d-40dd-bc0a-382f3cdd6175	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
35ce8e97-293c-4498-8080-6f7707a951ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
36621c98-6130-4705-bc35-e4ee62bf9834	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
37321558-1511-44ea-9dcc-f3abacc0b722	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
39533131-8e76-494e-b892-72e0bdaca095	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3a004616-16ec-4fc0-84f3-979ca75f5458	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3a4f3e78-8e09-499a-b51f-0ab76a642cf1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
3c8f700c-7c97-4b9c-beec-bce8386fab21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
3dcf3d9b-18cd-43f5-9ac4-7f2a6e9cbc4b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3e08f530-b3e5-4c2b-83a3-6a30c1d70895	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
3e3bb90b-9765-46ad-91d0-0af6e027fa60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
3feae5f6-4173-43c9-8674-9472be58d11d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
417d044d-f573-4ff9-9494-0f5e7e2bb983	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
43de1edd-e6c0-436e-a72c-ddb657a37c67	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
444c5f8d-541c-4448-b2d6-f08e81e84a02	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
44c7f1b3-7a29-4af2-a641-1aedee48ad49	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
45c4bf90-5f56-433d-aa18-2c53a79c55a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
47384d33-dfb2-4e33-8953-f1f237e4dfe1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
47941a9f-9397-4d41-b8c6-7ccdb4038c03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
47ad56fd-e6e7-4b14-adb2-14c90cc01041	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
498ee4a9-4814-496b-a57b-2186a17501ca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
49b9cbda-2d0b-43f3-a3c7-b902216a458d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
4b216c1a-dcd8-4bb6-8dd4-b65323e7659a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
4badfaf1-690c-4eec-bc94-88cf458bdb2f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
4de978cd-1498-4ea9-8b3d-5f7a9f49dead	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
4e2bd5bd-e070-4833-a399-c36169364991	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4ed77d72-b373-43d0-a740-71c5986d6b8a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
50140a70-35e3-48fe-87ec-78d750e87829	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
51f0791d-c533-4e99-bfc5-45487eb0b798	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5378244b-33d9-40cd-b979-f6caf9e20624	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
53aaa744-d42f-4ba8-a9d1-f780be297b2e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5483ba12-b589-42f2-840d-e95ccc5353bc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
549109c6-87f6-4e13-8208-7e8de50e07e7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
566dd384-a6ee-43cd-88be-7ed3c9870edb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
567aec0c-fc1d-4f68-9208-3d1ec66d8bc5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
57a8f725-f89f-4536-a1a9-baa402c2eaa2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
587a8df8-3c79-4f58-872c-e4942752f0a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5a6e0f92-82b5-4a21-a0e4-121bc823e0c6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
5ca8da99-0bb2-416f-81ce-c687393c6eb6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
5ca99e73-3fc5-45b3-9da9-7f90aaf8a727	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
5d263dfd-f053-4b02-8bd6-6ba87393d3c0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
602632ba-91bc-4d93-ae4c-456df49617d1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
61bb7d59-a254-40d8-bdfa-7cdbebd7de8b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
65e4d6ae-c24f-4b06-adc8-a88b3da71afa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
67aee31b-94ef-4e2a-9fa0-f2440106123d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
67b0ded4-13d6-4ff7-a84d-813cdaae250d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
686f057b-c241-4482-9cd7-05a9877564b2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
69079a58-6f66-4573-891d-aa2148178761	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
6a7b5600-f310-4b58-8c06-42f2227ae46d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
6cf5f15e-d67b-4c4f-aa46-4e4073b1fed4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6d65f37f-e3c4-4698-955a-40726263b0ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
6d9e52cc-2644-47df-a0c8-86671aaedce5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
6db66014-a2ad-475b-9a2d-e0a2b1432eec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
702d89ff-47ad-4a87-838a-2862346fea1d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
70ec6702-e712-4f01-9ae1-c9917103faed	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
72dfce7a-6b85-4b56-ac05-efd8abe1fdb8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
72fd8f83-0e33-4355-9743-829c68f17501	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
7309230e-9f0e-4e56-985c-c79a1320ea97	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
73162e8a-595f-4001-8757-fe1ad4aa6c33	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
7573ced8-e346-4d0d-a836-8bbb4e2bdf28	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
77da8bc1-f6d3-4aa4-86e2-0dfdc647cc4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
77fb8139-31ec-4fdb-9626-8cd844159158	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
79a7bf50-bfa8-4d9d-a940-669caa4877e8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
7a2041d7-3afb-4301-aaf2-0c589ba59b43	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
7ab5047f-d279-4ae6-bac7-a5d06e480986	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
7b30180a-c80e-4d8f-b471-24a7a979e61b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
7c83549e-9983-45b8-b5a1-6d6de58d7c79	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
7d0f369f-2d57-4d41-97d5-ac3c53703898	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
7f09f517-1cfc-4dc6-b01d-bfc75bb06a26	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
817541c5-5ae1-453c-bfc1-f77ca632f52b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
84932dae-6f57-43e8-81c9-7f00d00383d7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
84b0d445-4047-4d32-84cb-34244a67d72d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
85241ad0-9eca-4ca4-a615-69cd595423b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
85f46ec5-d1d6-4771-a3d9-20dcae0dca4b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
887a9f50-0b29-4162-bd96-31be110f0e41	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
88c4caad-6959-47a9-a66c-668111d847f8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
89e6ad14-944f-49c8-ba88-84d26dbd714d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
8ebb103b-a606-404e-89dc-aeb034769481	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
8f353329-0d5c-45e6-b845-f0cce6b63002	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8f3a7207-72c7-45bf-9e90-f54d99845a59	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
90414897-1a40-4503-8b40-7ec27abe4996	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
91030051-7ab7-4c87-bd45-5995f27f21a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
912c2462-9baf-469b-b864-df1981b81198	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
91ba5479-f3ba-48d1-9610-616f4ea1ad13	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
924f92f3-1031-4251-88c7-79d58b1bb6f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
92ce93cb-9ab5-47e3-8eb7-bcd596e379b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
932acfe8-1010-4f6e-88ef-dc51a3515442	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
93913d4f-eb01-4f5d-8706-d086436bd816	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
9404d5b8-aebf-49d6-94eb-583a43c37ea7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
94f6739e-b3a2-4463-bbba-d07f067c754c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
96c51438-3f00-4037-b046-f84abd0c9c5e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
976ad311-bcc9-4529-9c4f-2248e4a6439c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
9879c96e-c051-420e-beac-04d7177203ad	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
9972340a-728e-4772-8ac7-7e01752ad3ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
99b7f946-a50a-44c4-8a45-e07e703fe563	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
9ab7e8b5-87ba-41b6-9372-bdb2c353b9a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9b280c5f-fbaf-4676-8c97-0db424ee52b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9bf7a6bc-db0d-4cb1-898b-33c972ca0977	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9c366980-6b1c-499c-9839-9c8467da26c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
9ca6453f-e5d8-4cde-9629-038316cbc150	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
9cdcf225-7d3a-4abf-ad76-34a2a6a88f54	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9dec1ea9-34e4-48b6-9e56-390e7064e518	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
9e39cbe2-b61e-4ad2-ac1b-e25d6835ff90	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
a06c3454-2df7-4f50-8c6e-e1b712329a12	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a2a422ff-d378-4d31-b983-8338200adb85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a556f541-3a99-43fb-b7b7-c540f3c1137f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a73a02e7-200d-40ef-91d2-d0e3f9a12d3e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a7586e78-024a-432a-8a10-ecc2dfc44a16	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
a810022f-b398-4cdb-b121-5da91566af50	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
a928352e-38b5-491f-987b-4616c1c557db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
ab19f278-6e8b-42f4-b4f8-b757e84524ed	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ab96228d-cfee-460d-a42b-4c8472f13fd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
ac2c2a75-11f0-48eb-8265-60c582270c43	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
ac77287e-2332-4bab-93ef-c92485d3d887	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
ae954a8c-e01b-4848-a0ac-3b62fdb22ece	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
affbc6fd-eb14-436a-8072-e998d5f6df4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b168f7f2-a4f2-4a7d-8fe8-d2a3f8751931	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
b2057ed6-7d8f-460d-8092-ea8fc8aa0843	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
b3157acb-c35e-4ebd-896d-c558762f42e1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b3232122-d4e7-449a-aa9a-1ea3c000415f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
b52ddded-2886-4028-a8c5-312a9f7d4b67	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b635e153-c218-492e-b961-af2c5deb985f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b7fc51e6-bb13-487a-9ce9-f7a11461d255	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b95e820e-eeff-42ad-a2d3-e9eb7fb2864b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
b9bafd58-7007-472f-8b49-6d21de3b7ce5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bbd74e3d-60e1-486d-a528-2dcb93c5f09d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bd019229-908d-4a6b-89ea-ded814b6343c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
c184f138-d63e-4a9d-82ad-5dc2f675f73d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
c28d7f23-b962-4b6a-8273-cafc97bc1984	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
c2c1f159-c5d5-45ec-8ad3-7bb85c7ad697	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c355be9f-5f2d-4a0d-a29e-614cbe507803	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
c5995d09-8512-49a1-bcb2-c45c409876e6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
c59bcd6f-fbed-43fb-a0de-80f6bbc72de1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
c7205015-f658-4978-a048-cfdf148bbe68	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
cad48311-9743-4f9b-baf4-d59c410afbb0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
cb3112b1-6623-4243-bd3c-9db977223401	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
cdca3c82-9a42-4739-93b5-6e815921883d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
ce9c45fa-65a9-45ed-b8b1-99ff12349fd4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
cf7ccdfe-58aa-4457-85dc-6020ab16a872	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
cfbae36f-dde6-4fc9-9984-96332b4df1a0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
d05000de-d4b1-4968-9cb6-1e2a9a71651a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d476bf17-3e8a-4ed4-9185-bf53826f3c7e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
d5e5039c-64c4-4640-a884-7ff67ce83917	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
d63fae21-d77f-4267-b614-f3fec4a5013f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
d65c68f7-8f0b-40bc-9406-e21ab3995426	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d7012e7f-7d97-4860-b490-2ffed166b752	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
d9addd2a-4362-4893-af6a-3939578711c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
da070b1b-2c6d-4c82-a5dc-8d00e70163ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
db45a856-033e-47b9-9aeb-5b95a4f4fc62	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
de36369c-53ef-4eab-901e-d4a494bbfe6b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
df3d5869-fd33-436b-a34e-ae200a67fbc3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
df6a9350-2d5c-4626-934b-2d87f272c209	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
e0273cb3-0aac-47a9-b1c1-80f2fef6964d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e1a90213-17a4-4a31-be8f-6b90c9977891	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e47c25a7-53e8-49a3-bbe2-08ff8d39c299	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
e5b44b3f-8179-4e43-b1cc-e7a0176fbbb1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
e91cc994-36ea-4186-ad1f-7c1b100e3639	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
e99a18e3-b1bb-429f-99b4-f7c0bcf9198b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
eb1f65e7-0c6b-400f-ab99-f573986a5e2e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
ed418019-be95-4ce1-b66d-b6d77bb819bc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
ee9aabcf-d974-46fb-954d-63a6b95f181b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
ef074ea3-d9df-4dbc-b770-b12c6103017f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f1340e8e-e78e-453f-a504-ea78bcfa95a3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
f175eeaa-a3a8-4e90-97aa-100261d4fe52	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
f3aa4050-9419-4d39-96e4-e679f3d12531	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f41e2f91-2f66-4c3d-bf89-042319dbf9d0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
f43c1ce5-23d6-416c-b15c-1f48d4094408	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
f45ae12f-83ed-43b3-90cd-b45d7dc8f5f0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
f520e26b-8245-4a73-81e2-df07196c7835	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
f6c8110a-2387-4948-bc41-0e476dc2dbf9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
fa372fc6-1741-4b3e-99ab-6e02755b622c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
fa3b5524-a911-4f8a-a7d9-f1aecb2426fe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
fb283b84-6e4d-466c-998c-a4b0b1099330	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
fbb50ac2-4700-4f88-908f-d6ca43309560	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
fbed6823-1e5e-4687-8d70-8eb1bf80d40e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
fce0c821-3b32-45b9-8099-d9fd1b1627f8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
\.


--
-- TOC entry 5216 (class 0 OID 26483)
-- Dependencies: 226
-- Data for Name: base_equipments; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_equipments (id, name, rarity, is_unique, equipment_type_id, health, damage, smithing_material_id) FROM stdin;
1	Iron sword	1	f	1	\N	\N	1
2	Iron axe	1	f	2	\N	\N	1
3	Thunderfury	4	t	15	\N	\N	11
4	Iron armor	1	f	28	\N	\N	1
5	Iron gloves	1	f	26	\N	\N	1
6	Iron helmet	1	f	27	\N	\N	1
8	Iron boots	1	f	29	\N	\N	1
\.


--
-- TOC entry 5218 (class 0 OID 26495)
-- Dependencies: 228
-- Data for Name: base_heroes; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_heroes (id, name, rarity, is_unique, main_stat, health, damage) FROM stdin;
1	Warrior	1	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 24}}	\N
2	Huntress	1	f	2	{"damage": {"c": 5, "s": 21}, "health": {"c": 10, "s": 28}}	\N
3	Hammerman	1	f	1	{"damage": {"c": 3, "s": 25}, "health": {"c": 11, "s": 39}}	\N
4	Rogue	1	f	2	{"damage": {"c": 4, "s": 23}, "health": {"c": 15, "s": 21}}	\N
5	Battle orc	2	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 58}}	\N
\.


--
-- TOC entry 5220 (class 0 OID 26508)
-- Dependencies: 230
-- Data for Name: creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.creature_types (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5222 (class 0 OID 26514)
-- Dependencies: 232
-- Data for Name: damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.damage_types (id, name, name_ru, dev_hint_ru, category) FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)	1
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 	1
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)	1
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда	1
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"	0
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."	0
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."	1
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."	2
11	Radiant	Лучистый	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."	2
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."	2
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."	2
17	Dark magic	Тёмная магия	Критерий\tНекротический урон\tТёмная магия (Shadow/Dark)\nСуть\tРазложение, смерть, конец.\tСтрах, боль, подавление, коррупция.\nИсточник\tСмерть, небытие, пустота, анти-жизнь.\tОтрицательные эмоции, тени, извращённая магия, пакты с тёмными сущностями.\nКак выглядит/ощущается\tХолод, влажность, запах тления, серо-зелёные тона, иссушение, гниение.\tХолод или ледяное жжение, ощущение ужаса, давление на разум, чёрные/фиолетовые тона, искажение света.\nЭффект на живую цель\tВысасывает жизненную силу, вызывает быстрое старение, некроз тканей, разложение.\tДробит волю, наводит ужас, вызывает боль, ввергает в отчаяние, может подчинять разум.\nЭффект на нежить\tЧасто исцеляет или усиливает (это её родная стихия).\tМожет наносить урон (как любая агрессивная магия), а может усиливать, делая более агрессивной.\nЭффект на демонов/исчадий\tОбычно эффективен (смерть для всех).\tЧасто неэффективен или даже подпитывает их (они сами из этой энергии).\nТипичные заклинания\t«Палящий взгляд», «Круг смерти», «Вытягивание жизни», «Увядание».\t«Стрела Тьмы», «Объятья страха», «Проклятие боли», «Порча разума».\nАналогия\tРадиация или смертельная болезнь. Убивает всё живое, разлагает материю.\tПыточный инструмент или психологическая пытка. Ломает дух, чтобы сломить тело.\nЦель атаки\tТело и душа (физическое уничтожение).\tПсихика и дух (ментальное подчинение → физический урон).\nАрхетип мага\tНекромант. Холодный учёный смерти.\tЧернокнижник, Тёмный колдун. Эмоциональный манипулятор, заключивший сделку с силами тьмы.\n	2
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."	0
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."	0
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."	0
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."	0
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."	0
\.


--
-- TOC entry 5224 (class 0 OID 26524)
-- Dependencies: 234
-- Data for Name: equipment_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.equipment_types (id, name, name_ru, mass_physical, mass_magical, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, spend_action_points, block_other_hand, damage) FROM stdin;
1	Sword	Меч	1600	0	1	t	f	0	\N	{"c": 8, "s": 4}
2	Axe	Топор	2800	0	1	t	f	0	\N	{"c": 4, "s": 17}
3	Halberd	Алебарда	4400	0	1	t	f	0	\N	{"c": 4, "s": 27}
4	Berdysh	Бердыш	3800	0	1	t	f	0	\N	{"c": 4, "s": 23}
5	Poleaxe	Секира	4000	0	1	t	f	0	\N	{"c": 4, "s": 24}
6	Chakram	Чакрам	350	0	1	t	f	0	\N	{"c": 5, "s": 3}
7	Shuriken	Сюрикен	180	0	1	t	f	0	\N	{"c": 6, "s": 2}
8	Scythe	Коса	3200	0	1	t	f	0	\N	{"c": 5, "s": 3}
9	War fan	Боевой веер	800	0	1	t	f	0	\N	{"c": 5, "s": 3}
10	Scimitar	Скимитар	1200	0	1	t	f	0	\N	{"c": 6, "s": 4}
11	Katana	Катана	1100	0	1	t	f	0	\N	{"c": 7, "s": 3}
12	Yataghan	Ятаган	1000	0	1	t	f	0	\N	{"c": 6, "s": 3}
13	Sabre	Сабля	1100	0	1	t	f	0	\N	{"c": 7, "s": 3}
14	Morning star	Моргенштерн	5000	0	1	t	f	0	\N	{"c": 1, "s": 123}
15	Warhammer	Боевой молот	6200	0	1	t	f	0	\N	{"c": 1, "s": 153}
16	Mace	Булава	3000	0	1	t	f	0	\N	{"c": 1, "s": 73}
17	Crossbow	Арбалет	3200	0	1	t	f	0	\N	{"c": 14, "s": 2}
19	Trident	Трезубец	3400	0	1	t	f	0	\N	{"c": 28, "s": 2}
20	Rapier	Рапира	850	0	1	t	f	0	\N	{"c": 8, "s": 2}
21	Pike	Пика	2800	0	1	t	f	0	\N	{"c": 24, "s": 2}
22	Spear	Копьё	2200	0	1	t	f	0	\N	{"c": 20, "s": 2}
23	Broadaxe	Широкий топор	5200	0	1	t	f	0	\N	{"c": 4, "s": 32}
24	Dagger	Кинжал	400	0	1	t	f	0	\N	{"c": 4, "s": 2}
18	Bow	Лук	960	0	1	t	f	0	t	{"c": 4, "s": 2}
26	Hands	Руки	1240	0	7	t	f	0	\N	\N
27	Helmet	Шлем	1240	0	4	t	f	0	\N	\N
29	Boots	Сапоги	1860	0	9	t	f	0	\N	\N
25	Waist	Пояс	2170	0	10	t	f	0	\N	\N
28	Armor	Доспех	2480	0	6	t	f	0	\N	\N
\.


--
-- TOC entry 5226 (class 0 OID 26544)
-- Dependencies: 236
-- Data for Name: material_damage_percents; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.material_damage_percents (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5228 (class 0 OID 26552)
-- Dependencies: 238
-- Data for Name: slot_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slot_types (id, name, name_ru) FROM stdin;
14	Ring	Кольцо
16	Trinket	Аксессуар
1	Weapon	Оружие
2	Shield	Щит
4	Head	Голова
6	Armor	Доспех
7	Hands	Руки
9	Feet	Ступни
10	Waist	Пояс
17	Neck	Шея
\.


--
-- TOC entry 5230 (class 0 OID 26560)
-- Dependencies: 240
-- Data for Name: smithing_materials; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.smithing_materials (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5232 (class 0 OID 26568)
-- Dependencies: 242
-- Data for Name: x_equipment_type_damage_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_equipment_type_damage_type (equipment_type_id, damage_type_id, damage_coef) FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5233 (class 0 OID 26575)
-- Dependencies: 243
-- Data for Name: x_hero_creature_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_hero_creature_type (base_hero_id, creature_type_id) FROM stdin;
\.


--
-- TOC entry 5248 (class 0 OID 27014)
-- Dependencies: 258
-- Data for Name: auth_reg_logs; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.auth_reg_logs (id, email, user_id, success, version, created_at, user_device_id, ip, action_is_authentication) FROM stdin;
71a71144-316b-4530-8fcb-ab9307943346	SUPERadmin@mail.RU	\N	t	1	2026-01-02 00:11:42.371645+08	\N	::1	f
09813629-2b45-4230-b8ab-4dc92468578b	SUPERadmin@mail.RU	\N	t	1	2026-01-02 00:12:35.714515+08	\N	::1	f
3d9bd4f3-612e-46d1-8b28-84b484c8a6f5	SUPERadmin@mail.RU	\N	t	1	2026-01-02 10:52:16.837456+08	\N	::1	f
8fc23f7f-6904-49a0-bc30-fc3156f7656c	SUPERadmin@mail.RU	\N	t	1	2026-01-02 10:57:55.461398+08	\N	::1	f
ea4e7f09-fe44-44f1-b2ae-9807b0809cb1	SUPERadmin@mail.RU	\N	t	1	2026-01-02 10:59:42.158534+08	\N	::1	f
92fbd663-1ae8-41ba-a0fe-fab900402652	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:32:43.559755+08	\N	::1	f
23176af5-6d33-4cd2-974a-146fdfd3752a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:32:53.585177+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6ca8bd58-abe7-461d-9aa5-9362d7d0b972	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:36:08.552296+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2bb2682c-112b-40d4-a3c4-4ae68af98748	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:37:03.563437+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cbcb5337-be48-411c-a96c-58a48f700294	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:37:53.549686+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
57aab23b-8eab-413d-b5aa-7c4dd27e7b36	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:39:08.563693+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
492c2e49-c016-4aa2-9e03-081de2bede86	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:40:03.553397+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e8d451ef-b8df-4181-ab81-030cb03dd262	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:41:39.44512+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0188d17d-bc85-4074-9e21-364fa12166ac	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:45:04.339918+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2de1ef76-1d59-4952-9ce5-0f27f4383ce6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:45:22.17775+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cbb3d23c-a7ad-4c97-94b2-5f88675d5cdb	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:45:57.121681+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
560c5a21-3626-46b8-b47d-babb6b868119	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:46:12.080752+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
39167e3a-120b-4ab2-8c11-fd476b200508	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:47:25.893726+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
363c7ea1-6a15-45ba-a8cb-86589869f1cc	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:48:00.807997+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b6a74205-b6e2-445c-b2f8-c79db7185e8a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:48:35.770324+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9ce3acfb-690c-420b-bab1-e9ffead31b28	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:50:05.776837+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
40eaac14-3e5c-40cd-aae1-c82ca3e7e6eb	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:50:20.770259+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e2b67c45-5784-4f1e-a197-212206e87f76	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:52:00.774426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1bc76057-a9dd-4d6e-8445-b94edc948c9a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:54:41.936821+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
df87a4a4-485a-421f-bc3b-895bf32adf4e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:55:11.853077+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
72c54948-2d12-4404-8b77-64624f76868e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:56:21.835368+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2eb2fd7c-c4ae-4d36-b5cd-51490c70d89c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:57:58.693925+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ab2c2c03-de76-4239-b1e9-392e4ccc7eb3	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 13:59:13.582034+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
93e785ab-4bbf-47b3-a757-f7e0d5a9d636	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:02:01.383439+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
25478e51-c95d-452f-8739-70c92b81f0d5	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:02:41.154421+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3226b745-f503-4d6f-952e-0c0170f30644	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:37:18.452495+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
af23cd4c-746e-49c5-b790-6f6613abe9da	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:44:07.479777+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
dc709891-0755-417b-9c42-31c614a9fcfd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:45:50.837765+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9e055232-2f19-4001-ba5b-49b0d9140850	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:47:56.707208+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0a7e545f-9235-4dd1-91d0-7380e3e52bd4	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:50:42.312118+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6f29a4cf-e079-476e-b646-3d13d9bfa846	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:50:52.225168+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0ed64679-9004-4224-a672-0dd67bb9981c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:52:51.644232+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7695a98f-3441-434d-94cf-24a5465ceace	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:54:11.576177+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6328ccac-08de-48ab-9c14-7d96b93c5727	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:55:37.370762+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d3b3c019-86b0-4482-9046-a35b3a72a07a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:56:02.296767+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
22515d44-c94c-40ad-a9a6-1dc5f3bea743	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 14:59:51.790728+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
815c581b-372f-4d1b-ab9f-9ea3459d5b14	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:02:07.220659+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
544fdae5-e6b1-4305-a2a0-309e9bb3dd03	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:03:21.837268+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4fa4d608-b6d6-4f73-bc1a-2060463afa29	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:04:16.875283+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8806f029-e83a-4939-a6e4-616fac452b11	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:16:05.441375+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3ba3f347-a050-4714-bb83-1b77009be694	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:23:00.648812+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5ac1e580-bba1-4aec-b537-c7671ae48714	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:23:20.479146+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
dfa47a1e-12ec-4b37-abb7-41bb15db066c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:24:05.457418+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1487db39-4650-47e5-affa-da4ac8c8c845	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:24:25.448785+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3fd37551-2384-46f4-bfdd-bc7f5993a9af	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:25:25.462777+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
52a57ac6-f0d5-4fcf-93c1-7b9825d7b5db	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:26:00.455459+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
69353c7a-ad32-4922-a39e-c0a99902dc7e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:28:33.285147+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1da1fab6-c3fe-43ac-b49a-fe80683dc4fd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:28:48.19455+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
144b6c9e-4288-4962-8c74-12d1d03557fb	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 15:30:51.830137+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b86b59d7-26c1-48b6-a516-d76e79adb503	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 16:32:59.299886+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
bf7b00b3-4e8d-4798-bf4f-386d4581a931	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:55:08.509977+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ee46000a-323d-4d2c-9f93-8ad5c6f2a408	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:55:38.457619+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d846d533-47e0-4065-9bb2-e98271996256	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:55:58.433802+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e98529e9-56e1-414a-ae1e-8caa7603b482	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:57:33.42592+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6b4138f8-4c51-4473-8d97-102d4ef996dc	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:58:53.429441+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
34eb07cb-c183-408e-bec7-fcc17654dcb1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 17:59:13.423363+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0f751873-6309-4be2-8b8d-fb40f715164c	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:00:58.42813+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ae101342-f230-4e50-84e7-468f679d5f99	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:06:13.914208+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0509d1ee-fd4f-40ef-a3b0-42caa442ae32	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:08:20.594881+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3ffb6602-bcf6-4dd6-b5a5-e7e8f31b5924	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:17:15.522619+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
91a3e543-12a5-4a7f-8eaa-79d5293e14f5	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:22:25.485956+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3d55943c-f4b4-4386-ae9f-a17686094a50	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:24:05.49302+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c64d4b8d-76d3-440f-8f00-fb878cddbabc	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:29:00.49528+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
684a4515-ecdd-4dc5-ab10-981034b09132	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:31:20.49667+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ac4c50b8-2d05-49d2-9569-65b8e651bfa7	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:32:00.486618+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
239f2563-a2a3-4538-b42d-662e8f1f8d7e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:33:25.485896+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d5faab10-4135-4f7a-8f3c-4f19f5ee1b66	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:46:30.485642+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c370e45f-d8cf-40a7-8f39-ba827542a98c	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:49:00.484928+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cbb087f8-17c8-4ed6-99f2-6a755594f5af	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 18:49:35.492159+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a7510f49-fbe1-4f64-8cd3-9554daaf1e2f	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:01:05.52426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
16a3e5e5-c221-4ec1-ba92-e8ec557b77e6	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:10:30.488393+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6d45ac55-380c-4a05-b42e-8e727a92ed8e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:11:20.488928+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
157228a0-096e-4019-8572-3031399c8001	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:12:20.48864+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f54e8842-677a-48cc-bb76-c96b9f3095d5	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:12:50.489775+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
404faa84-c533-455b-8554-b752b19ff06e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:13:35.493181+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4b2dd22e-2a65-4e53-a70c-c920510a0301	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:14:10.492961+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c55adc8b-073a-4fc9-8309-b214bfbc3334	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:16:00.482302+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
04ef5169-0b9f-43b6-af85-d1cfb9bbaa47	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:16:50.496701+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9a14c9d7-d9b3-4a32-a9ff-37bca6220dde	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:23:40.495151+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
17061018-3419-415e-9e59-95eb220f0a72	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:26:35.492572+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4202f9c3-d49e-43e4-9659-b8b181a5e850	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:42:40.487852+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2033f071-a874-4016-a70d-5df5ececf81b	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:45:19.77623+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
39c04f76-f8cf-446b-a83a-98497e8071e8	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:55:37.545692+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
bc6623cb-528d-4612-b158-c030ae5cf836	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:56:42.44766+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
fb168619-5be3-41aa-a98d-d1446e773f0a	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 20:59:22.995494+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
87bad630-cfd0-4bec-beff-51cd39a04aa6	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:00:22.919556+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8c546c3e-0eec-4f8e-9a7b-8105b8064a9d	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:02:42.881803+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d1d75a6b-2eb9-4749-a534-08f88819a0b0	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:05:12.891581+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d85f3965-b4a6-446f-a1fc-dc432f23ad28	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:07:22.896553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
60f1f354-ed8d-4f75-acc1-17f4fb2ced75	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:15:42.892882+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
de822b78-b7bf-4fbb-a67e-f2f7a3070065	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:18:57.88284+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
293e3304-0f21-42bf-bbba-4bf1ddc108ec	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:20:42.88661+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f86daf09-d574-4cb4-a815-9d548c6b7575	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:26:32.890176+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
31ea6688-6d99-453b-b86f-1a80f4361e84	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-02 21:47:23.409136+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3c2753a2-aa16-433e-852f-3f54a3de194f	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 12:04:32.750931+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
fbd0533f-df39-4d52-a626-edbc2dfdcb14	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 12:05:35.920606+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1bf79676-cdb8-4e35-ad8a-27038b44b800	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 12:19:23.662481+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6935fb7b-cb35-49e1-98d5-1b18304c3a22	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 12:20:30.753773+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cba26513-7dbb-42ff-9c04-35fd73d41923	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 12:25:44.052961+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9df39901-371d-4a37-aef9-0a376d4216e2	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:06:54.008523+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a6ba703c-2e0a-4d11-8ef1-e7d43240d347	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:07:44.140336+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9d9c8f57-438e-4cd3-8df5-2ed1573e8638	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:08:54.098632+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
58ee850e-965a-4842-ace5-62bcfcaa25fd	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:10:40.360798+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
53ab2e11-3caf-4e90-af83-18d3b79d606e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:11:50.314102+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0e4574ff-8c71-4ced-aede-5c970c07acfe	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:12:00.298989+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
10005bf1-45ae-4518-b0a2-1ecb5d59525f	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:13:00.291168+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c298b6c0-f056-4416-ae8f-7eb984022f48	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:21:45.291337+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1823731a-d60e-4046-b6da-95a582d6bf39	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:23:15.28998+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
587b56ab-c4a9-4727-8a5d-5a9791786ef5	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:24:10.288366+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
581053f0-aede-4f9b-809e-26f654adba17	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:41:23.53619+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9156c059-876e-45f6-9823-a8c55f365eab	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:42:23.486683+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ba144579-7050-45c5-ac00-1bc3467b589e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:42:53.45426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b31fa328-569a-4107-a667-2d1e0ae9814a	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 14:43:13.445212+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
133fe29d-cd32-402d-aa0d-d4d8517ac4cf	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 15:07:34.562979+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3b63b0ce-892c-47a6-9b5f-36f56117afb3	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 15:30:20.233299+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c1449531-f5dc-42da-ba80-5ba4ae47bed5	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:08:55.459639+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
91312fc9-47c6-47c9-b059-a0a0b9f7acbd	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:09:05.391718+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
46fcbed6-4923-46f9-aff7-1b4800e9fb38	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:12:49.158177+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
bfbd27d4-e975-4c49-a011-d6d32547b33d	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:19:49.086208+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
edef0fe6-2053-4d9d-9b16-24adb2cd910a	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:22:09.05996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
206b047d-bd29-45c3-b381-5ea0fe49aec4	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:22:39.060967+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
14ff58cc-5353-4df1-9ef7-6c0dfea8804e	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:37:49.050259+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7bdd62c2-bf02-4e09-a991-235148312b1b	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:38:40.278934+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3e9254eb-9508-49ea-83a2-9996c595ee0c	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:46:26.257883+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
052c603a-cd1c-4b84-af11-a91db9f56e66	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:48:11.992871+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
22950050-7b35-489b-8ddf-5a01f9b64e52	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:48:42.224181+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
22624cd0-8300-4cfb-922f-d14aa261860f	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 20:50:26.372465+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b1f9742a-9495-4209-a13c-8c5b0dcf1290	SUPERADMIN@MAIL.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:17:43.294846+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b533142d-f85f-417b-b679-35fea2f2d167	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:26:08.225376+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f7df6c68-c5a8-4e8d-993a-c5ac3e502efc	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:26:28.190904+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f402727b-a526-4034-a44d-a4fb8caf91b2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:27:03.200039+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0b4f5f40-e54b-44e5-a86f-97a739dd0bd4	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:50:33.193391+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6fad33b3-ad85-41a8-b3f8-68c5229e6d0f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:50:53.201948+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cfd7fb04-75d6-4995-b493-8d4e561d6113	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:51:23.204021+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
51f5448b-4040-4075-8c04-61b394a0a7a0	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:51:33.201519+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3365b65d-1ba3-4eed-94e1-6303f4777032	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:51:48.196584+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ca912fa2-9927-4963-8118-ca2c3a170194	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:53:13.195454+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
39f50487-76b3-467c-862e-72af1b936c2e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:53:28.197909+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f4120687-5243-435c-8bff-ed77d109b4bd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:53:38.20221+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7f15c525-108c-4532-8204-d4b096c37c07	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:53:53.193569+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
439367d8-08a8-488a-ba3b-74393526ece7	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:54:23.484728+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ec60dc10-7cce-4715-876f-4e53f71e15b2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:54:33.506445+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
846e5d1e-1fc5-4c46-a7d1-dbcd56436677	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:54:54.956615+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a77864d0-af45-47ed-bdaf-da72dacc1128	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:55:19.994928+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
add70280-616d-4808-980c-b8acc9486881	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:55:24.848889+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c5b11919-4db9-434f-82d6-5179a7d8dc66	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:31.26002+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6d9522d5-c7bb-41f9-8a3f-289c2a47c84e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:36.17436+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0868d86c-5f93-483c-b1df-9dbddef5b96c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:41.13919+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
efa4ccf0-75bd-4202-8ce7-1f48429efb5d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:41.13919+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f2a2ddd8-9935-4887-9a58-e802b2f9cac2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:41.13919+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7b7a8ff5-2282-4ea7-b370-d3e4796a706e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:46.141549+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
983e4e22-bb67-4da9-a796-932ff5047bff	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:46.141549+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
df973c0d-b1b2-49ab-9105-23cd58701827	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:46.141549+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
44c8dbe3-16ae-4811-95d9-cbcda812aa66	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:51.140118+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
51fea415-a9e0-47fe-95d6-fc479f1d7d38	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:51.140118+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7cd6bb6a-2978-4b43-ae92-72309bfed105	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 22:56:51.140118+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
07850910-b217-40ea-b16e-a2920dc73d65	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0ed5b8d4-4db2-484f-9ece-f2ca75de6668	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1b1db6c6-bed5-438e-9eb9-d4f31a90593a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2060292d-4c5d-426e-b66e-e3bd9df80494	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
311b1fe7-0664-4353-bac3-51a11afcff5e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
860668ce-2395-484d-872d-33612cd8506b	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8fd06b44-a60f-44cf-b045-6548ad13c07d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9dffba4d-a2bd-48e7-b81a-55266f114874	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ae374727-02dd-4678-9236-7cdc0ef814fd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b1a110df-4078-47a9-98b5-a4712857d521	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b6600b43-7b55-485c-ba41-24ac5469021c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b686b843-9121-46b4-a798-291b4fb8332a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d516bbc4-0a89-48bb-8736-37cb4967c3cc	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d94d9a6b-70f8-4d6c-a360-b1210e426c82	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
dea10201-4982-4eec-9d32-d166915c104c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e5a81bcd-8693-4ce0-b01a-ebc787860cac	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:05:27.46195+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
20451a80-b65d-47e7-8ce7-3bf9803f4823	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
324690d6-0320-4f11-a903-f6c52d32fae1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
39345179-673e-4fab-8d99-1a6521f7e7db	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
47292a5c-02cc-4c19-8232-a4496af4f76a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
67ee634f-0491-4373-b898-5444e55f296e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6a2f1ea4-0f96-4c10-9eb8-89de9bb40ee4	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6f018794-e2fd-446b-aa45-e4c401d392cd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7ac38ee7-9915-4ba3-82ab-458ec36ed431	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7b3c908d-3740-4853-8dc4-78ddbbb1cc0a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8f819787-f9a3-4f6d-8e1f-9d5d822cb51d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b7aee443-17fe-4aa1-9093-e3d0779b20ea	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c7693183-7eaf-48c5-bf62-04a91030a3bc	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ddd25b98-ef69-4c35-a176-b860a73cfb77	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e4582b0c-a49e-4c2c-9ddc-37a967fd3174	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e7f725aa-6d82-43e0-8f27-0f0a10cc1a1d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e9ef768e-7a8e-469e-9aec-33e11aaf7787	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:07:30.803636+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
01923c00-5cab-41a5-9829-e9c36b77fbe3	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1c107295-55e5-4b09-896d-3e0318bae1d0	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4156f989-d6ea-47ba-88ac-d7c26c6c6eb9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4d5d6c47-6d01-4ab5-9a57-f0f87def22fe	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4fbc24ba-572f-4d01-84ee-fb05341dc2a1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
574c1b26-c9ec-4105-a548-caeac4f67bd6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
59063465-277e-4556-9540-7518c8e74603	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
64aeb6c7-359d-4455-bde1-021b8c1e371e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
67b50c6c-4274-46a3-bc55-9c5e6b56f6c8	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
76040d8a-2072-4755-ac13-ca7f453cac02	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7e63007e-a915-4dec-be89-9dd31f49c424	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a8755433-6c09-4ad0-ba6b-3e78a9920af9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
bd24ae54-d803-46d5-b87f-9d3afd40665c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d1ec330c-dae4-4a15-bc79-647c7ed2d68e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e0ec5a15-dcf8-4816-b813-5ad12a26740b	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f2c17dc8-5ca7-473f-9d5e-292eff779fa7	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:10:51.956527+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1baacdeb-0c54-4d9b-803b-06f1c74b80cb	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
22066e85-5433-4fa2-86a1-a742d5543cee	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
33bd607c-1aca-41b3-b421-b519601eb608	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
391b8b24-ee02-4362-bf4b-ed9e1d4cf858	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3c8e5c6b-d53e-4758-9c52-8cf0886b99dc	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4dd3ca34-5500-4bd8-bba5-b6397da38615	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5152812a-1ceb-4154-bbab-5ce1f8e5a35d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6bf3bcbf-a1c6-45a0-b73e-905213b29a9a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7f62456d-f219-47fd-836e-7ea1bf71c832	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a2993dc2-6f2b-43b4-b6bf-41478ea45cc5	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a5447ced-79ad-4e48-9020-0e36b2b5623c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a54fd384-2279-4de0-9c96-615c49b271c2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d4fd5c83-94cb-4b16-8dc4-05158b2d35f6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e6b63902-07f9-4434-a9c3-5e258b2ab139	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ebeb74fb-26c5-4fb4-80a0-da797cbd7b6d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ff5400ac-38d1-4a13-86fa-eaa41e9adf06	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:27:37.600553+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0d7af5c0-a949-424b-845c-833aac0d58da	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
106c1d3f-d14a-496b-941c-9195807184a6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
20372aea-a9bf-4612-8214-6277e1ffce28	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
29526c37-0562-49f9-96f3-725b5822c0e8	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
458a5285-713d-4585-b2be-1cd1e2d30f38	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
54092f20-749f-4d48-a287-18effc71224f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5fa55e43-620a-48f9-9f7f-cfef59300f75	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6aa82cad-1888-43e6-953b-7ddaaa4d34b7	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
719ea095-e1fb-4c03-9356-ce5265e4ebf4	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
75ef3353-e951-46c7-b806-af6e13c74103	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7f8c1fd2-d1eb-428c-87c8-951d957fa637	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
95981159-1380-4571-8cd7-f11d51ba4699	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c8e239c0-3c35-498d-9240-376140ff54f2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d0e2c7be-3cfb-4219-9feb-bf9f215a991d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f0a2b8dc-cc4a-4bed-994b-d335037d4bfd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f243c93c-d4ab-4b70-8379-482890f5e3d1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:30:16.236461+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
08156ab0-d386-4ea4-b8ae-a7f8bb936bfe	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
08248672-bb8a-4972-90eb-91e136ddcdaf	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
126ed760-fb60-4b04-bc4c-954d6c6acac0	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
16274e70-cebe-402d-9d84-11be5f3341e3	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
26a8b6b3-6df3-4589-95e4-8abaa7647e9f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3b4d296e-0868-42b0-8ec9-a04f036f07b2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4351baba-4beb-4a40-92a9-b13d0233527e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
51a36fc7-e05e-4a00-942c-c61163c835b3	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
68c3b449-93bd-4945-a801-b0c5d8dc000a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6fec02c8-4d9f-4666-b183-b80dbcfe1b8e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
73a223e1-98e3-4513-aa45-aa8fd7e0a3da	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7ccf70e4-c856-46d2-83f2-118b861ff3ce	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b6c0667c-dd84-4af4-8f6f-f9bd9baa167b	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cd6f40dd-9e10-4f41-9b71-454c197fa394	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d5b35ba6-6841-4981-9df5-b224d7bd3983	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
dbe004db-1e86-441e-b556-67f454b7f683	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e2154641-62c6-4e71-b086-f4bbb8629a0d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e6888045-b7c2-4ba6-8f41-26e58cd54348	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f13f5039-b25a-44ae-8448-7f69833f8960	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f4510cc2-6106-408a-b94b-a7e2356b6894	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:36:58.128996+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
07b0c412-e6a2-4c7e-a77e-a676effe699d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1138f772-15e4-4e4d-9414-64e738f25d59	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1353333f-d522-49f0-929f-b21605310415	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
240d19b5-adb0-4bd2-a56e-2cda0f5f9e66	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2b9ef400-eb1d-4563-bfbb-b86bfba45914	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
48a8cbb4-42e8-4451-aab4-4dc29fdf7785	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
49a08928-24de-4e12-a610-0d49951444ef	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6fa39d91-1dd4-4f11-ac21-9030bac2d176	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
73a145aa-68e8-4a0b-86ae-024cb67c8f3f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
750d048f-2368-4607-a885-dec88d63bd13	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7bb12ec6-7b74-44df-8d6c-7511a8f3ff6c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
825d0daf-8746-4dcd-888f-907f64881c1f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
94a946ca-4eaa-4714-ab9a-3fb7461ae95e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c8c9c801-4a39-449f-80a5-fb8a4a699309	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c951455d-d5e9-4fb7-b301-8203949c83a0	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d01f05b7-c038-44ce-be84-466ed1f296ef	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d4a6bcc6-62eb-4161-bf59-899e1cd14463	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f226272f-e624-479c-a52a-7e1fa65895d7	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f37ce67a-f268-4484-aea5-eb649ede6679	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f84c9470-d5eb-4fa6-9b89-5d116bcc86d0	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:39:23.128668+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0b90a58d-300e-4387-8f3c-b74c2e2714a5	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1a0d6ce1-2d12-4bfd-8c00-230d5b98bd4d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1ab2b087-8dfc-40d6-992d-c90eb34af12f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
242da62c-109c-43b5-a22a-97048d75ad98	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2601aafa-c701-4f37-8fc9-bccee2223759	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3e896fc0-22e1-4d0d-af8e-a10d47e4aa1c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3ef8c14b-d00e-447b-87d7-0e36a43efc51	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
43de7edb-a717-4e49-8be5-59373dfd955b	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
478c89ef-2306-4017-829e-8e1e64bcb058	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5fe66533-df1a-4860-9b91-8f689677c907	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
70ab41e8-5c76-4d7d-b808-9530c8b0ae34	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7587225b-06c0-4acb-809c-9c1e9a680c5c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9d82eae2-3b23-41b6-9002-330265aa0005	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a1f8310c-d344-4748-8e87-a355225197c8	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ab55bbdf-ada0-40f8-abd4-6cf55f615fa1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ae0d0dc7-b2b4-4c18-95da-7f302848ba68	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b97c0356-a3c4-47c5-93c7-5dde79d870f1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
bea29f0b-2874-4e5b-bc24-241ee6a84b6b	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ce601dc6-70f7-430a-8ca0-b14d70f544c9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d70bca14-2391-45ad-9308-86bc5d032a4c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:03.135868+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
09332481-9319-4352-b9af-e03b04fed3f4	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
09646e73-25e3-4ab7-a500-71e9dec3b663	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1585a044-ce80-49e0-be63-6c0052104e14	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1aa75647-4bae-4ece-b54f-4cb9f1a73f6e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
22424dd9-a243-4d30-892f-eda6933fc84f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
24a3fba1-24db-4b66-aeca-3b2eac8f366c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2e499ac9-d6aa-4b35-a2fb-d4606b3dfe56	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
30eeacfb-64fd-426b-81d0-517ee7574849	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
33f14d6b-093e-4317-825a-080c54ddd59b	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
36913435-87f4-4225-96ba-1a36138bb0cd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4418820a-8eff-4d39-bddd-47ea8d861fe5	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
45b0c4f1-0d4b-48f4-ac56-447271201050	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
49e8ea61-6104-43fa-a44c-955f63b379ef	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4a54facc-7457-4a62-9d15-8fdafb056382	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4cfed0d7-534f-48ca-8354-b124452b5317	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4fdfcde2-abdc-4be8-bdea-82edbd0ba444	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5cefc35b-c770-4995-b597-4cab7f3a0edd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5dbefff3-89bc-457a-bbb3-fe5a77f371ca	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5dd0353f-7dbb-4622-b89d-6da6624d60dd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
69783b11-a37b-4e2c-b72b-9a5050367ecd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
75bf7a89-0f80-4db5-ba64-cebdf4cceb2d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
80f3169d-2903-4dd6-8bc0-dd0751317bd9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
832a2cd6-f2c9-4d71-b5fb-ae767d06af6d	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
86d65fb0-346b-4bc2-92da-a14a2323ab20	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
87238150-1d52-4ca1-b1e7-1d9c64d3fbfa	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
887e0325-384a-47de-b075-f421ffe5ae19	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8e4d7091-0778-431d-85e4-6d1c518303e6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9936b457-5b0c-4fc7-8753-8d9c3d7aa26c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a5e4603b-cfa4-453c-85fb-d7b1791b1f58	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a91c86f4-feb5-4c0a-9e13-76fce844b932	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
aacf9211-4b7a-4e92-b5c0-6bcbbc4d9c37	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ac48b5f7-3bd6-4efe-8fe6-26d188729164	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
af44a249-15b1-4f1c-a327-1c8b04437414	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b1127548-83b3-4221-b87d-128cf05de211	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b1ea0c7b-ffba-4537-a6da-b581068057d6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b45f8be6-2883-4f22-89ce-5cc09b8bfbb0	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b57592de-c378-4a79-8c40-0c458308b570	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ba40f054-e6b5-43e2-bcef-83cb4a9c9fd8	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
bf40bdad-675b-4b18-a34d-e7b0614984a9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c0298db1-87f1-4bc7-92df-a24ca0d697bb	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c1c28ba2-64ee-4d0d-8f61-d4b9611985c7	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d5303107-137e-4fa4-8c49-c310384946b7	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d97c5ea2-96d4-4534-9839-b9698645ed37	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
dbb1290c-372d-4e49-a5e3-72cc973ea49a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e4cfca94-5028-4616-b25d-064400caeb92	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ea0d0fa6-689d-4250-a384-adc10ea38a06	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ecb611be-17f2-4404-9561-9acb25074fe3	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f133ec88-17c3-462a-aaf1-99371bd82bd5	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f38a6fde-7bd8-470c-a945-cfc8012daca9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f58ca872-50c6-4b05-a1be-34fec91f867c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ff5ee49b-cdb9-4420-9e83-925d280ed138	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:13.127426+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0017098e-238b-43f9-80d8-beab06c923e7	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0e60643a-368b-452f-a42d-a9fbcf3faf52	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0efaf8bf-454a-483e-8553-ab4ade080229	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
103a125f-d351-49af-b368-5b44482d2703	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1232f989-9695-4546-a8fb-0e5f351702c9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
15a0d6a4-f79d-42a5-a9c6-55105e95bb0c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1cd9c4df-547f-49c2-b592-d2780be32a7c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1da23a6e-5d89-4a87-92aa-ba72f3704750	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
200bc05b-b46f-45bb-856c-2257037ba356	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2155ab4d-0328-44f4-90fa-bec97bb889d0	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2299cd00-ab09-4326-a137-b2bd5e1a3010	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
25c2f782-0fa3-4622-a878-e752fe505fc9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
353eb4f9-e2d8-4838-a0b5-fc8db088ef41	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3bdbdc32-7260-40b9-8458-265081423204	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
432bd401-0aa3-49ea-88b9-9a9600655601	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
5e5e24c9-e6c1-4b42-8e32-2c062237b285	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6eefc0b3-f9d7-4887-ab4a-bcd81e738b85	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
774668d3-499f-4faa-92bf-dc76c60580b3	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
7e2f5c3a-714f-41e8-af70-117aed4d1883	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
85aa8148-0204-4776-b299-bf1ee04e87c8	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
86fb1d98-c96d-4ee7-8717-409e363513db	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
88e73aec-0212-486c-8dc0-8ffe2ab4b49b	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8c1ed80e-44c4-40c6-b0dd-ba1c5a2cb7c1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8cc41698-7fd1-4409-9362-4b240d8d98c8	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
90da57e0-e5f6-4c5d-8aca-651d9bbb7725	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
941fba1b-d528-4b8b-a228-e5da8417ab7c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
99829d03-354c-4d20-b486-fa2dcd3d6ae6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
9aa303cb-f0ab-4e42-9bcb-b386f1bfb924	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a27d40a6-c8ca-432f-9240-419de4132bf2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a3b3c7c7-fdc1-4f28-9e06-01fd3b251010	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
a43fd0dc-0f0f-441d-8d44-30101d79b07a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
aa0e4f1e-a159-439d-bb78-4d6f217043e2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b0db3ae4-f7b5-4d10-8aed-14348f34c349	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b98352ec-3048-48fd-a2cc-ec66d04757a5	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
be8b49c9-0521-4a92-8f17-d7bcf0085395	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c06eda60-9732-4118-b990-3556a44b20d1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c0f47f85-205c-48f6-bedd-608a94e0a5fd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d451eb8d-a82d-41f4-a713-a30652b1eccd	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d45ce121-11cf-46cd-b6ad-1d4d0c1b8921	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d54daf32-2245-4baf-88b5-58055c4dc842	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d7420c05-abc8-45d2-8f81-f18aafe9129e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d96fcfd8-28d1-4b04-9eca-0f3430791d5f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e1c53232-69a7-473b-8dea-6e8cbe31e24b	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e218cdae-cd36-484c-ad05-14bd3286f120	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e2d6b513-cb59-4ff2-812f-48e7f9e1f07f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e3a101a0-cd33-4410-a918-f1a2c048f102	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e5ae927a-2c75-4604-a48d-f6bec5f07bbf	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e8ac6309-4e2a-4ce0-bcf2-7ca7ab11c5d2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f293e9d1-1fea-44f7-852f-f958d9c172c7	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-03 23:40:18.469824+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
0971ffb5-5a44-4e4a-a71d-1b0764c515f9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
186db380-7726-4ccf-8d1a-6c1ecb4c33e4	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
1fbae533-f96d-419f-9a57-877576e8b318	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
22e7eeb1-2968-4243-bc6b-838b14f30312	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
2ceb31d1-8263-4a6a-beb2-e002113c337e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
3d992861-7752-489f-9024-a29c5ee1611f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4344b630-496a-49a9-865e-2c0b1c44fc10	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
4399e955-4e03-48c5-ae02-3e37cf5af09c	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
52aaee76-2c18-4ff5-9613-0797fdcd8dd6	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
53988f01-ebef-4da0-8206-794cbd209759	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
55a2bcad-94d2-4613-a99b-c340e5340501	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
573711cd-88d0-481f-94c4-0234435e51a0	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6413686f-6582-4957-a05d-fbe03a82455a	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
6f896031-5a28-4e23-8af8-e68e987fc1b9	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
706a3263-3b5c-4067-9a48-d242198486f1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
77ab859d-f72d-47b3-afeb-ae5eb9cae27e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
791a77c0-e577-4c8b-98bb-2f5f0f42d881	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
80a8de12-4114-46a1-bd72-439b9f89ef13	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
80d80753-9b08-475f-9983-251fe606e31e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
8bb88e56-b266-49b8-b862-48aaf1385f6f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
abf4ab87-94a1-4b3b-8c9d-438ff54413a1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
b1e6edd3-c31e-4cbf-b789-8a109cba2711	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
c976f219-b57d-4ed6-a16a-21a273fa88f8	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
cb03cdf7-eb33-4ffa-89e4-c8e02d8be59e	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d36092f4-b409-4165-ae2b-0f762ebf8bc1	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
d64424e7-0736-4468-91e0-778fa0f65b7f	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
dd76ca45-0152-4173-b57f-45dc9e730364	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e5851ac6-0204-4986-9bd9-fa0718670ad2	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
e6bf6719-76b5-4934-a5c9-ab807b5263de	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
eb2e1583-4b15-4ff5-8aa1-b0395fface40	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
ef90cf57-e42e-4e14-abe5-02234703d915	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
f5237619-0a06-4145-b5c3-883936e69115	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
fca5a1f6-bc94-495b-bf11-8d57f0d42c98	SUPERadmin@mail.RU	019b7d31-93fd-703f-a582-c82e6bd40036	t	1	2026-01-04 00:13:27.593866+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	127.0.0.1	t
\.


--
-- TOC entry 5234 (class 0 OID 26591)
-- Dependencies: 244
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251218141532_Init	10.0.1
20251219010850_Fix1	10.0.1
20251219104853_Fix2	10.0.1
20251219125100_Fix3	10.0.1
20251219144649_Fix4	10.0.1
20251219145307_Fix5	10.0.1
20251220111640_Fix6	10.0.1
20251220140152_Fix7	10.0.1
20251221062947_Fix8	10.0.1
20251221115503_Fix9	10.0.1
20251221115727_Fix10	10.0.1
20251222005509_Fix11	10.0.1
20251222005528_Fix12	10.0.1
20251222012124_Fix13	10.0.1
20251222014603_Fix14	10.0.1
20251222032345_Fix15	10.0.1
20251222082512_Fix16	10.0.1
20251222142042_Fix17	10.0.1
20251224050619_Fix18	10.0.1
20251224060154_Fix19	10.0.1
20251224071911_Fix20	10.0.1
20251224075948_Fix21	10.0.1
20251224084507_Fix22	10.0.1
20251224125003_Fix23	10.0.1
20251229100603_Fix24	10.0.1
20251230112703_InitIdentity	10.0.1
20251231063604_IdentityFix1	10.0.1
20260101132651_IdentityFix2	10.0.1
20260101140259_IdentityFix3	10.0.1
20260101154436_IdentityFix4	10.0.1
20260102073949_IdentityFix5	10.0.1
20260102074626_IdentityFix6	10.0.1
\.


--
-- TOC entry 5235 (class 0 OID 26596)
-- Dependencies: 245
-- Data for Name: user_ban_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_ban_reasons (id, name) FROM stdin;
\.


--
-- TOC entry 5242 (class 0 OID 26875)
-- Dependencies: 252
-- Data for Name: identity_role_claims; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_role_claims (id, role_id, claim_type, claim_value) FROM stdin;
\.


--
-- TOC entry 5239 (class 0 OID 26852)
-- Dependencies: 249
-- Data for Name: identity_roles; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_roles (id, name, normalized_name, concurrency_stamp) FROM stdin;
\.


--
-- TOC entry 5244 (class 0 OID 26890)
-- Dependencies: 254
-- Data for Name: identity_user_claims; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_claims (id, user_id, claim_type, claim_value) FROM stdin;
\.


--
-- TOC entry 5245 (class 0 OID 26904)
-- Dependencies: 255
-- Data for Name: identity_user_logins; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_logins (login_provider, provider_key, provider_display_name, user_id) FROM stdin;
\.


--
-- TOC entry 5246 (class 0 OID 26919)
-- Dependencies: 256
-- Data for Name: identity_user_roles; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_roles (user_id, role_id) FROM stdin;
\.


--
-- TOC entry 5247 (class 0 OID 26936)
-- Dependencies: 257
-- Data for Name: identity_user_tokens; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_tokens (user_id, login_provider, name, value) FROM stdin;
\.


--
-- TOC entry 5240 (class 0 OID 26860)
-- Dependencies: 250
-- Data for Name: identity_users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_users (id, user_name, normalized_user_name, email, normalized_email, email_confirmed, password_hash, security_stamp, concurrency_stamp, phone_number, phone_number_confirmed, two_factor_enabled, lockout_end, lockout_enabled, access_failed_count, created_at, time_zone, updated_at, version) FROM stdin;
019b7d31-93fd-703f-a582-c82e6bd40036	SUPERadmin@mail.RU	SUPERADMIN@MAIL.RU	SUPERadmin@mail.RU	SUPERADMIN@MAIL.RU	f	AQAAAAIAAYagAAAAEBag9pn4pztxrJtK71md3akGQ04Q/cWVqpDT8he8Ispn7t+HNGhKzrdXtWkKnE16vA==	JHMUKRZCKGMKN5TPX7UY47QU3OYRA44C	78551647-ef36-40b6-872c-bd8bbd3aa67e	\N	f	f	\N	t	0	2026-01-02 13:32:39.809088+08	\N	2026-01-02 13:32:39.809088+08	1
\.


--
-- TOC entry 5237 (class 0 OID 26604)
-- Dependencies: 247
-- Data for Name: user_bans; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_bans (id, user_id, version, created_at, updated_at, expires_at, user_ban_reason_id) FROM stdin;
\.


--
-- TOC entry 5238 (class 0 OID 26614)
-- Dependencies: 248
-- Data for Name: user_devices; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_devices (id, created_at, system_environment_user_name, time_zone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
47ee0275-bae7-c959-af87-f8b416a6cfd0	2025-12-19 22:55:44.844376+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
2f3585e2-e396-345a-b6d2-8d7079e5cdfc	2025-12-22 14:23:32.052081+08	adm-shumkov	480	30af10590f9f87bea6b087c950be35295e8eee95	B760 DS3H (Gigabyte Technology Co., Ltd.)	Desktop	Windows 10  (10.0.19045) 64bit	Intel(R) Core(TM) i9-14900K	32	65296	Intel(R) UHD Graphics 770	32648	t	Full
94a4eb4e-400c-2a56-ac6c-10dfb9250180	2026-01-02 13:31:08.667201+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
\.


--
-- TOC entry 5254 (class 0 OID 0)
-- Dependencies: 227
-- Name: base_equipments_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_equipments_id_seq', 9, true);


--
-- TOC entry 5255 (class 0 OID 0)
-- Dependencies: 229
-- Name: base_heroes_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_heroes_id_seq', 6, false);


--
-- TOC entry 5256 (class 0 OID 0)
-- Dependencies: 231
-- Name: creature_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.creature_types_id_seq', 9, false);


--
-- TOC entry 5257 (class 0 OID 0)
-- Dependencies: 233
-- Name: damage_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.damage_types_id_seq', 17, true);


--
-- TOC entry 5258 (class 0 OID 0)
-- Dependencies: 235
-- Name: equipment_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.equipment_types_id_seq', 32, true);


--
-- TOC entry 5259 (class 0 OID 0)
-- Dependencies: 237
-- Name: material_damage_percents_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.material_damage_percents_id_seq', 25, false);


--
-- TOC entry 5260 (class 0 OID 0)
-- Dependencies: 239
-- Name: slot_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slot_types_id_seq', 17, true);


--
-- TOC entry 5261 (class 0 OID 0)
-- Dependencies: 241
-- Name: smithing_materials_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.smithing_materials_id_seq', 19, true);


--
-- TOC entry 5262 (class 0 OID 0)
-- Dependencies: 246
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_ban_reasons_id_seq', 1, false);


--
-- TOC entry 5263 (class 0 OID 0)
-- Dependencies: 251
-- Name: asp_net_role_claims_id_seq; Type: SEQUENCE SET; Schema: users; Owner: -
--

SELECT pg_catalog.setval('users.asp_net_role_claims_id_seq', 1, false);


--
-- TOC entry 5264 (class 0 OID 0)
-- Dependencies: 253
-- Name: asp_net_user_claims_id_seq; Type: SEQUENCE SET; Schema: users; Owner: -
--

SELECT pg_catalog.setval('users.asp_net_user_claims_id_seq', 1, false);


--
-- TOC entry 4944 (class 2606 OID 26634)
-- Name: equipments equipments__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4960 (class 2606 OID 26636)
-- Name: heroes heroes__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4965 (class 2606 OID 26638)
-- Name: base_equipments base_equipments__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4969 (class 2606 OID 26640)
-- Name: base_heroes base_heroes__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_heroes
    ADD CONSTRAINT base_heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4972 (class 2606 OID 26642)
-- Name: creature_types creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.creature_types
    ADD CONSTRAINT creature_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4975 (class 2606 OID 26644)
-- Name: damage_types damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.damage_types
    ADD CONSTRAINT damage_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4978 (class 2606 OID 26646)
-- Name: equipment_types equipment_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4982 (class 2606 OID 26648)
-- Name: material_damage_percents material_damage_percents__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__pkey PRIMARY KEY (id);


--
-- TOC entry 4986 (class 2606 OID 26650)
-- Name: slot_types slot_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slot_types
    ADD CONSTRAINT slot_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4989 (class 2606 OID 26652)
-- Name: smithing_materials smithing_materials__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.smithing_materials
    ADD CONSTRAINT smithing_materials__pkey PRIMARY KEY (id);


--
-- TOC entry 4992 (class 2606 OID 26654)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__pkey PRIMARY KEY (equipment_type_id, damage_type_id);


--
-- TOC entry 4995 (class 2606 OID 26656)
-- Name: x_hero_creature_type x_hero_creature_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__pkey PRIMARY KEY (base_hero_id, creature_type_id);


--
-- TOC entry 5029 (class 2606 OID 27027)
-- Name: auth_reg_logs auth_reg_logs__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.auth_reg_logs
    ADD CONSTRAINT auth_reg_logs__pkey PRIMARY KEY (id);


--
-- TOC entry 4997 (class 2606 OID 26660)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 5000 (class 2606 OID 26662)
-- Name: user_ban_reasons user_ban_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_ban_reasons
    ADD CONSTRAINT user_ban_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 5015 (class 2606 OID 27117)
-- Name: identity_role_claims identity_role_claims__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_role_claims
    ADD CONSTRAINT identity_role_claims__pkey PRIMARY KEY (id);


--
-- TOC entry 5009 (class 2606 OID 27115)
-- Name: identity_roles identity_roles__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_roles
    ADD CONSTRAINT identity_roles__pkey PRIMARY KEY (id);


--
-- TOC entry 5018 (class 2606 OID 27113)
-- Name: identity_user_claims identity_user_claims__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_claims
    ADD CONSTRAINT identity_user_claims__pkey PRIMARY KEY (id);


--
-- TOC entry 5021 (class 2606 OID 27111)
-- Name: identity_user_logins identity_user_logins__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_logins
    ADD CONSTRAINT identity_user_logins__pkey PRIMARY KEY (login_provider, provider_key);


--
-- TOC entry 5024 (class 2606 OID 27109)
-- Name: identity_user_roles identity_user_roles__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__pkey PRIMARY KEY (user_id, role_id);


--
-- TOC entry 5027 (class 2606 OID 27107)
-- Name: identity_user_tokens identity_user_tokens__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_tokens
    ADD CONSTRAINT identity_user_tokens__pkey PRIMARY KEY (user_id, login_provider, name);


--
-- TOC entry 5013 (class 2606 OID 27105)
-- Name: identity_users identity_users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_users
    ADD CONSTRAINT identity_users__pkey PRIMARY KEY (id);


--
-- TOC entry 5002 (class 2606 OID 26664)
-- Name: user_bans user_bans__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__pkey PRIMARY KEY (id);


--
-- TOC entry 5006 (class 2606 OID 26666)
-- Name: user_devices user_devices__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_devices
    ADD CONSTRAINT user_devices__pkey PRIMARY KEY (id);


--
-- TOC entry 4942 (class 1259 OID 26669)
-- Name: equipments__base_equipment_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__base_equipment_id__idx ON collection.equipments USING btree (base_equipment_id);


--
-- TOC entry 4945 (class 1259 OID 26670)
-- Name: equipments__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__user_id__idx ON collection.equipments USING btree (user_id);


--
-- TOC entry 4946 (class 1259 OID 26671)
-- Name: heroes__base_hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__base_hero_id__idx ON collection.heroes USING btree (base_hero_id);


--
-- TOC entry 4947 (class 1259 OID 26672)
-- Name: heroes__equipment10id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment10id__idx ON collection.heroes USING btree (equipment10id);


--
-- TOC entry 4948 (class 1259 OID 26673)
-- Name: heroes__equipment11id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment11id__idx ON collection.heroes USING btree (equipment11id);


--
-- TOC entry 4949 (class 1259 OID 26674)
-- Name: heroes__equipment12id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment12id__idx ON collection.heroes USING btree (equipment12id);


--
-- TOC entry 4950 (class 1259 OID 26675)
-- Name: heroes__equipment1id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment1id__idx ON collection.heroes USING btree (equipment1id);


--
-- TOC entry 4951 (class 1259 OID 26676)
-- Name: heroes__equipment2id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment2id__idx ON collection.heroes USING btree (equipment2id);


--
-- TOC entry 4952 (class 1259 OID 26677)
-- Name: heroes__equipment3id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment3id__idx ON collection.heroes USING btree (equipment3id);


--
-- TOC entry 4953 (class 1259 OID 26678)
-- Name: heroes__equipment4id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment4id__idx ON collection.heroes USING btree (equipment4id);


--
-- TOC entry 4954 (class 1259 OID 26679)
-- Name: heroes__equipment5id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment5id__idx ON collection.heroes USING btree (equipment5id);


--
-- TOC entry 4955 (class 1259 OID 26680)
-- Name: heroes__equipment6id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment6id__idx ON collection.heroes USING btree (equipment6id);


--
-- TOC entry 4956 (class 1259 OID 26681)
-- Name: heroes__equipment7id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment7id__idx ON collection.heroes USING btree (equipment7id);


--
-- TOC entry 4957 (class 1259 OID 26682)
-- Name: heroes__equipment8id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment8id__idx ON collection.heroes USING btree (equipment8id);


--
-- TOC entry 4958 (class 1259 OID 26683)
-- Name: heroes__equipment9id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment9id__idx ON collection.heroes USING btree (equipment9id);


--
-- TOC entry 4961 (class 1259 OID 26684)
-- Name: heroes__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__user_id__idx ON collection.heroes USING btree (user_id);


--
-- TOC entry 4962 (class 1259 OID 26685)
-- Name: base_equipments__equipment_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__equipment_type_id__idx ON game_data.base_equipments USING btree (equipment_type_id);


--
-- TOC entry 4963 (class 1259 OID 26974)
-- Name: base_equipments__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_equipments__name__idx ON game_data.base_equipments USING btree (name);


--
-- TOC entry 4966 (class 1259 OID 26687)
-- Name: base_equipments__smithing_material_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__smithing_material_id__idx ON game_data.base_equipments USING btree (smithing_material_id);


--
-- TOC entry 4967 (class 1259 OID 26972)
-- Name: base_heroes__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_heroes__name__idx ON game_data.base_heroes USING btree (name);


--
-- TOC entry 4970 (class 1259 OID 26970)
-- Name: creature_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX creature_types__name__idx ON game_data.creature_types USING btree (name);


--
-- TOC entry 4973 (class 1259 OID 26968)
-- Name: damage_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX damage_types__name__idx ON game_data.damage_types USING btree (name);


--
-- TOC entry 4976 (class 1259 OID 26966)
-- Name: equipment_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX equipment_types__name__idx ON game_data.equipment_types USING btree (name);


--
-- TOC entry 4979 (class 1259 OID 26692)
-- Name: equipment_types__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX equipment_types__slot_type_id__idx ON game_data.equipment_types USING btree (slot_type_id);


--
-- TOC entry 4980 (class 1259 OID 26693)
-- Name: material_damage_percents__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__damage_type_id__idx ON game_data.material_damage_percents USING btree (damage_type_id);


--
-- TOC entry 4983 (class 1259 OID 26694)
-- Name: material_damage_percents__smithing_materials_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__smithing_materials_id__idx ON game_data.material_damage_percents USING btree (smithing_materials_id);


--
-- TOC entry 4984 (class 1259 OID 26963)
-- Name: slot_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slot_types__name__idx ON game_data.slot_types USING btree (name);


--
-- TOC entry 4987 (class 1259 OID 26961)
-- Name: smithing_materials__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX smithing_materials__name__idx ON game_data.smithing_materials USING btree (name);


--
-- TOC entry 4990 (class 1259 OID 26697)
-- Name: x_equipment_type_damage_type__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_equipment_type_damage_type__damage_type_id__idx ON game_data.x_equipment_type_damage_type USING btree (damage_type_id);


--
-- TOC entry 4993 (class 1259 OID 26698)
-- Name: x_hero_creature_type__creature_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_hero_creature_type__creature_type_id__idx ON game_data.x_hero_creature_type USING btree (creature_type_id);


--
-- TOC entry 5030 (class 1259 OID 27039)
-- Name: auth_reg_logs__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX auth_reg_logs__user_device_id__idx ON logs.auth_reg_logs USING btree (user_device_id);


--
-- TOC entry 5031 (class 1259 OID 27038)
-- Name: auth_reg_logs__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX auth_reg_logs__user_id__idx ON logs.auth_reg_logs USING btree (user_id);


--
-- TOC entry 4998 (class 1259 OID 26701)
-- Name: user_ban_reasons__name__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_ban_reasons__name__idx ON server.user_ban_reasons USING btree (name);


--
-- TOC entry 5016 (class 1259 OID 26951)
-- Name: identity_role_claims__role_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_role_claims__role_id__idx ON users.identity_role_claims USING btree (role_id);


--
-- TOC entry 5007 (class 1259 OID 26952)
-- Name: identity_roles__normalized_name__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX identity_roles__normalized_name__idx ON users.identity_roles USING btree (normalized_name);


--
-- TOC entry 5019 (class 1259 OID 26953)
-- Name: identity_user_claims__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_claims__user_id__idx ON users.identity_user_claims USING btree (user_id);


--
-- TOC entry 5022 (class 1259 OID 26954)
-- Name: identity_user_logins__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_logins__user_id__idx ON users.identity_user_logins USING btree (user_id);


--
-- TOC entry 5025 (class 1259 OID 26955)
-- Name: identity_user_roles__role_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_roles__role_id__idx ON users.identity_user_roles USING btree (role_id);


--
-- TOC entry 5010 (class 1259 OID 26956)
-- Name: identity_users__normalized_email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_users__normalized_email__idx ON users.identity_users USING btree (normalized_email);


--
-- TOC entry 5011 (class 1259 OID 26957)
-- Name: identity_users__normalized_user_name__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX identity_users__normalized_user_name__idx ON users.identity_users USING btree (normalized_user_name);


--
-- TOC entry 5003 (class 1259 OID 26702)
-- Name: user_bans__user_ban_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_ban_reason_id__idx ON users.user_bans USING btree (user_ban_reason_id);


--
-- TOC entry 5004 (class 1259 OID 26703)
-- Name: user_bans__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_id__idx ON users.user_bans USING btree (user_id);


--
-- TOC entry 5032 (class 2606 OID 26705)
-- Name: equipments equipments__base_equipment_id__base_equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__base_equipment_id__base_equipments__fkey FOREIGN KEY (base_equipment_id) REFERENCES game_data.base_equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5033 (class 2606 OID 27123)
-- Name: equipments equipments__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5034 (class 2606 OID 26715)
-- Name: heroes heroes__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5035 (class 2606 OID 26720)
-- Name: heroes heroes__equipment10id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment10id__equipments__fkey FOREIGN KEY (equipment10id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5036 (class 2606 OID 26725)
-- Name: heroes heroes__equipment11id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment11id__equipments__fkey FOREIGN KEY (equipment11id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5037 (class 2606 OID 26730)
-- Name: heroes heroes__equipment12id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment12id__equipments__fkey FOREIGN KEY (equipment12id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5038 (class 2606 OID 26735)
-- Name: heroes heroes__equipment1id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment1id__equipments__fkey FOREIGN KEY (equipment1id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5039 (class 2606 OID 26740)
-- Name: heroes heroes__equipment2id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment2id__equipments__fkey FOREIGN KEY (equipment2id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5040 (class 2606 OID 26745)
-- Name: heroes heroes__equipment3id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment3id__equipments__fkey FOREIGN KEY (equipment3id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5041 (class 2606 OID 26750)
-- Name: heroes heroes__equipment4id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment4id__equipments__fkey FOREIGN KEY (equipment4id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5042 (class 2606 OID 26755)
-- Name: heroes heroes__equipment5id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment5id__equipments__fkey FOREIGN KEY (equipment5id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5043 (class 2606 OID 26760)
-- Name: heroes heroes__equipment6id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment6id__equipments__fkey FOREIGN KEY (equipment6id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5044 (class 2606 OID 26765)
-- Name: heroes heroes__equipment7id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment7id__equipments__fkey FOREIGN KEY (equipment7id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5045 (class 2606 OID 26770)
-- Name: heroes heroes__equipment8id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment8id__equipments__fkey FOREIGN KEY (equipment8id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5046 (class 2606 OID 26775)
-- Name: heroes heroes__equipment9id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment9id__equipments__fkey FOREIGN KEY (equipment9id) REFERENCES collection.equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5047 (class 2606 OID 27128)
-- Name: heroes heroes__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5048 (class 2606 OID 26785)
-- Name: base_equipments base_equipments__equipment_type_id__equipment_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__equipment_type_id__equipment_types__fkey FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5049 (class 2606 OID 26790)
-- Name: base_equipments base_equipments__smithing_material_id__smithing_materials__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__smithing_material_id__smithing_materials__fkey FOREIGN KEY (smithing_material_id) REFERENCES game_data.smithing_materials(id) ON DELETE RESTRICT;


--
-- TOC entry 5050 (class 2606 OID 26795)
-- Name: equipment_types equipment_types__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5051 (class 2606 OID 26800)
-- Name: material_damage_percents material_damage_percents__damage_type_id__damage_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__damage_type_id__damage_types__fkey FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5052 (class 2606 OID 26805)
-- Name: material_damage_percents material_damage_percents__smithing_materials_id__smithing_mater; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__smithing_materials_id__smithing_mater FOREIGN KEY (smithing_materials_id) REFERENCES game_data.smithing_materials(id) ON DELETE RESTRICT;


--
-- TOC entry 5053 (class 2606 OID 26810)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__damage_type_id__damage_types__fke; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__damage_type_id__damage_types__fke FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5054 (class 2606 OID 26815)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__equipment_type_id__equipment_type; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__equipment_type_id__equipment_type FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5055 (class 2606 OID 26820)
-- Name: x_hero_creature_type x_hero_creature_type__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5056 (class 2606 OID 26825)
-- Name: x_hero_creature_type x_hero_creature_type__creature_type_id__creature_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__creature_type_id__creature_types__fkey FOREIGN KEY (creature_type_id) REFERENCES game_data.creature_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5065 (class 2606 OID 27033)
-- Name: auth_reg_logs auth_reg_logs__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.auth_reg_logs
    ADD CONSTRAINT auth_reg_logs__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE RESTRICT;


--
-- TOC entry 5066 (class 2606 OID 27118)
-- Name: auth_reg_logs auth_reg_logs__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.auth_reg_logs
    ADD CONSTRAINT auth_reg_logs__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE CASCADE;


--
-- TOC entry 5059 (class 2606 OID 27133)
-- Name: identity_role_claims identity_role_claims__role_id__identity_roles__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_role_claims
    ADD CONSTRAINT identity_role_claims__role_id__identity_roles__fkey FOREIGN KEY (role_id) REFERENCES users.identity_roles(id) ON DELETE RESTRICT;


--
-- TOC entry 5060 (class 2606 OID 27138)
-- Name: identity_user_claims identity_user_claims__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_claims
    ADD CONSTRAINT identity_user_claims__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5061 (class 2606 OID 27143)
-- Name: identity_user_logins identity_user_logins__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_logins
    ADD CONSTRAINT identity_user_logins__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5062 (class 2606 OID 27148)
-- Name: identity_user_roles identity_user_roles__role_id__identity_roles__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__role_id__identity_roles__fkey FOREIGN KEY (role_id) REFERENCES users.identity_roles(id) ON DELETE RESTRICT;


--
-- TOC entry 5063 (class 2606 OID 27153)
-- Name: identity_user_roles identity_user_roles__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5064 (class 2606 OID 27158)
-- Name: identity_user_tokens identity_user_tokens__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_tokens
    ADD CONSTRAINT identity_user_tokens__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5057 (class 2606 OID 26840)
-- Name: user_bans user_bans__user_ban_reason_id__user_ban_reasons__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_ban_reason_id__user_ban_reasons__fkey FOREIGN KEY (user_ban_reason_id) REFERENCES server.user_ban_reasons(id) ON DELETE RESTRICT;


--
-- TOC entry 5058 (class 2606 OID 27163)
-- Name: user_bans user_bans__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE CASCADE;


-- Completed on 2026-01-04 02:17:02

--
-- PostgreSQL database dump complete
--

\unrestrict o8oSx1VfS11TFfCQOMcNYMe9jezdb2vphp0ljcMogpTdzXNGwmUWEUDW1sOyysW

