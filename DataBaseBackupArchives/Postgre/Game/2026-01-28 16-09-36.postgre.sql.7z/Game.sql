--
-- PostgreSQL database dump
--

\restrict KYx2IRNB5lB4JlxodBKpbSXgWfxOgc6zvxSb4L7NIOIQ4Blw5KXxRDtX4g34E7i

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2026-01-28 16:09:36

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS on_ddl_create_table__prevent_id_update;
ALTER TABLE IF EXISTS ONLY users.user_sessions DROP CONSTRAINT IF EXISTS user_sessions__user_session_inactivation_reason_id__user_sessio;
ALTER TABLE IF EXISTS ONLY users.user_sessions DROP CONSTRAINT IF EXISTS user_sessions__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_ban_reason_id__user_ban_reasons__fkey;
ALTER TABLE IF EXISTS ONLY users.user_accesskeys DROP CONSTRAINT IF EXISTS user_accesskeys__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_tokens DROP CONSTRAINT IF EXISTS identity_user_tokens__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__role_id__identity_roles__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_logins DROP CONSTRAINT IF EXISTS identity_user_logins__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_claims DROP CONSTRAINT IF EXISTS identity_user_claims__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY users.identity_role_claims DROP CONSTRAINT IF EXISTS identity_role_claims__role_id__identity_roles__fkey;
ALTER TABLE IF EXISTS ONLY logs.registration_logs DROP CONSTRAINT IF EXISTS registration_logs__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY logs.registration_logs DROP CONSTRAINT IF EXISTS registration_logs__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY logs.authentication_logs DROP CONSTRAINT IF EXISTS authentication_logs__user_session_id__user_sessions__fkey;
ALTER TABLE IF EXISTS ONLY logs.authentication_logs DROP CONSTRAINT IF EXISTS authentication_logs__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY logs.authentication_logs DROP CONSTRAINT IF EXISTS authentication_logs__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_heroes_creature_types DROP CONSTRAINT IF EXISTS x_heroes_creature_types__creature_type_id__creature_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_heroes_creature_types DROP CONSTRAINT IF EXISTS x_heroes_creature_types__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_types_damage_types DROP CONSTRAINT IF EXISTS x_equipment_types_damage_types__equipment_type_id__equipment_ty;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_types_damage_types DROP CONSTRAINT IF EXISTS x_equipment_types_damage_types__damage_type_id__damage_types__f;
ALTER TABLE IF EXISTS ONLY game_data.slots DROP CONSTRAINT IF EXISTS slots__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__smithing_materials_id__smithing_mater;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__damage_type_id__damage_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__smithing_material_id__smithing_materials__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__equipment_type_id__equipment_types__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__user_id__identity_users__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__slot_id__slots__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__hero_id__heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__base_equipment_id__base_equipments__fkey;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.users;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.user_sessions;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.user_devices;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.user_bans;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.user_accesskeys;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.refresh_tokens;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.identity_users;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.identity_user_claims;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.identity_roles;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON users.identity_role_claims;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON server.user_session_inactivation_reasons;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON server.user_ban_reasons;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON logs.registration_logs;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON logs.authentication_logs;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.smithing_materials;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.slots;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.slot_types;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.material_damage_percents;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.equipment_types;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.damage_types;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.creature_types;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.base_heroes;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON game_data.base_equipments;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON collection.heroes;
DROP TRIGGER IF EXISTS trg_prevent_id_change ON collection.equipments;
DROP INDEX IF EXISTS users.users__email__idx;
DROP INDEX IF EXISTS users.user_sessions__user_session_inactivation_reason_id__idx;
DROP INDEX IF EXISTS users.user_sessions__user_device_id__idx;
DROP INDEX IF EXISTS users.user_sessions__refresh_token_hash__idx;
DROP INDEX IF EXISTS users.user_bans__user_id__idx;
DROP INDEX IF EXISTS users.user_bans__user_ban_reason_id__idx;
DROP INDEX IF EXISTS users.user_accesskeys__user_id__idx;
DROP INDEX IF EXISTS users.refresh_tokens__user_id__idx;
DROP INDEX IF EXISTS users.identity_users__normalized_user_name__idx;
DROP INDEX IF EXISTS users.identity_users__normalized_email__idx;
DROP INDEX IF EXISTS users.identity_user_roles__role_id__idx;
DROP INDEX IF EXISTS users.identity_user_logins__user_id__idx;
DROP INDEX IF EXISTS users.identity_user_claims__user_id__idx;
DROP INDEX IF EXISTS users.identity_roles__normalized_name__idx;
DROP INDEX IF EXISTS users.identity_role_claims__role_id__idx;
DROP INDEX IF EXISTS server.user_session_inactivation_reasons__code__idx;
DROP INDEX IF EXISTS server.user_ban_reasons__name__idx;
DROP INDEX IF EXISTS logs.registration_logs__user_id__idx;
DROP INDEX IF EXISTS logs.registration_logs__user_device_id__idx;
DROP INDEX IF EXISTS logs.authentication_logs__user_session_id__idx;
DROP INDEX IF EXISTS logs.authentication_logs__user_id__idx;
DROP INDEX IF EXISTS logs.authentication_logs__user_device_id__idx;
DROP INDEX IF EXISTS game_data.x_heroes_creature_types__creature_type_id__idx;
DROP INDEX IF EXISTS game_data.x_equipment_types_damage_types__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.smithing_materials__name__idx;
DROP INDEX IF EXISTS game_data.slots__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.slots__name__idx;
DROP INDEX IF EXISTS game_data.slot_types__name__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__smithing_materials_id__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__name__idx;
DROP INDEX IF EXISTS game_data.damage_types__name__idx;
DROP INDEX IF EXISTS game_data.creature_types__name__idx;
DROP INDEX IF EXISTS game_data.base_heroes__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__smithing_material_id__idx;
DROP INDEX IF EXISTS game_data.base_equipments__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__equipment_type_id__idx;
DROP INDEX IF EXISTS collection.heroes__user_id__idx;
DROP INDEX IF EXISTS collection.heroes__base_hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__user_id__idx;
DROP INDEX IF EXISTS collection.equipments__slot_id__hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__base_equipment_id__idx;
ALTER TABLE IF EXISTS ONLY users.users DROP CONSTRAINT IF EXISTS users__pkey;
ALTER TABLE IF EXISTS ONLY users.user_sessions DROP CONSTRAINT IF EXISTS user_sessions__pkey;
ALTER TABLE IF EXISTS ONLY users.user_devices DROP CONSTRAINT IF EXISTS user_devices__pkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__pkey;
ALTER TABLE IF EXISTS ONLY users.user_accesskeys DROP CONSTRAINT IF EXISTS user_accesskeys__pkey;
ALTER TABLE IF EXISTS ONLY users.refresh_tokens DROP CONSTRAINT IF EXISTS refresh_tokens__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_users DROP CONSTRAINT IF EXISTS identity_users__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_tokens DROP CONSTRAINT IF EXISTS identity_user_tokens__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_roles DROP CONSTRAINT IF EXISTS identity_user_roles__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_logins DROP CONSTRAINT IF EXISTS identity_user_logins__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_user_claims DROP CONSTRAINT IF EXISTS identity_user_claims__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_roles DROP CONSTRAINT IF EXISTS identity_roles__pkey;
ALTER TABLE IF EXISTS ONLY users.identity_role_claims DROP CONSTRAINT IF EXISTS identity_role_claims__pkey;
ALTER TABLE IF EXISTS ONLY server.user_session_inactivation_reasons DROP CONSTRAINT IF EXISTS user_session_inactivation_reasons__pkey;
ALTER TABLE IF EXISTS ONLY server.user_ban_reasons DROP CONSTRAINT IF EXISTS user_ban_reasons__pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY logs.registration_logs DROP CONSTRAINT IF EXISTS registration_logs__pkey;
ALTER TABLE IF EXISTS ONLY logs.authentication_logs DROP CONSTRAINT IF EXISTS authentication_logs__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_heroes_creature_types DROP CONSTRAINT IF EXISTS x_heroes_creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_types_damage_types DROP CONSTRAINT IF EXISTS x_equipment_types_damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.smithing_materials DROP CONSTRAINT IF EXISTS smithing_materials__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slots DROP CONSTRAINT IF EXISTS slots__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slot_types DROP CONSTRAINT IF EXISTS slot_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__pkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.damage_types DROP CONSTRAINT IF EXISTS damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.creature_types DROP CONSTRAINT IF EXISTS creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_heroes DROP CONSTRAINT IF EXISTS base_heroes__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__pkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__pkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__pkey;
DROP TABLE IF EXISTS users.users;
DROP TABLE IF EXISTS users.user_sessions;
DROP TABLE IF EXISTS users.user_devices;
DROP TABLE IF EXISTS users.user_bans;
DROP TABLE IF EXISTS users.user_accesskeys;
DROP TABLE IF EXISTS users.refresh_tokens;
DROP TABLE IF EXISTS users.identity_users;
DROP TABLE IF EXISTS users.identity_user_tokens;
DROP TABLE IF EXISTS users.identity_user_roles;
DROP TABLE IF EXISTS users.identity_user_logins;
DROP TABLE IF EXISTS users.identity_roles;
DROP TABLE IF EXISTS users.identity_user_claims;
DROP TABLE IF EXISTS users.identity_role_claims;
DROP TABLE IF EXISTS server.user_session_inactivation_reasons;
DROP TABLE IF EXISTS server.user_ban_reasons;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS logs.registration_logs;
DROP TABLE IF EXISTS logs.authentication_logs;
DROP TABLE IF EXISTS game_data.x_heroes_creature_types;
DROP TABLE IF EXISTS game_data.x_equipment_types_damage_types;
DROP TABLE IF EXISTS game_data.smithing_materials;
DROP TABLE IF EXISTS game_data.slots;
DROP TABLE IF EXISTS game_data.slot_types;
DROP TABLE IF EXISTS game_data.material_damage_percents;
DROP TABLE IF EXISTS game_data.equipment_types;
DROP TABLE IF EXISTS game_data.damage_types;
DROP TABLE IF EXISTS game_data.creature_types;
DROP TABLE IF EXISTS game_data.base_heroes;
DROP TABLE IF EXISTS game_data.base_equipments;
DROP TABLE IF EXISTS collection.heroes;
DROP TABLE IF EXISTS collection.equipments;
DROP FUNCTION IF EXISTS public.prevent_id_update();
DROP FUNCTION IF EXISTS public.fn_on_ddl_prevent_id_update();
DROP FUNCTION IF EXISTS public.create_triggers__prevent_id_update();
DROP SCHEMA IF EXISTS users;
DROP SCHEMA IF EXISTS server;
DROP SCHEMA IF EXISTS logs;
DROP SCHEMA IF EXISTS game_data;
DROP SCHEMA IF EXISTS collection;
--
-- TOC entry 6 (class 2615 OID 55815)
-- Name: collection; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA collection;


--
-- TOC entry 7 (class 2615 OID 55816)
-- Name: game_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA game_data;


--
-- TOC entry 8 (class 2615 OID 55817)
-- Name: logs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA logs;


--
-- TOC entry 9 (class 2615 OID 55818)
-- Name: server; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA server;


--
-- TOC entry 10 (class 2615 OID 55819)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


--
-- TOC entry 279 (class 1255 OID 55820)
-- Name: create_triggers__prevent_id_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_triggers__prevent_id_update() RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    tbl_record RECORD;
BEGIN
    -- Перебор всех таблиц, кроме схемы public, у которых есть колонка 'id'
    FOR tbl_record IN
        SELECT n.nspname AS schema_name, c.relname AS table_name
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname != 'public'
          AND c.relkind = 'r' -- только обычные таблицы
          AND EXISTS (
              SELECT 1 
              FROM pg_attribute a 
              WHERE a.attrelid = c.oid 
                AND a.attname = 'id' 
                AND a.attnum > 0 
                AND NOT a.attisdropped
          )
    LOOP
        -- Динамическое создание триггера
        EXECUTE format('
            DROP TRIGGER IF EXISTS trg_prevent_id_change ON %I.%I;
            CREATE TRIGGER trg_prevent_id_change
            BEFORE UPDATE ON %I.%I
            FOR EACH ROW
            EXECUTE FUNCTION public.prevent_id_update();',
            tbl_record.schema_name, tbl_record.table_name,
            tbl_record.schema_name, tbl_record.table_name
        );
    END LOOP;
END;
$$;


--
-- TOC entry 280 (class 1255 OID 55821)
-- Name: fn_on_ddl_prevent_id_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.fn_on_ddl_prevent_id_update() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    obj RECORD;
    schema_name TEXT;
    table_name TEXT;
    has_id BOOLEAN;
    trigger_exists BOOLEAN;
BEGIN
    -- Перебор объектов, затронутых командой DDL
    FOR obj IN SELECT * FROM pg_event_trigger_ddl_commands() LOOP
        
        -- Работаем только с таблицами
        IF obj.object_type = 'table' THEN
            
            -- Получение имени схемы и таблицы через OID объекта
            SELECT n.nspname, c.relname
            INTO schema_name, table_name
            FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE c.oid = obj.objid;

            -- Проверка условий: схема не public
            IF schema_name IS DISTINCT FROM 'public' THEN
                
                -- Проверка наличия колонки id
                SELECT EXISTS (
                    SELECT 1 
                    FROM pg_attribute 
                    WHERE attrelid = obj.objid 
                      AND attname = 'id' 
                      AND attnum > 0 
                      AND NOT attisdropped
                ) INTO has_id;

                -- Если колонка id есть
                IF has_id THEN
                    -- ВАЖНО: Проверяем, существует ли уже такой триггер для этой таблицы
                    SELECT EXISTS (
                        SELECT 1 
                        FROM pg_trigger 
                        WHERE tgrelid = obj.objid 
                          AND tgname = 'trg_prevent_id_change'
                    ) INTO trigger_exists;

                    -- Создаем триггер только если его нет
                    IF NOT trigger_exists THEN
                        EXECUTE format('
                            CREATE TRIGGER trg_prevent_id_change
                            BEFORE UPDATE ON %I.%I
                            FOR EACH ROW
                            EXECUTE FUNCTION public.prevent_id_update();',
                            schema_name, table_name
                        );
                    END IF;
                END IF;
            END IF;
        END IF;
    END LOOP;
END;
$$;


--
-- TOC entry 281 (class 1255 OID 55822)
-- Name: prevent_id_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_id_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Проверка на изменение значения id
    IF NEW.id IS DISTINCT FROM OLD.id THEN
        RAISE EXCEPTION 'Изменение поля "id" запрещено. (Table: %.%)', TG_TABLE_SCHEMA, TG_TABLE_NAME;
    END IF;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 55823)
-- Name: equipments; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.equipments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    base_equipment_id integer NOT NULL,
    group_name character varying(256),
    hero_id uuid,
    slot_id integer
);


--
-- TOC entry 225 (class 1259 OID 55836)
-- Name: heroes; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.heroes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_hero_id integer NOT NULL,
    health1000 bigint CONSTRAINT heroes_health_not_null NOT NULL,
    strength integer NOT NULL,
    agility integer NOT NULL,
    intelligence integer NOT NULL,
    crit_chance integer NOT NULL,
    crit_power integer NOT NULL,
    haste integer NOT NULL,
    versality integer NOT NULL,
    endurance_physical integer NOT NULL,
    endurance_magical integer NOT NULL,
    resist_damage_physical integer NOT NULL,
    resist_damage_magical integer NOT NULL,
    experience_now bigint DEFAULT 0 NOT NULL,
    group_name character varying(256),
    level integer DEFAULT 1 NOT NULL,
    rarity integer DEFAULT 1 NOT NULL,
    damage jsonb
);


--
-- TOC entry 226 (class 1259 OID 55866)
-- Name: base_equipments; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_equipments (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    equipment_type_id integer NOT NULL,
    health jsonb,
    damage jsonb,
    smithing_material_id integer
);


--
-- TOC entry 227 (class 1259 OID 55877)
-- Name: base_equipments_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_equipments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_equipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 55878)
-- Name: base_heroes; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_heroes (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL,
    health jsonb,
    damage jsonb
);


--
-- TOC entry 229 (class 1259 OID 55890)
-- Name: base_heroes_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_heroes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_heroes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 55891)
-- Name: creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.creature_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 55896)
-- Name: creature_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.creature_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.creature_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 55897)
-- Name: damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.damage_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256),
    dev_hint_ru text,
    category integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 55906)
-- Name: damage_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.damage_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.damage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 55907)
-- Name: equipment_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.equipment_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256) NOT NULL,
    mass_physical integer DEFAULT 0 NOT NULL,
    mass_magical integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    spend_action_points integer DEFAULT 0 NOT NULL,
    block_other_hand boolean,
    damage jsonb
);


--
-- TOC entry 235 (class 1259 OID 55926)
-- Name: equipment_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.equipment_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.equipment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 55927)
-- Name: material_damage_percents; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.material_damage_percents (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 55934)
-- Name: material_damage_percents_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.material_damage_percents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.material_damage_percents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 55935)
-- Name: slot_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slot_types (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256)
);


--
-- TOC entry 239 (class 1259 OID 55942)
-- Name: slot_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slot_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slot_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 55943)
-- Name: slots; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slots (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    slot_type_id integer NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 55949)
-- Name: slots_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slots ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 55950)
-- Name: smithing_materials; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.smithing_materials (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    name_ru character varying(256)
);


--
-- TOC entry 243 (class 1259 OID 55957)
-- Name: smithing_materials_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.smithing_materials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.smithing_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 244 (class 1259 OID 55958)
-- Name: x_equipment_types_damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_equipment_types_damage_types (
    equipment_type_id integer CONSTRAINT x_equipment_type_damage_type_equipment_type_id_not_null NOT NULL,
    damage_type_id integer CONSTRAINT x_equipment_type_damage_type_damage_type_id_not_null NOT NULL,
    damage_coef integer DEFAULT 0 CONSTRAINT x_equipment_type_damage_type_damage_coef_not_null NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 55965)
-- Name: x_heroes_creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_heroes_creature_types (
    base_hero_id integer CONSTRAINT x_hero_creature_type_hero_id_not_null NOT NULL,
    creature_type_id integer CONSTRAINT x_hero_creature_type_creature_type_id_not_null NOT NULL
);


--
-- TOC entry 266 (class 1259 OID 56427)
-- Name: authentication_logs; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.authentication_logs (
    id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    email character varying(256),
    user_id uuid,
    success boolean NOT NULL,
    user_device_id uuid,
    ip inet,
    user_session_id uuid
);


--
-- TOC entry 267 (class 1259 OID 56455)
-- Name: registration_logs; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.registration_logs (
    id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    email character varying(256),
    user_id uuid,
    success boolean NOT NULL,
    user_device_id uuid,
    ip inet
);


--
-- TOC entry 246 (class 1259 OID 55993)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 55998)
-- Name: user_ban_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_ban_reasons (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- TOC entry 248 (class 1259 OID 56005)
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_ban_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_ban_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 249 (class 1259 OID 56006)
-- Name: user_session_inactivation_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_session_inactivation_reasons (
    id integer NOT NULL,
    name text NOT NULL,
    code integer NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 56014)
-- Name: user_session_inactivation_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_session_inactivation_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_session_inactivation_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 251 (class 1259 OID 56015)
-- Name: identity_role_claims; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_role_claims (
    id integer CONSTRAINT asp_net_role_claims_id_not_null NOT NULL,
    role_id uuid CONSTRAINT asp_net_role_claims_role_id_not_null NOT NULL,
    claim_type text,
    claim_value text
);


--
-- TOC entry 252 (class 1259 OID 56022)
-- Name: asp_net_role_claims_id_seq; Type: SEQUENCE; Schema: users; Owner: -
--

ALTER TABLE users.identity_role_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME users.asp_net_role_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 253 (class 1259 OID 56023)
-- Name: identity_user_claims; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_claims (
    id integer CONSTRAINT asp_net_user_claims_id_not_null NOT NULL,
    user_id uuid CONSTRAINT asp_net_user_claims_user_id_not_null NOT NULL,
    claim_type text,
    claim_value text
);


--
-- TOC entry 254 (class 1259 OID 56030)
-- Name: asp_net_user_claims_id_seq; Type: SEQUENCE; Schema: users; Owner: -
--

ALTER TABLE users.identity_user_claims ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME users.asp_net_user_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 255 (class 1259 OID 56031)
-- Name: identity_roles; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_roles (
    id uuid CONSTRAINT asp_net_roles_id_not_null NOT NULL,
    name character varying(256),
    normalized_name character varying(256),
    concurrency_stamp text
);


--
-- TOC entry 256 (class 1259 OID 56037)
-- Name: identity_user_logins; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_logins (
    login_provider text CONSTRAINT asp_net_user_logins_login_provider_not_null NOT NULL,
    provider_key text CONSTRAINT asp_net_user_logins_provider_key_not_null NOT NULL,
    provider_display_name text,
    user_id uuid CONSTRAINT asp_net_user_logins_user_id_not_null NOT NULL
);


--
-- TOC entry 257 (class 1259 OID 56045)
-- Name: identity_user_roles; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_roles (
    user_id uuid CONSTRAINT asp_net_user_roles_user_id_not_null NOT NULL,
    role_id uuid CONSTRAINT asp_net_user_roles_role_id_not_null NOT NULL
);


--
-- TOC entry 258 (class 1259 OID 56050)
-- Name: identity_user_tokens; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_user_tokens (
    user_id uuid CONSTRAINT asp_net_user_tokens_user_id_not_null NOT NULL,
    login_provider text CONSTRAINT asp_net_user_tokens_login_provider_not_null NOT NULL,
    name text CONSTRAINT asp_net_user_tokens_name_not_null NOT NULL,
    value text
);


--
-- TOC entry 259 (class 1259 OID 56058)
-- Name: identity_users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.identity_users (
    id uuid CONSTRAINT asp_net_users_id_not_null NOT NULL,
    user_name character varying(256),
    normalized_user_name character varying(256),
    email character varying(256),
    normalized_email character varying(256),
    email_confirmed boolean CONSTRAINT asp_net_users_email_confirmed_not_null NOT NULL,
    password_hash text,
    security_stamp text,
    concurrency_stamp text,
    phone_number text,
    phone_number_confirmed boolean CONSTRAINT asp_net_users_phone_number_confirmed_not_null NOT NULL,
    two_factor_enabled boolean CONSTRAINT asp_net_users_two_factor_enabled_not_null NOT NULL,
    lockout_end timestamp with time zone,
    lockout_enabled boolean CONSTRAINT asp_net_users_lockout_enabled_not_null NOT NULL,
    access_failed_count integer CONSTRAINT asp_net_users_access_failed_count_not_null NOT NULL,
    created_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone CONSTRAINT asp_net_users_created_at_not_null NOT NULL,
    time_zone character varying(256),
    updated_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone CONSTRAINT asp_net_users_updated_at_not_null NOT NULL,
    version bigint DEFAULT 1 CONSTRAINT asp_net_users_version_not_null NOT NULL
);


--
-- TOC entry 260 (class 1259 OID 56075)
-- Name: refresh_tokens; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.refresh_tokens (
    id uuid NOT NULL,
    token text,
    expired_date timestamp with time zone NOT NULL,
    user_id uuid NOT NULL
);


--
-- TOC entry 261 (class 1259 OID 56083)
-- Name: user_accesskeys; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_accesskeys (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    descriptor_id bytea NOT NULL,
    public_key bytea NOT NULL,
    signature_counter bigint NOT NULL,
    device_name character varying(256),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    version bigint DEFAULT 1 NOT NULL
);


--
-- TOC entry 262 (class 1259 OID 56097)
-- Name: user_bans; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_bans (
    id uuid NOT NULL,
    user_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    user_ban_reason_id integer NOT NULL
);


--
-- TOC entry 263 (class 1259 OID 56108)
-- Name: user_devices; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_devices (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    system_environment_user_name character varying(255),
    time_zone_minutes integer,
    device_unique_identifier character varying(255),
    device_model character varying(255),
    device_type character varying(255),
    operating_system character varying(255),
    processor_type character varying(255),
    processor_count integer,
    system_memory_size integer,
    graphics_device_name character varying(255),
    graphics_memory_size integer,
    system_info_supports_instancing boolean,
    system_info_npot_support character varying(255)
);


--
-- TOC entry 264 (class 1259 OID 56115)
-- Name: user_sessions; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    refresh_token_hash bytea CONSTRAINT user_sessions_token_hash_not_null NOT NULL,
    is_used boolean NOT NULL,
    is_revoked boolean NOT NULL,
    inactivated_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    user_device_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    user_session_inactivation_reason_id integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 265 (class 1259 OID 56134)
-- Name: users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.users (
    id uuid NOT NULL,
    email character varying(255),
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    time_zone character varying(255),
    is_admin boolean DEFAULT false NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 5236 (class 0 OID 55823)
-- Dependencies: 224
-- Data for Name: equipments; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.equipments (id, user_id, version, created_at, updated_at, base_equipment_id, group_name, hero_id, slot_id) FROM stdin;
bc658f5b-271e-413d-8772-01e5b007fe3d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 15:52:42.946044+08	2026-01-02 15:52:42.946044+08	1	\N	\N	\N
d93c1740-5cbb-4999-9111-d6d3e911438f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 16:31:49.146447+08	2026-01-02 16:31:49.146447+08	1	\N	\N	\N
004eac23-45a7-4c23-bc9a-f5cface0724e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
03c21165-35ea-40eb-93d4-c8e0a21f12c2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
0728f0a9-4467-4b19-8327-ad7a38b999d6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
0818ce4d-a550-4af1-9720-47e6e34d93f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
0941dcf5-f725-43ee-93c5-99025a0749f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
09d32c97-4701-4285-aed0-5bc2e8900dd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
0b8705ad-b51f-4150-b348-61fe3d5022e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
0baea179-2ced-4c5f-98bf-db2e215756fa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
0d60e004-045f-4814-9815-d865dcc4d78c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
0d68e344-00f9-49a9-a58f-4bd6f4c709cf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
0fc1b8ea-793b-4e45-a9a7-11f96111ad33	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
14e5a55d-bbb1-4725-9e64-f6534c6a243f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
15532ac5-f5a5-4859-bd84-3386a4423c60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
16228250-1463-4aa3-be37-8d392c72c9c2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
1772726b-5e3b-44bb-8bd4-e38bb4d6911d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
177aff17-7de1-4e0c-a925-6cfda50b6d2f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
1911011e-f51a-4740-9825-dd30b75b9f60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
1beb3870-caa1-4ca5-8ced-d3087f00cf06	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
1c292258-50ca-495d-ade8-96f2c806ea4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
1e56081d-2f18-4021-b38e-56c04e5125a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
21206d91-cccf-498c-b98d-a2164f3316fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
24250502-0844-49bb-917d-d60a7de3b879	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
281160a4-1d0a-49a4-9da8-b453658ba7c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
2a6666b9-c75f-4dff-a49f-f67390cc7929	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
2b4980ab-cbea-4819-ab36-6882f53269a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
2e297eb9-73b5-4f3c-9165-bd031d2b1164	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
2ee52ff8-2437-4b40-8a93-45bd812c2510	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
2f0d86f4-1d9f-4afb-a5cd-9a86c8c7443d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
3172af51-2883-4939-bb6e-7728690886e2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
404201c5-0458-4bc4-aca1-5f4b4de403c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
4374af37-05eb-4649-864c-7db43de733f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
44905d22-b651-4015-a946-77d1fb3da0a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
4858af6f-c03d-4b5d-8e51-a118ada986fe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
486b8fb7-86f9-4355-8c1e-7402453b8233	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
4abadd00-2a20-4865-80a9-466dd1593f9e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
4ad6fea0-cd58-4596-8f0a-57ade89f6a4d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
4cd987bf-ff00-477a-94b6-ce5ff050e320	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
4cfd6971-54bb-4214-81b7-238ba51c6b03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
54551190-5dc3-4992-b3f3-4b52a9c5af0d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
5e572c90-cd06-4716-b948-e46743a7f084	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
62c00c46-355c-4c81-bf5d-78c30f63e317	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
662b725f-5d76-461a-b43f-fe245e0e6938	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
6bdda9c4-819a-4eff-a08e-43d70272a0fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
6f2b1238-3a32-4ac4-8160-d7fabdc8e055	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
70242065-3ee0-4068-b703-4675e62cfd8c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
7582f03b-0c80-4d43-80c4-6252293d14e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
76092f4e-9590-4449-a084-4d089e6c2537	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
7b3a1271-d793-49f1-a25e-632e0904ecbc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
80c1d388-8e54-44a0-9689-15a4ea28d124	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
80e2b06e-361c-4981-8b54-3d252a3909c1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
88fe39a3-1753-48db-8648-062434eb4943	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
89a62f9c-02e3-43c3-b43c-e85ed404f905	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
8becde0f-700c-4085-be4c-62b0d597c0e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
90d42bde-ee4e-4f2d-8e12-f2c111f15b26	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
921258a5-6bd4-482b-aed7-ad1d5423f108	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
9335f1fa-78b9-4271-a26b-71bfa80e569a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
93470745-5108-441f-b23e-5601e2007e3a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
98b0da3a-2bcc-4329-a36a-26cb6bc13633	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
990971b2-89ed-4b92-a751-810da143ad5a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
9f72c879-f5eb-4636-b78a-98682b0a071e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
a0fd5a82-5969-4f3d-83ca-7678b13c74ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
a2a63ce0-bcba-4570-989d-a81ff4f56531	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
a2bb8afa-4b0b-488f-9e62-a20c634b729d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
a834c17f-3188-48b4-8025-86e3cc0bdf0a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
a8cb9a26-6249-439e-aed7-f55e0e90399f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
a91ee17e-74d2-498b-a6c3-326a3ff43a10	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
ab351ca9-1f4c-4f49-80ff-d33a3b6860d2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
abf7d895-5486-4398-97fc-447e5c1d5c94	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
b0b60e7d-99de-4d36-9f75-34011a398acf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
b3109a89-a033-4aa7-9e3f-3c6ec8fa509e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
b44b6bc8-ff3f-462a-919c-d47719dd8962	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
b4a46daa-eb71-4e9f-9547-e3c2cb405ddb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
b8e8291e-bd33-45d0-94f4-0ca449b2a8a9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
b938d21a-8951-46ea-9bf9-dafceb3ccf47	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
be6022b8-d505-4986-8900-a0bad47cbc25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
bfdbe6aa-1915-4ecf-860a-6c6c2c939334	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
c1970acb-ae5e-4e04-8b79-a89f5af3478a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
c1fc4653-b96a-4100-a0cd-2d0d42eace5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
c2e4c3ad-659b-4ce0-8fbd-002ded27d18e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
c79c3d53-06e3-4135-9592-f255c3979322	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
c811abc5-dcac-426d-8774-0eff73e52af6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
c811f6b7-04b3-427d-b594-1d2cf2bc9d79	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
c852cf2c-79bd-4549-a7de-dc5b47790aea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
c8e8b107-dbbd-41a2-923e-04c5b83e737a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
cdacef26-5c67-49c0-99e3-8969deeb1012	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
d0e066e0-cacb-4927-a207-975e23e6be98	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
d4df6bae-9bfa-4f0d-aa4a-e17aa3748f9b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	3	\N	\N	\N
d4fb341b-d7de-44f7-9e1a-e50d39816ef1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
d5d3cafc-eb45-43cf-8757-5eb4dcdaa86c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
d903e974-c37e-417d-9e68-36a7fbb10279	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
da5a7832-bd3f-463e-87e2-4b766b7fe11f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
dffa4c5c-fd2a-4bb9-a27c-45f7fa553852	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
e2eabb23-3dcf-4b57-89d4-f0ce03337c22	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	5	\N	\N	\N
e5d8cc10-0f19-4677-9768-7c0b8fa6c815	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	1	\N	\N	\N
e60484c7-e027-4f17-becb-3482576fc50c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	6	\N	\N	\N
eb3fb02e-4351-47e4-bc2e-57c252962833	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
ef649618-6fc3-4b29-94c8-1f2ccd11c5d8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	8	\N	\N	\N
f848e76d-0abd-486a-b098-43ae740ef2c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
f8f02643-b4c6-4fc1-81a4-da2ec5c3b6cb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	2	\N	\N	\N
f9074397-5296-4dc7-a21a-9170c04a76de	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:53:16.146893+08	2026-01-02 17:53:16.146893+08	4	\N	\N	\N
007fb8ff-635b-44fd-91c7-5f90d9929fbd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
06215d30-a645-434c-b01a-d79e9119b26a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
06f621e6-5898-4c10-a8ef-ee81be6938e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
083f7830-321a-435f-8b63-b821a789049a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
0a94e05f-8b3e-4997-b3a1-edf586a71c8e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
0ea2b2b1-cff4-466a-add8-b3327463cde6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
117f3921-7c47-40b0-8f0e-c9eb7d857082	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
11f98e9d-2abd-4c50-b29e-a5e1798dd14f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
16a0117c-f84c-4154-abea-889dba76dee6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
1a43fcf1-b6f7-4fd2-a0ad-8ace9631c62f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
1c8e67b9-20b8-4bbc-8a48-5b764cc90527	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
290e124f-0b1d-4675-8710-6cc68c61897d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
2a5d7295-91b3-4eb3-a7e1-76dafea76a76	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
2f3f4082-cd7a-4453-9eca-291012762956	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
31ce9a1a-200c-4112-b138-d378f8f3af91	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
3305df7d-a699-4d6a-beb3-b14a4aa3deac	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
3a44dda9-77ba-4491-91a1-cc9dcd1429bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
3cc5ee0b-958e-436c-8ed6-8f678c22d401	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
3fc37e1b-9b3d-4ff1-b225-974a0174aeb2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
3fd3050b-5124-43fc-b3a1-21d7a2cef715	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
40723513-6b5d-4cb8-9309-3145630b690c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
43980a85-0963-40c0-99fb-76ea962556ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
49533fe0-41ec-4068-a55d-9cd7c58591b5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
4c722bc1-482e-4251-a99d-efe04ddfb59f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
4d05a739-acd1-411e-b209-155907bb31a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
4d976284-a6dc-48cd-83e4-d7f2f894344e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
4e7f7b5a-f072-4296-920a-7611ba5f8b49	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
4f8c1255-be27-4d37-b63d-0b44cdd035ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
51eaae7d-216a-4cd1-ae5c-2032338608ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
5382ca7f-7558-441d-9d8d-e80f7a21d501	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
5419e4ed-45d9-4c11-aed7-11e56d31f7e4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
5523751a-5dda-4e28-9cad-762f598a1cb7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
55773bc3-50ff-4269-a8ad-7a55f8b1ae5b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
56c2c02b-a474-4d61-97d4-0269d6469fe0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
59150023-2912-4d0b-8a52-789c55d88f25	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
59f16175-b77a-47b8-86b0-da960c018e5f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
5b067d42-bd9b-4354-94b3-7197ab48c35e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
5b563efe-67f1-4d1f-8af1-1f6b88fa714a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
5d8b8fcf-b60b-4597-ae3a-c1452a4c07e8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
5e076804-ba23-4a08-80be-dd5cf23d5e45	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
5e63a3ef-0a0d-4f73-b0cd-9549c630fd36	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
602ae1f0-ef45-4f51-b2d1-3c8ef93f6638	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
6aa8dd70-f3d0-410f-ad64-ab7a62907c32	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
71ccc8eb-05b6-4709-a740-3b615194c9c8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
76e72ba0-b270-4d23-9704-f319c101a1fd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
774d5117-2628-4e8c-90c6-0ddaf398b1c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
777a0401-45b0-418a-80bc-3425e95db6b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
78830dd5-3adc-4278-83ed-e55fe0f452c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
7e1e1850-f912-499b-993e-74d764089129	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
7ecf1025-781e-4629-9595-defb4ab1b6bf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
82714929-210d-458c-9d89-1b8aaa9577aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
82e015ff-8374-4440-a7bd-b101203d00b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
834b96da-8144-4336-a3d3-f192471b4214	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
89f608fa-db98-454c-9fcc-85fbb8f42d21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
8fc09204-0f4f-4118-8ec9-dd8c85de2d9f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
93dffad3-c0a4-484b-a56e-b7477db9a9b3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
97131b87-bce4-4c52-aafc-ef8378f78ea7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
995572df-5ba3-4377-b694-d6e9fe017bc9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
99e584cb-5ec5-4de1-9d0d-91b8759e8b18	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
9e765e4c-7048-4484-9e41-968019c87f39	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
9edde83b-bf78-4bf9-b1e2-c893c1a20d3b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
a0060589-5283-4f2e-adda-64cb31ca61b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
a1858b11-e636-4f3f-8f19-3829c69f1da0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
a262216e-373b-4231-988b-8966717879db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
a3952170-bbc6-44df-908b-2ddd4aec18c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
a51eb0c0-b5b5-4578-946d-e5b90f3b1cf5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
a60152ac-7ffa-4307-835a-8f5d3e74045d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
a7e22674-3d61-475d-9e84-acfa44994e24	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
a85a52b9-c269-4efc-aac5-6c6d47f93654	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
a9c2a338-7c08-4255-94fb-0bd7c45c283a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
ab56d6ec-fdf1-4d64-9293-db7f571be8c7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
ac2783e6-48ab-45ad-abf9-e0fd3e73c337	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
ac3723f8-9be6-4893-9083-e15f61bd4df9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
b1372774-7834-428f-adbd-a65416fb0667	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
b22b1c17-d3dc-4691-b735-867cfc07169b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
b5cdedca-ae41-4208-8bac-dcb50c82e085	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
b6297efb-c9b6-4aa4-95d9-d868fca7eb9d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
b700eb7d-c2d4-445f-b66f-1949f20d45cc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
ba0e4120-ce83-4b6b-a773-a7608c9ab6fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
ba9f89c5-bca8-4060-9c25-2b24b188c45a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
c581f993-c590-40c2-8ba4-60577d3776b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
c6afcce0-cc91-49c6-a5ce-e31715423c08	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
ce711283-f774-469d-a311-9046810c12b8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
d52c707e-f2ac-4694-8aea-11170130b2ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	1	\N	\N	\N
d6b4bc72-8e32-4ee8-86bc-2fadfebe918b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	6	\N	\N	\N
d89f0aa3-d3cc-436e-b609-4aa5d7cea7b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
da03d703-2058-4553-bb88-99cf9edfeacd	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
dba4c117-51d3-4aac-a1a9-8e32506f3e11	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
dc370da0-6cfe-4fa4-be72-fa06f177bdca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
dcf95c24-5efe-4917-a254-a976fa0782b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
de47d95b-6ff3-4f77-a4e0-6baefc36d21d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
de9b6a2e-d425-426d-bf8a-6bfc8818d66d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
e331c1a9-498a-4657-b488-ea3f8292ac3f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	8	\N	\N	\N
e621af9b-7976-4c6c-8bd9-e45ac4fc96e6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	3	\N	\N	\N
e68754c3-407c-4c8d-9c76-440cd5c85284	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
e7004cad-dfbf-4baf-ad59-8f87c3a727aa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
eae8115b-4db6-48dd-8182-019f4dc44b2c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	5	\N	\N	\N
f04a2861-811b-4bdf-9cda-f2028e45eff6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	2	\N	\N	\N
f97ceaaa-0679-4f84-9c68-8f93257735a0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
fa4965b4-4fea-4895-a862-5ced93c5d226	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-02 17:55:03.324747+08	2026-01-02 17:55:03.324747+08	4	\N	\N	\N
\.


--
-- TOC entry 5237 (class 0 OID 55836)
-- Dependencies: 225
-- Data for Name: heroes; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.heroes (id, user_id, version, created_at, updated_at, base_hero_id, health1000, strength, agility, intelligence, crit_chance, crit_power, haste, versality, endurance_physical, endurance_magical, resist_damage_physical, resist_damage_magical, experience_now, group_name, level, rarity, damage) FROM stdin;
00d15172-a3af-4d5b-b74a-afff5e4f40ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
0266366e-b12a-469c-803f-b7ee15b27873	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
04656b9b-054e-46e5-a1e9-37a89f7a567c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
05dffd34-79a7-4ff1-acf2-21fd50813567	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
0754256d-73cf-491b-9db5-6d602d5f6d85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
07a88b06-e936-47ad-a6b6-3a7bcbc9b2ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
08408de3-dae4-4f8c-9d2e-0a51f2a7f2c7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
08e3971a-f82b-495d-99d8-500b901ef8a4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
0aeef53d-4cd4-418b-afbb-f5410a3f3928	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
0b643d98-6e79-435f-933d-e5509760dd1a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
0cf13183-5006-4ec3-be7d-b5c6baf97f32	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
0dfbeb24-96fc-486e-8a45-8e07a6c40aa0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
0ed634b5-ecc9-43cb-835d-4be0cfe2d7fb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
143d2a3b-b95e-4d37-8c43-469d7adb0bd4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
14b74ba6-ac36-4175-a598-a1635ac7d990	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
15997452-6402-4b73-9e45-317bf4175749	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
15a600d4-bd74-46b8-b517-7aef13bf8409	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
164918fa-e22a-4967-98b5-133fcf95a176	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
17e05720-b2b4-42c4-86fc-e07b7a110099	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
18cbf529-1ff3-4207-9471-7fc56481c5b0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
1bf8858e-4976-4c1e-a1ca-4536fedcd9f3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
1c126ec2-7da6-4336-99e2-193f91ee4ef3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
1c668c54-9a1a-42dc-8cde-0726b2e3c3e3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
1eca8648-1ee4-4a2f-85f9-bfddb1d553c4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
21b8d7da-a0d5-464b-a845-4afb764f9314	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
2338b545-48d8-41f0-bb27-1706937571c3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
235a0901-ad04-48ed-96a2-1cfa40889ba3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
24217f56-f036-4aa6-9903-28891644aefc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
260dc441-c013-4e75-8e4a-8d131d2f37e2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
26953a41-ac9b-4a74-851b-483d85cfdada	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
27ab0120-3d47-484f-ad6a-3417ce5562cf	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
28b197a1-4e7e-4dd4-9b80-1634ae196c03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
28b6618a-e460-4a11-a1db-0006e70a8a03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
29149a2a-f227-4e48-b3d8-45784b5f5fe5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
2994039f-7818-4bc3-8496-40b1908b048e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
299b966a-b4d9-41fc-a78c-5dcf9d55e176	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
2a2dc63e-0ad8-48fe-9544-bcab07ae160a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
2ab86ee2-ae56-4008-9b1a-d034c1790977	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
2d8330a3-ee74-401a-82a9-b738dd4a13a2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
2daf9231-5dd6-4957-b81b-734092b3e3d2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
2e0d1dd3-3445-462a-82b9-291d67f5dba0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
2eb96905-9161-4046-b21c-ea225a83c57e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
2ef1f600-ff3a-4fee-a4cc-3c156cc8879c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
33136c07-231f-4e3a-9d28-754750e34c82	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
347c32b1-be4c-424c-b9f2-26f0b6e7b8f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
352f4318-ab60-4d8f-8733-b4a06b837a28	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
3554516d-5d1d-40dd-bc0a-382f3cdd6175	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
35ce8e97-293c-4498-8080-6f7707a951ec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
36621c98-6130-4705-bc35-e4ee62bf9834	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
37321558-1511-44ea-9dcc-f3abacc0b722	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
39533131-8e76-494e-b892-72e0bdaca095	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
3a004616-16ec-4fc0-84f3-979ca75f5458	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
3a4f3e78-8e09-499a-b51f-0ab76a642cf1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
3c8f700c-7c97-4b9c-beec-bce8386fab21	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
3dcf3d9b-18cd-43f5-9ac4-7f2a6e9cbc4b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
3e08f530-b3e5-4c2b-83a3-6a30c1d70895	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
3e3bb90b-9765-46ad-91d0-0af6e027fa60	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
3feae5f6-4173-43c9-8674-9472be58d11d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
417d044d-f573-4ff9-9494-0f5e7e2bb983	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
43de1edd-e6c0-436e-a72c-ddb657a37c67	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
444c5f8d-541c-4448-b2d6-f08e81e84a02	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
44c7f1b3-7a29-4af2-a641-1aedee48ad49	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
45c4bf90-5f56-433d-aa18-2c53a79c55a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
47384d33-dfb2-4e33-8953-f1f237e4dfe1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
47941a9f-9397-4d41-b8c6-7ccdb4038c03	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
47ad56fd-e6e7-4b14-adb2-14c90cc01041	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
498ee4a9-4814-496b-a57b-2186a17501ca	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
49b9cbda-2d0b-43f3-a3c7-b902216a458d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
4b216c1a-dcd8-4bb6-8dd4-b65323e7659a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
4badfaf1-690c-4eec-bc94-88cf458bdb2f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
4de978cd-1498-4ea9-8b3d-5f7a9f49dead	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
4e2bd5bd-e070-4833-a399-c36169364991	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
4ed77d72-b373-43d0-a740-71c5986d6b8a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
50140a70-35e3-48fe-87ec-78d750e87829	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
51f0791d-c533-4e99-bfc5-45487eb0b798	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
5378244b-33d9-40cd-b979-f6caf9e20624	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
53aaa744-d42f-4ba8-a9d1-f780be297b2e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
5483ba12-b589-42f2-840d-e95ccc5353bc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
549109c6-87f6-4e13-8208-7e8de50e07e7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
566dd384-a6ee-43cd-88be-7ed3c9870edb	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
567aec0c-fc1d-4f68-9208-3d1ec66d8bc5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
57a8f725-f89f-4536-a1a9-baa402c2eaa2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
587a8df8-3c79-4f58-872c-e4942752f0a6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
5a6e0f92-82b5-4a21-a0e4-121bc823e0c6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
5ca8da99-0bb2-416f-81ce-c687393c6eb6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
5ca99e73-3fc5-45b3-9da9-7f90aaf8a727	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
5d263dfd-f053-4b02-8bd6-6ba87393d3c0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
602632ba-91bc-4d93-ae4c-456df49617d1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
61bb7d59-a254-40d8-bdfa-7cdbebd7de8b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
65e4d6ae-c24f-4b06-adc8-a88b3da71afa	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
67aee31b-94ef-4e2a-9fa0-f2440106123d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
67b0ded4-13d6-4ff7-a84d-813cdaae250d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
686f057b-c241-4482-9cd7-05a9877564b2	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
69079a58-6f66-4573-891d-aa2148178761	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
6a7b5600-f310-4b58-8c06-42f2227ae46d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
6cf5f15e-d67b-4c4f-aa46-4e4073b1fed4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
6d65f37f-e3c4-4698-955a-40726263b0ea	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
6d9e52cc-2644-47df-a0c8-86671aaedce5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
6db66014-a2ad-475b-9a2d-e0a2b1432eec	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
702d89ff-47ad-4a87-838a-2862346fea1d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
70ec6702-e712-4f01-9ae1-c9917103faed	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
72dfce7a-6b85-4b56-ac05-efd8abe1fdb8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
72fd8f83-0e33-4355-9743-829c68f17501	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
7309230e-9f0e-4e56-985c-c79a1320ea97	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
73162e8a-595f-4001-8757-fe1ad4aa6c33	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
7573ced8-e346-4d0d-a836-8bbb4e2bdf28	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
77da8bc1-f6d3-4aa4-86e2-0dfdc647cc4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
77fb8139-31ec-4fdb-9626-8cd844159158	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
79a7bf50-bfa8-4d9d-a940-669caa4877e8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
7a2041d7-3afb-4301-aaf2-0c589ba59b43	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
7ab5047f-d279-4ae6-bac7-a5d06e480986	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
7b30180a-c80e-4d8f-b471-24a7a979e61b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
7c83549e-9983-45b8-b5a1-6d6de58d7c79	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
7d0f369f-2d57-4d41-97d5-ac3c53703898	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
7f09f517-1cfc-4dc6-b01d-bfc75bb06a26	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
817541c5-5ae1-453c-bfc1-f77ca632f52b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
84932dae-6f57-43e8-81c9-7f00d00383d7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
84b0d445-4047-4d32-84cb-34244a67d72d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
85241ad0-9eca-4ca4-a615-69cd595423b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
85f46ec5-d1d6-4771-a3d9-20dcae0dca4b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
887a9f50-0b29-4162-bd96-31be110f0e41	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
88c4caad-6959-47a9-a66c-668111d847f8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
89e6ad14-944f-49c8-ba88-84d26dbd714d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
8ebb103b-a606-404e-89dc-aeb034769481	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
8f353329-0d5c-45e6-b845-f0cce6b63002	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
8f3a7207-72c7-45bf-9e90-f54d99845a59	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
90414897-1a40-4503-8b40-7ec27abe4996	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
91030051-7ab7-4c87-bd45-5995f27f21a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
912c2462-9baf-469b-b864-df1981b81198	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
91ba5479-f3ba-48d1-9610-616f4ea1ad13	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
924f92f3-1031-4251-88c7-79d58b1bb6f6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
92ce93cb-9ab5-47e3-8eb7-bcd596e379b4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
932acfe8-1010-4f6e-88ef-dc51a3515442	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
93913d4f-eb01-4f5d-8706-d086436bd816	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
9404d5b8-aebf-49d6-94eb-583a43c37ea7	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
94f6739e-b3a2-4463-bbba-d07f067c754c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
96c51438-3f00-4037-b046-f84abd0c9c5e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
976ad311-bcc9-4529-9c4f-2248e4a6439c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
9879c96e-c051-420e-beac-04d7177203ad	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
9972340a-728e-4772-8ac7-7e01752ad3ce	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
99b7f946-a50a-44c4-8a45-e07e703fe563	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
9ab7e8b5-87ba-41b6-9372-bdb2c353b9a5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9b280c5f-fbaf-4676-8c97-0db424ee52b9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9bf7a6bc-db0d-4cb1-898b-33c972ca0977	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9c366980-6b1c-499c-9839-9c8467da26c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
9ca6453f-e5d8-4cde-9629-038316cbc150	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
9cdcf225-7d3a-4abf-ad76-34a2a6a88f54	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9dec1ea9-34e4-48b6-9e56-390e7064e518	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
9e39cbe2-b61e-4ad2-ac1b-e25d6835ff90	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
a06c3454-2df7-4f50-8c6e-e1b712329a12	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a2a422ff-d378-4d31-b983-8338200adb85	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a556f541-3a99-43fb-b7b7-c540f3c1137f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a73a02e7-200d-40ef-91d2-d0e3f9a12d3e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a7586e78-024a-432a-8a10-ecc2dfc44a16	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
a810022f-b398-4cdb-b121-5da91566af50	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
a928352e-38b5-491f-987b-4616c1c557db	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
ab19f278-6e8b-42f4-b4f8-b757e84524ed	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
ab96228d-cfee-460d-a42b-4c8472f13fd0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
ac2c2a75-11f0-48eb-8265-60c582270c43	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
ac77287e-2332-4bab-93ef-c92485d3d887	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
ae954a8c-e01b-4848-a0ac-3b62fdb22ece	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
affbc6fd-eb14-436a-8072-e998d5f6df4a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
b168f7f2-a4f2-4a7d-8fe8-d2a3f8751931	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
b2057ed6-7d8f-460d-8092-ea8fc8aa0843	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
b3157acb-c35e-4ebd-896d-c558762f42e1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
b3232122-d4e7-449a-aa9a-1ea3c000415f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
b52ddded-2886-4028-a8c5-312a9f7d4b67	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
b635e153-c218-492e-b961-af2c5deb985f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
b7fc51e6-bb13-487a-9ce9-f7a11461d255	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
b95e820e-eeff-42ad-a2d3-e9eb7fb2864b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
b9bafd58-7007-472f-8b49-6d21de3b7ce5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
bbd74e3d-60e1-486d-a528-2dcb93c5f09d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
bd019229-908d-4a6b-89ea-ded814b6343c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
c184f138-d63e-4a9d-82ad-5dc2f675f73d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
c28d7f23-b962-4b6a-8273-cafc97bc1984	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
c2c1f159-c5d5-45ec-8ad3-7bb85c7ad697	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
c355be9f-5f2d-4a0d-a29e-614cbe507803	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
c5995d09-8512-49a1-bcb2-c45c409876e6	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
c59bcd6f-fbed-43fb-a0de-80f6bbc72de1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
c7205015-f658-4978-a048-cfdf148bbe68	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
cad48311-9743-4f9b-baf4-d59c410afbb0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
cb3112b1-6623-4243-bd3c-9db977223401	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
cdca3c82-9a42-4739-93b5-6e815921883d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
ce9c45fa-65a9-45ed-b8b1-99ff12349fd4	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
cf7ccdfe-58aa-4457-85dc-6020ab16a872	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
cfbae36f-dde6-4fc9-9984-96332b4df1a0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
d05000de-d4b1-4968-9cb6-1e2a9a71651a	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
d476bf17-3e8a-4ed4-9185-bf53826f3c7e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
d5e5039c-64c4-4640-a884-7ff67ce83917	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
d63fae21-d77f-4267-b614-f3fec4a5013f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
d65c68f7-8f0b-40bc-9406-e21ab3995426	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
d7012e7f-7d97-4860-b490-2ffed166b752	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
d9addd2a-4362-4893-af6a-3939578711c5	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
da070b1b-2c6d-4c82-a5dc-8d00e70163ff	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
db45a856-033e-47b9-9aeb-5b95a4f4fc62	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
de36369c-53ef-4eab-901e-d4a494bbfe6b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
df3d5869-fd33-436b-a34e-ae200a67fbc3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
df6a9350-2d5c-4626-934b-2d87f272c209	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
e0273cb3-0aac-47a9-b1c1-80f2fef6964d	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
e1a90213-17a4-4a31-be8f-6b90c9977891	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
e47c25a7-53e8-49a3-bbe2-08ff8d39c299	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
e5b44b3f-8179-4e43-b1cc-e7a0176fbbb1	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
e91cc994-36ea-4186-ad1f-7c1b100e3639	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
e99a18e3-b1bb-429f-99b4-f7c0bcf9198b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
eb1f65e7-0c6b-400f-ab99-f573986a5e2e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
ed418019-be95-4ce1-b66d-b6d77bb819bc	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
ee9aabcf-d974-46fb-954d-63a6b95f181b	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
ef074ea3-d9df-4dbc-b770-b12c6103017f	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
f1340e8e-e78e-453f-a504-ea78bcfa95a3	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
f175eeaa-a3a8-4e90-97aa-100261d4fe52	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	5	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
f3aa4050-9419-4d39-96e4-e679f3d12531	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
f41e2f91-2f66-4c3d-bf89-042319dbf9d0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
f43c1ce5-23d6-416c-b15c-1f48d4094408	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	5	\N
f45ae12f-83ed-43b3-90cd-b45d7dc8f5f0	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	6	\N
f520e26b-8245-4a73-81e2-df07196c7835	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
f6c8110a-2387-4948-bc41-0e476dc2dbf9	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
fa372fc6-1741-4b3e-99ab-6e02755b622c	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
fa3b5524-a911-4f8a-a7d9-f1aecb2426fe	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	4	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	3	\N
fb283b84-6e4d-466c-998c-a4b0b1099330	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
fbb50ac2-4700-4f88-908f-d6ca43309560	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	1	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	2	\N
fbed6823-1e5e-4687-8d70-8eb1bf80d40e	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	3	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	1	\N
fce0c821-3b32-45b9-8099-d9fd1b1627f8	019b7d31-93fd-703f-a582-c82e6bd40036	1	2026-01-03 15:29:54.95603+08	2026-01-03 15:29:54.95603+08	2	0	0	0	0	0	0	0	0	0	0	0	0	0	\N	1	4	\N
\.


--
-- TOC entry 5238 (class 0 OID 55866)
-- Dependencies: 226
-- Data for Name: base_equipments; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_equipments (id, name, rarity, is_unique, equipment_type_id, health, damage, smithing_material_id) FROM stdin;
2	Iron axe	1	f	2	\N	\N	1
3	Thunderfury	4	t	15	\N	\N	11
4	Iron armor	1	f	28	\N	\N	1
5	Iron gloves	1	f	26	\N	\N	1
6	Iron helmet	1	f	27	\N	\N	1
8	Iron boots	1	f	29	\N	\N	1
1	Iron sword	1	f	1	\N	\N	1
\.


--
-- TOC entry 5240 (class 0 OID 55878)
-- Dependencies: 228
-- Data for Name: base_heroes; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_heroes (id, name, rarity, is_unique, main_stat, health, damage) FROM stdin;
1	Warrior	1	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 24}}	\N
2	Huntress	1	f	2	{"damage": {"c": 5, "s": 21}, "health": {"c": 10, "s": 28}}	\N
3	Hammerman	1	f	1	{"damage": {"c": 3, "s": 25}, "health": {"c": 11, "s": 39}}	\N
4	Rogue	1	f	2	{"damage": {"c": 4, "s": 23}, "health": {"c": 15, "s": 21}}	\N
5	Battle orc	2	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 58}}	\N
\.


--
-- TOC entry 5242 (class 0 OID 55891)
-- Dependencies: 230
-- Data for Name: creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.creature_types (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5244 (class 0 OID 55897)
-- Dependencies: 232
-- Data for Name: damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.damage_types (id, name, name_ru, dev_hint_ru, category) FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)	1
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 	1
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)	1
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда	1
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"	0
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."	0
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."	1
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."	2
11	Radiant	Лучистый	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."	2
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."	2
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."	2
17	Dark magic	Тёмная магия	Критерий\tНекротический урон\tТёмная магия (Shadow/Dark)\nСуть\tРазложение, смерть, конец.\tСтрах, боль, подавление, коррупция.\nИсточник\tСмерть, небытие, пустота, анти-жизнь.\tОтрицательные эмоции, тени, извращённая магия, пакты с тёмными сущностями.\nКак выглядит/ощущается\tХолод, влажность, запах тления, серо-зелёные тона, иссушение, гниение.\tХолод или ледяное жжение, ощущение ужаса, давление на разум, чёрные/фиолетовые тона, искажение света.\nЭффект на живую цель\tВысасывает жизненную силу, вызывает быстрое старение, некроз тканей, разложение.\tДробит волю, наводит ужас, вызывает боль, ввергает в отчаяние, может подчинять разум.\nЭффект на нежить\tЧасто исцеляет или усиливает (это её родная стихия).\tМожет наносить урон (как любая агрессивная магия), а может усиливать, делая более агрессивной.\nЭффект на демонов/исчадий\tОбычно эффективен (смерть для всех).\tЧасто неэффективен или даже подпитывает их (они сами из этой энергии).\nТипичные заклинания\t«Палящий взгляд», «Круг смерти», «Вытягивание жизни», «Увядание».\t«Стрела Тьмы», «Объятья страха», «Проклятие боли», «Порча разума».\nАналогия\tРадиация или смертельная болезнь. Убивает всё живое, разлагает материю.\tПыточный инструмент или психологическая пытка. Ломает дух, чтобы сломить тело.\nЦель атаки\tТело и душа (физическое уничтожение).\tПсихика и дух (ментальное подчинение → физический урон).\nАрхетип мага\tНекромант. Холодный учёный смерти.\tЧернокнижник, Тёмный колдун. Эмоциональный манипулятор, заключивший сделку с силами тьмы.\n	2
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."	0
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."	0
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."	0
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."	0
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."	0
\.


--
-- TOC entry 5246 (class 0 OID 55907)
-- Dependencies: 234
-- Data for Name: equipment_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.equipment_types (id, name, name_ru, mass_physical, mass_magical, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, spend_action_points, block_other_hand, damage) FROM stdin;
1	Sword	Меч	1600	0	1	t	f	0	\N	{"c": 8, "s": 4}
2	Axe	Топор	2800	0	1	t	f	0	\N	{"c": 4, "s": 17}
3	Halberd	Алебарда	4400	0	1	t	f	0	\N	{"c": 4, "s": 27}
4	Berdysh	Бердыш	3800	0	1	t	f	0	\N	{"c": 4, "s": 23}
5	Poleaxe	Секира	4000	0	1	t	f	0	\N	{"c": 4, "s": 24}
6	Chakram	Чакрам	350	0	1	t	f	0	\N	{"c": 5, "s": 3}
7	Shuriken	Сюрикен	180	0	1	t	f	0	\N	{"c": 6, "s": 2}
8	Scythe	Коса	3200	0	1	t	f	0	\N	{"c": 5, "s": 3}
9	War fan	Боевой веер	800	0	1	t	f	0	\N	{"c": 5, "s": 3}
10	Scimitar	Скимитар	1200	0	1	t	f	0	\N	{"c": 6, "s": 4}
11	Katana	Катана	1100	0	1	t	f	0	\N	{"c": 7, "s": 3}
12	Yataghan	Ятаган	1000	0	1	t	f	0	\N	{"c": 6, "s": 3}
13	Sabre	Сабля	1100	0	1	t	f	0	\N	{"c": 7, "s": 3}
14	Morning star	Моргенштерн	5000	0	1	t	f	0	\N	{"c": 1, "s": 123}
15	Warhammer	Боевой молот	6200	0	1	t	f	0	\N	{"c": 1, "s": 153}
16	Mace	Булава	3000	0	1	t	f	0	\N	{"c": 1, "s": 73}
17	Crossbow	Арбалет	3200	0	1	t	f	0	\N	{"c": 14, "s": 2}
19	Trident	Трезубец	3400	0	1	t	f	0	\N	{"c": 28, "s": 2}
20	Rapier	Рапира	850	0	1	t	f	0	\N	{"c": 8, "s": 2}
21	Pike	Пика	2800	0	1	t	f	0	\N	{"c": 24, "s": 2}
22	Spear	Копьё	2200	0	1	t	f	0	\N	{"c": 20, "s": 2}
23	Broadaxe	Широкий топор	5200	0	1	t	f	0	\N	{"c": 4, "s": 32}
24	Dagger	Кинжал	400	0	1	t	f	0	\N	{"c": 4, "s": 2}
18	Bow	Лук	960	0	1	t	f	0	t	{"c": 4, "s": 2}
26	Hands	Руки	1240	0	7	t	f	0	\N	\N
27	Helmet	Шлем	1240	0	4	t	f	0	\N	\N
29	Boots	Сапоги	1860	0	9	t	f	0	\N	\N
25	Waist	Пояс	2170	0	10	t	f	0	\N	\N
28	Armor	Доспех	2480	0	6	t	f	0	\N	\N
\.


--
-- TOC entry 5248 (class 0 OID 55927)
-- Dependencies: 236
-- Data for Name: material_damage_percents; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.material_damage_percents (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5250 (class 0 OID 55935)
-- Dependencies: 238
-- Data for Name: slot_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slot_types (id, name, name_ru) FROM stdin;
1	Weapon	Оружие
4	Head	Голова
6	Armor	Доспех
7	Hands	Руки
9	Feet	Ступни
10	Waist	Пояс
17	Neck	Шея
14	Ring	Кольцо
16	Trinket	Аксессуар
2	Shield	Щит
\.


--
-- TOC entry 5252 (class 0 OID 55943)
-- Dependencies: 240
-- Data for Name: slots; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slots (id, name, slot_type_id) FROM stdin;
1	RightHand	1
2	LeftHand	2
3	Head	4
4	Armor	6
5	Hands	7
6	Feet	9
7	Waist	10
8	Ring1	14
9	Ring2	14
10	Trinket1	16
11	Trinket2	16
12	Neck	17
\.


--
-- TOC entry 5254 (class 0 OID 55950)
-- Dependencies: 242
-- Data for Name: smithing_materials; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.smithing_materials (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5256 (class 0 OID 55958)
-- Dependencies: 244
-- Data for Name: x_equipment_types_damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_equipment_types_damage_types (equipment_type_id, damage_type_id, damage_coef) FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5257 (class 0 OID 55965)
-- Dependencies: 245
-- Data for Name: x_heroes_creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_heroes_creature_types (base_hero_id, creature_type_id) FROM stdin;
\.


--
-- TOC entry 5278 (class 0 OID 56427)
-- Dependencies: 266
-- Data for Name: authentication_logs; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.authentication_logs (id, version, created_at, email, user_id, success, user_device_id, ip, user_session_id) FROM stdin;
\.


--
-- TOC entry 5279 (class 0 OID 56455)
-- Dependencies: 267
-- Data for Name: registration_logs; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.registration_logs (id, version, created_at, email, user_id, success, user_device_id, ip) FROM stdin;
\.


--
-- TOC entry 5258 (class 0 OID 55993)
-- Dependencies: 246
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251218141532_Init	10.0.1
20251219010850_Fix1	10.0.1
20251219104853_Fix2	10.0.1
20251219125100_Fix3	10.0.1
20251219144649_Fix4	10.0.1
20251219145307_Fix5	10.0.1
20251220111640_Fix6	10.0.1
20251220140152_Fix7	10.0.1
20251221062947_Fix8	10.0.1
20251221115503_Fix9	10.0.1
20251221115727_Fix10	10.0.1
20251222005509_Fix11	10.0.1
20251222005528_Fix12	10.0.1
20251222012124_Fix13	10.0.1
20251222014603_Fix14	10.0.1
20251222032345_Fix15	10.0.1
20251222082512_Fix16	10.0.1
20251222142042_Fix17	10.0.1
20251224050619_Fix18	10.0.1
20251224060154_Fix19	10.0.1
20251224071911_Fix20	10.0.1
20251224075948_Fix21	10.0.1
20251224084507_Fix22	10.0.1
20251224125003_Fix23	10.0.1
20251229100603_Fix24	10.0.1
20251230112703_InitIdentity	10.0.1
20251231063604_IdentityFix1	10.0.1
20260101132651_IdentityFix2	10.0.1
20260101140259_IdentityFix3	10.0.1
20260101154436_IdentityFix4	10.0.1
20260102073949_IdentityFix5	10.0.1
20260102074626_IdentityFix6	10.0.1
20260106100111_EquipmentFix1	10.0.1
20260106110903_EquipmentFix2	10.0.1
20260107064521_RefreshTokenInit	10.0.1
20260112031013_EasyRefreshTokenRemove	10.0.1
20260112061648_UserSessionInit	10.0.1
20260113004051_UserSessionFix1	10.0.1
20260123052621_UserSessionFix2	10.0.2
20260126004106_UserSessionFix3	10.0.2
20260126014922_Fix25	10.0.2
20260126030039_UserSessionFix4	10.0.2
20260127150706_Fix26	10.0.2
20260128080318_LogFix1	10.0.2
\.


--
-- TOC entry 5259 (class 0 OID 55998)
-- Dependencies: 247
-- Data for Name: user_ban_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_ban_reasons (id, name) FROM stdin;
\.


--
-- TOC entry 5261 (class 0 OID 56006)
-- Dependencies: 249
-- Data for Name: user_session_inactivation_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_session_inactivation_reasons (id, name, code) FROM stdin;
1	EXPIRED	1
2	ROTATION	2
3	USER_LOGOUT	3
5	MANUAL_REVOCATION	4
7	OTHER_DEVICE	5
8	NONE	0
\.


--
-- TOC entry 5263 (class 0 OID 56015)
-- Dependencies: 251
-- Data for Name: identity_role_claims; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_role_claims (id, role_id, claim_type, claim_value) FROM stdin;
\.


--
-- TOC entry 5267 (class 0 OID 56031)
-- Dependencies: 255
-- Data for Name: identity_roles; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_roles (id, name, normalized_name, concurrency_stamp) FROM stdin;
\.


--
-- TOC entry 5265 (class 0 OID 56023)
-- Dependencies: 253
-- Data for Name: identity_user_claims; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_claims (id, user_id, claim_type, claim_value) FROM stdin;
\.


--
-- TOC entry 5268 (class 0 OID 56037)
-- Dependencies: 256
-- Data for Name: identity_user_logins; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_logins (login_provider, provider_key, provider_display_name, user_id) FROM stdin;
\.


--
-- TOC entry 5269 (class 0 OID 56045)
-- Dependencies: 257
-- Data for Name: identity_user_roles; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_roles (user_id, role_id) FROM stdin;
\.


--
-- TOC entry 5270 (class 0 OID 56050)
-- Dependencies: 258
-- Data for Name: identity_user_tokens; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_user_tokens (user_id, login_provider, name, value) FROM stdin;
\.


--
-- TOC entry 5271 (class 0 OID 56058)
-- Dependencies: 259
-- Data for Name: identity_users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.identity_users (id, user_name, normalized_user_name, email, normalized_email, email_confirmed, password_hash, security_stamp, concurrency_stamp, phone_number, phone_number_confirmed, two_factor_enabled, lockout_end, lockout_enabled, access_failed_count, created_at, time_zone, updated_at, version) FROM stdin;
019b7d31-93fd-703f-a582-c82e6bd40036	SUPERadmin@mail.RU	SUPERADMIN@MAIL.RU	SUPERadmin@mail.RU	SUPERADMIN@MAIL.RU	f	AQAAAAIAAYagAAAAEBag9pn4pztxrJtK71md3akGQ04Q/cWVqpDT8he8Ispn7t+HNGhKzrdXtWkKnE16vA==	JHMUKRZCKGMKN5TPX7UY47QU3OYRA44C	78551647-ef36-40b6-872c-bd8bbd3aa67e	\N	f	f	\N	t	0	2026-01-02 13:32:39.809088+08	\N	2026-01-02 13:32:39.809088+08	1
\.


--
-- TOC entry 5272 (class 0 OID 56075)
-- Dependencies: 260
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.refresh_tokens (id, token, expired_date, user_id) FROM stdin;
019b97b5-19de-7cb6-a733-9c1735bd282e	+gw9KupdUq+e1nwl8Urk0YYURi5SI63N0AA9h8oL06g=	2026-02-06 17:06:26.897926+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9cb1-838d-7606-9d32-a753d5c29f0a	zbv337X4UPQj1YMDjpGB13v58qF4gJTt+vCwocyHOBU=	2026-02-07 16:20:37.892781+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9cb1-ac6b-76e6-bad5-77534f4d9492	zTxcdbt3Hx5U6Hkv91NJi3pSHIYCP5zv0LAwRd8iSKw=	2026-02-07 16:20:48.363212+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9cc2-c976-7161-9cda-0264905335c8	tMctB+bwD1jxYyN+Sdbh1lgpOlQDnJW3mEqdxA+Y5fo=	2026-02-07 16:39:29.900663+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9cd6-9ed2-757b-b0b6-640b5894787b	Juy6D1OVoDsqbwfzfbO17GVBfwoGOBhCGt42S4gU+VY=	2026-02-07 17:01:09.713893+08	019b7d31-93fd-703f-a582-c82e6bd40036
019b9d0c-d09c-7692-80a3-705078979d3c	l0dR/jskyvfPOm4qggdl5IfwZ7+EXsr+5QLtfxdvL3s=	2026-02-07 18:00:21.404268+08	019b7d31-93fd-703f-a582-c82e6bd40036
\.


--
-- TOC entry 5273 (class 0 OID 56083)
-- Dependencies: 261
-- Data for Name: user_accesskeys; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_accesskeys (id, user_id, descriptor_id, public_key, signature_counter, device_name, created_at, updated_at, version) FROM stdin;
\.


--
-- TOC entry 5274 (class 0 OID 56097)
-- Dependencies: 262
-- Data for Name: user_bans; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_bans (id, user_id, version, created_at, updated_at, expires_at, user_ban_reason_id) FROM stdin;
\.


--
-- TOC entry 5275 (class 0 OID 56108)
-- Dependencies: 263
-- Data for Name: user_devices; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_devices (id, created_at, system_environment_user_name, time_zone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
47ee0275-bae7-c959-af87-f8b416a6cfd0	2025-12-19 22:55:44.844376+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
2f3585e2-e396-345a-b6d2-8d7079e5cdfc	2025-12-22 14:23:32.052081+08	adm-shumkov	480	30af10590f9f87bea6b087c950be35295e8eee95	B760 DS3H (Gigabyte Technology Co., Ltd.)	Desktop	Windows 10  (10.0.19045) 64bit	Intel(R) Core(TM) i9-14900K	32	65296	Intel(R) UHD Graphics 770	32648	t	Full
c22b70fd-fce2-735e-ab24-28fbf624f3e4	2026-01-26 09:51:53.761321+08	adm-shumkov	480	30af10590f9f87bea6b087c950be35295e8eee95	B760 DS3H (Gigabyte Technology Co., Ltd.)	Desktop	Windows 10  (10.0.19045) 64bit	Intel(R) Core(TM) i9-14900K	32	65296	Intel(R) UHD Graphics 770	32648	t	Full
94a4eb4e-400c-2a56-ac6c-10dfb9250180	2026-01-27 23:05:43.949037+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
\.


--
-- TOC entry 5276 (class 0 OID 56115)
-- Dependencies: 264
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_sessions (id, user_id, refresh_token_hash, is_used, is_revoked, inactivated_at, expires_at, created_at, updated_at, user_device_id, version, user_session_inactivation_reason_id) FROM stdin;
4be0b99f-3f9f-4c90-a493-e352a0423ca0	019b7d31-93fd-703f-a582-c82e6bd40036	\\x6b4d7185c3eeca18784c2074caa2a864c9227a5e29a8e94e94ae1e80343f5c65	f	f	\N	2026-02-10 23:24:19.101942+08	2026-01-27 23:24:19.134047+08	2026-01-27 23:24:19.134047+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	1	8
af8abb56-f781-4a2b-b9f4-0b9b337a5c8e	019b7d31-93fd-703f-a582-c82e6bd40036	\\x90117493f7371098299be8cab4956c16cd2380685ad89cbda620c9ccf14e40e0	f	f	\N	2026-02-10 23:24:35.84706+08	2026-01-27 23:24:45.620428+08	2026-01-27 23:24:45.620428+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	1	8
9a5c04cb-a69e-4518-adee-c01a45272679	019b7d31-93fd-703f-a582-c82e6bd40036	\\xe2633b4b06bc665e69340463fcd5ca2649274be3a0fcba3129be5734fb2d2da1	f	f	\N	2026-02-10 23:29:53.313773+08	2026-01-27 23:29:53.366352+08	2026-01-27 23:29:53.366352+08	94a4eb4e-400c-2a56-ac6c-10dfb9250180	1	8
\.


--
-- TOC entry 5277 (class 0 OID 56134)
-- Dependencies: 265
-- Data for Name: users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.users (id, email, email_verified_at, password_hash, time_zone, is_admin, version, created_at, updated_at) FROM stdin;
113ae534-2310-40e3-a895-f3747ea976ca	SuperAdmin@mail.ru	\N	AQAAAAIAAYagAAAAEA+MLlU2KQvPMPQ0RCAWN2iQDElD1+zOUuwLjyXnOlBxsikuTAtogGdY3m5zDWnrXg==	\N	t	1	2025-12-03 10:45:43.769905+08	2025-12-03 10:45:43.769905+08
\.


--
-- TOC entry 5285 (class 0 OID 0)
-- Dependencies: 227
-- Name: base_equipments_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_equipments_id_seq', 9, true);


--
-- TOC entry 5286 (class 0 OID 0)
-- Dependencies: 229
-- Name: base_heroes_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_heroes_id_seq', 6, false);


--
-- TOC entry 5287 (class 0 OID 0)
-- Dependencies: 231
-- Name: creature_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.creature_types_id_seq', 9, false);


--
-- TOC entry 5288 (class 0 OID 0)
-- Dependencies: 233
-- Name: damage_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.damage_types_id_seq', 17, true);


--
-- TOC entry 5289 (class 0 OID 0)
-- Dependencies: 235
-- Name: equipment_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.equipment_types_id_seq', 32, true);


--
-- TOC entry 5290 (class 0 OID 0)
-- Dependencies: 237
-- Name: material_damage_percents_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.material_damage_percents_id_seq', 25, false);


--
-- TOC entry 5291 (class 0 OID 0)
-- Dependencies: 239
-- Name: slot_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slot_types_id_seq', 19, true);


--
-- TOC entry 5292 (class 0 OID 0)
-- Dependencies: 241
-- Name: slots_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slots_id_seq', 12, true);


--
-- TOC entry 5293 (class 0 OID 0)
-- Dependencies: 243
-- Name: smithing_materials_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.smithing_materials_id_seq', 19, true);


--
-- TOC entry 5294 (class 0 OID 0)
-- Dependencies: 248
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_ban_reasons_id_seq', 1, false);


--
-- TOC entry 5295 (class 0 OID 0)
-- Dependencies: 250
-- Name: user_session_inactivation_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_session_inactivation_reasons_id_seq', 8, true);


--
-- TOC entry 5296 (class 0 OID 0)
-- Dependencies: 252
-- Name: asp_net_role_claims_id_seq; Type: SEQUENCE SET; Schema: users; Owner: -
--

SELECT pg_catalog.setval('users.asp_net_role_claims_id_seq', 1, false);


--
-- TOC entry 5297 (class 0 OID 0)
-- Dependencies: 254
-- Name: asp_net_user_claims_id_seq; Type: SEQUENCE SET; Schema: users; Owner: -
--

SELECT pg_catalog.setval('users.asp_net_user_claims_id_seq', 1, false);


--
-- TOC entry 4930 (class 2606 OID 56147)
-- Name: equipments equipments__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4935 (class 2606 OID 56149)
-- Name: heroes heroes__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4940 (class 2606 OID 56151)
-- Name: base_equipments base_equipments__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4944 (class 2606 OID 56153)
-- Name: base_heroes base_heroes__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_heroes
    ADD CONSTRAINT base_heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4947 (class 2606 OID 56155)
-- Name: creature_types creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.creature_types
    ADD CONSTRAINT creature_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4950 (class 2606 OID 56157)
-- Name: damage_types damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.damage_types
    ADD CONSTRAINT damage_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4953 (class 2606 OID 56159)
-- Name: equipment_types equipment_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4956 (class 2606 OID 56161)
-- Name: material_damage_percents material_damage_percents__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__pkey PRIMARY KEY (id);


--
-- TOC entry 4960 (class 2606 OID 56163)
-- Name: slot_types slot_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slot_types
    ADD CONSTRAINT slot_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4963 (class 2606 OID 56165)
-- Name: slots slots__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slots
    ADD CONSTRAINT slots__pkey PRIMARY KEY (id);


--
-- TOC entry 4967 (class 2606 OID 56167)
-- Name: smithing_materials smithing_materials__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.smithing_materials
    ADD CONSTRAINT smithing_materials__pkey PRIMARY KEY (id);


--
-- TOC entry 4970 (class 2606 OID 56169)
-- Name: x_equipment_types_damage_types x_equipment_types_damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_types_damage_types
    ADD CONSTRAINT x_equipment_types_damage_types__pkey PRIMARY KEY (equipment_type_id, damage_type_id);


--
-- TOC entry 4973 (class 2606 OID 56171)
-- Name: x_heroes_creature_types x_heroes_creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_heroes_creature_types
    ADD CONSTRAINT x_heroes_creature_types__pkey PRIMARY KEY (base_hero_id, creature_type_id);


--
-- TOC entry 5024 (class 2606 OID 56438)
-- Name: authentication_logs authentication_logs__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.authentication_logs
    ADD CONSTRAINT authentication_logs__pkey PRIMARY KEY (id);


--
-- TOC entry 5029 (class 2606 OID 56466)
-- Name: registration_logs registration_logs__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.registration_logs
    ADD CONSTRAINT registration_logs__pkey PRIMARY KEY (id);


--
-- TOC entry 4975 (class 2606 OID 56177)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4978 (class 2606 OID 56179)
-- Name: user_ban_reasons user_ban_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_ban_reasons
    ADD CONSTRAINT user_ban_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 4981 (class 2606 OID 56181)
-- Name: user_session_inactivation_reasons user_session_inactivation_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_session_inactivation_reasons
    ADD CONSTRAINT user_session_inactivation_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 4983 (class 2606 OID 56183)
-- Name: identity_role_claims identity_role_claims__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_role_claims
    ADD CONSTRAINT identity_role_claims__pkey PRIMARY KEY (id);


--
-- TOC entry 4990 (class 2606 OID 56185)
-- Name: identity_roles identity_roles__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_roles
    ADD CONSTRAINT identity_roles__pkey PRIMARY KEY (id);


--
-- TOC entry 4986 (class 2606 OID 56187)
-- Name: identity_user_claims identity_user_claims__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_claims
    ADD CONSTRAINT identity_user_claims__pkey PRIMARY KEY (id);


--
-- TOC entry 4992 (class 2606 OID 56189)
-- Name: identity_user_logins identity_user_logins__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_logins
    ADD CONSTRAINT identity_user_logins__pkey PRIMARY KEY (login_provider, provider_key);


--
-- TOC entry 4995 (class 2606 OID 56191)
-- Name: identity_user_roles identity_user_roles__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__pkey PRIMARY KEY (user_id, role_id);


--
-- TOC entry 4998 (class 2606 OID 56193)
-- Name: identity_user_tokens identity_user_tokens__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_tokens
    ADD CONSTRAINT identity_user_tokens__pkey PRIMARY KEY (user_id, login_provider, name);


--
-- TOC entry 5002 (class 2606 OID 56195)
-- Name: identity_users identity_users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_users
    ADD CONSTRAINT identity_users__pkey PRIMARY KEY (id);


--
-- TOC entry 5004 (class 2606 OID 56197)
-- Name: refresh_tokens refresh_tokens__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.refresh_tokens
    ADD CONSTRAINT refresh_tokens__pkey PRIMARY KEY (id);


--
-- TOC entry 5007 (class 2606 OID 56199)
-- Name: user_accesskeys user_accesskeys__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_accesskeys
    ADD CONSTRAINT user_accesskeys__pkey PRIMARY KEY (id);


--
-- TOC entry 5010 (class 2606 OID 56201)
-- Name: user_bans user_bans__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__pkey PRIMARY KEY (id);


--
-- TOC entry 5014 (class 2606 OID 56203)
-- Name: user_devices user_devices__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_devices
    ADD CONSTRAINT user_devices__pkey PRIMARY KEY (id);


--
-- TOC entry 5016 (class 2606 OID 56205)
-- Name: user_sessions user_sessions__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions__pkey PRIMARY KEY (id);


--
-- TOC entry 5022 (class 2606 OID 56207)
-- Name: users users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users__pkey PRIMARY KEY (id);


--
-- TOC entry 4927 (class 1259 OID 56208)
-- Name: equipments__base_equipment_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__base_equipment_id__idx ON collection.equipments USING btree (base_equipment_id);


--
-- TOC entry 4928 (class 1259 OID 56209)
-- Name: equipments__hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__hero_id__idx ON collection.equipments USING btree (hero_id);


--
-- TOC entry 4931 (class 1259 OID 56210)
-- Name: equipments__slot_id__hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE UNIQUE INDEX equipments__slot_id__hero_id__idx ON collection.equipments USING btree (slot_id, hero_id);


--
-- TOC entry 4932 (class 1259 OID 56211)
-- Name: equipments__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__user_id__idx ON collection.equipments USING btree (user_id);


--
-- TOC entry 4933 (class 1259 OID 56212)
-- Name: heroes__base_hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__base_hero_id__idx ON collection.heroes USING btree (base_hero_id);


--
-- TOC entry 4936 (class 1259 OID 56213)
-- Name: heroes__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__user_id__idx ON collection.heroes USING btree (user_id);


--
-- TOC entry 4937 (class 1259 OID 56214)
-- Name: base_equipments__equipment_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__equipment_type_id__idx ON game_data.base_equipments USING btree (equipment_type_id);


--
-- TOC entry 4938 (class 1259 OID 56215)
-- Name: base_equipments__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_equipments__name__idx ON game_data.base_equipments USING btree (name);


--
-- TOC entry 4941 (class 1259 OID 56216)
-- Name: base_equipments__smithing_material_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__smithing_material_id__idx ON game_data.base_equipments USING btree (smithing_material_id);


--
-- TOC entry 4942 (class 1259 OID 56217)
-- Name: base_heroes__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_heroes__name__idx ON game_data.base_heroes USING btree (name);


--
-- TOC entry 4945 (class 1259 OID 56218)
-- Name: creature_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX creature_types__name__idx ON game_data.creature_types USING btree (name);


--
-- TOC entry 4948 (class 1259 OID 56219)
-- Name: damage_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX damage_types__name__idx ON game_data.damage_types USING btree (name);


--
-- TOC entry 4951 (class 1259 OID 56220)
-- Name: equipment_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX equipment_types__name__idx ON game_data.equipment_types USING btree (name);


--
-- TOC entry 4954 (class 1259 OID 56221)
-- Name: material_damage_percents__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__damage_type_id__idx ON game_data.material_damage_percents USING btree (damage_type_id);


--
-- TOC entry 4957 (class 1259 OID 56222)
-- Name: material_damage_percents__smithing_materials_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__smithing_materials_id__idx ON game_data.material_damage_percents USING btree (smithing_materials_id);


--
-- TOC entry 4958 (class 1259 OID 56223)
-- Name: slot_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slot_types__name__idx ON game_data.slot_types USING btree (name);


--
-- TOC entry 4961 (class 1259 OID 56224)
-- Name: slots__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slots__name__idx ON game_data.slots USING btree (name);


--
-- TOC entry 4964 (class 1259 OID 56225)
-- Name: slots__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX slots__slot_type_id__idx ON game_data.slots USING btree (slot_type_id);


--
-- TOC entry 4965 (class 1259 OID 56226)
-- Name: smithing_materials__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX smithing_materials__name__idx ON game_data.smithing_materials USING btree (name);


--
-- TOC entry 4968 (class 1259 OID 56227)
-- Name: x_equipment_types_damage_types__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_equipment_types_damage_types__damage_type_id__idx ON game_data.x_equipment_types_damage_types USING btree (damage_type_id);


--
-- TOC entry 4971 (class 1259 OID 56228)
-- Name: x_heroes_creature_types__creature_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_heroes_creature_types__creature_type_id__idx ON game_data.x_heroes_creature_types USING btree (creature_type_id);


--
-- TOC entry 5025 (class 1259 OID 56478)
-- Name: authentication_logs__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX authentication_logs__user_device_id__idx ON logs.authentication_logs USING btree (user_device_id);


--
-- TOC entry 5026 (class 1259 OID 56479)
-- Name: authentication_logs__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX authentication_logs__user_id__idx ON logs.authentication_logs USING btree (user_id);


--
-- TOC entry 5027 (class 1259 OID 56480)
-- Name: authentication_logs__user_session_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX authentication_logs__user_session_id__idx ON logs.authentication_logs USING btree (user_session_id);


--
-- TOC entry 5030 (class 1259 OID 56481)
-- Name: registration_logs__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX registration_logs__user_device_id__idx ON logs.registration_logs USING btree (user_device_id);


--
-- TOC entry 5031 (class 1259 OID 56482)
-- Name: registration_logs__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX registration_logs__user_id__idx ON logs.registration_logs USING btree (user_id);


--
-- TOC entry 4976 (class 1259 OID 56233)
-- Name: user_ban_reasons__name__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_ban_reasons__name__idx ON server.user_ban_reasons USING btree (name);


--
-- TOC entry 4979 (class 1259 OID 56234)
-- Name: user_session_inactivation_reasons__code__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_session_inactivation_reasons__code__idx ON server.user_session_inactivation_reasons USING btree (code);


--
-- TOC entry 4984 (class 1259 OID 56235)
-- Name: identity_role_claims__role_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_role_claims__role_id__idx ON users.identity_role_claims USING btree (role_id);


--
-- TOC entry 4988 (class 1259 OID 56236)
-- Name: identity_roles__normalized_name__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX identity_roles__normalized_name__idx ON users.identity_roles USING btree (normalized_name);


--
-- TOC entry 4987 (class 1259 OID 56237)
-- Name: identity_user_claims__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_claims__user_id__idx ON users.identity_user_claims USING btree (user_id);


--
-- TOC entry 4993 (class 1259 OID 56238)
-- Name: identity_user_logins__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_logins__user_id__idx ON users.identity_user_logins USING btree (user_id);


--
-- TOC entry 4996 (class 1259 OID 56239)
-- Name: identity_user_roles__role_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_user_roles__role_id__idx ON users.identity_user_roles USING btree (role_id);


--
-- TOC entry 4999 (class 1259 OID 56240)
-- Name: identity_users__normalized_email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX identity_users__normalized_email__idx ON users.identity_users USING btree (normalized_email);


--
-- TOC entry 5000 (class 1259 OID 56241)
-- Name: identity_users__normalized_user_name__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX identity_users__normalized_user_name__idx ON users.identity_users USING btree (normalized_user_name);


--
-- TOC entry 5005 (class 1259 OID 56242)
-- Name: refresh_tokens__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX refresh_tokens__user_id__idx ON users.refresh_tokens USING btree (user_id);


--
-- TOC entry 5008 (class 1259 OID 56243)
-- Name: user_accesskeys__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_accesskeys__user_id__idx ON users.user_accesskeys USING btree (user_id);


--
-- TOC entry 5011 (class 1259 OID 56244)
-- Name: user_bans__user_ban_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_ban_reason_id__idx ON users.user_bans USING btree (user_ban_reason_id);


--
-- TOC entry 5012 (class 1259 OID 56245)
-- Name: user_bans__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_id__idx ON users.user_bans USING btree (user_id);


--
-- TOC entry 5017 (class 1259 OID 56246)
-- Name: user_sessions__refresh_token_hash__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX user_sessions__refresh_token_hash__idx ON users.user_sessions USING btree (refresh_token_hash) WHERE ((is_used = false) AND (is_revoked = false));


--
-- TOC entry 5018 (class 1259 OID 56247)
-- Name: user_sessions__user_device_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_sessions__user_device_id__idx ON users.user_sessions USING btree (user_device_id);


--
-- TOC entry 5019 (class 1259 OID 56248)
-- Name: user_sessions__user_session_inactivation_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_sessions__user_session_inactivation_reason_id__idx ON users.user_sessions USING btree (user_session_inactivation_reason_id);


--
-- TOC entry 5020 (class 1259 OID 56249)
-- Name: users__email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX users__email__idx ON users.users USING btree (email);


--
-- TOC entry 5064 (class 2620 OID 56250)
-- Name: equipments trg_prevent_id_change; Type: TRIGGER; Schema: collection; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON collection.equipments FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5065 (class 2620 OID 56251)
-- Name: heroes trg_prevent_id_change; Type: TRIGGER; Schema: collection; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON collection.heroes FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5066 (class 2620 OID 56252)
-- Name: base_equipments trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.base_equipments FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5067 (class 2620 OID 56253)
-- Name: base_heroes trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.base_heroes FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5068 (class 2620 OID 56254)
-- Name: creature_types trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.creature_types FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5069 (class 2620 OID 56255)
-- Name: damage_types trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.damage_types FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5070 (class 2620 OID 56256)
-- Name: equipment_types trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.equipment_types FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5071 (class 2620 OID 56257)
-- Name: material_damage_percents trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.material_damage_percents FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5072 (class 2620 OID 56258)
-- Name: slot_types trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.slot_types FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5073 (class 2620 OID 56259)
-- Name: slots trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.slots FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5074 (class 2620 OID 56260)
-- Name: smithing_materials trg_prevent_id_change; Type: TRIGGER; Schema: game_data; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON game_data.smithing_materials FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5087 (class 2620 OID 56454)
-- Name: authentication_logs trg_prevent_id_change; Type: TRIGGER; Schema: logs; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON logs.authentication_logs FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5088 (class 2620 OID 56477)
-- Name: registration_logs trg_prevent_id_change; Type: TRIGGER; Schema: logs; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON logs.registration_logs FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5075 (class 2620 OID 56263)
-- Name: user_ban_reasons trg_prevent_id_change; Type: TRIGGER; Schema: server; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON server.user_ban_reasons FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5076 (class 2620 OID 56264)
-- Name: user_session_inactivation_reasons trg_prevent_id_change; Type: TRIGGER; Schema: server; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON server.user_session_inactivation_reasons FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5077 (class 2620 OID 56265)
-- Name: identity_role_claims trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.identity_role_claims FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5079 (class 2620 OID 56266)
-- Name: identity_roles trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.identity_roles FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5078 (class 2620 OID 56267)
-- Name: identity_user_claims trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.identity_user_claims FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5080 (class 2620 OID 56268)
-- Name: identity_users trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.identity_users FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5081 (class 2620 OID 56269)
-- Name: refresh_tokens trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.refresh_tokens FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5082 (class 2620 OID 56270)
-- Name: user_accesskeys trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.user_accesskeys FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5083 (class 2620 OID 56271)
-- Name: user_bans trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.user_bans FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5084 (class 2620 OID 56272)
-- Name: user_devices trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.user_devices FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5085 (class 2620 OID 56273)
-- Name: user_sessions trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.user_sessions FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5086 (class 2620 OID 56274)
-- Name: users trg_prevent_id_change; Type: TRIGGER; Schema: users; Owner: -
--

CREATE TRIGGER trg_prevent_id_change BEFORE UPDATE ON users.users FOR EACH ROW EXECUTE FUNCTION public.prevent_id_update();


--
-- TOC entry 5032 (class 2606 OID 56275)
-- Name: equipments equipments__base_equipment_id__base_equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__base_equipment_id__base_equipments__fkey FOREIGN KEY (base_equipment_id) REFERENCES game_data.base_equipments(id) ON DELETE RESTRICT;


--
-- TOC entry 5033 (class 2606 OID 56280)
-- Name: equipments equipments__hero_id__heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__hero_id__heroes__fkey FOREIGN KEY (hero_id) REFERENCES collection.heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5034 (class 2606 OID 56285)
-- Name: equipments equipments__slot_id__slots__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__slot_id__slots__fkey FOREIGN KEY (slot_id) REFERENCES game_data.slots(id) ON DELETE RESTRICT;


--
-- TOC entry 5035 (class 2606 OID 56290)
-- Name: equipments equipments__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5036 (class 2606 OID 56295)
-- Name: heroes heroes__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5037 (class 2606 OID 56300)
-- Name: heroes heroes__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5038 (class 2606 OID 56305)
-- Name: base_equipments base_equipments__equipment_type_id__equipment_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__equipment_type_id__equipment_types__fkey FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5039 (class 2606 OID 56310)
-- Name: base_equipments base_equipments__smithing_material_id__smithing_materials__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__smithing_material_id__smithing_materials__fkey FOREIGN KEY (smithing_material_id) REFERENCES game_data.smithing_materials(id) ON DELETE RESTRICT;


--
-- TOC entry 5040 (class 2606 OID 56315)
-- Name: material_damage_percents material_damage_percents__damage_type_id__damage_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__damage_type_id__damage_types__fkey FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5041 (class 2606 OID 56320)
-- Name: material_damage_percents material_damage_percents__smithing_materials_id__smithing_mater; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__smithing_materials_id__smithing_mater FOREIGN KEY (smithing_materials_id) REFERENCES game_data.smithing_materials(id) ON DELETE RESTRICT;


--
-- TOC entry 5042 (class 2606 OID 56325)
-- Name: slots slots__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slots
    ADD CONSTRAINT slots__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5043 (class 2606 OID 56330)
-- Name: x_equipment_types_damage_types x_equipment_types_damage_types__damage_type_id__damage_types__f; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_types_damage_types
    ADD CONSTRAINT x_equipment_types_damage_types__damage_type_id__damage_types__f FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5044 (class 2606 OID 56335)
-- Name: x_equipment_types_damage_types x_equipment_types_damage_types__equipment_type_id__equipment_ty; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_types_damage_types
    ADD CONSTRAINT x_equipment_types_damage_types__equipment_type_id__equipment_ty FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5045 (class 2606 OID 56340)
-- Name: x_heroes_creature_types x_heroes_creature_types__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_heroes_creature_types
    ADD CONSTRAINT x_heroes_creature_types__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE RESTRICT;


--
-- TOC entry 5046 (class 2606 OID 56345)
-- Name: x_heroes_creature_types x_heroes_creature_types__creature_type_id__creature_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_heroes_creature_types
    ADD CONSTRAINT x_heroes_creature_types__creature_type_id__creature_types__fkey FOREIGN KEY (creature_type_id) REFERENCES game_data.creature_types(id) ON DELETE RESTRICT;


--
-- TOC entry 5059 (class 2606 OID 56439)
-- Name: authentication_logs authentication_logs__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.authentication_logs
    ADD CONSTRAINT authentication_logs__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE RESTRICT;


--
-- TOC entry 5060 (class 2606 OID 56444)
-- Name: authentication_logs authentication_logs__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.authentication_logs
    ADD CONSTRAINT authentication_logs__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE CASCADE;


--
-- TOC entry 5061 (class 2606 OID 56449)
-- Name: authentication_logs authentication_logs__user_session_id__user_sessions__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.authentication_logs
    ADD CONSTRAINT authentication_logs__user_session_id__user_sessions__fkey FOREIGN KEY (user_session_id) REFERENCES users.user_sessions(id) ON DELETE RESTRICT;


--
-- TOC entry 5062 (class 2606 OID 56467)
-- Name: registration_logs registration_logs__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.registration_logs
    ADD CONSTRAINT registration_logs__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE RESTRICT;


--
-- TOC entry 5063 (class 2606 OID 56472)
-- Name: registration_logs registration_logs__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.registration_logs
    ADD CONSTRAINT registration_logs__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5047 (class 2606 OID 56365)
-- Name: identity_role_claims identity_role_claims__role_id__identity_roles__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_role_claims
    ADD CONSTRAINT identity_role_claims__role_id__identity_roles__fkey FOREIGN KEY (role_id) REFERENCES users.identity_roles(id) ON DELETE RESTRICT;


--
-- TOC entry 5048 (class 2606 OID 56370)
-- Name: identity_user_claims identity_user_claims__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_claims
    ADD CONSTRAINT identity_user_claims__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5049 (class 2606 OID 56375)
-- Name: identity_user_logins identity_user_logins__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_logins
    ADD CONSTRAINT identity_user_logins__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5050 (class 2606 OID 56380)
-- Name: identity_user_roles identity_user_roles__role_id__identity_roles__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__role_id__identity_roles__fkey FOREIGN KEY (role_id) REFERENCES users.identity_roles(id) ON DELETE RESTRICT;


--
-- TOC entry 5051 (class 2606 OID 56385)
-- Name: identity_user_roles identity_user_roles__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_roles
    ADD CONSTRAINT identity_user_roles__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5052 (class 2606 OID 56390)
-- Name: identity_user_tokens identity_user_tokens__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.identity_user_tokens
    ADD CONSTRAINT identity_user_tokens__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5053 (class 2606 OID 56395)
-- Name: refresh_tokens refresh_tokens__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.refresh_tokens
    ADD CONSTRAINT refresh_tokens__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5054 (class 2606 OID 56400)
-- Name: user_accesskeys user_accesskeys__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_accesskeys
    ADD CONSTRAINT user_accesskeys__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE RESTRICT;


--
-- TOC entry 5055 (class 2606 OID 56405)
-- Name: user_bans user_bans__user_ban_reason_id__user_ban_reasons__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_ban_reason_id__user_ban_reasons__fkey FOREIGN KEY (user_ban_reason_id) REFERENCES server.user_ban_reasons(id) ON DELETE RESTRICT;


--
-- TOC entry 5056 (class 2606 OID 56410)
-- Name: user_bans user_bans__user_id__identity_users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_id__identity_users__fkey FOREIGN KEY (user_id) REFERENCES users.identity_users(id) ON DELETE CASCADE;


--
-- TOC entry 5057 (class 2606 OID 56415)
-- Name: user_sessions user_sessions__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id) ON DELETE RESTRICT;


--
-- TOC entry 5058 (class 2606 OID 56420)
-- Name: user_sessions user_sessions__user_session_inactivation_reason_id__user_sessio; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_sessions
    ADD CONSTRAINT user_sessions__user_session_inactivation_reason_id__user_sessio FOREIGN KEY (user_session_inactivation_reason_id) REFERENCES server.user_session_inactivation_reasons(id) ON DELETE RESTRICT;


--
-- TOC entry 4895 (class 3466 OID 56425)
-- Name: on_ddl_create_table__prevent_id_update; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER on_ddl_create_table__prevent_id_update ON ddl_command_end
         WHEN TAG IN ('CREATE TABLE', 'CREATE TABLE AS')
   EXECUTE FUNCTION public.fn_on_ddl_prevent_id_update();


-- Completed on 2026-01-28 16:09:36

--
-- PostgreSQL database dump complete
--

\unrestrict KYx2IRNB5lB4JlxodBKpbSXgWfxOgc6zvxSb4L7NIOIQ4Blw5KXxRDtX4g34E7i

