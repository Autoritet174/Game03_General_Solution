--
-- PostgreSQL database dump
--

\restrict aTTNiL5sKEaqFtMOOmbjhgNJHkjhIUAcsjYnpYTFJZ5kFswj4bIdr12gx0IvgE9

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-11-03 18:59:16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY xcross.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type_hero_id_heroes_fkey;
ALTER TABLE IF EXISTS ONLY xcross.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type_creature_type_id_creature_types_fkey;
DROP TRIGGER IF EXISTS set_timestamps_trigger ON _main.heroes;
DROP TRIGGER IF EXISTS set_timestamps_trigger ON _main.creature_types;
CREATE OR REPLACE VIEW _main.v_heroes_with_creature_types AS
SELECT
    NULL::character varying(255) AS name,
    NULL::integer AS rarity,
    NULL::text AS creature_types;
DROP INDEX IF EXISTS xcross.x_hero_creature_type_hero_id_idx;
DROP INDEX IF EXISTS xcross.x_hero_creature_type_creature_type_id_idx;
DROP INDEX IF EXISTS _main.heroes_name_idx;
DROP INDEX IF EXISTS _main.creature_types_name_idx;
ALTER TABLE IF EXISTS ONLY xcross.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type_pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY _main.heroes DROP CONSTRAINT IF EXISTS heroes_pkey;
ALTER TABLE IF EXISTS ONLY _main.creature_types DROP CONSTRAINT IF EXISTS creature_types_pkey;
DROP TABLE IF EXISTS xcross.x_hero_creature_type;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP VIEW IF EXISTS _main.v_heroes_with_creature_types;
DROP TABLE IF EXISTS _main.heroes;
DROP TABLE IF EXISTS _main.creature_types;
DROP FUNCTION IF EXISTS public.set_timestamp();
DROP PROCEDURE IF EXISTS _main.add_hero_creature_type(IN p_hero_name text, IN p_creature_type_name text);
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP SCHEMA IF EXISTS xcross;
DROP SCHEMA IF EXISTS _main;
--
-- TOC entry 7 (class 2615 OID 18269)
-- Name: _main; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _main;


--
-- TOC entry 8 (class 2615 OID 18270)
-- Name: xcross; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA xcross;


--
-- TOC entry 2 (class 3079 OID 17913)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 5020 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 249 (class 1255 OID 18327)
-- Name: add_hero_creature_type(text, text); Type: PROCEDURE; Schema: _main; Owner: -
--

CREATE PROCEDURE _main.add_hero_creature_type(IN p_hero_name text, IN p_creature_type_name text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_hero_id         uuid;
    v_creature_type_id uuid;
    v_link_exists     boolean;
BEGIN
    -- Получаем ID героя
    SELECT id INTO v_hero_id
    FROM _main.heroes
    WHERE name ILIKE p_hero_name
    LIMIT 1;

    IF v_hero_id IS NULL THEN
        RAISE EXCEPTION 'Ошибка: Герой "%" не найден', p_hero_name;
    END IF;

    -- Получаем ID типа существа
    SELECT id INTO v_creature_type_id
    FROM _main.creature_types
    WHERE name ILIKE p_creature_type_name
    LIMIT 1;

    IF v_creature_type_id IS NULL THEN
        RAISE EXCEPTION 'Ошибка: Тип существа "%" не найден', p_creature_type_name;
    END IF;

    -- Проверяем существование связи
    SELECT EXISTS (
        SELECT 1
        FROM xcross.x_hero_creature_type
        WHERE hero_id = v_hero_id
          AND creature_type_id = v_creature_type_id
    ) INTO v_link_exists;

    -- Добавляем связь если её нет
    IF NOT v_link_exists THEN
        INSERT INTO xcross.x_hero_creature_type (hero_id, creature_type_id)
        VALUES (v_hero_id, v_creature_type_id);

        RAISE NOTICE 'Успех: Связь добавлена - герой "%" → тип "%"', p_hero_name, p_creature_type_name;
    ELSE
        RAISE NOTICE 'Информация: Связь уже существует - герой "%" → тип "%"', p_hero_name, p_creature_type_name;
    END IF;
END;
$$;


--
-- TOC entry 248 (class 1255 OID 17925)
-- Name: set_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.created_at := COALESCE(NEW.created_at, NOW());
        NEW.updated_at := COALESCE(NEW.updated_at, NOW());
    ELSIF TG_OP = 'UPDATE' THEN
        NEW.created_at := OLD.created_at;
        IF NEW.updated_at IS NULL OR NEW.updated_at = OLD.updated_at THEN
            NEW.updated_at := NOW();
        END IF;
    END IF;
    RETURN NEW;
END;$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 223 (class 1259 OID 18271)
-- Name: creature_types; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.creature_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 18283)
-- Name: heroes; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.heroes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer CONSTRAINT heroes__rarity_not_null NOT NULL,
    base_health real NOT NULL,
    base_attack real NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 18333)
-- Name: v_heroes_with_creature_types; Type: VIEW; Schema: _main; Owner: -
--

CREATE VIEW _main.v_heroes_with_creature_types AS
SELECT
    NULL::character varying(255) AS name,
    NULL::integer AS rarity,
    NULL::text AS creature_types;


--
-- TOC entry 222 (class 1259 OID 18262)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 18298)
-- Name: x_hero_creature_type; Type: TABLE; Schema: xcross; Owner: -
--

CREATE TABLE xcross.x_hero_creature_type (
    hero_id uuid NOT NULL,
    creature_type_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 5012 (class 0 OID 18271)
-- Dependencies: 223
-- Data for Name: creature_types; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.creature_types (id, created_at, updated_at, name) FROM stdin;
40bcd67a-2fb7-4ddd-b194-f496464aea14	2025-07-31 14:35:56.034856+08	2025-07-31 14:35:56.034856+08	Wolf
52b2c4d8-977c-4dc3-967a-5bfc320a232a	2025-07-31 14:36:13.53242+08	2025-07-31 14:36:13.53242+08	Bear
550d1671-3f32-4041-a27a-217f157722b3	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Skeleton
710bda30-8522-4a6f-bcc2-f06ab5d175ab	2025-07-31 14:36:36.443478+08	2025-07-31 14:36:36.443478+08	Vampire
c79ce293-b425-4b64-85a4-61108433b13f	2025-07-31 14:36:36.443478+08	2025-07-31 14:36:36.443478+08	Zombie
cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-07-31 14:35:37.323451+08	2025-07-31 14:35:37.323451+08	Humanoid
d95ca0ae-6236-4dd6-a239-1c3d727e6230	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Orc
df0e65a9-5dc6-44c2-ae40-ab76ec162aa1	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Goblin
\.


--
-- TOC entry 5013 (class 0 OID 18283)
-- Dependencies: 224
-- Data for Name: heroes; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.heroes (id, created_at, updated_at, name, rarity, base_health, base_attack) FROM stdin;
58e860c7-3819-4f5b-bdff-f36850411498	2025-11-03 13:45:04.074396+08	2025-11-03 13:52:24.243739+08	warrior	1	0	0
64ec68ff-ee4d-4204-a830-5f992f64fae9	2025-11-03 13:45:04.074396+08	2025-11-03 13:52:24.243739+08	novice huntress	1	0	0
b582d3e8-d673-462f-80ad-f59b0deb1373	2025-11-03 13:45:04.074396+08	2025-11-03 13:52:24.243739+08	orc with axes	2	0	0
c5c4aaa5-a4d3-4f4b-ac8c-26d77f6ea198	2025-11-03 13:45:04.074396+08	2025-11-03 13:52:24.243739+08	hammerman	1	0	0
eb93675d-d05f-43ad-857f-e47d43152e43	2025-11-03 13:45:04.074396+08	2025-11-03 13:52:24.243739+08	rogue	1	0	0
\.


--
-- TOC entry 5011 (class 0 OID 18262)
-- Dependencies: 222
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251103041722_Start	9.0.10
20251103081817_Start2	9.0.10
\.


--
-- TOC entry 5014 (class 0 OID 18298)
-- Dependencies: 225
-- Data for Name: x_hero_creature_type; Type: TABLE DATA; Schema: xcross; Owner: -
--

COPY xcross.x_hero_creature_type (hero_id, creature_type_id, created_at) FROM stdin;
58e860c7-3819-4f5b-bdff-f36850411498	cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-11-03 13:53:24.497434+08
b582d3e8-d673-462f-80ad-f59b0deb1373	cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-11-03 13:54:28.640968+08
b582d3e8-d673-462f-80ad-f59b0deb1373	d95ca0ae-6236-4dd6-a239-1c3d727e6230	2025-11-03 13:55:27.10382+08
\.


--
-- TOC entry 4851 (class 2606 OID 18282)
-- Name: creature_types creature_types_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.creature_types
    ADD CONSTRAINT creature_types_pkey PRIMARY KEY (id);


--
-- TOC entry 4854 (class 2606 OID 18297)
-- Name: heroes heroes_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.heroes
    ADD CONSTRAINT heroes_pkey PRIMARY KEY (id);


--
-- TOC entry 4848 (class 2606 OID 18268)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4858 (class 2606 OID 18306)
-- Name: x_hero_creature_type x_hero_creature_type_pkey; Type: CONSTRAINT; Schema: xcross; Owner: -
--

ALTER TABLE ONLY xcross.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type_pkey PRIMARY KEY (hero_id, creature_type_id);


--
-- TOC entry 4849 (class 1259 OID 18317)
-- Name: creature_types_name_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE UNIQUE INDEX creature_types_name_idx ON _main.creature_types USING btree (name);


--
-- TOC entry 4852 (class 1259 OID 18318)
-- Name: heroes_name_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE UNIQUE INDEX heroes_name_idx ON _main.heroes USING btree (name);


--
-- TOC entry 4855 (class 1259 OID 18319)
-- Name: x_hero_creature_type_creature_type_id_idx; Type: INDEX; Schema: xcross; Owner: -
--

CREATE INDEX x_hero_creature_type_creature_type_id_idx ON xcross.x_hero_creature_type USING btree (creature_type_id);


--
-- TOC entry 4856 (class 1259 OID 18320)
-- Name: x_hero_creature_type_hero_id_idx; Type: INDEX; Schema: xcross; Owner: -
--

CREATE INDEX x_hero_creature_type_hero_id_idx ON xcross.x_hero_creature_type USING btree (hero_id);


--
-- TOC entry 5010 (class 2618 OID 18336)
-- Name: v_heroes_with_creature_types _RETURN; Type: RULE; Schema: _main; Owner: -
--

CREATE OR REPLACE VIEW _main.v_heroes_with_creature_types AS
 SELECT hero.name,
    hero.rarity,
    string_agg((ct.name)::text, ', '::text ORDER BY ct.name) AS creature_types
   FROM ((_main.heroes hero
     LEFT JOIN xcross.x_hero_creature_type hct ON ((hero.id = hct.hero_id)))
     LEFT JOIN _main.creature_types ct ON ((hct.creature_type_id = ct.id)))
  GROUP BY hero.id
  ORDER BY hero.rarity DESC, hero.name;


--
-- TOC entry 4861 (class 2620 OID 18322)
-- Name: creature_types set_timestamps_trigger; Type: TRIGGER; Schema: _main; Owner: -
--

CREATE TRIGGER set_timestamps_trigger BEFORE INSERT OR UPDATE ON _main.creature_types FOR EACH ROW EXECUTE FUNCTION public.set_timestamp();


--
-- TOC entry 4862 (class 2620 OID 18321)
-- Name: heroes set_timestamps_trigger; Type: TRIGGER; Schema: _main; Owner: -
--

CREATE TRIGGER set_timestamps_trigger BEFORE INSERT OR UPDATE ON _main.heroes FOR EACH ROW EXECUTE FUNCTION public.set_timestamp();


--
-- TOC entry 4859 (class 2606 OID 18307)
-- Name: x_hero_creature_type x_hero_creature_type_creature_type_id_creature_types_fkey; Type: FK CONSTRAINT; Schema: xcross; Owner: -
--

ALTER TABLE ONLY xcross.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type_creature_type_id_creature_types_fkey FOREIGN KEY (creature_type_id) REFERENCES _main.creature_types(id) ON DELETE CASCADE;


--
-- TOC entry 4860 (class 2606 OID 18312)
-- Name: x_hero_creature_type x_hero_creature_type_hero_id_heroes_fkey; Type: FK CONSTRAINT; Schema: xcross; Owner: -
--

ALTER TABLE ONLY xcross.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type_hero_id_heroes_fkey FOREIGN KEY (hero_id) REFERENCES _main.heroes(id) ON DELETE CASCADE;


-- Completed on 2025-11-03 18:59:16

--
-- PostgreSQL database dump complete
--

\unrestrict aTTNiL5sKEaqFtMOOmbjhgNJHkjhIUAcsjYnpYTFJZ5kFswj4bIdr12gx0IvgE9

