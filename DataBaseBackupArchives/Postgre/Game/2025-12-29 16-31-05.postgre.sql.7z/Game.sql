--
-- PostgreSQL database dump
--

\restrict Ssf2FGDrFncuPdssYvUbDRJ8FVmBr8E0AEo0o87RdcRzhL3KBKMvBkICyBQSfvU

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-12-29 16:31:05

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__user_ban_reason_id__user_ban_reasons__fkey;
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__user_device_id__user_devices__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__creature_type_id__creature_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__equipment_type_id__equipment_type;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__damage_type_id__damage_types__fke;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__smithing_materials_id__smithing_mater;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__damage_type_id__damage_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__slot_type_id__slot_types__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__smithing_material_id__smithing_materials__fkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__equipment_type_id__equipment_types__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment9id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment8id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment7id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment6id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment5id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment4id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment3id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment2id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment24id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment23id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment22id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment21id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment20id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment1id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment19id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment18id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment17id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment16id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment15id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment14id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment13id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment12id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment11id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__equipment10id__equipments__fkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__base_hero_id__base_heroes__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__user_id__users__fkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__base_equipment_id__base_equipments__fkey;
DROP INDEX IF EXISTS users.users__email__idx;
DROP INDEX IF EXISTS users.user_bans__user_id__idx;
DROP INDEX IF EXISTS users.user_bans__user_ban_reason_id__idx;
DROP INDEX IF EXISTS server.user_ban_reasons__name__idx;
DROP INDEX IF EXISTS logs.user_authorizations__user_id__idx;
DROP INDEX IF EXISTS logs.user_authorizations__user_device_id__idx;
DROP INDEX IF EXISTS game_data.x_hero_creature_type__creature_type_id__idx;
DROP INDEX IF EXISTS game_data.x_equipment_type_damage_type__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.smithing_materials__name__idx;
DROP INDEX IF EXISTS game_data.slot_types__name__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__smithing_materials_id__idx;
DROP INDEX IF EXISTS game_data.material_damage_percents__damage_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__slot_type_id__idx;
DROP INDEX IF EXISTS game_data.equipment_types__name__idx;
DROP INDEX IF EXISTS game_data.damage_types__name__idx;
DROP INDEX IF EXISTS game_data.creature_types__name__idx;
DROP INDEX IF EXISTS game_data.base_heroes__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__smithing_material_id__idx;
DROP INDEX IF EXISTS game_data.base_equipments__name__idx;
DROP INDEX IF EXISTS game_data.base_equipments__equipment_type_id__idx;
DROP INDEX IF EXISTS collection.heroes__user_id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment9id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment8id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment7id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment6id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment5id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment4id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment3id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment2id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment24id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment23id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment22id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment21id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment20id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment1id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment19id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment18id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment17id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment16id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment15id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment14id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment13id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment12id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment11id__idx;
DROP INDEX IF EXISTS collection.heroes__equipment10id__idx;
DROP INDEX IF EXISTS collection.heroes__base_hero_id__idx;
DROP INDEX IF EXISTS collection.equipments__user_id__idx;
DROP INDEX IF EXISTS collection.equipments__base_equipment_id__idx;
ALTER TABLE IF EXISTS ONLY users.users DROP CONSTRAINT IF EXISTS users__pkey;
ALTER TABLE IF EXISTS ONLY users.user_devices DROP CONSTRAINT IF EXISTS user_devices__pkey;
ALTER TABLE IF EXISTS ONLY users.user_bans DROP CONSTRAINT IF EXISTS user_bans__pkey;
ALTER TABLE IF EXISTS ONLY server.user_ban_reasons DROP CONSTRAINT IF EXISTS user_ban_reasons__pkey;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY logs.user_authorizations DROP CONSTRAINT IF EXISTS user_authorizations__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.x_equipment_type_damage_type DROP CONSTRAINT IF EXISTS x_equipment_type_damage_type__pkey;
ALTER TABLE IF EXISTS ONLY game_data.smithing_materials DROP CONSTRAINT IF EXISTS smithing_materials__pkey;
ALTER TABLE IF EXISTS ONLY game_data.slot_types DROP CONSTRAINT IF EXISTS slot_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.material_damage_percents DROP CONSTRAINT IF EXISTS material_damage_percents__pkey;
ALTER TABLE IF EXISTS ONLY game_data.equipment_types DROP CONSTRAINT IF EXISTS equipment_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.damage_types DROP CONSTRAINT IF EXISTS damage_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.creature_types DROP CONSTRAINT IF EXISTS creature_types__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_heroes DROP CONSTRAINT IF EXISTS base_heroes__pkey;
ALTER TABLE IF EXISTS ONLY game_data.base_equipments DROP CONSTRAINT IF EXISTS base_equipments__pkey;
ALTER TABLE IF EXISTS ONLY collection.heroes DROP CONSTRAINT IF EXISTS heroes__pkey;
ALTER TABLE IF EXISTS ONLY collection.equipments DROP CONSTRAINT IF EXISTS equipments__pkey;
DROP TABLE IF EXISTS users.users;
DROP TABLE IF EXISTS users.user_devices;
DROP TABLE IF EXISTS users.user_bans;
DROP TABLE IF EXISTS server.user_ban_reasons;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP TABLE IF EXISTS logs.user_authorizations;
DROP TABLE IF EXISTS game_data.x_hero_creature_type;
DROP TABLE IF EXISTS game_data.x_equipment_type_damage_type;
DROP TABLE IF EXISTS game_data.smithing_materials;
DROP TABLE IF EXISTS game_data.slot_types;
DROP TABLE IF EXISTS game_data.material_damage_percents;
DROP TABLE IF EXISTS game_data.equipment_types;
DROP TABLE IF EXISTS game_data.damage_types;
DROP TABLE IF EXISTS game_data.creature_types;
DROP TABLE IF EXISTS game_data.base_heroes;
DROP TABLE IF EXISTS game_data.base_equipments;
DROP TABLE IF EXISTS collection.heroes;
DROP TABLE IF EXISTS collection.equipments;
DROP SCHEMA IF EXISTS users;
DROP SCHEMA IF EXISTS server;
DROP SCHEMA IF EXISTS logs;
DROP SCHEMA IF EXISTS game_data;
DROP SCHEMA IF EXISTS collection;
--
-- TOC entry 6 (class 2615 OID 52320)
-- Name: collection; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA collection;


--
-- TOC entry 7 (class 2615 OID 52321)
-- Name: game_data; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA game_data;


--
-- TOC entry 8 (class 2615 OID 52322)
-- Name: logs; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA logs;


--
-- TOC entry 9 (class 2615 OID 52323)
-- Name: server; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA server;


--
-- TOC entry 10 (class 2615 OID 52324)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 52325)
-- Name: equipments; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.equipments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    base_equipment_id integer NOT NULL,
    group_name character varying(255)
);


--
-- TOC entry 225 (class 1259 OID 52338)
-- Name: heroes; Type: TABLE; Schema: collection; Owner: -
--

CREATE TABLE collection.heroes (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    base_hero_id integer NOT NULL,
    health1000 bigint CONSTRAINT heroes_health_not_null NOT NULL,
    strength integer NOT NULL,
    agility integer NOT NULL,
    intelligence integer NOT NULL,
    crit_chance integer NOT NULL,
    crit_power integer NOT NULL,
    haste integer NOT NULL,
    versality integer NOT NULL,
    endurance_physical integer NOT NULL,
    endurance_magical integer NOT NULL,
    resist_damage_physical integer NOT NULL,
    resist_damage_magical integer NOT NULL,
    equipment1id uuid,
    equipment2id uuid,
    equipment3id uuid,
    equipment4id uuid,
    equipment5id uuid,
    equipment6id uuid,
    equipment7id uuid,
    equipment8id uuid,
    equipment9id uuid,
    equipment10id uuid,
    equipment11id uuid,
    equipment12id uuid,
    equipment13id uuid,
    equipment14id uuid,
    equipment15id uuid,
    equipment16id uuid,
    equipment17id uuid,
    equipment18id uuid,
    equipment19id uuid,
    equipment20id uuid,
    equipment21id uuid,
    equipment22id uuid,
    equipment23id uuid,
    equipment24id uuid,
    experience_now bigint DEFAULT 0 NOT NULL,
    group_name character varying(255),
    level integer DEFAULT 1 NOT NULL,
    rarity integer DEFAULT 1 NOT NULL,
    damage jsonb
);


--
-- TOC entry 226 (class 1259 OID 52368)
-- Name: base_equipments; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_equipments (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    equipment_type_id integer NOT NULL,
    health jsonb,
    damage jsonb,
    smithing_material_id integer
);


--
-- TOC entry 227 (class 1259 OID 52379)
-- Name: base_equipments_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_equipments ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_equipments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 228 (class 1259 OID 52380)
-- Name: base_heroes; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.base_heroes (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    main_stat integer DEFAULT 0 NOT NULL,
    health jsonb,
    damage jsonb
);


--
-- TOC entry 229 (class 1259 OID 52392)
-- Name: base_heroes_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.base_heroes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.base_heroes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 52393)
-- Name: creature_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.creature_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 52398)
-- Name: creature_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.creature_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.creature_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 52399)
-- Name: damage_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.damage_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255),
    dev_hint_ru text,
    category integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 52408)
-- Name: damage_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.damage_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.damage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 52409)
-- Name: equipment_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.equipment_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255) NOT NULL,
    mass_physical integer DEFAULT 0 NOT NULL,
    mass_magical integer DEFAULT 0 NOT NULL,
    slot_type_id integer NOT NULL,
    can_craft_smithing boolean DEFAULT false NOT NULL,
    can_craft_jewelcrafting boolean DEFAULT false NOT NULL,
    spend_action_points integer DEFAULT 0 NOT NULL,
    block_other_hand boolean,
    damage jsonb
);


--
-- TOC entry 235 (class 1259 OID 52428)
-- Name: equipment_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.equipment_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.equipment_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 52429)
-- Name: material_damage_percents; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.material_damage_percents (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 52436)
-- Name: material_damage_percents_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.material_damage_percents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.material_damage_percents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 52437)
-- Name: slot_types; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.slot_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 239 (class 1259 OID 52444)
-- Name: slot_types_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.slot_types ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.slot_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 52445)
-- Name: smithing_materials; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.smithing_materials (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 241 (class 1259 OID 52452)
-- Name: smithing_materials_id_seq; Type: SEQUENCE; Schema: game_data; Owner: -
--

ALTER TABLE game_data.smithing_materials ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME game_data.smithing_materials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 52453)
-- Name: x_equipment_type_damage_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_equipment_type_damage_type (
    equipment_type_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    damage_coef integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 52460)
-- Name: x_hero_creature_type; Type: TABLE; Schema: game_data; Owner: -
--

CREATE TABLE game_data.x_hero_creature_type (
    base_hero_id integer CONSTRAINT x_hero_creature_type_hero_id_not_null NOT NULL,
    creature_type_id integer NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 52465)
-- Name: user_authorizations; Type: TABLE; Schema: logs; Owner: -
--

CREATE TABLE logs.user_authorizations (
    id uuid NOT NULL,
    email character varying(255),
    user_id uuid,
    success boolean NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    user_device_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid,
    ip inet
);


--
-- TOC entry 245 (class 1259 OID 52476)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 52481)
-- Name: user_ban_reasons; Type: TABLE; Schema: server; Owner: -
--

CREATE TABLE server.user_ban_reasons (
    id integer NOT NULL,
    name text NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 52488)
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE; Schema: server; Owner: -
--

ALTER TABLE server.user_ban_reasons ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME server.user_ban_reasons_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 248 (class 1259 OID 52489)
-- Name: user_bans; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_bans (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    user_ban_reason_id integer NOT NULL
);


--
-- TOC entry 249 (class 1259 OID 52499)
-- Name: user_devices; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.user_devices (
    id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    system_environment_user_name character varying(255),
    time_zone_minutes integer,
    device_unique_identifier character varying(255),
    device_model character varying(255),
    device_type character varying(255),
    operating_system character varying(255),
    processor_type character varying(255),
    processor_count integer,
    system_memory_size integer,
    graphics_device_name character varying(255),
    graphics_memory_size integer,
    system_info_supports_instancing boolean,
    system_info_npot_support character varying(255)
);


--
-- TOC entry 250 (class 1259 OID 52506)
-- Name: users; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.users (
    id uuid NOT NULL,
    email character varying(255),
    email_verified_at timestamp with time zone,
    password_hash character varying(255),
    time_zone character varying(255),
    is_admin boolean DEFAULT false NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 5131 (class 0 OID 52325)
-- Dependencies: 224
-- Data for Name: equipments; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.equipments (id, user_id, version, created_at, updated_at, base_equipment_id, group_name) FROM stdin;
fdd8c5a3-3154-4b15-8421-b51813e9d94a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	5	\N
05c7c86b-e9c9-4aed-93d6-aa7ce882001b	113ae534-2310-40e3-a895-f3747ea976ca	8	2025-12-19 10:22:04.781589+08	2025-12-19 10:49:01.82747+08	6	\N
ebdb63b7-14c5-452f-a1f9-31f2d21ef9a4	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	8	\N
b770885c-33b6-44d6-bcc8-9c4d3a9ea33b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:22:04.781589+08	2025-12-19 10:22:04.781589+08	9	\N
\.


--
-- TOC entry 5132 (class 0 OID 52338)
-- Dependencies: 225
-- Data for Name: heroes; Type: TABLE DATA; Schema: collection; Owner: -
--

COPY collection.heroes (id, user_id, version, created_at, updated_at, base_hero_id, health1000, strength, agility, intelligence, crit_chance, crit_power, haste, versality, endurance_physical, endurance_magical, resist_damage_physical, resist_damage_magical, equipment1id, equipment2id, equipment3id, equipment4id, equipment5id, equipment6id, equipment7id, equipment8id, equipment9id, equipment10id, equipment11id, equipment12id, equipment13id, equipment14id, equipment15id, equipment16id, equipment17id, equipment18id, equipment19id, equipment20id, equipment21id, equipment22id, equipment23id, equipment24id, experience_now, group_name, level, rarity, damage) FROM stdin;
6e04e752-046f-4920-b768-02ae3e5d9027	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
7069aabd-3492-4ddd-b169-183227deea19	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
726951f0-964d-45d5-bb75-2d0747aee5a0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
84214c20-5893-4fcc-87f2-9c899acf3304	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
8509518a-83f8-424d-b98b-e137918fe288	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
86bee793-9ca8-4891-8c93-d31d05e98d4e	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
9190bfdb-9859-435b-8698-4bda48110cd2	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
97e422f9-fab2-49f4-9baa-597f0267ecbe	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
aa31edd3-4170-4a56-aa95-f1512b15ed05	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b075c17b-b766-454e-a6bb-5f1d077d1e97	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b58d2432-9f69-4207-898d-0cbef2a96f9b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
b6c097bb-4533-439e-8d92-549944953b68	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bc29da98-93a8-4ee5-8410-98ff47e8a5c0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
bfd045e4-b18c-42f5-999e-361606e7db36	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
c68bdd39-5c13-4f44-b78e-c3103c15843a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d3e2d306-2d65-4429-bb73-868cd9e6d49d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
d6a8d5c0-147c-44aa-95a3-26cd1e72da92	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
da9113a3-75c2-4e7f-8f18-4bb2801140f0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
df320eb3-4a55-4285-a56f-d0cb9bbee8b8	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
e646db49-1d8f-4a8e-afbd-4c59132d1fae	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f0b28a6a-2eff-4fa3-b937-cffe833d9e38	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
f81e4bb5-9d11-485e-a9d9-32f10c7a98a1	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
fa74574f-d388-487d-b22c-afc303586331	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
07ca8aa2-1818-4d5d-8e94-550c38781fd6	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1509d0cc-60b8-4a34-bde9-f3b9c953c346	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	6	\N
1a678339-5de4-4158-885f-2a98f3559f87	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
1c3353b7-9d76-4ee3-a643-c38391977357	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	3	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
245adf15-4177-472e-b26a-e72b626f7913	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
35d12794-d235-4e17-b63a-de8686ecbbff	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	5	\N
3a9c4a11-7866-4f07-be28-077c8b92287c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
46059840-ea65-4a09-80d7-8a0ee31d1a7c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5633a525-85f5-4cee-aba2-ea7a0456c7be	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	1	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
fb7f80bb-f5d8-4137-99e9-0253d36e5e13	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	1	\N
0898028c-387b-4287-bae6-f2c772cb122a	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
179d9a78-b08a-4066-83a4-44878c0f5fb2	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
4157b965-d367-4beb-bb05-e110858bd3dc	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6e141540-016c-466e-8d37-20712fc22d5d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6f3bdb81-031c-4f29-8e67-ee0597e8226d	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
879ea6cc-728c-4534-88dc-210d145c4f93	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a2191a50-eb1e-45ea-9df2-98f8cdfa2c34	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
a6ecb7fa-d9fb-470a-ae38-e54be27111a0	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
aa3114ef-ebfb-464c-9051-7f4cccdc78db	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
b62b12d4-91f7-49bb-a31b-765a5ab42adc	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	5	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
574d58cd-3556-409f-b71f-d8256813c0f7	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	4	\N
5a0e846c-8d97-494d-9349-808b8240d11b	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
5e7ef4f3-5478-4379-a404-31d10e41c90f	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
642d2670-60ef-4a23-9fd1-c53f455bc73c	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
64611efc-b08d-4d2f-be14-577ff77c58a5	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	3	\N
68afa62f-7590-4f33-87dc-2bb593dd8b71	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	2	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
6c5c5b0f-bc6d-445d-9c44-b276c6aa1ca7	113ae534-2310-40e3-a895-f3747ea976ca	1	2025-12-19 10:03:09.293032+08	2025-12-19 10:03:09.293032+08	4	0	0	0	0	0	0	0	0	0	0	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	1	2	\N
\.


--
-- TOC entry 5133 (class 0 OID 52368)
-- Dependencies: 226
-- Data for Name: base_equipments; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_equipments (id, name, rarity, is_unique, equipment_type_id, health, damage, smithing_material_id) FROM stdin;
5	Iron gloves	1	f	26	\N	\N	1
6	Iron helmet	1	f	27	\N	\N	1
8	Iron boots	1	f	29	\N	\N	1
9	Iron armor	1	f	30	\N	\N	1
\.


--
-- TOC entry 5135 (class 0 OID 52380)
-- Dependencies: 228
-- Data for Name: base_heroes; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.base_heroes (id, name, rarity, is_unique, main_stat, health, damage) FROM stdin;
1	Warrior	1	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 24}}	\N
2	Huntress	1	f	2	{"damage": {"c": 5, "s": 21}, "health": {"c": 10, "s": 28}}	\N
3	Hammerman	1	f	1	{"damage": {"c": 3, "s": 25}, "health": {"c": 11, "s": 39}}	\N
4	Rogue	1	f	2	{"damage": {"c": 4, "s": 23}, "health": {"c": 15, "s": 21}}	\N
5	Battle orc	2	f	1	{"damage": {"c": 4, "s": 21}, "health": {"c": 16, "s": 58}}	\N
\.


--
-- TOC entry 5137 (class 0 OID 52393)
-- Dependencies: 230
-- Data for Name: creature_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.creature_types (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5139 (class 0 OID 52399)
-- Dependencies: 232
-- Data for Name: damage_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.damage_types (id, name, name_ru, dev_hint_ru, category) FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)	1
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 	1
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)	1
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда	1
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\n\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\n\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\n\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\n\n"	0
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\n\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\n\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\n\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."	0
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\n\nУязвимы: Призраки, астральные существа (иногда).\n\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\n\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."	1
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\n\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\n\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\n\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."	2
11	Radiant	Лучистый	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\n\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\n\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\n\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."	2
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\n\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\n\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\n\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."	2
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\n\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\n\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\n\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."	2
17	Dark magic	Тёмная магия	Критерий\tНекротический урон\tТёмная магия (Shadow/Dark)\nСуть\tРазложение, смерть, конец.\tСтрах, боль, подавление, коррупция.\nИсточник\tСмерть, небытие, пустота, анти-жизнь.\tОтрицательные эмоции, тени, извращённая магия, пакты с тёмными сущностями.\nКак выглядит/ощущается\tХолод, влажность, запах тления, серо-зелёные тона, иссушение, гниение.\tХолод или ледяное жжение, ощущение ужаса, давление на разум, чёрные/фиолетовые тона, искажение света.\nЭффект на живую цель\tВысасывает жизненную силу, вызывает быстрое старение, некроз тканей, разложение.\tДробит волю, наводит ужас, вызывает боль, ввергает в отчаяние, может подчинять разум.\nЭффект на нежить\tЧасто исцеляет или усиливает (это её родная стихия).\tМожет наносить урон (как любая агрессивная магия), а может усиливать, делая более агрессивной.\nЭффект на демонов/исчадий\tОбычно эффективен (смерть для всех).\tЧасто неэффективен или даже подпитывает их (они сами из этой энергии).\nТипичные заклинания\t«Палящий взгляд», «Круг смерти», «Вытягивание жизни», «Увядание».\t«Стрела Тьмы», «Объятья страха», «Проклятие боли», «Порча разума».\nАналогия\tРадиация или смертельная болезнь. Убивает всё живое, разлагает материю.\tПыточный инструмент или психологическая пытка. Ломает дух, чтобы сломить тело.\nЦель атаки\tТело и душа (физическое уничтожение).\tПсихика и дух (ментальное подчинение → физический урон).\nАрхетип мага\tНекромант. Холодный учёный смерти.\tЧернокнижник, Тёмный колдун. Эмоциональный манипулятор, заключивший сделку с силами тьмы.\n	2
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\n\nУязвимы: ВСЕ. По определению.\n\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\n\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\n\nУльтимативные способности с долгим откатом.\n\nЛегендарные/божественные артефакты.\n\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\n\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."	0
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\n\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\n\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\n\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."	0
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\n\nУязвимы: Органические, живые существа (люди, звери, растения).\n\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\n\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."	0
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\n\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\n\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\n\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."	0
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\n\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\n\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\n\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."	0
\.


--
-- TOC entry 5141 (class 0 OID 52409)
-- Dependencies: 234
-- Data for Name: equipment_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.equipment_types (id, name, name_ru, mass_physical, mass_magical, slot_type_id, can_craft_smithing, can_craft_jewelcrafting, spend_action_points, block_other_hand, damage) FROM stdin;
18	bow	лук	960	0	0	t	f	0	t	{"c": 4, "s": 2}
26	hands	руки	1240	0	0	t	f	0	\N	\N
27	helmet	шлем	1240	0	0	t	f	0	\N	\N
29	boots	сапоги	1860	0	0	t	f	0	\N	\N
30	chest	нагрудник	4340	0	0	t	f	0	\N	\N
32	waist	пояс	620	0	0	t	f	0	\N	\N
\.


--
-- TOC entry 5143 (class 0 OID 52429)
-- Dependencies: 236
-- Data for Name: material_damage_percents; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.material_damage_percents (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5145 (class 0 OID 52437)
-- Dependencies: 238
-- Data for Name: slot_types; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.slot_types (id, name, name_ru) FROM stdin;
0	NONE	NONE
1	Weapon	оружие
2	WeaponShield	оружие/щит
4	Head	голова
6	Armor	броня
7	Hands	руки
9	Feet	сапоги
10	Waist	пояс
14	Ring	кольцо
16	Trinket	аксессуар
17	Neck	шея
\.


--
-- TOC entry 5147 (class 0 OID 52445)
-- Dependencies: 240
-- Data for Name: smithing_materials; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.smithing_materials (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
11	Fulgurite	Фульгурит
\.


--
-- TOC entry 5149 (class 0 OID 52453)
-- Dependencies: 242
-- Data for Name: x_equipment_type_damage_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_equipment_type_damage_type (equipment_type_id, damage_type_id, damage_coef) FROM stdin;
18	1	100
\.


--
-- TOC entry 5150 (class 0 OID 52460)
-- Dependencies: 243
-- Data for Name: x_hero_creature_type; Type: TABLE DATA; Schema: game_data; Owner: -
--

COPY game_data.x_hero_creature_type (base_hero_id, creature_type_id) FROM stdin;
\.


--
-- TOC entry 5151 (class 0 OID 52465)
-- Dependencies: 244
-- Data for Name: user_authorizations; Type: TABLE DATA; Schema: logs; Owner: -
--

COPY logs.user_authorizations (id, email, user_id, success, version, created_at, user_device_id, ip) FROM stdin;
166dea33-90ad-4614-847a-d3856731a681	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	f	1	2025-12-19 22:55:44.844376+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
a13f9f9d-3a07-481c-a1f3-264aedb92f66	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	f	1	2025-12-19 22:56:04.849562+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
74dd7b84-ed79-4eb3-97c5-84b71b4a2eb5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-19 22:56:34.849562+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
4f79d7a8-c7a1-4896-8326-64ca4f8bfef2	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:04:50.644044+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
9ee8120d-bb22-48aa-82ad-c143e3549067	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:07:05.505557+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
04b14bd1-5d84-46c3-a434-93e3abd9316b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:07:42.79347+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
3eebd86a-a994-499f-886a-df03bc23b326	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:10:57.703253+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
eb5b88ed-904d-478b-a839-dd64eda2e2d4	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:11:27.707658+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
bdf67461-7ddc-4002-88a1-fa690790e54c	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:13:17.698237+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
50df87b1-0f74-461f-924e-1c77e507c8f5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:13:44.752459+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
468b4b7e-1786-496e-b047-2fcab968af27	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:15:39.671995+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
284f47a7-9d8c-41c5-9ceb-dfdd225fc01f	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:19:46.866552+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
94192ddf-adeb-4023-a54f-dbd217b35842	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:20:56.76968+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f4602676-e5ef-4840-aea8-efdd2c2a8026	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:22:22.456088+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f4a91bb3-58dc-4d56-82f5-0d4b9012afcc	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:23:20.82107+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
1121435d-924e-4e37-92d2-e0c06de96835	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:24:30.735273+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
43192cf8-352c-4156-937f-f119608bac35	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:25:44.620405+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
c1e31780-465a-4e3c-8372-497442c011c4	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:35:34.529348+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
eada9055-f59d-49ff-8c04-fd3986fd3a45	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:35:54.525534+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
2b3b5b39-6c10-43cb-96f0-8ae60b73783d	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:45:04.527987+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
95e8c1ba-99e2-4d07-b259-6b9e748fb5c7	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:52:19.528408+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
e0fd014a-9062-439f-98ae-be274e6ac45b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 19:54:03.43298+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
6112be84-2e3d-4549-ad0e-a8546de803e3	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 20:12:18.347252+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
2e95118a-5ec5-462c-b8b5-039a5ddb7aa2	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 20:16:13.334472+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f557836a-bd0e-4981-9093-5936b4ff0909	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 20:18:28.33651+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
d7708120-908c-48c0-9078-9c990752ccaa	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-20 20:19:08.346365+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
ce7db772-9fe5-48d5-aee2-cc8bebe0c954	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:23:32.052081+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
b108e92f-22c3-41d4-8f53-1f0a822e2149	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:25:04.759962+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
c4a7ec3f-7ba2-40c9-8d10-5eda57da93b1	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:25:54.708643+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
5b0862ce-ff50-45ef-bda7-7980f8b39e8e	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:27:39.883947+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
4a3f5217-be04-44a0-af7f-206f01def6de	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:28:42.128968+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
28def4ab-d4f2-49d9-a949-f770ea20dcf6	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:29:02.064135+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f29e85f7-1c19-4c5c-a328-2cf765e1645a	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:29:56.739072+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
a165b86b-d8b2-4695-a120-df3d87ddc687	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:31:10.405265+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
64b4a800-21b8-42b3-99bc-af89e4b60a31	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:33:34.613595+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
d6bb5dab-595a-4f40-b218-0d48c7935219	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:36:43.582073+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f62f9ed7-24f8-420e-ba30-23212f54b544	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:38:38.483075+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
35f61632-9cf2-4c8e-8cff-60de0dd1bb82	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 14:39:41.543994+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
6f1c0a96-f8c5-4a0f-8444-52e7c1b52037	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 16:55:08.615268+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
97981dcd-13e6-4a98-bad2-089af5ea91af	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 16:55:28.561697+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
971618bf-6d30-4912-8a58-587056f3fbbf	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:16:28.596933+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
836cf87d-4180-4284-a264-109e869b9990	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:17:53.496633+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
cda12320-db0c-4406-ab94-8c08faeca416	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:18:48.491335+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
a8f27201-7dd1-4f02-8ccb-8a32efbb78a5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:19:13.49068+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
d812123b-b210-4640-997c-fadce6f51007	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:21:14.003477+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
6658b017-a677-4a6c-b527-d5384f235d6b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:21:28.905734+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
a68939e8-fa6f-4624-9652-64a91873db6b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:21:58.899557+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
dd4314e8-1ff9-4c35-81f4-2fd2fb8c3c78	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:22:08.895427+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
e9eadb65-e0ed-4b41-bb98-dde5e8d4381b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:22:28.891867+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
5eaa521e-8bfb-40a8-9763-625947c444f3	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:23:08.902228+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
7fb69044-5227-4b72-bc66-5660e6c5dfce	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:23:33.904234+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
31a0ac30-bec9-474d-bbf6-f4ec8f4dee87	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-22 22:28:33.874637+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
8483f802-d96f-4754-ae4b-0e9f387479e4	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 10:24:24.372121+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
8f9758ae-3583-44e4-a4c9-a7a4ce4212f9	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 10:56:09.31155+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
27589940-25b3-4cab-8b3e-9ae72515840a	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 10:57:09.31192+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
7b7b3ac2-d380-4ee2-9342-7659a0493fcd	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 11:00:49.306524+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
7c525ce7-9249-4af0-9323-d390e927a7c5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 11:01:34.301858+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
9101a83f-c83b-401f-9129-37375868127f	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 11:03:59.299626+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
75ef0c41-ba8a-4b37-abf3-6b9db92b3a83	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 11:45:09.286417+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
c3af8c66-0972-4394-a3f5-fdd715562a69	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 12:04:39.278122+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
94dd9420-d471-4d80-a34a-af3cb1a14d2e	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:06:20.569861+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
2b8d8dc3-44ba-41f5-b4b7-d3d0a4a655e8	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:09:05.5145+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
da25e300-ba44-44d9-98d0-0d2087ec3082	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:12:15.509607+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
0b5e6b3c-dba0-45fa-950b-716d12224b9b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:12:45.517633+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
5eeedba5-36fe-42ff-9afe-c11339dba676	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:26:00.507188+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
ea3eb12c-02f9-4f38-a7e6-0776ea92354d	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:26:40.517488+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
467433e9-d8bc-4a9e-8e48-288b67ff64d7	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:28:05.519139+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
31c97bbf-a4e6-427c-9811-982064135fd0	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:31:25.515643+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
43fe0282-b3dc-42fa-b3f2-e82933a0a922	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 13:44:00.521049+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
9e0c87e8-9684-423f-98e9-7f18744b9795	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 20:10:31.305183+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
227ed8fc-af3e-4568-8fdc-dc5ad4fdaf46	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 20:10:56.235537+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
89f99fef-46e1-4dac-86c1-cd350632bfe8	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 21:45:31.301785+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
93495b05-9820-43c1-8724-737d112eb268	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 21:46:36.179389+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
0ca8b71c-7543-460f-9018-a907b5950adb	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 21:47:51.170991+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
9fce0aed-1d17-4bf1-bd3c-0ec02f48c450	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 21:55:16.173681+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
4c2f0299-5ff7-43c9-a984-5aaa15f23702	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 21:56:36.173346+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
6fb9ae44-d3a0-4561-89a6-c8282883736b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 21:58:11.167789+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
48af1ae7-7866-44e1-89a2-5e3f3db43e3d	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 21:59:41.177883+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
0e537098-9365-4ca0-aed5-0aa4c93f2323	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 22:03:26.170582+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
c72ae548-8cf2-462b-b3fe-f3d3e62eb218	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 22:06:21.170919+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
5835fe5c-5c39-463f-8cdd-6cc032481f5a	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 22:11:16.203304+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
d9460f1a-fbb2-4c5a-ab69-8588fef6258b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 22:16:26.173702+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
ae765c41-3be7-4c61-9709-f599bf9104bc	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-23 22:24:26.175133+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
65961259-730b-4eb5-8236-0f96f91c1843	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 08:35:40.143821+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
ba119feb-e121-4b6c-8ce7-7eb0d188a347	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 08:50:45.097316+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
45f6c0f3-f952-4ae3-92ce-4415b4e0d681	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 08:53:20.078499+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
c086d1b2-2704-49b0-adfd-3926c228d710	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 08:55:10.064005+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
96069f7f-e1af-4495-9d8b-67051309d658	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 08:55:35.075639+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
d41dba00-5c9c-4fb0-920b-714c9a14c1df	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 08:57:30.067416+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
224b4663-1b5b-491b-b48d-eed517cc2ade	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 09:05:10.062415+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
4ba91bb4-ed9a-4769-bee2-d8afdd8e891a	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 09:42:00.062332+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
719a6219-c908-4dd6-8061-cfdc60726774	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 09:53:00.065048+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
7286ed0d-c640-412f-9b18-4b50fe724eb1	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 10:13:50.025125+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
88723226-f800-45d6-a792-095002cd9c26	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 10:18:25.036671+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
a6048709-ebe6-4585-a44a-3de944662f44	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 10:19:35.031858+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
ec5aaeb9-1520-4c53-a406-40ef2284cf0d	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 10:21:35.032736+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
48ac3909-78c4-43a7-92d2-2dce52a10544	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 10:43:25.049745+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
6661422a-bb8e-4ea4-8152-3ddc5a766eed	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 11:08:55.030371+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
2a3161b8-15cc-4d14-bc69-683ead15014b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 12:35:36.800985+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
7d09602d-b4fa-4f0b-a04c-a7e813a95f27	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 12:36:21.750346+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
baea3903-af0d-4e6f-ac71-d8bf0e8f8281	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 16:47:21.886984+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
292257a1-a0b5-479e-8614-e6b4d88258ec	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 16:57:37.888866+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
5c4cf240-e637-4a06-867c-a14f1e951d3a	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 21:14:10.705817+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
f6c31a96-df59-4557-bc09-940e08e3c6ba	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-24 21:15:30.624583+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
0279dde6-bba6-4904-8bcf-5449b538aa32	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-25 13:11:59.182034+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
f477ecc7-4a77-473b-b8fb-d7c71fdbecdc	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-25 13:12:44.129283+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
03130acd-055d-48e6-a4ee-fcade48d8993	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-25 13:13:19.103216+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
11652d18-3dd1-4961-a64c-ee7596742738	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-25 13:13:54.103075+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
4a26f6eb-05f1-44db-ac27-c53773b8a090	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-25 14:03:04.081492+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
e4ecfeff-4776-41b0-bfda-7cf5e6baf3dc	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-25 14:18:09.111892+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
16805717-73f8-4ad2-85a8-7485a37a17f3	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-25 17:05:55.547534+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
a0bd25a0-fe46-4589-a7b4-eb5953997878	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-25 17:07:40.030371+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
387b7e4c-dcd3-408c-a52b-54700912a3dc	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-27 14:18:13.702818+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
3acf3345-4adb-4985-b4c0-104f13b82ad1	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-27 15:04:58.602725+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
7e177b57-7196-4bd9-8d06-4639a9a5848c	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-27 17:31:11.8723+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
303a3cb4-e82f-4f8c-b7b5-b013dbc59ae5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-27 17:36:26.864966+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
88de296d-6706-473d-8caa-45974fa3a209	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-27 17:38:06.740556+08	47ee0275-bae7-c959-af87-f8b416a6cfd0	127.0.0.1
ee7c1bd1-55ea-41f0-973b-5d2360d5f63a	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 10:44:36.26957+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
f1c40505-5b73-4d81-a53c-ab74f900f210	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 10:46:16.240915+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
63a44f18-61c3-45a6-a1a4-4b8864bec3a0	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 10:48:46.191756+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
03f4322b-0697-40bb-a5c5-d656c80fbf37	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 10:57:11.18645+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
494bebc2-25d2-4d41-81c3-6b6edfdfa389	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 10:58:56.196015+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
1df1cdf5-a8c7-41ae-99e5-254dce7b94e6	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 10:59:56.183197+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
344ce2c3-f65b-4b87-8f6b-be852b83d167	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:05:11.18958+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
ea755f86-bb3c-4941-8a3b-bc10313b6d94	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:05:41.191292+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
a6a8eaff-549e-42f7-9ca7-b7a7918de9bb	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:09:21.18446+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
35bce8a5-1865-45c5-b1d0-6fb11d943f72	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:10:11.185494+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
1af277d6-49f9-4ac1-bd0f-a6341bc9a6c5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:10:41.183281+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
104f14c9-6f72-420b-9879-dd31a237b525	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:16:08.617252+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
b90e1351-53a3-468f-9fc6-425e2a4918fd	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:17:03.53801+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
7f12b51d-6912-4ffb-b2dc-26cdcc382368	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:17:48.53222+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
cc7ec601-7d0f-4f1b-be4f-2eb368ecbd35	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 11:59:58.511638+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
18d2cc33-4786-4e42-b79b-4cb534ddc76b	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:06:13.515417+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
536108d3-fe49-44ea-9013-fbf5422e5408	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:07:03.503217+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
5565ce48-ffdc-466b-aa09-0c154a5df3d8	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:14:43.510677+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
4fe0d59b-ce13-4591-a829-0e65f7279ff4	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:16:38.504015+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
68105231-cfda-4a8f-9781-cf05627d1728	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:31:23.525744+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
4bef934e-1598-434e-8846-cafdf1b97be9	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:32:48.490952+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
4d98c49f-bf1f-4f76-af63-378907d05e47	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:33:35.992042+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
dae28564-9272-4cfb-b5b5-68ec60f9181d	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:34:10.916996+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
ae8e32b6-e207-4f0f-b2e7-aba7c9bfa09f	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:35:56.706958+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
54e0a303-55b7-4631-84aa-08856f8f3c59	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:37:01.584581+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
ec50a98e-422d-4a5e-be82-2a2ede895689	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:42:21.572834+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
05e00207-9f64-4a22-b33a-deaf8d6250ea	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 12:45:31.579383+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
5d827121-375d-4689-9775-aa6a2debe3d5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 16:17:16.502368+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
efa8cdd9-b843-4cea-a3b6-663e64d3f8d5	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 16:21:06.48959+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
93272e18-2b7c-4ae5-930b-897370f93b18	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 16:22:36.482897+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
4db3636e-83b9-47f9-92e2-7ac48c334486	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 16:24:51.491827+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
ded8e16f-51c9-489e-bad8-6983d44d0d78	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 16:27:46.481948+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
39896162-fa02-45e0-a293-3573777b6ecf	SUPERADMIN@MAIL.RU	113ae534-2310-40e3-a895-f3747ea976ca	t	1	2025-12-29 16:29:26.483412+08	2f3585e2-e396-345a-b6d2-8d7079e5cdfc	127.0.0.1
\.


--
-- TOC entry 5152 (class 0 OID 52476)
-- Dependencies: 245
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251218141532_Init	10.0.1
20251219010850_Fix1	10.0.1
20251219104853_Fix2	10.0.1
20251219125100_Fix3	10.0.1
20251219144649_Fix4	10.0.1
20251219145307_Fix5	10.0.1
20251220111640_Fix6	10.0.1
20251220140152_Fix7	10.0.1
20251221062947_Fix8	10.0.1
20251221115503_Fix9	10.0.1
20251221115727_Fix10	10.0.1
20251222005509_Fix11	10.0.1
20251222005528_Fix12	10.0.1
20251222012124_Fix13	10.0.1
20251222014603_Fix14	10.0.1
20251222032345_Fix15	10.0.1
20251222082512_Fix16	10.0.1
20251222142042_Fix17	10.0.1
20251224050619_Fix18	10.0.1
20251224060154_Fix19	10.0.1
20251224071911_Fix20	10.0.1
20251224075948_Fix21	10.0.1
20251224084507_Fix22	10.0.1
20251224125003_Fix23	10.0.1
\.


--
-- TOC entry 5153 (class 0 OID 52481)
-- Dependencies: 246
-- Data for Name: user_ban_reasons; Type: TABLE DATA; Schema: server; Owner: -
--

COPY server.user_ban_reasons (id, name) FROM stdin;
\.


--
-- TOC entry 5155 (class 0 OID 52489)
-- Dependencies: 248
-- Data for Name: user_bans; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_bans (id, user_id, version, created_at, updated_at, expires_at, user_ban_reason_id) FROM stdin;
\.


--
-- TOC entry 5156 (class 0 OID 52499)
-- Dependencies: 249
-- Data for Name: user_devices; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.user_devices (id, created_at, system_environment_user_name, time_zone_minutes, device_unique_identifier, device_model, device_type, operating_system, processor_type, processor_count, system_memory_size, graphics_device_name, graphics_memory_size, system_info_supports_instancing, system_info_npot_support) FROM stdin;
47ee0275-bae7-c959-af87-f8b416a6cfd0	2025-12-19 22:55:44.844376+08	AUTORITET	480	e307f13fd5fb9d8c59a3a7b4df863c02bdbb300c	B550 GAMING X V2 (Gigabyte Technology Co., Ltd.)	Desktop	Windows 11  (10.0.22000) 64bit	AMD Ryzen 7 3700X 8-Core Processor	16	32691	NVIDIA GeForce RTX 4070	12011	t	Full
2f3585e2-e396-345a-b6d2-8d7079e5cdfc	2025-12-22 14:23:32.052081+08	adm-shumkov	480	30af10590f9f87bea6b087c950be35295e8eee95	B760 DS3H (Gigabyte Technology Co., Ltd.)	Desktop	Windows 10  (10.0.19045) 64bit	Intel(R) Core(TM) i9-14900K	32	65296	Intel(R) UHD Graphics 770	32648	t	Full
\.


--
-- TOC entry 5157 (class 0 OID 52506)
-- Dependencies: 250
-- Data for Name: users; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.users (id, email, email_verified_at, password_hash, time_zone, is_admin, version, created_at, updated_at) FROM stdin;
113ae534-2310-40e3-a895-f3747ea976ca	SuperAdmin@mail.ru	\N	AQAAAAIAAYagAAAAEA+MLlU2KQvPMPQ0RCAWN2iQDElD1+zOUuwLjyXnOlBxsikuTAtogGdY3m5zDWnrXg==	\N	t	1	2025-12-03 10:45:43.769905+08	2025-12-03 10:45:43.769905+08
\.


--
-- TOC entry 5163 (class 0 OID 0)
-- Dependencies: 227
-- Name: base_equipments_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_equipments_id_seq', 9, true);


--
-- TOC entry 5164 (class 0 OID 0)
-- Dependencies: 229
-- Name: base_heroes_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.base_heroes_id_seq', 6, false);


--
-- TOC entry 5165 (class 0 OID 0)
-- Dependencies: 231
-- Name: creature_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.creature_types_id_seq', 9, false);


--
-- TOC entry 5166 (class 0 OID 0)
-- Dependencies: 233
-- Name: damage_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.damage_types_id_seq', 17, true);


--
-- TOC entry 5167 (class 0 OID 0)
-- Dependencies: 235
-- Name: equipment_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.equipment_types_id_seq', 32, true);


--
-- TOC entry 5168 (class 0 OID 0)
-- Dependencies: 237
-- Name: material_damage_percents_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.material_damage_percents_id_seq', 25, false);


--
-- TOC entry 5169 (class 0 OID 0)
-- Dependencies: 239
-- Name: slot_types_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.slot_types_id_seq', 17, true);


--
-- TOC entry 5170 (class 0 OID 0)
-- Dependencies: 241
-- Name: smithing_materials_id_seq; Type: SEQUENCE SET; Schema: game_data; Owner: -
--

SELECT pg_catalog.setval('game_data.smithing_materials_id_seq', 19, true);


--
-- TOC entry 5171 (class 0 OID 0)
-- Dependencies: 247
-- Name: user_ban_reasons_id_seq; Type: SEQUENCE SET; Schema: server; Owner: -
--

SELECT pg_catalog.setval('server.user_ban_reasons_id_seq', 1, false);


--
-- TOC entry 4861 (class 2606 OID 52519)
-- Name: equipments equipments__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4889 (class 2606 OID 52521)
-- Name: heroes heroes__pkey; Type: CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4894 (class 2606 OID 52523)
-- Name: base_equipments base_equipments__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__pkey PRIMARY KEY (id);


--
-- TOC entry 4898 (class 2606 OID 52525)
-- Name: base_heroes base_heroes__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_heroes
    ADD CONSTRAINT base_heroes__pkey PRIMARY KEY (id);


--
-- TOC entry 4901 (class 2606 OID 52527)
-- Name: creature_types creature_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.creature_types
    ADD CONSTRAINT creature_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4904 (class 2606 OID 52529)
-- Name: damage_types damage_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.damage_types
    ADD CONSTRAINT damage_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4907 (class 2606 OID 52531)
-- Name: equipment_types equipment_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4911 (class 2606 OID 52533)
-- Name: material_damage_percents material_damage_percents__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__pkey PRIMARY KEY (id);


--
-- TOC entry 4915 (class 2606 OID 52535)
-- Name: slot_types slot_types__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.slot_types
    ADD CONSTRAINT slot_types__pkey PRIMARY KEY (id);


--
-- TOC entry 4918 (class 2606 OID 52537)
-- Name: smithing_materials smithing_materials__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.smithing_materials
    ADD CONSTRAINT smithing_materials__pkey PRIMARY KEY (id);


--
-- TOC entry 4921 (class 2606 OID 52539)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__pkey PRIMARY KEY (equipment_type_id, damage_type_id);


--
-- TOC entry 4924 (class 2606 OID 52541)
-- Name: x_hero_creature_type x_hero_creature_type__pkey; Type: CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__pkey PRIMARY KEY (base_hero_id, creature_type_id);


--
-- TOC entry 4926 (class 2606 OID 52543)
-- Name: user_authorizations user_authorizations__pkey; Type: CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__pkey PRIMARY KEY (id);


--
-- TOC entry 4930 (class 2606 OID 52545)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4933 (class 2606 OID 52547)
-- Name: user_ban_reasons user_ban_reasons__pkey; Type: CONSTRAINT; Schema: server; Owner: -
--

ALTER TABLE ONLY server.user_ban_reasons
    ADD CONSTRAINT user_ban_reasons__pkey PRIMARY KEY (id);


--
-- TOC entry 4935 (class 2606 OID 52549)
-- Name: user_bans user_bans__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__pkey PRIMARY KEY (id);


--
-- TOC entry 4939 (class 2606 OID 52551)
-- Name: user_devices user_devices__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_devices
    ADD CONSTRAINT user_devices__pkey PRIMARY KEY (id);


--
-- TOC entry 4942 (class 2606 OID 52553)
-- Name: users users__pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.users
    ADD CONSTRAINT users__pkey PRIMARY KEY (id);


--
-- TOC entry 4859 (class 1259 OID 52554)
-- Name: equipments__base_equipment_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__base_equipment_id__idx ON collection.equipments USING btree (base_equipment_id);


--
-- TOC entry 4862 (class 1259 OID 52555)
-- Name: equipments__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX equipments__user_id__idx ON collection.equipments USING btree (user_id);


--
-- TOC entry 4863 (class 1259 OID 52556)
-- Name: heroes__base_hero_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__base_hero_id__idx ON collection.heroes USING btree (base_hero_id);


--
-- TOC entry 4864 (class 1259 OID 52557)
-- Name: heroes__equipment10id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment10id__idx ON collection.heroes USING btree (equipment10id);


--
-- TOC entry 4865 (class 1259 OID 52558)
-- Name: heroes__equipment11id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment11id__idx ON collection.heroes USING btree (equipment11id);


--
-- TOC entry 4866 (class 1259 OID 52559)
-- Name: heroes__equipment12id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment12id__idx ON collection.heroes USING btree (equipment12id);


--
-- TOC entry 4867 (class 1259 OID 52560)
-- Name: heroes__equipment13id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment13id__idx ON collection.heroes USING btree (equipment13id);


--
-- TOC entry 4868 (class 1259 OID 52561)
-- Name: heroes__equipment14id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment14id__idx ON collection.heroes USING btree (equipment14id);


--
-- TOC entry 4869 (class 1259 OID 52562)
-- Name: heroes__equipment15id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment15id__idx ON collection.heroes USING btree (equipment15id);


--
-- TOC entry 4870 (class 1259 OID 52563)
-- Name: heroes__equipment16id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment16id__idx ON collection.heroes USING btree (equipment16id);


--
-- TOC entry 4871 (class 1259 OID 52564)
-- Name: heroes__equipment17id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment17id__idx ON collection.heroes USING btree (equipment17id);


--
-- TOC entry 4872 (class 1259 OID 52565)
-- Name: heroes__equipment18id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment18id__idx ON collection.heroes USING btree (equipment18id);


--
-- TOC entry 4873 (class 1259 OID 52566)
-- Name: heroes__equipment19id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment19id__idx ON collection.heroes USING btree (equipment19id);


--
-- TOC entry 4874 (class 1259 OID 52567)
-- Name: heroes__equipment1id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment1id__idx ON collection.heroes USING btree (equipment1id);


--
-- TOC entry 4875 (class 1259 OID 52568)
-- Name: heroes__equipment20id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment20id__idx ON collection.heroes USING btree (equipment20id);


--
-- TOC entry 4876 (class 1259 OID 52569)
-- Name: heroes__equipment21id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment21id__idx ON collection.heroes USING btree (equipment21id);


--
-- TOC entry 4877 (class 1259 OID 52570)
-- Name: heroes__equipment22id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment22id__idx ON collection.heroes USING btree (equipment22id);


--
-- TOC entry 4878 (class 1259 OID 52571)
-- Name: heroes__equipment23id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment23id__idx ON collection.heroes USING btree (equipment23id);


--
-- TOC entry 4879 (class 1259 OID 52572)
-- Name: heroes__equipment24id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment24id__idx ON collection.heroes USING btree (equipment24id);


--
-- TOC entry 4880 (class 1259 OID 52573)
-- Name: heroes__equipment2id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment2id__idx ON collection.heroes USING btree (equipment2id);


--
-- TOC entry 4881 (class 1259 OID 52574)
-- Name: heroes__equipment3id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment3id__idx ON collection.heroes USING btree (equipment3id);


--
-- TOC entry 4882 (class 1259 OID 52575)
-- Name: heroes__equipment4id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment4id__idx ON collection.heroes USING btree (equipment4id);


--
-- TOC entry 4883 (class 1259 OID 52576)
-- Name: heroes__equipment5id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment5id__idx ON collection.heroes USING btree (equipment5id);


--
-- TOC entry 4884 (class 1259 OID 52577)
-- Name: heroes__equipment6id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment6id__idx ON collection.heroes USING btree (equipment6id);


--
-- TOC entry 4885 (class 1259 OID 52578)
-- Name: heroes__equipment7id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment7id__idx ON collection.heroes USING btree (equipment7id);


--
-- TOC entry 4886 (class 1259 OID 52579)
-- Name: heroes__equipment8id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment8id__idx ON collection.heroes USING btree (equipment8id);


--
-- TOC entry 4887 (class 1259 OID 52580)
-- Name: heroes__equipment9id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__equipment9id__idx ON collection.heroes USING btree (equipment9id);


--
-- TOC entry 4890 (class 1259 OID 52581)
-- Name: heroes__user_id__idx; Type: INDEX; Schema: collection; Owner: -
--

CREATE INDEX heroes__user_id__idx ON collection.heroes USING btree (user_id);


--
-- TOC entry 4891 (class 1259 OID 52582)
-- Name: base_equipments__equipment_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__equipment_type_id__idx ON game_data.base_equipments USING btree (equipment_type_id);


--
-- TOC entry 4892 (class 1259 OID 52583)
-- Name: base_equipments__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_equipments__name__idx ON game_data.base_equipments USING btree (name);


--
-- TOC entry 4895 (class 1259 OID 52584)
-- Name: base_equipments__smithing_material_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX base_equipments__smithing_material_id__idx ON game_data.base_equipments USING btree (smithing_material_id);


--
-- TOC entry 4896 (class 1259 OID 52585)
-- Name: base_heroes__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX base_heroes__name__idx ON game_data.base_heroes USING btree (name);


--
-- TOC entry 4899 (class 1259 OID 52586)
-- Name: creature_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX creature_types__name__idx ON game_data.creature_types USING btree (name);


--
-- TOC entry 4902 (class 1259 OID 52587)
-- Name: damage_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX damage_types__name__idx ON game_data.damage_types USING btree (name);


--
-- TOC entry 4905 (class 1259 OID 52588)
-- Name: equipment_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX equipment_types__name__idx ON game_data.equipment_types USING btree (name);


--
-- TOC entry 4908 (class 1259 OID 52589)
-- Name: equipment_types__slot_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX equipment_types__slot_type_id__idx ON game_data.equipment_types USING btree (slot_type_id);


--
-- TOC entry 4909 (class 1259 OID 52590)
-- Name: material_damage_percents__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__damage_type_id__idx ON game_data.material_damage_percents USING btree (damage_type_id);


--
-- TOC entry 4912 (class 1259 OID 52591)
-- Name: material_damage_percents__smithing_materials_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX material_damage_percents__smithing_materials_id__idx ON game_data.material_damage_percents USING btree (smithing_materials_id);


--
-- TOC entry 4913 (class 1259 OID 52592)
-- Name: slot_types__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX slot_types__name__idx ON game_data.slot_types USING btree (name);


--
-- TOC entry 4916 (class 1259 OID 52593)
-- Name: smithing_materials__name__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE UNIQUE INDEX smithing_materials__name__idx ON game_data.smithing_materials USING btree (name);


--
-- TOC entry 4919 (class 1259 OID 52594)
-- Name: x_equipment_type_damage_type__damage_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_equipment_type_damage_type__damage_type_id__idx ON game_data.x_equipment_type_damage_type USING btree (damage_type_id);


--
-- TOC entry 4922 (class 1259 OID 52595)
-- Name: x_hero_creature_type__creature_type_id__idx; Type: INDEX; Schema: game_data; Owner: -
--

CREATE INDEX x_hero_creature_type__creature_type_id__idx ON game_data.x_hero_creature_type USING btree (creature_type_id);


--
-- TOC entry 4927 (class 1259 OID 52596)
-- Name: user_authorizations__user_device_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX user_authorizations__user_device_id__idx ON logs.user_authorizations USING btree (user_device_id);


--
-- TOC entry 4928 (class 1259 OID 52597)
-- Name: user_authorizations__user_id__idx; Type: INDEX; Schema: logs; Owner: -
--

CREATE INDEX user_authorizations__user_id__idx ON logs.user_authorizations USING btree (user_id);


--
-- TOC entry 4931 (class 1259 OID 52598)
-- Name: user_ban_reasons__name__idx; Type: INDEX; Schema: server; Owner: -
--

CREATE UNIQUE INDEX user_ban_reasons__name__idx ON server.user_ban_reasons USING btree (name);


--
-- TOC entry 4936 (class 1259 OID 52599)
-- Name: user_bans__user_ban_reason_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_ban_reason_id__idx ON users.user_bans USING btree (user_ban_reason_id);


--
-- TOC entry 4937 (class 1259 OID 52600)
-- Name: user_bans__user_id__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX user_bans__user_id__idx ON users.user_bans USING btree (user_id);


--
-- TOC entry 4940 (class 1259 OID 52601)
-- Name: users__email__idx; Type: INDEX; Schema: users; Owner: -
--

CREATE UNIQUE INDEX users__email__idx ON users.users USING btree (email);


--
-- TOC entry 4943 (class 2606 OID 52602)
-- Name: equipments equipments__base_equipment_id__base_equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__base_equipment_id__base_equipments__fkey FOREIGN KEY (base_equipment_id) REFERENCES game_data.base_equipments(id) ON DELETE CASCADE;


--
-- TOC entry 4944 (class 2606 OID 52607)
-- Name: equipments equipments__user_id__users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.equipments
    ADD CONSTRAINT equipments__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


--
-- TOC entry 4945 (class 2606 OID 52612)
-- Name: heroes heroes__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE CASCADE;


--
-- TOC entry 4946 (class 2606 OID 52617)
-- Name: heroes heroes__equipment10id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment10id__equipments__fkey FOREIGN KEY (equipment10id) REFERENCES collection.equipments(id);


--
-- TOC entry 4947 (class 2606 OID 52622)
-- Name: heroes heroes__equipment11id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment11id__equipments__fkey FOREIGN KEY (equipment11id) REFERENCES collection.equipments(id);


--
-- TOC entry 4948 (class 2606 OID 52627)
-- Name: heroes heroes__equipment12id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment12id__equipments__fkey FOREIGN KEY (equipment12id) REFERENCES collection.equipments(id);


--
-- TOC entry 4949 (class 2606 OID 52632)
-- Name: heroes heroes__equipment13id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment13id__equipments__fkey FOREIGN KEY (equipment13id) REFERENCES collection.equipments(id);


--
-- TOC entry 4950 (class 2606 OID 52637)
-- Name: heroes heroes__equipment14id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment14id__equipments__fkey FOREIGN KEY (equipment14id) REFERENCES collection.equipments(id);


--
-- TOC entry 4951 (class 2606 OID 52642)
-- Name: heroes heroes__equipment15id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment15id__equipments__fkey FOREIGN KEY (equipment15id) REFERENCES collection.equipments(id);


--
-- TOC entry 4952 (class 2606 OID 52647)
-- Name: heroes heroes__equipment16id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment16id__equipments__fkey FOREIGN KEY (equipment16id) REFERENCES collection.equipments(id);


--
-- TOC entry 4953 (class 2606 OID 52652)
-- Name: heroes heroes__equipment17id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment17id__equipments__fkey FOREIGN KEY (equipment17id) REFERENCES collection.equipments(id);


--
-- TOC entry 4954 (class 2606 OID 52657)
-- Name: heroes heroes__equipment18id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment18id__equipments__fkey FOREIGN KEY (equipment18id) REFERENCES collection.equipments(id);


--
-- TOC entry 4955 (class 2606 OID 52662)
-- Name: heroes heroes__equipment19id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment19id__equipments__fkey FOREIGN KEY (equipment19id) REFERENCES collection.equipments(id);


--
-- TOC entry 4956 (class 2606 OID 52667)
-- Name: heroes heroes__equipment1id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment1id__equipments__fkey FOREIGN KEY (equipment1id) REFERENCES collection.equipments(id);


--
-- TOC entry 4957 (class 2606 OID 52672)
-- Name: heroes heroes__equipment20id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment20id__equipments__fkey FOREIGN KEY (equipment20id) REFERENCES collection.equipments(id);


--
-- TOC entry 4958 (class 2606 OID 52677)
-- Name: heroes heroes__equipment21id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment21id__equipments__fkey FOREIGN KEY (equipment21id) REFERENCES collection.equipments(id);


--
-- TOC entry 4959 (class 2606 OID 52682)
-- Name: heroes heroes__equipment22id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment22id__equipments__fkey FOREIGN KEY (equipment22id) REFERENCES collection.equipments(id);


--
-- TOC entry 4960 (class 2606 OID 52687)
-- Name: heroes heroes__equipment23id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment23id__equipments__fkey FOREIGN KEY (equipment23id) REFERENCES collection.equipments(id);


--
-- TOC entry 4961 (class 2606 OID 52692)
-- Name: heroes heroes__equipment24id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment24id__equipments__fkey FOREIGN KEY (equipment24id) REFERENCES collection.equipments(id);


--
-- TOC entry 4962 (class 2606 OID 52697)
-- Name: heroes heroes__equipment2id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment2id__equipments__fkey FOREIGN KEY (equipment2id) REFERENCES collection.equipments(id);


--
-- TOC entry 4963 (class 2606 OID 52702)
-- Name: heroes heroes__equipment3id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment3id__equipments__fkey FOREIGN KEY (equipment3id) REFERENCES collection.equipments(id);


--
-- TOC entry 4964 (class 2606 OID 52707)
-- Name: heroes heroes__equipment4id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment4id__equipments__fkey FOREIGN KEY (equipment4id) REFERENCES collection.equipments(id);


--
-- TOC entry 4965 (class 2606 OID 52712)
-- Name: heroes heroes__equipment5id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment5id__equipments__fkey FOREIGN KEY (equipment5id) REFERENCES collection.equipments(id);


--
-- TOC entry 4966 (class 2606 OID 52717)
-- Name: heroes heroes__equipment6id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment6id__equipments__fkey FOREIGN KEY (equipment6id) REFERENCES collection.equipments(id);


--
-- TOC entry 4967 (class 2606 OID 52722)
-- Name: heroes heroes__equipment7id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment7id__equipments__fkey FOREIGN KEY (equipment7id) REFERENCES collection.equipments(id);


--
-- TOC entry 4968 (class 2606 OID 52727)
-- Name: heroes heroes__equipment8id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment8id__equipments__fkey FOREIGN KEY (equipment8id) REFERENCES collection.equipments(id);


--
-- TOC entry 4969 (class 2606 OID 52732)
-- Name: heroes heroes__equipment9id__equipments__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__equipment9id__equipments__fkey FOREIGN KEY (equipment9id) REFERENCES collection.equipments(id);


--
-- TOC entry 4970 (class 2606 OID 52737)
-- Name: heroes heroes__user_id__users__fkey; Type: FK CONSTRAINT; Schema: collection; Owner: -
--

ALTER TABLE ONLY collection.heroes
    ADD CONSTRAINT heroes__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


--
-- TOC entry 4971 (class 2606 OID 52742)
-- Name: base_equipments base_equipments__equipment_type_id__equipment_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__equipment_type_id__equipment_types__fkey FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE CASCADE;


--
-- TOC entry 4972 (class 2606 OID 52747)
-- Name: base_equipments base_equipments__smithing_material_id__smithing_materials__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.base_equipments
    ADD CONSTRAINT base_equipments__smithing_material_id__smithing_materials__fkey FOREIGN KEY (smithing_material_id) REFERENCES game_data.smithing_materials(id);


--
-- TOC entry 4973 (class 2606 OID 52752)
-- Name: equipment_types equipment_types__slot_type_id__slot_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.equipment_types
    ADD CONSTRAINT equipment_types__slot_type_id__slot_types__fkey FOREIGN KEY (slot_type_id) REFERENCES game_data.slot_types(id) ON DELETE CASCADE;


--
-- TOC entry 4974 (class 2606 OID 52757)
-- Name: material_damage_percents material_damage_percents__damage_type_id__damage_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__damage_type_id__damage_types__fkey FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE CASCADE;


--
-- TOC entry 4975 (class 2606 OID 52762)
-- Name: material_damage_percents material_damage_percents__smithing_materials_id__smithing_mater; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.material_damage_percents
    ADD CONSTRAINT material_damage_percents__smithing_materials_id__smithing_mater FOREIGN KEY (smithing_materials_id) REFERENCES game_data.smithing_materials(id) ON DELETE CASCADE;


--
-- TOC entry 4976 (class 2606 OID 52767)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__damage_type_id__damage_types__fke; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__damage_type_id__damage_types__fke FOREIGN KEY (damage_type_id) REFERENCES game_data.damage_types(id) ON DELETE CASCADE;


--
-- TOC entry 4977 (class 2606 OID 52772)
-- Name: x_equipment_type_damage_type x_equipment_type_damage_type__equipment_type_id__equipment_type; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_equipment_type_damage_type
    ADD CONSTRAINT x_equipment_type_damage_type__equipment_type_id__equipment_type FOREIGN KEY (equipment_type_id) REFERENCES game_data.equipment_types(id) ON DELETE CASCADE;


--
-- TOC entry 4978 (class 2606 OID 52777)
-- Name: x_hero_creature_type x_hero_creature_type__base_hero_id__base_heroes__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__base_hero_id__base_heroes__fkey FOREIGN KEY (base_hero_id) REFERENCES game_data.base_heroes(id) ON DELETE CASCADE;


--
-- TOC entry 4979 (class 2606 OID 52782)
-- Name: x_hero_creature_type x_hero_creature_type__creature_type_id__creature_types__fkey; Type: FK CONSTRAINT; Schema: game_data; Owner: -
--

ALTER TABLE ONLY game_data.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type__creature_type_id__creature_types__fkey FOREIGN KEY (creature_type_id) REFERENCES game_data.creature_types(id) ON DELETE CASCADE;


--
-- TOC entry 4980 (class 2606 OID 52787)
-- Name: user_authorizations user_authorizations__user_device_id__user_devices__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__user_device_id__user_devices__fkey FOREIGN KEY (user_device_id) REFERENCES users.user_devices(id);


--
-- TOC entry 4981 (class 2606 OID 52792)
-- Name: user_authorizations user_authorizations__user_id__users__fkey; Type: FK CONSTRAINT; Schema: logs; Owner: -
--

ALTER TABLE ONLY logs.user_authorizations
    ADD CONSTRAINT user_authorizations__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id);


--
-- TOC entry 4982 (class 2606 OID 52797)
-- Name: user_bans user_bans__user_ban_reason_id__user_ban_reasons__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_ban_reason_id__user_ban_reasons__fkey FOREIGN KEY (user_ban_reason_id) REFERENCES server.user_ban_reasons(id) ON DELETE CASCADE;


--
-- TOC entry 4983 (class 2606 OID 52802)
-- Name: user_bans user_bans__user_id__users__fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.user_bans
    ADD CONSTRAINT user_bans__user_id__users__fkey FOREIGN KEY (user_id) REFERENCES users.users(id) ON DELETE CASCADE;


-- Completed on 2025-12-29 16:31:05

--
-- PostgreSQL database dump complete
--

\unrestrict Ssf2FGDrFncuPdssYvUbDRJ8FVmBr8E0AEo0o87RdcRzhL3KBKMvBkICyBQSfvU

