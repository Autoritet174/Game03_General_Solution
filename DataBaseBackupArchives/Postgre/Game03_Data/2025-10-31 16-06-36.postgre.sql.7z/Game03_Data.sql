--
-- PostgreSQL database dump
--

\restrict evSPznN4as3Rd6v4fT4FGs7GBfp73b0bxKvbcGFCygqmarvxyNkEREXzMFkhPN5

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-10-31 16:06:36

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY relations.hero_x_creature_type DROP CONSTRAINT IF EXISTS fk_hero_x_creature_type_hero_id_heroes;
ALTER TABLE IF EXISTS ONLY relations.hero_x_creature_type DROP CONSTRAINT IF EXISTS fk_hero_x_creature_type_creature_type_id_creature_types;
DROP TRIGGER IF EXISTS set_timestamp_heroes ON main.heroes;
CREATE OR REPLACE VIEW main.v_heroes AS
SELECT
    NULL::character varying(255) AS name,
    NULL::integer AS rarity,
    NULL::text AS creature_types;
DROP INDEX IF EXISTS relations.idx_hero_x_creature_type_hero_id;
DROP INDEX IF EXISTS relations.idx_hero_x_creature_type_creature_type_id;
DROP INDEX IF EXISTS main.idx_heroes_name;
DROP INDEX IF EXISTS main.idx_creature_types_name;
ALTER TABLE IF EXISTS ONLY relations.hero_x_creature_type DROP CONSTRAINT IF EXISTS pk_hero_x_creature_type;
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY main.heroes DROP CONSTRAINT IF EXISTS pk_heroes;
ALTER TABLE IF EXISTS ONLY main.creature_types DROP CONSTRAINT IF EXISTS pk_creature_types;
ALTER TABLE IF EXISTS main.heroes DROP CONSTRAINT IF EXISTS ck_hero_rarity_range;
DROP TABLE IF EXISTS relations.hero_x_creature_type;
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP VIEW IF EXISTS main.v_heroes;
DROP TABLE IF EXISTS main.heroes;
DROP TABLE IF EXISTS main.creature_types;
DROP FUNCTION IF EXISTS public.set_timestamp();
DROP PROCEDURE IF EXISTS main.add_hero_creature_type(IN p_hero_name character varying, IN p_creature_type_name character varying);
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP SCHEMA IF EXISTS relations;
DROP SCHEMA IF EXISTS main;
--
-- TOC entry 7 (class 2615 OID 16560)
-- Name: main; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA main;


--
-- TOC entry 8 (class 2615 OID 16561)
-- Name: relations; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA relations;


--
-- TOC entry 2 (class 3079 OID 16562)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4968 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 248 (class 1255 OID 16573)
-- Name: add_hero_creature_type(character varying, character varying); Type: PROCEDURE; Schema: main; Owner: -
--

CREATE PROCEDURE main.add_hero_creature_type(IN p_hero_name character varying, IN p_creature_type_name character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_hero_id UUID;
    v_creature_type_id UUID;
    v_link_exists BOOLEAN;
BEGIN
    -- Получаем ID героя
    SELECT id INTO v_hero_id
    FROM main.heroes
    WHERE name ILIKE p_hero_name;

    IF v_hero_id IS NULL THEN
        RAISE EXCEPTION 'Ошибка: Герой "%" не найден', p_hero_name;
    END IF;

    -- Получаем ID типа существа
    SELECT id INTO v_creature_type_id
    FROM main.creature_types
    WHERE name ILIKE p_creature_type_name;

    IF v_creature_type_id IS NULL THEN
        RAISE EXCEPTION 'Ошибка: Тип существа "%" не найден', p_creature_type_name;
    END IF;

    -- Проверяем существование связи
    SELECT EXISTS (
        SELECT 1
        FROM relations.hero_x_creature_type
        WHERE hero_id = v_hero_id
          AND creature_type_id = v_creature_type_id
    ) INTO v_link_exists;

    -- Добавляем связь если её нет
    IF NOT v_link_exists THEN
        INSERT INTO relations.hero_x_creature_type (hero_id, creature_type_id)
        VALUES (v_hero_id, v_creature_type_id);

        RAISE NOTICE 'Успех: Связь добавлена - герой "%" → тип "%"', p_hero_name, p_creature_type_name;
    ELSE
        RAISE NOTICE 'Информация: Связь уже существует - герой "%" → тип "%"', p_hero_name, p_creature_type_name;
    END IF;
END;
$$;


--
-- TOC entry 249 (class 1255 OID 16574)
-- Name: set_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.created_at := COALESCE(NEW.created_at, NOW());
        NEW.updated_at := COALESCE(NEW.updated_at, NOW());
    ELSIF TG_OP = 'UPDATE' THEN
        NEW.created_at := OLD.created_at;
        IF NEW.updated_at IS NULL OR NEW.updated_at = OLD.updated_at THEN
            NEW.updated_at := NOW();
        END IF;
    END IF;
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 16575)
-- Name: creature_types; Type: TABLE; Schema: main; Owner: -
--

CREATE TABLE main.creature_types (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 16585)
-- Name: heroes; Type: TABLE; Schema: main; Owner: -
--

CREATE TABLE main.heroes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL,
    _rarity integer DEFAULT 0 NOT NULL,
    base_health real DEFAULT 0 NOT NULL,
    base_attack real DEFAULT 0 NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 16601)
-- Name: v_heroes; Type: VIEW; Schema: main; Owner: -
--

CREATE VIEW main.v_heroes AS
SELECT
    NULL::character varying(255) AS name,
    NULL::integer AS rarity,
    NULL::text AS creature_types;


--
-- TOC entry 225 (class 1259 OID 16605)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 16610)
-- Name: hero_x_creature_type; Type: TABLE; Schema: relations; Owner: -
--

CREATE TABLE relations.hero_x_creature_type (
    hero_id uuid NOT NULL,
    creature_type_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 4959 (class 0 OID 16575)
-- Dependencies: 222
-- Data for Name: creature_types; Type: TABLE DATA; Schema: main; Owner: -
--

COPY main.creature_types (id, created_at, updated_at, name) FROM stdin;
cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-07-31 14:35:37.323451+08	2025-07-31 14:35:37.323451+08	Humanoid
40bcd67a-2fb7-4ddd-b194-f496464aea14	2025-07-31 14:35:56.034856+08	2025-07-31 14:35:56.034856+08	Wolf
52b2c4d8-977c-4dc3-967a-5bfc320a232a	2025-07-31 14:36:13.53242+08	2025-07-31 14:36:13.53242+08	Bear
c79ce293-b425-4b64-85a4-61108433b13f	2025-07-31 14:36:36.443478+08	2025-07-31 14:36:36.443478+08	Zombie
710bda30-8522-4a6f-bcc2-f06ab5d175ab	2025-07-31 14:36:36.443478+08	2025-07-31 14:36:36.443478+08	Vampire
550d1671-3f32-4041-a27a-217f157722b3	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Skeleton
df0e65a9-5dc6-44c2-ae40-ab76ec162aa1	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Goblin
d95ca0ae-6236-4dd6-a239-1c3d727e6230	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Orc
\.


--
-- TOC entry 4960 (class 0 OID 16585)
-- Dependencies: 223
-- Data for Name: heroes; Type: TABLE DATA; Schema: main; Owner: -
--

COPY main.heroes (id, created_at, updated_at, name, _rarity, base_health, base_attack) FROM stdin;
58e860c7-3819-4f5b-bdff-f36850411498	2025-07-27 11:45:19.652798+08	2025-09-11 12:36:15.706404+08	warrior	1	0	0
64ec68ff-ee4d-4204-a830-5f992f64fae9	2025-07-27 11:45:19.652798+08	2025-09-11 12:36:15.706404+08	novice huntress	1	0	0
c5c4aaa5-a4d3-4f4b-ac8c-26d77f6ea198	2025-07-27 11:45:19.652798+08	2025-09-11 12:36:15.706404+08	hammerman	1	0	0
eb93675d-d05f-43ad-857f-e47d43152e43	2025-07-27 11:45:19.652798+08	2025-09-11 12:36:15.706404+08	rogue	1	0	0
b582d3e8-d673-462f-80ad-f59b0deb1373	2025-07-27 11:45:19.652798+08	2025-09-11 14:22:48.931447+08	orc with axes	2	0	0
\.


--
-- TOC entry 4961 (class 0 OID 16605)
-- Dependencies: 225
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20250727024815_Init	9.0.7
20250727051015_HeroesNameOnlyUpperCase	9.0.7
20250731045552_Hero_CreatureType_ManyToMany_And_ToSnakeCase	9.0.7
20250731050535_реструктуризация	9.0.7
20250731065729_AddColumn_Rarity_InTable_Heroes	9.0.7
20250731072919_Column_Rarity_Range_1_5	9.0.7
20250731073454_Remove_HeroesNameOnlyUpperCase	9.0.7
20250731080250_fixName_CretureType	9.0.7
20250731081219_DeleteColumns_DeletedAt	9.0.7
20250731093258_UpdateTable_HeroCreatureType	9.0.7
20250801013642_CREATE_TABLE_hero_x_creature_type	9.0.7
20250801020922_CREATE_VIEW_v_heroes	9.0.7
20250914064646_NewBaseStat001	9.0.7
20250914073417_NewBaseStat002	9.0.7
\.


--
-- TOC entry 4962 (class 0 OID 16610)
-- Dependencies: 226
-- Data for Name: hero_x_creature_type; Type: TABLE DATA; Schema: relations; Owner: -
--

COPY relations.hero_x_creature_type (hero_id, creature_type_id, created_at) FROM stdin;
58e860c7-3819-4f5b-bdff-f36850411498	cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-08-01 09:43:24.936084+08
\.


--
-- TOC entry 4795 (class 2606 OID 16617)
-- Name: heroes ck_hero_rarity_range; Type: CHECK CONSTRAINT; Schema: main; Owner: -
--

ALTER TABLE main.heroes
    ADD CONSTRAINT ck_hero_rarity_range CHECK (((_rarity > 0) AND (_rarity < 7))) NOT VALID;


--
-- TOC entry 4798 (class 2606 OID 16619)
-- Name: creature_types pk_creature_types; Type: CONSTRAINT; Schema: main; Owner: -
--

ALTER TABLE ONLY main.creature_types
    ADD CONSTRAINT pk_creature_types PRIMARY KEY (id);


--
-- TOC entry 4801 (class 2606 OID 16621)
-- Name: heroes pk_heroes; Type: CONSTRAINT; Schema: main; Owner: -
--

ALTER TABLE ONLY main.heroes
    ADD CONSTRAINT pk_heroes PRIMARY KEY (id);


--
-- TOC entry 4803 (class 2606 OID 16623)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4807 (class 2606 OID 16625)
-- Name: hero_x_creature_type pk_hero_x_creature_type; Type: CONSTRAINT; Schema: relations; Owner: -
--

ALTER TABLE ONLY relations.hero_x_creature_type
    ADD CONSTRAINT pk_hero_x_creature_type PRIMARY KEY (hero_id, creature_type_id);


--
-- TOC entry 4796 (class 1259 OID 16626)
-- Name: idx_creature_types_name; Type: INDEX; Schema: main; Owner: -
--

CREATE UNIQUE INDEX idx_creature_types_name ON main.creature_types USING btree (name);


--
-- TOC entry 4799 (class 1259 OID 16627)
-- Name: idx_heroes_name; Type: INDEX; Schema: main; Owner: -
--

CREATE UNIQUE INDEX idx_heroes_name ON main.heroes USING btree (name);


--
-- TOC entry 4804 (class 1259 OID 16628)
-- Name: idx_hero_x_creature_type_creature_type_id; Type: INDEX; Schema: relations; Owner: -
--

CREATE INDEX idx_hero_x_creature_type_creature_type_id ON relations.hero_x_creature_type USING btree (creature_type_id);


--
-- TOC entry 4805 (class 1259 OID 16629)
-- Name: idx_hero_x_creature_type_hero_id; Type: INDEX; Schema: relations; Owner: -
--

CREATE INDEX idx_hero_x_creature_type_hero_id ON relations.hero_x_creature_type USING btree (hero_id);


--
-- TOC entry 4958 (class 2618 OID 16604)
-- Name: v_heroes _RETURN; Type: RULE; Schema: main; Owner: -
--

CREATE OR REPLACE VIEW main.v_heroes AS
 SELECT hero.name,
    hero._rarity AS rarity,
    string_agg((ct.name)::text, ', '::text) AS creature_types
   FROM ((main.heroes hero
     LEFT JOIN relations.hero_x_creature_type hct ON ((hero.id = hct.hero_id)))
     LEFT JOIN main.creature_types ct ON ((hct.creature_type_id = ct.id)))
  GROUP BY hero.id;


--
-- TOC entry 4810 (class 2620 OID 16631)
-- Name: heroes set_timestamp_heroes; Type: TRIGGER; Schema: main; Owner: -
--

CREATE TRIGGER set_timestamp_heroes BEFORE INSERT OR UPDATE ON main.heroes FOR EACH ROW EXECUTE FUNCTION public.set_timestamp();


--
-- TOC entry 4808 (class 2606 OID 16632)
-- Name: hero_x_creature_type fk_hero_x_creature_type_creature_type_id_creature_types; Type: FK CONSTRAINT; Schema: relations; Owner: -
--

ALTER TABLE ONLY relations.hero_x_creature_type
    ADD CONSTRAINT fk_hero_x_creature_type_creature_type_id_creature_types FOREIGN KEY (creature_type_id) REFERENCES main.creature_types(id) ON DELETE CASCADE;


--
-- TOC entry 4809 (class 2606 OID 16637)
-- Name: hero_x_creature_type fk_hero_x_creature_type_hero_id_heroes; Type: FK CONSTRAINT; Schema: relations; Owner: -
--

ALTER TABLE ONLY relations.hero_x_creature_type
    ADD CONSTRAINT fk_hero_x_creature_type_hero_id_heroes FOREIGN KEY (hero_id) REFERENCES main.heroes(id) ON DELETE CASCADE;


-- Completed on 2025-10-31 16:06:36

--
-- PostgreSQL database dump complete
--

\unrestrict evSPznN4as3Rd6v4fT4FGs7GBfp73b0bxKvbcGFCygqmarvxyNkEREXzMFkhPN5

