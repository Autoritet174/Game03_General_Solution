--
-- PostgreSQL database dump
--

\restrict W1gxav0PnWFKSpT2uG3sxDhiVUmrUrA4QZqiRBugwtC1X7iBCqWn9BdZt7JiIQz

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-12-10 23:09:45

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY xcross.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type_hero_id_heroes_fkey;
ALTER TABLE IF EXISTS ONLY xcross.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type_creature_type_id_creature_types_fkey;
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_WeaponType_DamageType" DROP CONSTRAINT IF EXISTS "X_WeaponType_DamageType_weapon_type_id_weapon_types_fkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_WeaponType_DamageType" DROP CONSTRAINT IF EXISTS "X_WeaponType_DamageType_damage_type_id_damage_types_fkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType_hero_id_heroes_fkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType_creature_type_id_creature_types_fkey";
ALTER TABLE IF EXISTS ONLY _equipment."Weapons" DROP CONSTRAINT IF EXISTS "Weapons_weapon_type_id_weapon_types_fkey";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercent" DROP CONSTRAINT IF EXISTS "MaterialDamagePercent_smithing_materials_id_smithing_materials_";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercent" DROP CONSTRAINT IF EXISTS "MaterialDamagePercent_damage_type_id_damage_types_fkey";
DROP TRIGGER IF EXISTS set_timestamps_trigger ON _main.heroes;
DROP TRIGGER IF EXISTS set_timestamps_trigger ON _main.creature_types;
CREATE OR REPLACE VIEW _main.v_heroes_with_creature_types AS
SELECT
    NULL::character varying(255) AS name,
    NULL::integer AS rarity,
    NULL::text AS creature_types;
DROP INDEX IF EXISTS xcross.x_hero_creature_type_hero_id_idx;
DROP INDEX IF EXISTS xcross.x_hero_creature_type_creature_type_id_idx;
DROP INDEX IF EXISTS "x_Cross"."X_WeaponType_DamageType_WeaponTypeId_idx";
DROP INDEX IF EXISTS "x_Cross"."X_WeaponType_DamageType_DamageTypeId_idx";
DROP INDEX IF EXISTS "x_Cross"."X_Hero_CreatureType_HeroId_idx";
DROP INDEX IF EXISTS "x_Cross"."X_Hero_CreatureType_CreatureTypeId_idx";
DROP INDEX IF EXISTS _main.heroes_name_idx;
DROP INDEX IF EXISTS _main.creature_types_name_idx;
DROP INDEX IF EXISTS _heroes."Heroes_name_idx";
DROP INDEX IF EXISTS _equipment."Weapons_weapon_type_id_idx";
DROP INDEX IF EXISTS _equipment."Weapons_name_idx";
DROP INDEX IF EXISTS __lists."WeaponTypes_name_idx";
DROP INDEX IF EXISTS __lists."SmithingMaterials_name_idx";
DROP INDEX IF EXISTS __lists."MaterialDamagePercent_smithing_materials_id_idx";
DROP INDEX IF EXISTS __lists."MaterialDamagePercent_damage_type_id_idx";
DROP INDEX IF EXISTS __lists."DamageTypes_name_idx";
DROP INDEX IF EXISTS __lists."CreatureTypes_name_idx";
ALTER TABLE IF EXISTS ONLY xcross.x_hero_creature_type DROP CONSTRAINT IF EXISTS x_hero_creature_type_pkey;
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_WeaponType_DamageType" DROP CONSTRAINT IF EXISTS "X_WeaponType_DamageType_pkey";
ALTER TABLE IF EXISTS ONLY "x_Cross"."X_Hero_CreatureType" DROP CONSTRAINT IF EXISTS "X_Hero_CreatureType_pkey";
ALTER TABLE IF EXISTS ONLY public."__EFMigrationsHistory" DROP CONSTRAINT IF EXISTS "PK___EFMigrationsHistory";
ALTER TABLE IF EXISTS ONLY _main.heroes DROP CONSTRAINT IF EXISTS heroes_pkey;
ALTER TABLE IF EXISTS ONLY _main.creature_types DROP CONSTRAINT IF EXISTS creature_types_pkey;
ALTER TABLE IF EXISTS ONLY _heroes."Heroes" DROP CONSTRAINT IF EXISTS "Heroes_pkey";
ALTER TABLE IF EXISTS ONLY _equipment."Weapons" DROP CONSTRAINT IF EXISTS "Weapons_pkey";
ALTER TABLE IF EXISTS ONLY __lists."WeaponTypes" DROP CONSTRAINT IF EXISTS "WeaponTypes_pkey";
ALTER TABLE IF EXISTS ONLY __lists."SmithingMaterials" DROP CONSTRAINT IF EXISTS "SmithingMaterials_pkey";
ALTER TABLE IF EXISTS ONLY __lists."MaterialDamagePercent" DROP CONSTRAINT IF EXISTS "MaterialDamagePercent_pkey";
ALTER TABLE IF EXISTS ONLY __lists."DamageTypes" DROP CONSTRAINT IF EXISTS "DamageTypes_pkey";
ALTER TABLE IF EXISTS ONLY __lists."CreatureTypes" DROP CONSTRAINT IF EXISTS "CreatureTypes_pkey";
DROP TABLE IF EXISTS xcross.x_hero_creature_type;
DROP TABLE IF EXISTS "x_Cross"."X_Hero_CreatureType";
DROP TABLE IF EXISTS public."__EFMigrationsHistory";
DROP VIEW IF EXISTS _main.v_heroes_with_creature_types;
DROP TABLE IF EXISTS _main.heroes;
DROP TABLE IF EXISTS _main.creature_types;
DROP TABLE IF EXISTS _heroes."Heroes";
DROP TABLE IF EXISTS _equipment."Weapons";
DROP VIEW IF EXISTS __lists."v_WeaponTypes";
DROP TABLE IF EXISTS "x_Cross"."X_WeaponType_DamageType";
DROP TABLE IF EXISTS __lists."WeaponTypes";
DROP TABLE IF EXISTS __lists."SmithingMaterials";
DROP TABLE IF EXISTS __lists."MaterialDamagePercent";
DROP TABLE IF EXISTS __lists."DamageTypes";
DROP TABLE IF EXISTS __lists."CreatureTypes";
DROP FUNCTION IF EXISTS public.set_timestamp();
DROP PROCEDURE IF EXISTS _main.add_hero_creature_type(IN p_hero_name text, IN p_creature_type_name text);
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP SCHEMA IF EXISTS xcross;
DROP SCHEMA IF EXISTS "x_Cross";
DROP SCHEMA IF EXISTS _main;
DROP SCHEMA IF EXISTS _heroes;
DROP SCHEMA IF EXISTS _equipment;
DROP SCHEMA IF EXISTS __lists;
--
-- TOC entry 9 (class 2615 OID 18965)
-- Name: __lists; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA __lists;


--
-- TOC entry 10 (class 2615 OID 18966)
-- Name: _equipment; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _equipment;


--
-- TOC entry 11 (class 2615 OID 18967)
-- Name: _heroes; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _heroes;


--
-- TOC entry 7 (class 2615 OID 18647)
-- Name: _main; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA _main;


--
-- TOC entry 12 (class 2615 OID 18968)
-- Name: x_Cross; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "x_Cross";


--
-- TOC entry 8 (class 2615 OID 18648)
-- Name: xcross; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA xcross;


--
-- TOC entry 2 (class 3079 OID 18649)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 5130 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 269 (class 1255 OID 18660)
-- Name: add_hero_creature_type(text, text); Type: PROCEDURE; Schema: _main; Owner: -
--

CREATE PROCEDURE _main.add_hero_creature_type(IN p_hero_name text, IN p_creature_type_name text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_hero_id         uuid;
    v_creature_type_id uuid;
    v_link_exists     boolean;
BEGIN
    -- Получаем ID героя
    SELECT id INTO v_hero_id
    FROM _main.heroes
    WHERE name ILIKE p_hero_name
    LIMIT 1;

    IF v_hero_id IS NULL THEN
        RAISE EXCEPTION 'Ошибка: Герой "%" не найден', p_hero_name;
    END IF;

    -- Получаем ID типа существа
    SELECT id INTO v_creature_type_id
    FROM _main.creature_types
    WHERE name ILIKE p_creature_type_name
    LIMIT 1;

    IF v_creature_type_id IS NULL THEN
        RAISE EXCEPTION 'Ошибка: Тип существа "%" не найден', p_creature_type_name;
    END IF;

    -- Проверяем существование связи
    SELECT EXISTS (
        SELECT 1
        FROM xcross.x_hero_creature_type
        WHERE hero_id = v_hero_id
          AND creature_type_id = v_creature_type_id
    ) INTO v_link_exists;

    -- Добавляем связь если её нет
    IF NOT v_link_exists THEN
        INSERT INTO xcross.x_hero_creature_type (hero_id, creature_type_id)
        VALUES (v_hero_id, v_creature_type_id);

        RAISE NOTICE 'Успех: Связь добавлена - герой "%" → тип "%"', p_hero_name, p_creature_type_name;
    ELSE
        RAISE NOTICE 'Информация: Связь уже существует - герой "%" → тип "%"', p_hero_name, p_creature_type_name;
    END IF;
END;
$$;


--
-- TOC entry 270 (class 1255 OID 18661)
-- Name: set_timestamp(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.set_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.created_at := COALESCE(NEW.created_at, NOW());
        NEW.updated_at := COALESCE(NEW.updated_at, NOW());
    ELSIF TG_OP = 'UPDATE' THEN
        NEW.created_at := OLD.created_at;
        IF NEW.updated_at IS NULL OR NEW.updated_at = OLD.updated_at THEN
            NEW.updated_at := NOW();
        END IF;
    END IF;
    RETURN NEW;
END;$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 230 (class 1259 OID 18969)
-- Name: CreatureTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."CreatureTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 18974)
-- Name: CreatureTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."CreatureTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."CreatureTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 18975)
-- Name: DamageTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."DamageTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255),
    "DevHintRu" text
);


--
-- TOC entry 233 (class 1259 OID 18982)
-- Name: DamageTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."DamageTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."DamageTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 247 (class 1259 OID 19239)
-- Name: MaterialDamagePercent; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."MaterialDamagePercent" (
    id integer NOT NULL,
    smithing_materials_id integer NOT NULL,
    damage_type_id integer NOT NULL,
    percent integer NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 19238)
-- Name: MaterialDamagePercent_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."MaterialDamagePercent" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."MaterialDamagePercent_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 245 (class 1259 OID 19112)
-- Name: SmithingMaterials; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."SmithingMaterials" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255)
);


--
-- TOC entry 244 (class 1259 OID 19111)
-- Name: SmithingMaterials_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."SmithingMaterials" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."SmithingMaterials_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 18983)
-- Name: WeaponTypes; Type: TABLE; Schema: __lists; Owner: -
--

CREATE TABLE __lists."WeaponTypes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255) DEFAULT ''::character varying NOT NULL,
    mass integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 18988)
-- Name: WeaponTypes_id_seq; Type: SEQUENCE; Schema: __lists; Owner: -
--

ALTER TABLE __lists."WeaponTypes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME __lists."WeaponTypes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 19024)
-- Name: X_WeaponType_DamageType; Type: TABLE; Schema: x_Cross; Owner: -
--

CREATE TABLE "x_Cross"."X_WeaponType_DamageType" (
    "WeaponTypeId" integer NOT NULL,
    "DamageTypeId" integer NOT NULL,
    "DamageCoef" integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 19104)
-- Name: v_WeaponTypes; Type: VIEW; Schema: __lists; Owner: -
--

CREATE VIEW __lists."v_WeaponTypes" AS
 SELECT id,
    name,
    name_ru,
    ( SELECT string_agg(((((d.name_ru)::text || '('::text) || wd."DamageCoef") || ')'::text), ', '::text ORDER BY wd."DamageCoef" DESC, wd."DamageTypeId") AS string_agg
           FROM ("x_Cross"."X_WeaponType_DamageType" wd
             LEFT JOIN __lists."DamageTypes" d ON ((d.id = wd."DamageTypeId")))
          WHERE (wd."WeaponTypeId" = w.id)) AS damagetypes
   FROM __lists."WeaponTypes" w
  ORDER BY id;


--
-- TOC entry 236 (class 1259 OID 18989)
-- Name: Weapons; Type: TABLE; Schema: _equipment; Owner: -
--

CREATE TABLE _equipment."Weapons" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean DEFAULT false NOT NULL,
    damage character varying(255) NOT NULL,
    weapon_type_id integer NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 19001)
-- Name: Weapons_id_seq; Type: SEQUENCE; Schema: _equipment; Owner: -
--

ALTER TABLE _equipment."Weapons" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME _equipment."Weapons_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 19002)
-- Name: Heroes; Type: TABLE; Schema: _heroes; Owner: -
--

CREATE TABLE _heroes."Heroes" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer NOT NULL,
    is_unique boolean NOT NULL,
    health character varying(255) NOT NULL,
    damage character varying(255) NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 19013)
-- Name: Heroes_id_seq; Type: SEQUENCE; Schema: _heroes; Owner: -
--

ALTER TABLE _heroes."Heroes" ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME _heroes."Heroes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 226 (class 1259 OID 18662)
-- Name: creature_types; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.creature_types (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 18672)
-- Name: heroes; Type: TABLE; Schema: _main; Owner: -
--

CREATE TABLE _main.heroes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(255) NOT NULL,
    rarity integer CONSTRAINT heroes__rarity_not_null NOT NULL,
    base_health real NOT NULL,
    base_attack real NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 18685)
-- Name: v_heroes_with_creature_types; Type: VIEW; Schema: _main; Owner: -
--

CREATE VIEW _main.v_heroes_with_creature_types AS
SELECT
    NULL::character varying(255) AS name,
    NULL::integer AS rarity,
    NULL::text AS creature_types;


--
-- TOC entry 240 (class 1259 OID 19014)
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 19019)
-- Name: X_Hero_CreatureType; Type: TABLE; Schema: x_Cross; Owner: -
--

CREATE TABLE "x_Cross"."X_Hero_CreatureType" (
    "HeroId" integer NOT NULL,
    "CreatureTypeId" integer NOT NULL
);


--
-- TOC entry 229 (class 1259 OID 18694)
-- Name: x_hero_creature_type; Type: TABLE; Schema: xcross; Owner: -
--

CREATE TABLE xcross.x_hero_creature_type (
    hero_id uuid NOT NULL,
    creature_type_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 5108 (class 0 OID 18969)
-- Dependencies: 230
-- Data for Name: CreatureTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."CreatureTypes" (id, name) FROM stdin;
1	Humanoid
2	Orc
3	Goblin
4	Zombie
5	Vampire
6	Skeleton
7	Bear
8	Wolf
\.


--
-- TOC entry 5110 (class 0 OID 18975)
-- Dependencies: 232
-- Data for Name: DamageTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."DamageTypes" (id, name, name_ru, "DevHintRu") FROM stdin;
1	Piercing	Колющий	Копьё Пика Рапира Шпага Трезубец Лук Арбалет Дротики Меч(колющий)
2	Blunt	Дробящий	Булава Палица Боевой молот Моргенштерн 
3	Cutting	Режущий	Сабля Ятаган Катана Скимитар Боевой веер Коса Бумеранг Чакрам Меч(режущий)
4	Chopping	Рубящий	Топор Секира Бердыш Алебарда
5	Force	Силовой	"Проявления: Волшебные стрелы (Magic Missile), телекинетические удары, невидимые клинки силы.\r\n\r\nУязвимы: Призраки, астральные существа (иногда).\r\n\r\nУстойчивы/Иммунны: Практически нет, это магическая энергия.\r\n\r\nОсобенность: Редко имеет сопротивление. Наносит чистый, не-элементальный магический урон. Часто не может быть отражен или заблокирован обычным щитом, только магическими средствами. Может отбрасывать цели."
6	Fire	Огненный	"Проявления: Огненные шары, пламя дракона, горение.\r\n\r\nУязвимы: Духи льда, растения, нежить (часто), насекомые, ледяные элементали.\r\n\r\nУстойчивы/Иммунны: Демоны, огненные элементали, лавовые големы, красные драконы.\r\n\r\nОсобенность: Часто накладывает эффект горения (DoT), может разрушать ледяные преграды, поджигать местность. Противоположен Ледяному.\r\n\r\n"
7	Frost	Ледяной	"Проявления: Ледяные стрелы, стужа, обморожение, ледяная тюрьма.\r\n\r\nУязвимы: Огненные существа, драконы, рептилии, лавовые големы.\r\n\r\nУстойчивы/Иммунны: Ледяные элементали, белые драконы, арктические существа.\r\n\r\nОсобенность: Часто накладывает эффект замедления или оковы (обездвиживания). Может создавать ледяной наст на воде. Противоположен Огненному."
8	Electric	Электрический	"Проявления: Молнии, электрические разряды, шок, громовые волны.\r\n\r\nУязвимы: Механизмы (роботы, големы), существа в металлической броне, водные/слизневые существа (проводят ток).\r\n\r\nУстойчивы/Иммунны: Воздушные элементали, существа из изоляционных материалов (камень, дерево — не всегда).\r\n\r\nОсобенность: Высокий шанс наложить эффект стана (паралич, оглушение). Урон может цепляться на несколько ближайших целей. Часто игнорирует часть брони."
9	Poison	Ядовитый	"Проявления: Ядовитые облака, укусы, отравленные клинки, токсичные выбросы.\r\n\r\nУязвимы: Органические, живые существа (люди, звери, растения).\r\n\r\nУстойчивы/Иммунны: Нежить, конструкты, каменные/земляные элементали, ядовитые сами по себе монстры (гигантские пауки, скорпионы).\r\n\r\nОсобенность:* Практически всегда наносит урон по времени (Damage over Time - DoT). Может накладывать ослабляющие эффекты (снижение характеристик, замедление регенерации)."
10	Sonic	Звуковой	"Проявления: Разрушительный рёв, ударная звуковая волна, резонанс, разрыв барабанных перепонок, крик банши, звуковые пушки.\r\n\r\nУязвимы: Стеклянные/хрустальные существа, конструкции с хрупкими элементами, существа с тонким слухом (летучие мыши, эльфы). Механизмы (может нарушить работу).\r\n\r\nУстойчивы/Иммунны: Глухие существа, каменные/земляные големы (плохо проводят звук), существа из вакуума/космоса, призраки (иногда).\r\n\r\nОсобенность: Часто игнорирует физическую броню (звук проходит сквозь пластины) и магическую защиту. Имеет высокий шанс наложить дебаффы: оглушение, дезориентация, снижение точности, развеивание иллюзий/невидимости. Может активировать хрупкие механизмы или разрушать звуковые барьеры. В тихих локациях (подземелья) может привлекать других врагов."
11	Light	Световой	"Проявления: Божественный гнев, очищающий свет, заклинания жрецов и паладинов, освящённое оружие.\r\n\r\nУязвимы: Нежить (зомби, скелеты, призраки, вампиры), демоны/исчадия, существа Тьмы и Хаоса.\r\n\r\nУстойчивы/Иммунны: Ангелы, святые существа, некоторые нейтральные духи природы.\r\n\r\nОсобенность: Часто прерывает концентрацию магов, изгоняет/отпугивает нежить, наносит увеличенный/критический урон к уязвимым типам. Может накладывать ослепление."
12	Necrotic	Некротический	"Проявления: Энергия смерти, вампиризм (кража HP), проклятия, теневая магия.\r\n\r\nУязвимы: Живые существа (подрывает жизненную силу), святые существа (иногда).\r\n\r\nУстойчивы/Иммунны: Нежить (часто её лечит или не вредит), демоны Тени, существа Смерти.\r\n\r\nОсобенность: Может накладывать эффекты снижения максимального запаса здоровья, запрета на лечение (анти-хил), страха или ослабления. Противоположен Священному."
13	Telepathic	Телепатический	"Проявления: Взрыв разума, телепатическое копье, ментальные тиски, навязывание невыносимых мыслей, иллюзии, причиняющие реальную боль, атаки по сновидениям.\r\n\r\nУязвимы: Все разумные существа (люди, эльфы, орки, драконы). Особенно те, кто обладает высоким интеллектом, но слабой силой воли.\r\n\r\nУстойчивы/Иммунны: Конструкты, големы, неразумная нежить (зомби, скелеты), животные/звери с примитивным интеллектом, берсеркеры/дикари (их разум хаотичен и защищен яростью), роботы, некоторые демоны пустоты.\r\n\r\nОсобенность: Почти всегда игнорирует физическую броню и магическую защиту (зависит от сопротивления ментальным эффектам/силе воли). Реже наносит чистый урон, чаще накладывает мощнейшие контроль-эффекты: страх, очарование, сон, паралич, безумие, взятие под контроль. Может снижать характеристики (Интеллект, Мудрость, Харизму). Не оставляет физических ран."
14	Acid	Кислотный	"Проявления: Плевки кислотой, едкие пары, растворяющие жидкости.\r\n\r\nУязвимы: Существа с хитиновым/металлическим панцирем, механизмы, бронированные цели.\r\n\r\nУстойчивы/Иммунны: Слизни, кислотные элементали, аморфные существа.\r\n\r\nОсобенность: Часто снижает защиту (броню) цели на время или игнорирует её часть. Может наносить урон предметам/снаряжению."
15	Chaos	Хаотический	"Проявления: Нестабильная энергия хаоса, смесь стихий, дикая магия.\r\n\r\nУязвимы: Существа Закона и Порядка (дэвы, механикусы).\r\n\r\nУстойчивы/Иммунны: Демоны Бездны, хаотические элементали.\r\n\r\nОсобенность: Часто игнорирует фиксированный процент всех сопротивлений (например, 50% урона проходит всегда) или имеет шанс наложить случайный негативный эффект. Непредсказуем."
16	Pure	Чистый	"Проявления: Божественная кара, нарушение законов реальности, урон из самого ""кода"" вселенной, абсолютное расщепление материи, хирургически точное уничтожение без эффектов.\r\n\r\nУязвимы: ВСЕ. По определению.\r\n\r\nУстойчивы/Иммунны: НИКТО. По определению. (Хотя могут быть исключения в виде уникальных божественных артефактов или "сюжетная неуязвимость").\r\n\r\nОсобенность: Игнорирует ВСЕ виды защиты, сопротивления, иммунитеты, поглощения и снижения урона. Наносит ровно то количество урона, которое указано. Это последний аргумент в игровом балансе. Крайне редок, обычно доступен через:\r\n\r\nУльтимативные способности с долгим откатом.\r\n\r\nЛегендарные/божественные артефакты.\r\n\r\nСпособности, срабатывающие при выполнении сложных условий (например, при HP противника ниже 5%).\r\n\r\nКак механика для определенных типов врагов (например, урон от падения в бездну или ""неизбежная"" атака босса)."
\.


--
-- TOC entry 5124 (class 0 OID 19239)
-- Dependencies: 247
-- Data for Name: MaterialDamagePercent; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."MaterialDamagePercent" (id, smithing_materials_id, damage_type_id, percent) FROM stdin;
1	2	1	10
2	2	2	10
3	2	3	10
4	2	4	10
5	3	1	50
6	4	2	50
7	5	3	50
8	6	4	50
9	7	1	40
10	7	2	40
11	7	3	40
12	7	4	40
13	8	5	50
14	9	6	50
15	10	7	50
16	11	8	50
17	12	9	50
18	13	10	50
19	14	11	50
20	15	12	50
21	16	13	50
22	17	14	50
23	18	15	500
24	19	16	50
\.


--
-- TOC entry 5122 (class 0 OID 19112)
-- Dependencies: 245
-- Data for Name: SmithingMaterials; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."SmithingMaterials" (id, name, name_ru) FROM stdin;
1	Iron	Железо
2	Steel	Сталь
3	Penetron	Пенетрон
4	Brutalite	Бруталит
5	Ostenium	Остениум
6	Divisorium	Дивизориум
7	Ebonite	Эбонит
8	Volantir	Волантир
9	Pyronite	Пиронит
10	Cryonite	Крионит
11	Fulgurite	Фульгорит
12	Vermium	Вермиум
13	Vibranium	Вибраниум
14	Solarium	Солариум
15	Mortium	Мортиум
16	Somnir	Сомнир
17	Acidium	Ацидиум
18	Discord	Дискорд
19	Nullite	Нуллит
\.


--
-- TOC entry 5112 (class 0 OID 18983)
-- Dependencies: 234
-- Data for Name: WeaponTypes; Type: TABLE DATA; Schema: __lists; Owner: -
--

COPY __lists."WeaponTypes" (id, name, name_ru, mass) FROM stdin;
1	Sword	Меч	1600
2	Axe	Топор	2800
3	Halberd	Алебарда	4400
4	Berdysh	Бердыш	3800
5	Poleaxe	Секира	4000
6	Chakram	Чакрам	350
7	Shuriken	Сюрикен	180
8	Scythe	Коса	3200
9	War Fan	Боевой веер	800
10	Scimitar	Скимитар	1200
11	Katana	Катана	1100
12	Yataghan	Ятаган	1000
13	Sabre	Сабля	1100
14	Morning Star	Моргенштерн	5000
15	Warhammer	Боевой молот	6200
16	Mace	Булава	3000
17	Crossbow	Арбалет	2800
18	Bow	Лук	1000
19	Trident	Трезубец	3400
20	Rapier	Рапира	850
21	Pike	Пика	2800
22	Spear	Копьё	2200
23	Broadaxe	Широкий топор	5200
24	Dagger	Кинжал	400
\.


--
-- TOC entry 5114 (class 0 OID 18989)
-- Dependencies: 236
-- Data for Name: Weapons; Type: TABLE DATA; Schema: _equipment; Owner: -
--

COPY _equipment."Weapons" (id, name, rarity, is_unique, damage, weapon_type_id) FROM stdin;
\.


--
-- TOC entry 5116 (class 0 OID 19002)
-- Dependencies: 238
-- Data for Name: Heroes; Type: TABLE DATA; Schema: _heroes; Owner: -
--

COPY _heroes."Heroes" (id, name, rarity, is_unique, health, damage) FROM stdin;
1	Warrior	1	f	16d24_200	4d21_44
2	Huntress	1	f	10d28_145	5d21_55
3	Hammerman	1	f	11d39_220	3d25_39
4	Rogue	1	f	15d21_165	4d23_48
5	Battle orc	1	f	16d58_472	4d21_44
\.


--
-- TOC entry 5105 (class 0 OID 18662)
-- Dependencies: 226
-- Data for Name: creature_types; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.creature_types (id, created_at, updated_at, name) FROM stdin;
40bcd67a-2fb7-4ddd-b194-f496464aea14	2025-07-31 14:35:56.034856+08	2025-07-31 14:35:56.034856+08	Wolf
52b2c4d8-977c-4dc3-967a-5bfc320a232a	2025-07-31 14:36:13.53242+08	2025-07-31 14:36:13.53242+08	Bear
550d1671-3f32-4041-a27a-217f157722b3	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Skeleton
710bda30-8522-4a6f-bcc2-f06ab5d175ab	2025-07-31 14:36:36.443478+08	2025-07-31 14:36:36.443478+08	Vampire
c79ce293-b425-4b64-85a4-61108433b13f	2025-07-31 14:36:36.443478+08	2025-07-31 14:36:36.443478+08	Zombie
cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-07-31 14:35:37.323451+08	2025-07-31 14:35:37.323451+08	Humanoid
d95ca0ae-6236-4dd6-a239-1c3d727e6230	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Orc
df0e65a9-5dc6-44c2-ae40-ab76ec162aa1	2025-07-31 14:39:23.275849+08	2025-07-31 14:39:23.275849+08	Goblin
\.


--
-- TOC entry 5106 (class 0 OID 18672)
-- Dependencies: 227
-- Data for Name: heroes; Type: TABLE DATA; Schema: _main; Owner: -
--

COPY _main.heroes (id, created_at, updated_at, name, rarity, base_health, base_attack) FROM stdin;
58e860c7-3819-4f5b-bdff-f36850411498	2025-11-03 13:45:04.074396+08	2025-11-06 11:00:56.868871+08	warrior	1	100	10
64ec68ff-ee4d-4204-a830-5f992f64fae9	2025-11-03 13:45:04.074396+08	2025-11-06 11:00:56.868871+08	huntress	1	60	18
b582d3e8-d673-462f-80ad-f59b0deb1373	2025-11-03 13:45:04.074396+08	2025-11-06 11:17:06.136185+08	orc with axes	2	180	25
eb93675d-d05f-43ad-857f-e47d43152e43	2025-11-03 13:45:04.074396+08	2025-11-06 11:17:06.136185+08	rogue	1	70	21
c5c4aaa5-a4d3-4f4b-ac8c-26d77f6ea198	2025-11-03 13:45:04.074396+08	2025-11-06 11:19:53.052512+08	hammerman	1	110	16
\.


--
-- TOC entry 5118 (class 0 OID 19014)
-- Dependencies: 240
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20251205052813_Init	9.0.10
20251206063518_Fix2	10.0.0
20251206074050_Fix3	10.0.0
20251206175439_Fix4	10.0.0
20251210093206_SmithingMaterials	10.0.0
20251210113701_SmithingMaterials_Fix	10.0.0
20251210115042_SmithingMaterials_Fix2	10.0.0
20251210115307_SmithingMaterials_Fix3	10.0.0
20251210133152_SmithingMaterials_Fix4	10.0.0
20251210133802_SmithingMaterials_Fix5	10.0.0
\.


--
-- TOC entry 5119 (class 0 OID 19019)
-- Dependencies: 241
-- Data for Name: X_Hero_CreatureType; Type: TABLE DATA; Schema: x_Cross; Owner: -
--

COPY "x_Cross"."X_Hero_CreatureType" ("HeroId", "CreatureTypeId") FROM stdin;
\.


--
-- TOC entry 5120 (class 0 OID 19024)
-- Dependencies: 242
-- Data for Name: X_WeaponType_DamageType; Type: TABLE DATA; Schema: x_Cross; Owner: -
--

COPY "x_Cross"."X_WeaponType_DamageType" ("WeaponTypeId", "DamageTypeId", "DamageCoef") FROM stdin;
14	1	15
14	2	85
19	1	73
19	2	9
2	2	10
2	3	5
2	4	85
16	1	16
19	3	18
21	1	100
16	2	75
16	4	9
15	2	100
7	1	55
7	3	45
6	1	11
6	3	89
4	1	12
22	1	80
22	2	5
22	3	15
23	4	100
4	3	2
18	1	100
17	1	100
24	1	70
24	2	0
24	3	30
4	4	86
8	1	35
8	3	65
1	1	27
24	4	0
1	3	56
1	4	17
13	1	13
13	3	65
13	4	22
3	1	37
3	2	7
3	4	56
5	2	8
5	3	17
5	4	75
10	1	6
10	3	87
10	4	7
11	1	13
11	3	80
11	4	7
12	1	19
12	3	77
12	4	4
20	1	84
20	3	14
20	4	2
9	3	100
\.


--
-- TOC entry 5107 (class 0 OID 18694)
-- Dependencies: 229
-- Data for Name: x_hero_creature_type; Type: TABLE DATA; Schema: xcross; Owner: -
--

COPY xcross.x_hero_creature_type (hero_id, creature_type_id, created_at) FROM stdin;
58e860c7-3819-4f5b-bdff-f36850411498	cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-11-03 13:53:24.497434+08
b582d3e8-d673-462f-80ad-f59b0deb1373	cf46ed89-990b-4fc5-a694-ee724d3641cb	2025-11-03 13:54:28.640968+08
b582d3e8-d673-462f-80ad-f59b0deb1373	d95ca0ae-6236-4dd6-a239-1c3d727e6230	2025-11-03 13:55:27.10382+08
\.


--
-- TOC entry 5131 (class 0 OID 0)
-- Dependencies: 231
-- Name: CreatureTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."CreatureTypes_id_seq"', 9, false);


--
-- TOC entry 5132 (class 0 OID 0)
-- Dependencies: 233
-- Name: DamageTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."DamageTypes_id_seq"', 17, false);


--
-- TOC entry 5133 (class 0 OID 0)
-- Dependencies: 246
-- Name: MaterialDamagePercent_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."MaterialDamagePercent_id_seq"', 24, true);


--
-- TOC entry 5134 (class 0 OID 0)
-- Dependencies: 244
-- Name: SmithingMaterials_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."SmithingMaterials_id_seq"', 19, true);


--
-- TOC entry 5135 (class 0 OID 0)
-- Dependencies: 235
-- Name: WeaponTypes_id_seq; Type: SEQUENCE SET; Schema: __lists; Owner: -
--

SELECT pg_catalog.setval('__lists."WeaponTypes_id_seq"', 24, true);


--
-- TOC entry 5136 (class 0 OID 0)
-- Dependencies: 237
-- Name: Weapons_id_seq; Type: SEQUENCE SET; Schema: _equipment; Owner: -
--

SELECT pg_catalog.setval('_equipment."Weapons_id_seq"', 1, false);


--
-- TOC entry 5137 (class 0 OID 0)
-- Dependencies: 239
-- Name: Heroes_id_seq; Type: SEQUENCE SET; Schema: _heroes; Owner: -
--

SELECT pg_catalog.setval('_heroes."Heroes_id_seq"', 6, false);


--
-- TOC entry 4914 (class 2606 OID 19030)
-- Name: CreatureTypes CreatureTypes_pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."CreatureTypes"
    ADD CONSTRAINT "CreatureTypes_pkey" PRIMARY KEY (id);


--
-- TOC entry 4917 (class 2606 OID 19032)
-- Name: DamageTypes DamageTypes_pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."DamageTypes"
    ADD CONSTRAINT "DamageTypes_pkey" PRIMARY KEY (id);


--
-- TOC entry 4943 (class 2606 OID 19247)
-- Name: MaterialDamagePercent MaterialDamagePercent_pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercent"
    ADD CONSTRAINT "MaterialDamagePercent_pkey" PRIMARY KEY (id);


--
-- TOC entry 4940 (class 2606 OID 19120)
-- Name: SmithingMaterials SmithingMaterials_pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."SmithingMaterials"
    ADD CONSTRAINT "SmithingMaterials_pkey" PRIMARY KEY (id);


--
-- TOC entry 4920 (class 2606 OID 19034)
-- Name: WeaponTypes WeaponTypes_pkey; Type: CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."WeaponTypes"
    ADD CONSTRAINT "WeaponTypes_pkey" PRIMARY KEY (id);


--
-- TOC entry 4923 (class 2606 OID 19036)
-- Name: Weapons Weapons_pkey; Type: CONSTRAINT; Schema: _equipment; Owner: -
--

ALTER TABLE ONLY _equipment."Weapons"
    ADD CONSTRAINT "Weapons_pkey" PRIMARY KEY (id);


--
-- TOC entry 4927 (class 2606 OID 19038)
-- Name: Heroes Heroes_pkey; Type: CONSTRAINT; Schema: _heroes; Owner: -
--

ALTER TABLE ONLY _heroes."Heroes"
    ADD CONSTRAINT "Heroes_pkey" PRIMARY KEY (id);


--
-- TOC entry 4904 (class 2606 OID 18702)
-- Name: creature_types creature_types_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.creature_types
    ADD CONSTRAINT creature_types_pkey PRIMARY KEY (id);


--
-- TOC entry 4907 (class 2606 OID 18704)
-- Name: heroes heroes_pkey; Type: CONSTRAINT; Schema: _main; Owner: -
--

ALTER TABLE ONLY _main.heroes
    ADD CONSTRAINT heroes_pkey PRIMARY KEY (id);


--
-- TOC entry 4929 (class 2606 OID 19040)
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- TOC entry 4933 (class 2606 OID 19042)
-- Name: X_Hero_CreatureType X_Hero_CreatureType_pkey; Type: CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType_pkey" PRIMARY KEY ("HeroId", "CreatureTypeId");


--
-- TOC entry 4937 (class 2606 OID 19044)
-- Name: X_WeaponType_DamageType X_WeaponType_DamageType_pkey; Type: CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_WeaponType_DamageType"
    ADD CONSTRAINT "X_WeaponType_DamageType_pkey" PRIMARY KEY ("WeaponTypeId", "DamageTypeId");


--
-- TOC entry 4911 (class 2606 OID 18708)
-- Name: x_hero_creature_type x_hero_creature_type_pkey; Type: CONSTRAINT; Schema: xcross; Owner: -
--

ALTER TABLE ONLY xcross.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type_pkey PRIMARY KEY (hero_id, creature_type_id);


--
-- TOC entry 4912 (class 1259 OID 19045)
-- Name: CreatureTypes_name_idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "CreatureTypes_name_idx" ON __lists."CreatureTypes" USING btree (name);


--
-- TOC entry 4915 (class 1259 OID 19046)
-- Name: DamageTypes_name_idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "DamageTypes_name_idx" ON __lists."DamageTypes" USING btree (name);


--
-- TOC entry 4941 (class 1259 OID 19258)
-- Name: MaterialDamagePercent_damage_type_id_idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE INDEX "MaterialDamagePercent_damage_type_id_idx" ON __lists."MaterialDamagePercent" USING btree (damage_type_id);


--
-- TOC entry 4944 (class 1259 OID 19259)
-- Name: MaterialDamagePercent_smithing_materials_id_idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE INDEX "MaterialDamagePercent_smithing_materials_id_idx" ON __lists."MaterialDamagePercent" USING btree (smithing_materials_id);


--
-- TOC entry 4938 (class 1259 OID 19127)
-- Name: SmithingMaterials_name_idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "SmithingMaterials_name_idx" ON __lists."SmithingMaterials" USING btree (name);


--
-- TOC entry 4918 (class 1259 OID 19047)
-- Name: WeaponTypes_name_idx; Type: INDEX; Schema: __lists; Owner: -
--

CREATE UNIQUE INDEX "WeaponTypes_name_idx" ON __lists."WeaponTypes" USING btree (name);


--
-- TOC entry 4921 (class 1259 OID 19048)
-- Name: Weapons_name_idx; Type: INDEX; Schema: _equipment; Owner: -
--

CREATE UNIQUE INDEX "Weapons_name_idx" ON _equipment."Weapons" USING btree (name);


--
-- TOC entry 4924 (class 1259 OID 19049)
-- Name: Weapons_weapon_type_id_idx; Type: INDEX; Schema: _equipment; Owner: -
--

CREATE INDEX "Weapons_weapon_type_id_idx" ON _equipment."Weapons" USING btree (weapon_type_id);


--
-- TOC entry 4925 (class 1259 OID 19050)
-- Name: Heroes_name_idx; Type: INDEX; Schema: _heroes; Owner: -
--

CREATE UNIQUE INDEX "Heroes_name_idx" ON _heroes."Heroes" USING btree (name);


--
-- TOC entry 4902 (class 1259 OID 18709)
-- Name: creature_types_name_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE UNIQUE INDEX creature_types_name_idx ON _main.creature_types USING btree (name);


--
-- TOC entry 4905 (class 1259 OID 18710)
-- Name: heroes_name_idx; Type: INDEX; Schema: _main; Owner: -
--

CREATE UNIQUE INDEX heroes_name_idx ON _main.heroes USING btree (name);


--
-- TOC entry 4930 (class 1259 OID 19051)
-- Name: X_Hero_CreatureType_CreatureTypeId_idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_Hero_CreatureType_CreatureTypeId_idx" ON "x_Cross"."X_Hero_CreatureType" USING btree ("CreatureTypeId");


--
-- TOC entry 4931 (class 1259 OID 19052)
-- Name: X_Hero_CreatureType_HeroId_idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_Hero_CreatureType_HeroId_idx" ON "x_Cross"."X_Hero_CreatureType" USING btree ("HeroId");


--
-- TOC entry 4934 (class 1259 OID 19053)
-- Name: X_WeaponType_DamageType_DamageTypeId_idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_WeaponType_DamageType_DamageTypeId_idx" ON "x_Cross"."X_WeaponType_DamageType" USING btree ("DamageTypeId");


--
-- TOC entry 4935 (class 1259 OID 19054)
-- Name: X_WeaponType_DamageType_WeaponTypeId_idx; Type: INDEX; Schema: x_Cross; Owner: -
--

CREATE INDEX "X_WeaponType_DamageType_WeaponTypeId_idx" ON "x_Cross"."X_WeaponType_DamageType" USING btree ("WeaponTypeId");


--
-- TOC entry 4908 (class 1259 OID 18711)
-- Name: x_hero_creature_type_creature_type_id_idx; Type: INDEX; Schema: xcross; Owner: -
--

CREATE INDEX x_hero_creature_type_creature_type_id_idx ON xcross.x_hero_creature_type USING btree (creature_type_id);


--
-- TOC entry 4909 (class 1259 OID 18712)
-- Name: x_hero_creature_type_hero_id_idx; Type: INDEX; Schema: xcross; Owner: -
--

CREATE INDEX x_hero_creature_type_hero_id_idx ON xcross.x_hero_creature_type USING btree (hero_id);


--
-- TOC entry 5103 (class 2618 OID 18688)
-- Name: v_heroes_with_creature_types _RETURN; Type: RULE; Schema: _main; Owner: -
--

CREATE OR REPLACE VIEW _main.v_heroes_with_creature_types AS
 SELECT hero.name,
    hero.rarity,
    string_agg((ct.name)::text, ', '::text ORDER BY ct.name) AS creature_types
   FROM ((_main.heroes hero
     LEFT JOIN xcross.x_hero_creature_type hct ON ((hero.id = hct.hero_id)))
     LEFT JOIN _main.creature_types ct ON ((hct.creature_type_id = ct.id)))
  GROUP BY hero.id
  ORDER BY hero.rarity DESC, hero.name;


--
-- TOC entry 4954 (class 2620 OID 18714)
-- Name: creature_types set_timestamps_trigger; Type: TRIGGER; Schema: _main; Owner: -
--

CREATE TRIGGER set_timestamps_trigger BEFORE INSERT OR UPDATE ON _main.creature_types FOR EACH ROW EXECUTE FUNCTION public.set_timestamp();


--
-- TOC entry 4955 (class 2620 OID 18715)
-- Name: heroes set_timestamps_trigger; Type: TRIGGER; Schema: _main; Owner: -
--

CREATE TRIGGER set_timestamps_trigger BEFORE INSERT OR UPDATE ON _main.heroes FOR EACH ROW EXECUTE FUNCTION public.set_timestamp();


--
-- TOC entry 4952 (class 2606 OID 19248)
-- Name: MaterialDamagePercent MaterialDamagePercent_damage_type_id_damage_types_fkey; Type: FK CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercent"
    ADD CONSTRAINT "MaterialDamagePercent_damage_type_id_damage_types_fkey" FOREIGN KEY (damage_type_id) REFERENCES __lists."DamageTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4953 (class 2606 OID 19253)
-- Name: MaterialDamagePercent MaterialDamagePercent_smithing_materials_id_smithing_materials_; Type: FK CONSTRAINT; Schema: __lists; Owner: -
--

ALTER TABLE ONLY __lists."MaterialDamagePercent"
    ADD CONSTRAINT "MaterialDamagePercent_smithing_materials_id_smithing_materials_" FOREIGN KEY (smithing_materials_id) REFERENCES __lists."SmithingMaterials"(id) ON DELETE CASCADE;


--
-- TOC entry 4947 (class 2606 OID 19055)
-- Name: Weapons Weapons_weapon_type_id_weapon_types_fkey; Type: FK CONSTRAINT; Schema: _equipment; Owner: -
--

ALTER TABLE ONLY _equipment."Weapons"
    ADD CONSTRAINT "Weapons_weapon_type_id_weapon_types_fkey" FOREIGN KEY (weapon_type_id) REFERENCES __lists."WeaponTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4948 (class 2606 OID 19060)
-- Name: X_Hero_CreatureType X_Hero_CreatureType_creature_type_id_creature_types_fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType_creature_type_id_creature_types_fkey" FOREIGN KEY ("CreatureTypeId") REFERENCES __lists."CreatureTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4949 (class 2606 OID 19065)
-- Name: X_Hero_CreatureType X_Hero_CreatureType_hero_id_heroes_fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_Hero_CreatureType"
    ADD CONSTRAINT "X_Hero_CreatureType_hero_id_heroes_fkey" FOREIGN KEY ("HeroId") REFERENCES _heroes."Heroes"(id) ON DELETE CASCADE;


--
-- TOC entry 4950 (class 2606 OID 19070)
-- Name: X_WeaponType_DamageType X_WeaponType_DamageType_damage_type_id_damage_types_fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_WeaponType_DamageType"
    ADD CONSTRAINT "X_WeaponType_DamageType_damage_type_id_damage_types_fkey" FOREIGN KEY ("DamageTypeId") REFERENCES __lists."DamageTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4951 (class 2606 OID 19075)
-- Name: X_WeaponType_DamageType X_WeaponType_DamageType_weapon_type_id_weapon_types_fkey; Type: FK CONSTRAINT; Schema: x_Cross; Owner: -
--

ALTER TABLE ONLY "x_Cross"."X_WeaponType_DamageType"
    ADD CONSTRAINT "X_WeaponType_DamageType_weapon_type_id_weapon_types_fkey" FOREIGN KEY ("WeaponTypeId") REFERENCES __lists."WeaponTypes"(id) ON DELETE CASCADE;


--
-- TOC entry 4945 (class 2606 OID 18716)
-- Name: x_hero_creature_type x_hero_creature_type_creature_type_id_creature_types_fkey; Type: FK CONSTRAINT; Schema: xcross; Owner: -
--

ALTER TABLE ONLY xcross.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type_creature_type_id_creature_types_fkey FOREIGN KEY (creature_type_id) REFERENCES _main.creature_types(id) ON DELETE CASCADE;


--
-- TOC entry 4946 (class 2606 OID 18721)
-- Name: x_hero_creature_type x_hero_creature_type_hero_id_heroes_fkey; Type: FK CONSTRAINT; Schema: xcross; Owner: -
--

ALTER TABLE ONLY xcross.x_hero_creature_type
    ADD CONSTRAINT x_hero_creature_type_hero_id_heroes_fkey FOREIGN KEY (hero_id) REFERENCES _main.heroes(id) ON DELETE CASCADE;


-- Completed on 2025-12-10 23:09:45

--
-- PostgreSQL database dump complete
--

\unrestrict W1gxav0PnWFKSpT2uG3sxDhiVUmrUrA4QZqiRBugwtC1X7iBCqWn9BdZt7JiIQz

